/*! For license information please see 5f05bac55c49716a.js.LICENSE.txt */
"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
  [221],
  {
    44525: function (e, t, n) {
      function r(e, t) {
        var n = (function (e, t) {
            return (
              (e = e.replace(/\{(.*?)\??\}/g, function (e, n) {
                if (t.hasOwnProperty(n)) {
                  var r = t[n];
                  return delete t[n], encodeURIComponent(r);
                }
                return e;
              })),
              (e = e.replace(/\/\{.*?\?\}/g, "")),
              e
            );
          })(e, t),
          r = (function (e) {
            var t = [];
            for (var n in e)
              e.hasOwnProperty(n) &&
                t.push("".concat(n, "=").concat(encodeURIComponent(e[n])));
            if (t.length < 1) return "";
            return "?".concat(t.join("&"));
          })(t);
        return (function (e) {
          return "/".concat(e.replace(/(^\/?|\/?$)/g, ""));
        })(n + r);
      }
      function o() {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
          route: function (t) {
            var n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              o = e[t] || window.routes[t];
            if (o) return r(o, n);
          },
        };
      }
      n.d(t, {
        l: function () {
          return o;
        },
      });
    },
    74894: function (e, t, n) {
      function r() {
        var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return {
          trans: function (t) {
            var n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              r = e[t] || window.trans[t] || t;
            return (
              Object.keys(n).forEach(function (e) {
                r = r.replace(":".concat(e), n[e]);
              }),
              r
            );
          },
          transChoice: function (t) {
            var n =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 1,
              r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : {},
              o = (e[t] || window.trans[t] || null).split("|");
            return (
              (o = (n > 1 && o[1]) || o[0]),
              (r.count = n),
              Object.keys(r).forEach(function (e) {
                o = o.replace(":".concat(e), r[e]);
              }),
              o
            );
          },
        };
      }
      n.d(t, {
        m: function () {
          return r;
        },
      });
    },
    84221: function (e, t, n) {
      n.r(t),
        n.d(t, {
          default: function () {
            return A;
          },
        });
      var r = n(29726),
        o = n(14783),
        a = n.n(o),
        i = n(74894),
        c = n(44525),
        l = n(72505);
      function u() {
        var e,
          t,
          n = "function" == typeof Symbol ? Symbol : {},
          r = n.iterator || "@@iterator",
          o = n.toStringTag || "@@toStringTag";
        function a(n, r, o, a) {
          var l = r && r.prototype instanceof c ? r : c,
            u = Object.create(l.prototype);
          return (
            s(
              u,
              "_invoke",
              (function (n, r, o) {
                var a,
                  c,
                  l,
                  u = 0,
                  s = o || [],
                  d = !1,
                  f = {
                    p: 0,
                    n: 0,
                    v: e,
                    a: v,
                    f: v.bind(e, 4),
                    d: function (t, n) {
                      return (a = t), (c = 0), (l = e), (f.n = n), i;
                    },
                  };
                function v(n, r) {
                  for (
                    c = n, l = r, t = 0;
                    !d && u && !o && t < s.length;
                    t++
                  ) {
                    var o,
                      a = s[t],
                      v = f.p,
                      p = a[2];
                    n > 3
                      ? (o = p === r) &&
                        ((l = a[(c = a[4]) ? 5 : ((c = 3), 3)]),
                        (a[4] = a[5] = e))
                      : a[0] <= v &&
                        ((o = n < 2 && v < a[1])
                          ? ((c = 0), (f.v = r), (f.n = a[1]))
                          : v < p &&
                            (o = n < 3 || a[0] > r || r > p) &&
                            ((a[4] = n), (a[5] = r), (f.n = p), (c = 0)));
                  }
                  if (o || n > 1) return i;
                  throw ((d = !0), r);
                }
                return function (o, s, p) {
                  if (u > 1) throw TypeError("Generator is already running");
                  for (
                    d && 1 === s && v(s, p), c = s, l = p;
                    (t = c < 2 ? e : l) || !d;

                  ) {
                    a ||
                      (c
                        ? c < 3
                          ? (c > 1 && (f.n = -1), v(c, l))
                          : (f.n = l)
                        : (f.v = l));
                    try {
                      if (((u = 2), a)) {
                        if ((c || (o = "next"), (t = a[o]))) {
                          if (!(t = t.call(a, l)))
                            throw TypeError("iterator result is not an object");
                          if (!t.done) return t;
                          (l = t.value), c < 2 && (c = 0);
                        } else
                          1 === c && (t = a.return) && t.call(a),
                            c < 2 &&
                              ((l = TypeError(
                                "The iterator does not provide a '" +
                                  o +
                                  "' method"
                              )),
                              (c = 1));
                        a = e;
                      } else if ((t = (d = f.n < 0) ? l : n.call(r, f)) !== i)
                        break;
                    } catch (t) {
                      (a = e), (c = 1), (l = t);
                    } finally {
                      u = 1;
                    }
                  }
                  return { value: t, done: d };
                };
              })(n, o, a),
              !0
            ),
            u
          );
        }
        var i = {};
        function c() {}
        function l() {}
        function d() {}
        t = Object.getPrototypeOf;
        var f = [][r]
            ? t(t([][r]()))
            : (s((t = {}), r, function () {
                return this;
              }),
              t),
          v = (d.prototype = c.prototype = Object.create(f));
        function p(e) {
          return (
            Object.setPrototypeOf
              ? Object.setPrototypeOf(e, d)
              : ((e.__proto__ = d), s(e, o, "GeneratorFunction")),
            (e.prototype = Object.create(v)),
            e
          );
        }
        return (
          (l.prototype = d),
          s(v, "constructor", d),
          s(d, "constructor", l),
          (l.displayName = "GeneratorFunction"),
          s(d, o, "GeneratorFunction"),
          s(v),
          s(v, o, "Generator"),
          s(v, r, function () {
            return this;
          }),
          s(v, "toString", function () {
            return "[object Generator]";
          }),
          (u = function () {
            return { w: a, m: p };
          })()
        );
      }
      function s(e, t, n, r) {
        var o = Object.defineProperty;
        try {
          o({}, "", {});
        } catch (e) {
          o = 0;
        }
        (s = function (e, t, n, r) {
          function a(t, n) {
            s(e, t, function (e) {
              return this._invoke(t, n, e);
            });
          }
          t
            ? o
              ? o(e, t, {
                  value: n,
                  enumerable: !r,
                  configurable: !r,
                  writable: !r,
                })
              : (e[t] = n)
            : (a("next", 0), a("throw", 1), a("return", 2));
        }),
          s(e, t, n, r);
      }
      function d(e, t, n, r, o, a, i) {
        try {
          var c = e[a](i),
            l = c.value;
        } catch (e) {
          return void n(e);
        }
        c.done ? t(l) : Promise.resolve(l).then(r, o);
      }
      var f = { class: "Block__header" },
        v = { class: "Block__content" },
        p = { class: "Chart__header" },
        m = { class: "Chart__header__title" },
        h = { class: "Chart__header__options" },
        y = { value: "last_30" },
        _ = { value: "this_month" },
        g = { value: "last_month" },
        b = { value: "this_year" },
        E = { value: "last_year" },
        w = { class: "Chart__container" },
        N = { style: { height: "300px" } },
        V = { class: "Grid Grid--equal-3 Clear" },
        C = { class: "Col" },
        S = { class: "Counter Counter--numbers" },
        D = { class: "Heading--h1 Counter__amount" },
        k = { class: "Heading--h5 Counter__label" },
        O = { class: "Col" },
        j = { class: "Counter Counter--numbers" },
        x = { class: "Heading--h1 Counter__amount" },
        T = { class: "Heading--h5 Counter__label" },
        G = { class: "Col" },
        P = { class: "Counter Counter--numbers" },
        F = { class: "Heading--h1 Counter__amount" },
        H = { class: "Heading--h5 Counter__label" },
        B = {
          __name: "CustomerFileServices",
          props: ["translations", "routes"],
          setup: function (e) {
            var t = e,
              n = (0, c.l)(t.routes).route,
              o = (0, i.m)(t.translations).trans,
              s = (0, r.ref)(null),
              B = (0, r.ref)(!0),
              A = (0, r.ref)(null),
              I = (0, r.ref)([]),
              R = (0, r.ref)(null),
              U = (0, r.ref)("last_30");
            function z() {
              return M.apply(this, arguments);
            }
            function M() {
              var e;
              return (
                (e = u().m(function e() {
                  var t, o;
                  return u().w(function (e) {
                    for (;;)
                      switch (e.n) {
                        case 0:
                          return (
                            (B.value = !0),
                            (e.n = 1),
                            l.get(n("customer.dashboard.file-services"), {
                              params: { period: U.value },
                            })
                          );
                        case 1:
                          return (
                            (t = e.v),
                            (o = t.data),
                            (A.value = o.counters),
                            (I.value = o.points),
                            (B.value = !1),
                            (e.n = 2),
                            (0, r.nextTick)()
                          );
                        case 2:
                          $();
                        case 3:
                          return e.a(2);
                      }
                  }, e);
                })),
                (M = function () {
                  var t = this,
                    n = arguments;
                  return new Promise(function (r, o) {
                    var a = e.apply(t, n);
                    function i(e) {
                      d(a, r, o, i, c, "next", e);
                    }
                    function c(e) {
                      d(a, r, o, i, c, "throw", e);
                    }
                    i(void 0);
                  });
                }),
                M.apply(this, arguments)
              );
            }
            function q(e) {
              return new Intl.NumberFormat(
                document.documentElement.lang || "nl",
                { style: "decimal", maximumFractionDigits: 0 }
              ).format(e);
            }
            function $() {
              R.value
                ? R.value.series[0].update({
                    data: I.value.map(function (e) {
                      return [new Date(e[0]).getTime(), e[1]];
                    }),
                  })
                : (R.value = a().chart(s.value, {
                    chart: {
                      zoomType: "x",
                      height: 300,
                      backgroundColor: "transparent",
                    },
                    title: null,
                    credits: { enabled: !1 },
                    xAxis: { type: "datetime" },
                    yAxis: { title: null },
                    legend: {
                      enabled: !0,
                      align: "left",
                      verticalAlign: "top",
                    },
                    series: [
                      {
                        type: "line",
                        name: o(
                          "cms::dashboard.graphs.file_services.item_name"
                        ),
                        data: I.value.map(function (e) {
                          return [new Date(e[0]).getTime(), e[1]];
                        }),
                        marker: { enabled: !1 },
                      },
                    ],
                  }));
            }
            return (
              (0, r.onMounted)(function () {
                z();
              }),
              (0, r.watch)(U, z),
              function (e, t) {
                return (
                  (0, r.openBlock)(),
                  (0, r.createElementBlock)(
                    "div",
                    {
                      class: "Block",
                      style: (0, r.normalizeStyle)(
                        (0, r.unref)(B) ? { opacity: 0.5 } : {}
                      ),
                    },
                    [
                      (0, r.createElementVNode)(
                        "div",
                        f,
                        (0, r.toDisplayString)(
                          (0, r.unref)(o)(
                            "customer::dashboard.file_services.title"
                          )
                        ),
                        1
                      ),
                      (0, r.createElementVNode)("div", v, [
                        (0, r.createElementVNode)("div", p, [
                          (0, r.createElementVNode)(
                            "div",
                            m,
                            (0, r.toDisplayString)(
                              (0, r.unref)(o)(
                                "customer::dashboard.file_services.description"
                              )
                            ),
                            1
                          ),
                          (0, r.createElementVNode)("div", h, [
                            (0, r.withDirectives)(
                              (0, r.createElementVNode)(
                                "select",
                                {
                                  name: "period",
                                  class: "select",
                                  "onUpdate:modelValue":
                                    t[0] ||
                                    (t[0] = function (e) {
                                      return (0, r.isRef)(U)
                                        ? (U.value = e)
                                        : (U = e);
                                    }),
                                },
                                [
                                  (0, r.createElementVNode)(
                                    "option",
                                    y,
                                    (0, r.toDisplayString)(
                                      (0, r.unref)(o)(
                                        "dashboard::cms.analytics.periods.last_30"
                                      )
                                    ),
                                    1
                                  ),
                                  (0, r.createElementVNode)(
                                    "option",
                                    _,
                                    (0, r.toDisplayString)(
                                      (0, r.unref)(o)(
                                        "dashboard::cms.analytics.periods.this_month"
                                      )
                                    ),
                                    1
                                  ),
                                  (0, r.createElementVNode)(
                                    "option",
                                    g,
                                    (0, r.toDisplayString)(
                                      (0, r.unref)(o)(
                                        "dashboard::cms.analytics.periods.last_month"
                                      )
                                    ),
                                    1
                                  ),
                                  (0, r.createElementVNode)(
                                    "option",
                                    b,
                                    (0, r.toDisplayString)(
                                      (0, r.unref)(o)(
                                        "dashboard::cms.analytics.periods.this_year"
                                      )
                                    ),
                                    1
                                  ),
                                  (0, r.createElementVNode)(
                                    "option",
                                    E,
                                    (0, r.toDisplayString)(
                                      (0, r.unref)(o)(
                                        "dashboard::cms.analytics.periods.last_year"
                                      )
                                    ),
                                    1
                                  ),
                                ],
                                512
                              ),
                              [[r.vModelSelect, (0, r.unref)(U)]]
                            ),
                          ]),
                        ]),
                        (0, r.createElementVNode)("div", w, [
                          (0, r.withDirectives)(
                            (0, r.createElementVNode)(
                              "div",
                              { ref_key: "chart", ref: s },
                              null,
                              512
                            ),
                            [[r.vShow, !(0, r.unref)(B)]]
                          ),
                          (0, r.withDirectives)(
                            (0, r.createElementVNode)("div", N, null, 512),
                            [[r.vShow, (0, r.unref)(B)]]
                          ),
                        ]),
                        (0, r.createElementVNode)("div", V, [
                          (0, r.createElementVNode)("div", C, [
                            (0, r.createElementVNode)("div", S, [
                              (0, r.createElementVNode)(
                                "div",
                                D,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(A)
                                    ? q((0, r.unref)(A).open)
                                    : "--"
                                ),
                                1
                              ),
                              (0, r.createElementVNode)(
                                "div",
                                k,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(o)(
                                    "customer::dashboard.file_services.open"
                                  )
                                ),
                                1
                              ),
                            ]),
                          ]),
                          (0, r.createElementVNode)("div", O, [
                            (0, r.createElementVNode)("div", j, [
                              (0, r.createElementVNode)(
                                "div",
                                x,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(A)
                                    ? q((0, r.unref)(A).waiting)
                                    : "--"
                                ),
                                1
                              ),
                              (0, r.createElementVNode)(
                                "div",
                                T,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(o)(
                                    "customer::dashboard.file_services.pending"
                                  )
                                ),
                                1
                              ),
                            ]),
                          ]),
                          (0, r.createElementVNode)("div", G, [
                            (0, r.createElementVNode)("div", P, [
                              (0, r.createElementVNode)(
                                "div",
                                F,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(A)
                                    ? q((0, r.unref)(A).completed)
                                    : "--"
                                ),
                                1
                              ),
                              (0, r.createElementVNode)(
                                "div",
                                H,
                                (0, r.toDisplayString)(
                                  (0, r.unref)(o)(
                                    "customer::dashboard.file_services.completed"
                                  )
                                ),
                                1
                              ),
                            ]),
                          ]),
                        ]),
                      ]),
                    ],
                    4
                  )
                );
              }
            );
          },
        };
      var A = B;
    },
  },
]);
