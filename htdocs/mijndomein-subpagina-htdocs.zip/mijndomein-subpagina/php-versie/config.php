<?php
// MIJNDOMEIN — Subpagina PHP proxy config
// Zet hier waar je Node app draait. Voorbeelden:

// 1. Node op zelfde server (VPS / localhost):
$BACKEND = 'http://127.0.0.1:3000';

// 2. Node extern (aanrader voor standaard Mijndomein Webhosting zonder Node):
// $BACKEND = 'https://jouw-node-server.nl';
// $BACKEND = 'https://3000-xxxxx.e2b.app'; // preview tijdelijk

// 3. Als je Node in submap draait op andere poort:
// $BACKEND = 'http://127.0.0.1:3001';

// Timeout in seconden
$TIMEOUT = 15;
