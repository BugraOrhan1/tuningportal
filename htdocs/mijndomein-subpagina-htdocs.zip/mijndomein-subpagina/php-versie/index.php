<?php
// MIJNDOMEIN — Subpagina PHP Proxy voor Mijndomein Webhosting (zonder Node)
// Plaats dit bestand als /domains/mijndomein.nl/public_html/tuning/index.php
// Werkt naast je bestaande site — alle requests worden doorgestuurd naar Node backend.

require __DIR__ . '/config.php';
if (!isset($BACKEND)) $BACKEND = 'http://127.0.0.1:3000';
if (!isset($TIMEOUT)) $TIMEOUT = 15;

// Bepaal pad na /tuning/
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/tuning'), '/');
if ($scriptDir === '' || $scriptDir === '.') $scriptDir = '';
// Verwijder submap prefix voor backend
$path = $requestUri;
if ($scriptDir !== '' && strpos($path, $scriptDir) === 0) {
    $path = substr($path, strlen($scriptDir));
}
if ($path === '' || $path[0] !== '/') $path = '/' . $path;
// Behoud query string
$qs = $_SERVER['QUERY_STRING'] ?? '';
if ($qs !== '' && strpos($path, '?') === false) $path .= '?' . $qs;

$target = rtrim($BACKEND, '/') . $path;
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Headers doorsturen (cookies belangrijk voor login!)
$headers = [];
foreach (getallheaders() as $k => $v) {
    $lk = strtolower($k);
    if (in_array($lk, ['host','content-length','connection'])) continue;
    $headers[] = "$k: $v";
}
// Zorg dat backend weet dat origineel https was (voor Secure cookie)
if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https' || ($_SERVER['SERVER_PORT'] ?? '') == 443) {
    $headers[] = 'X-Forwarded-Proto: https';
} else {
    // Mijndomein draait vaak https — forceer https voor login cookies als domein https is
    if (strpos($BACKEND, 'https://') === 0) $headers[] = 'X-Forwarded-Proto: https';
}

$ch = curl_init($target);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
curl_setopt($ch, CURLOPT_TIMEOUT, $TIMEOUT);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

// Body doorsturen (POST / uploads)
$body = file_get_contents('php://input');
if ($body !== '' && $body !== false) {
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
}

// Cookies doorsturen
if (!empty($_SERVER['HTTP_COOKIE'])) {
    curl_setopt($ch, CURLOPT_COOKIE, $_SERVER['HTTP_COOKIE']);
}

$response = curl_exec($ch);
if ($response === false) {
    http_response_code(502);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h1>MIJNDOMEIN — Backend niet bereikbaar</h1>';
    echo '<p>Node backend <code>' . htmlspecialchars($BACKEND) . '</code> reageert niet.<br>';
    echo 'Controleer <code>config.php</code> → $BACKEND en of <code>node server.js</code> draait (poort 3000).<br>';
    echo 'Error: ' . htmlspecialchars(curl_error($ch)) . '</p>';
    echo '<p><a href="/">Terug naar mijndomein.nl</a></p>';
    exit;
}
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$headerStr = substr($response, 0, $headerSize);
$bodyStr = substr($response, $headerSize);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Headers terugsturen (Set-Cookie is cruciaal voor login)
$headersOut = explode("\r\n", $headerStr);
foreach ($headersOut as $h) {
    if (trim($h) === '') continue;
    if (stripos($h, 'HTTP/') === 0) continue;
    // Voorkom dubbele content-length
    if (stripos($h, 'Content-Length:') === 0) continue;
    // Transfer-Encoding ook overslaan
    if (stripos($h, 'Transfer-Encoding:') === 0) continue;
    header($h, false);
}
http_response_code($status);
echo $bodyStr;
