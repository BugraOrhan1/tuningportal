# MIJNDOMEIN.NL — Subpagina htdocs

**Domein:** mijndomein.nl — **Merk:** MIJNDOMEIN Performance Files — `info@mijndomein.nl`  
Deze map is speciaal voor **toevoegen als subpagina** op je bestaande Mijndomein-website (Mijndomein Webhosting / Website Builder).

Je hebt **2 opties** — kies wat je hosting ondersteunt:

---

## OPTIE A — Simpelst: iFrame embed (werkt op ALLE Mijndomein hosting, geen Node nodig)

1. In Mijndomein Website Builder: maak nieuwe **Subpagina** (bijv. `Tuning` of `Chiptuning`)
2. Sleep element **HTML** / **Code** op de pagina
3. Plak dit (vervang `https://jouw-node-server.nl` door waar je Node draait):

```html
<iframe src="https://jouw-node-server.nl" 
  style="width:100%;height:900px;border:0;min-height:800px" 
  loading="lazy" allow="fullscreen"></iframe>
```

- Draait je Node al op `mijndomein.nl` via proxy? Gebruik dan `src="/mijndomein/"` of `src="/tuning/"`
- Voor preview nu: `https://3000-xxxx.e2b.app` (tijdelijk)
- Klaar — geen FTP nodig

> Bestand `iframe-code.html` bevat kant-en-klare code om te kopiëren.

---

## OPTIE B — PHP proxy (standaard Mijndomein Webhosting zonder Node)

Voor **gewone Mijndomein Webhosting (Apache + PHP)** waar geen Node draait. De PHP file stuurt alles door naar je Node backend die ergens anders draait (VPS, of tijdelijk de preview).

**FTP via FileZilla / Mijndomein File Manager:**
```
Host: ftp.mijndomein.nl  (of sftp.mijndomein.nl)
Map op server: /domains/mijndomein.nl/public_html/
```

1. Maak submap aan: `/domains/mijndomein.nl/public_html/tuning/`  (naam vrij: tuning / chiptuning / portal)
2. Upload **inhoud van `php-versie/`** naar die submap:
   - `index.php`
   - `.htaccess`
   - `config.php`  ← hier stel je backend in
3. Open `config.php` en zet je Node URL:
```php
$BACKEND = 'http://127.0.0.1:3000'; // als Node op zelfde server draait
// of extern:
$BACKEND = 'https://jouw-node-server.nl';
```
4. Ga naar `https://mijndomein.nl/tuning/` — je ziet MIJNDOMEIN portal als subpagina naast je bestaande site

**Voordelen:** werkt naast bestaande site, geen Node op webhosting nodig, behoudt inloggen + alle auto's via `/api/v1/type-loader`.

---

## OPTIE C — Volledige Node in submap (Mijndomein VPS / Node hosting)

Heb je **VPS of hosting met Node.js** (Plesk > Node.js):

1. Upload **inhoud van `node-versie/`** naar `/domains/mijndomein.nl/public_html/tuning/` of `/htdocs/tuning/`
   - bevat `server.js`, `package.json`, `views/`, `public/`, `data/`, `.htaccess`
2. SSH / Terminal op server:
```bash
cd /domains/mijndomein.nl/public_html/tuning
npm install
pm2 start server.js --name mijndomein-tuning
pm2 save
```
3. `.htaccess` is al geconfigureerd:
```apache
RewriteEngine On
RewriteBase /tuning/
RewriteRule ^(.*)$ http://127.0.0.1:3000/$1 [P,L]
```
- Als je Node poort anders is, pas `3000` aan in `.htaccess` en `config`
- Zorg dat `proxy` en `proxy_http` aan staan (Mijndomein support kan helpen)

Dan draait `https://mijndomein.nl/tuning/` volledig als Node app in submap, met inloggen `demo@mijndomein.nl / demo123`.

---

## Demo inloggen (alle opties)
- `demo@mijndomein.nl` / `demo123`  (nieuw, MIJNDOMEIN)
- `demo@revboost.nl` / `demo123`  (oude, blijft werken)
- Alle auto's laden via `/api/v1/type-loader` — exact zoals `dashboard.fast-chiptuningfiles.com`

## Hulp
- Lokaal testen (XAMPP): `C:\xampp\htdocs\tuning\` → `npm install && npm start` → `http://localhost/tuning`
- Vragen? Mail `info@mijndomein.nl`
