tuningportal.dashfix.nl - ALLE PAGINA'S (zonder Node)

Deze versie bevat:
- index.html (homepage)
- login.html + /login/
- register.html + /register/
- tuning-specs.html + /tuning-specs/
- legal/*.html
- account/* -> redirect naar login (static heeft geen backend - voor echt file-panel gebruik PROVIDER zip met Node)

Upload alles naar public_html en ALLE links werken (geen 404 meer).
