// DASHFIX API fallback - werkt zonder Node
async function loadMakesFallback() {
  try { let r=await fetch('/api/v1/type-loader'); if(r.ok) return await r.json(); } catch(e){}
  try { let r=await fetch('/data/vehicles.json'); let v=await r.json(); return {choices:{makes:v.makes}}; } catch(e){ return {choices:{makes:[]}}; }
}
