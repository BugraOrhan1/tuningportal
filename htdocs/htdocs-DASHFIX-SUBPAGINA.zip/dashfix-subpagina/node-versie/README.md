# tuningportal.dashfix.nl — DASHFIX TuningPortal
Domein: tuningportal.dashfix.nl — info@dashfix.nl

Demo: demo@dashfix.nl / demo123

Upload naar /domains/tuningportal.dashfix.nl/public_html/ of /domains/dashfix.nl/public_html/tuningportal/
Run: npm install && pm2 start server.js
