<?php
require __DIR__ . '/config.php';
$target = rtrim($BACKEND, '/') . $_SERVER['REQUEST_URI'];
echo file_get_contents($target);
