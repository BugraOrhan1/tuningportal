tuningportal.dashfix.nl - KLAAR VOOR UPLOAD ZONDER SSH

DOMEIN: tuningportal.dashfix.nl
MERK: DASHFIX - info@dashfix.nl
DEMO: demo@dashfix.nl / demo123

1. UPLOADEN ZONDER SSH (alleen File Manager):
   - DirectAdmin -> File Manager -> /domains/tuningportal.dashfix.nl/public_html/
   - Upload dit zip -> Extract
   - Klaar! Ga naar https://tuningportal.dashfix.nl -> je ziet DASHFIX homepage

   Geen `npm install`, geen `pm2`, geen SSH nodig.

2. CERTIFICATEN (https) ZONDER SSH:
   - DirectAdmin -> SSL Certificates -> Free & automatic certificate from Let's Encrypt
   - Vink: tuningportal.dashfix.nl + www.tuningportal.dashfix.nl
   - Klik Save -> binnen 1 minuut groen slotje, geen certificaat zelf maken
   - Geen certificaat? Vraag hoster: "Let's Encrypt aanzetten voor tuningportal.dashfix.nl"

3. SUBDOMEIN AANMAKEN (als nog niet bestaat):
   - DirectAdmin -> Subdomain Management -> Create: tuningportal

4. VOLLEDIGE VERSIE MET INLOGGEN (optioneel, WEL Node nodig):
   Gebruik htdocs-DASHFIX-PROVIDER.zip (+ npm install via Node.js App in DirectAdmin ipv SSH)
   of htdocs-DASHFIX-SUBPAGINA.zip voor subpagina.

Deze GEEN-SSH versie toont homepage + login statisch.
Alle auto's laden via https://tuningportal.dashfix.nl/api/v1/type-loader (werkt zodra Node ergens draait,
anders fallback naar dashboard.fast-chiptuningfiles.com).
