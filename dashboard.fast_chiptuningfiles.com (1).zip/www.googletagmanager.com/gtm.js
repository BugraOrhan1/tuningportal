// Copyright 2012 Google Inc. All rights reserved.

(function () {
  var data = {
    resource: {
      version: "2",

      macros: [
        { function: "__e" },
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "HOST",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "PATH",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        { function: "__f", vtp_component: "URL" },
        { function: "__e" },
      ],
      tags: [
        {
          function: "__googtag",
          metadata: ["map"],
          once_per_event: true,
          vtp_tagId: "G-TRTLPMBVZX",
          tag_id: 4,
        },
        {
          function: "__googtag",
          metadata: ["map"],
          once_per_event: true,
          vtp_tagId: "AW-16452509899",
          tag_id: 5,
        },
      ],
      predicates: [
        { function: "_eq", arg0: ["macro", 0], arg1: "gtm.js" },
        { function: "_eq", arg0: ["macro", 0], arg1: "gtm.init" },
      ],
      rules: [
        [
          ["if", 0],
          ["add", 0],
        ],
        [
          ["if", 1],
          ["add", 1],
        ],
      ],
    },
    runtime: [
      [
        50,
        "__e",
        [46, "a"],
        [
          36,
          [
            13,
            [41, "$0"],
            [3, "$0", ["require", "internal.getEventData"]],
            ["$0", "event"],
          ],
        ],
      ],
      [
        50,
        "__f",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getReferrerUrl"]],
        [52, "d", ["require", "makeString"]],
        [52, "e", ["require", "parseUrl"]],
        [52, "f", [15, "__module_legacyUrls"]],
        [52, "g", [30, ["b", "gtm.referrer", 1], ["c"]]],
        [22, [28, [15, "g"]], [46, [36, ["d", [15, "g"]]]]],
        [
          38,
          [17, [15, "a"], "component"],
          [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
          [
            46,
            [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "C",
                    [7, [15, "g"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "E",
                    [7, [15, "g"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [
              5,
              [
                46,
                [
                  22,
                  [17, [15, "a"], "queryKey"],
                  [
                    46,
                    [
                      53,
                      [
                        36,
                        [
                          2,
                          [15, "f"],
                          "H",
                          [7, [15, "g"], [17, [15, "a"], "queryKey"]],
                        ],
                      ],
                    ],
                  ],
                ],
                [52, "h", ["e", [15, "g"]]],
                [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__googtag",
        [46, "a"],
        [
          50,
          "m",
          [46, "v", "w"],
          [
            66,
            "x",
            [2, [15, "b"], "keys", [7, [15, "w"]]],
            [46, [53, [43, [15, "v"], [15, "x"], [16, [15, "w"], [15, "x"]]]]],
          ],
        ],
        [
          50,
          "n",
          [46],
          [36, [7, [17, [15, "f"], "IE"], [17, [15, "f"], "IX"]]],
        ],
        [
          50,
          "o",
          [46, "v"],
          [52, "w", ["n"]],
          [
            65,
            "x",
            [15, "w"],
            [
              46,
              [
                53,
                [52, "y", [16, [15, "v"], [15, "x"]]],
                [22, [15, "y"], [46, [36, [15, "y"]]]],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "Object"]],
        [52, "c", ["require", "createArgumentsQueue"]],
        [52, "d", [15, "__module_gtag"]],
        [52, "e", ["require", "internal.gtagConfig"]],
        [52, "f", [15, "__module_gtagSchema"]],
        [52, "g", ["require", "getType"]],
        [52, "h", ["require", "internal.loadGoogleTag"]],
        [52, "i", ["require", "logToConsole"]],
        [52, "j", ["require", "makeNumber"]],
        [52, "k", ["require", "makeString"]],
        [52, "l", ["require", "makeTableMap"]],
        [52, "p", [30, [17, [15, "a"], "tagId"], ""]],
        [
          22,
          [
            30,
            [21, ["g", [15, "p"]], "string"],
            [24, [2, [15, "p"], "indexOf", [7, "-"]], 0],
          ],
          [
            46,
            [
              53,
              [
                "i",
                [
                  0,
                  "Invalid Measurement ID for the GA4 Configuration tag: ",
                  [15, "p"],
                ],
              ],
              [2, [15, "a"], "gtmOnFailure", [7]],
              [36],
            ],
          ],
        ],
        [52, "q", [30, [17, [15, "a"], "configSettingsVariable"], [8]]],
        [
          52,
          "r",
          [
            30,
            [
              "l",
              [30, [17, [15, "a"], "configSettingsTable"], [7]],
              "parameter",
              "parameterValue",
            ],
            [8],
          ],
        ],
        ["m", [15, "q"], [15, "r"]],
        [52, "s", [30, [17, [15, "a"], "eventSettingsVariable"], [8]]],
        [
          52,
          "t",
          [
            30,
            [
              "l",
              [30, [17, [15, "a"], "eventSettingsTable"], [7]],
              "parameter",
              "parameterValue",
            ],
            [8],
          ],
        ],
        ["m", [15, "s"], [15, "t"]],
        [52, "u", [15, "q"]],
        ["m", [15, "u"], [15, "s"]],
        [
          22,
          [
            30,
            [2, [15, "u"], "hasOwnProperty", [7, [17, [15, "f"], "JT"]]],
            [17, [15, "a"], "userProperties"],
          ],
          [
            46,
            [
              53,
              [52, "v", [30, [16, [15, "u"], [17, [15, "f"], "JT"]], [8]]],
              [
                "m",
                [15, "v"],
                [
                  30,
                  [
                    "l",
                    [30, [17, [15, "a"], "userProperties"], [7]],
                    "name",
                    "value",
                  ],
                  [8],
                ],
              ],
              [43, [15, "u"], [17, [15, "f"], "JT"], [15, "v"]],
            ],
          ],
        ],
        [
          2,
          [15, "d"],
          "E",
          [
            7,
            [15, "u"],
            [17, [15, "d"], "B"],
            [
              51,
              "",
              [7, "v"],
              [
                36,
                [
                  39,
                  [20, "false", [2, ["k", [15, "v"]], "toLowerCase", [7]]],
                  false,
                  [28, [28, [15, "v"]]],
                ],
              ],
            ],
          ],
        ],
        [
          2,
          [15, "d"],
          "E",
          [
            7,
            [15, "u"],
            [17, [15, "d"], "D"],
            [51, "", [7, "v"], [36, ["j", [15, "v"]]]],
          ],
        ],
        ["h", [15, "p"], [8, "firstPartyUrl", ["o", [15, "u"]]]],
        ["e", [15, "p"], [15, "u"], [8, "noTargetGroup", true]],
        [2, [15, "a"], "gtmOnSuccess", [7]],
      ],
      [
        50,
        "__u",
        [46, "a"],
        [
          50,
          "k",
          [46, "l", "m"],
          [52, "n", [17, [15, "m"], "multiQueryKeys"]],
          [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
          [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
          [
            22,
            [20, [15, "o"], ""],
            [
              46,
              [
                53,
                [
                  52,
                  "r",
                  [
                    2,
                    [17, ["i", [15, "l"]], "search"],
                    "replace",
                    [7, "?", ""],
                  ],
                ],
                [36, [39, [1, [28, [15, "r"]], [15, "p"]], [44], [15, "r"]]],
              ],
            ],
          ],
          [41, "q"],
          [
            22,
            [15, "n"],
            [
              46,
              [
                53,
                [
                  22,
                  [20, ["e", [15, "o"]], "array"],
                  [46, [53, [3, "q", [15, "o"]]]],
                  [
                    46,
                    [
                      53,
                      [52, "r", ["c", "\\s+", "g"]],
                      [
                        3,
                        "q",
                        [
                          2,
                          [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]],
                          "split",
                          [7, ","],
                        ],
                      ],
                    ],
                  ],
                ],
              ],
            ],
            [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]],
          ],
          [
            65,
            "r",
            [15, "q"],
            [
              46,
              [
                53,
                [52, "s", [2, [15, "h"], "H", [7, [15, "l"], [15, "r"]]]],
                [
                  22,
                  [29, [15, "s"], [44]],
                  [
                    46,
                    [
                      53,
                      [
                        22,
                        [1, [15, "p"], [20, [15, "s"], ""]],
                        [46, [53, [6]]],
                      ],
                      [36, [15, "s"]],
                    ],
                  ],
                ],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getUrl"]],
        [52, "e", ["require", "getType"]],
        [52, "f", ["require", "makeString"]],
        [52, "g", ["require", "parseUrl"]],
        [52, "h", [15, "__module_legacyUrls"]],
        [52, "i", ["require", "internal.legacyParseUrl"]],
        [41, "j"],
        [
          22,
          [17, [15, "a"], "customUrlSource"],
          [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
          [46, [53, [3, "j", ["b", "gtm.url", 1]]]],
        ],
        [3, "j", [30, [15, "j"], ["d"]]],
        [
          38,
          [17, [15, "a"], "component"],
          [
            46,
            "PROTOCOL",
            "HOST",
            "PORT",
            "PATH",
            "EXTENSION",
            "QUERY",
            "FRAGMENT",
            "URL",
          ],
          [
            46,
            [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "C",
                    [7, [15, "j"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "E",
                    [7, [15, "j"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
            [5, [46, [36, ["k", [15, "j"], [15, "a"]]]]],
            [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]],
          ],
        ],
      ],
      [
        52,
        "__module_gtagSchema",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", "ad_storage"],
                [52, "c", "ad_user_data"],
                [52, "d", "consent_updated"],
                [52, "e", "_&emfm"],
                [52, "f", "app_remove"],
                [52, "g", "app_store_refund"],
                [52, "h", "app_store_subscription_cancel"],
                [52, "i", "app_store_subscription_convert"],
                [52, "j", "app_store_subscription_renew"],
                [52, "k", "conversion"],
                [52, "l", "first_open"],
                [52, "m", "first_visit"],
                [52, "n", "gtag.config"],
                [52, "o", "in_app_purchase"],
                [52, "p", "page_view"],
                [52, "q", "session_start"],
                [52, "r", "user_engagement"],
                [52, "s", "ads_data_redaction"],
                [52, "t", "allow_ad_personalization_signals"],
                [52, "u", "allow_custom_scripts"],
                [52, "v", "allow_enhanced_conversions"],
                [52, "w", "allow_google_signals"],
                [52, "x", "aw_remarketing_only"],
                [52, "y", "discount"],
                [52, "z", "aw_feed_country"],
                [52, "aA", "aw_feed_language"],
                [52, "aB", "items"],
                [52, "aC", "aw_merchant_id"],
                [52, "aD", "client_id"],
                [52, "aE", "conversion_cookie_prefix"],
                [52, "aF", "conversion_id"],
                [52, "aG", "conversion_linker"],
                [52, "aH", "conversion_api"],
                [52, "aI", "cookie_expires"],
                [52, "aJ", "cookie_prefix"],
                [52, "aK", "cookie_update"],
                [52, "aL", "country"],
                [52, "aM", "currency"],
                [52, "aN", "customer_lifetime_value"],
                [52, "aO", "customer_type"],
                [52, "aP", "debug_mode"],
                [52, "aQ", "shipping"],
                [52, "aR", "engagement_time_msec"],
                [52, "aS", "estimated_delivery_date"],
                [52, "aT", "event_developer_id_string"],
                [52, "aU", "event_id"],
                [52, "aV", "event"],
                [52, "aW", "event_timeout"],
                [52, "aX", "ext_client_id"],
                [52, "aY", "first_party_collection"],
                [52, "aZ", "match_id"],
                [52, "bA", "_gt_metadata"],
                [52, "bB", "google_analysis_params"],
                [52, "bC", "gsa_experiment_id"],
                [52, "bD", "ignore_referrer"],
                [52, "bE", "merchant_feed_label"],
                [52, "bF", "merchant_feed_language"],
                [52, "bG", "merchant_id"],
                [52, "bH", "new_customer"],
                [52, "bI", "page_hostname"],
                [52, "bJ", "page_path"],
                [52, "bK", "page_referrer"],
                [52, "bL", "page_title"],
                [52, "bM", "_platinum_request_status"],
                [52, "bN", "quantity"],
                [52, "bO", "restricted_data_processing"],
                [52, "bP", "send_page_view"],
                [52, "bQ", "server_container_3p_enrichment"],
                [52, "bR", "server_container_url"],
                [52, "bS", "session_duration"],
                [52, "bT", "session_engaged_time"],
                [52, "bU", "session_id"],
                [52, "bV", "_shared_user_id"],
                [52, "bW", "delivery_postal_code"],
                [52, "bX", "testonly"],
                [52, "bY", "topmost_url"],
                [52, "bZ", "transaction_id"],
                [52, "cA", "transaction_id_source"],
                [52, "cB", "transport_url"],
                [52, "cC", "update"],
                [52, "cD", "user_data"],
                [52, "cE", "user_data_auto_latency"],
                [52, "cF", "user_data_auto_meta"],
                [52, "cG", "user_data_auto_multi"],
                [52, "cH", "user_data_auto_selectors"],
                [52, "cI", "user_data_auto_status"],
                [52, "cJ", "user_data_mode"],
                [52, "cK", "user_id"],
                [52, "cL", "user_properties"],
                [52, "cM", "value"],
                [52, "cN", "_fpm_parameters"],
                [52, "cO", "_host_name"],
                [52, "cP", "_in_page_command"],
                [52, "cQ", "_measurement_type"],
                [52, "cR", "conversion_label"],
                [52, "cS", "page_location"],
                [52, "cT", "_extracted_data"],
                [52, "cU", "global_developer_id_string"],
                [
                  36,
                  [
                    8,
                    "B",
                    [15, "b"],
                    "C",
                    [15, "c"],
                    "F",
                    [15, "d"],
                    "I",
                    [15, "e"],
                    "J",
                    [15, "f"],
                    "K",
                    [15, "g"],
                    "L",
                    [15, "h"],
                    "M",
                    [15, "i"],
                    "N",
                    [15, "j"],
                    "P",
                    [15, "k"],
                    "AG",
                    [15, "l"],
                    "AH",
                    [15, "m"],
                    "AI",
                    [15, "n"],
                    "AK",
                    [15, "o"],
                    "AL",
                    [15, "p"],
                    "AN",
                    [15, "q"],
                    "AR",
                    [15, "r"],
                    "BD",
                    [15, "s"],
                    "BK",
                    [15, "t"],
                    "BL",
                    [15, "u"],
                    "BN",
                    [15, "v"],
                    "BO",
                    [15, "w"],
                    "BY",
                    [15, "x"],
                    "BZ",
                    [15, "y"],
                    "CA",
                    [15, "z"],
                    "CB",
                    [15, "aA"],
                    "CC",
                    [15, "aB"],
                    "CD",
                    [15, "aC"],
                    "CM",
                    [15, "aD"],
                    "CR",
                    [15, "aE"],
                    "CS",
                    [15, "aF"],
                    "KI",
                    [15, "cR"],
                    "CT",
                    [15, "aG"],
                    "CV",
                    [15, "aH"],
                    "CZ",
                    [15, "aI"],
                    "DD",
                    [15, "aJ"],
                    "DE",
                    [15, "aK"],
                    "DF",
                    [15, "aL"],
                    "DG",
                    [15, "aM"],
                    "DH",
                    [15, "aN"],
                    "DI",
                    [15, "aO"],
                    "DO",
                    [15, "aP"],
                    "EB",
                    [15, "aQ"],
                    "ED",
                    [15, "aR"],
                    "EH",
                    [15, "aS"],
                    "EK",
                    [15, "aT"],
                    "EL",
                    [15, "aU"],
                    "EO",
                    [15, "aV"],
                    "ER",
                    [15, "aW"],
                    "KK",
                    [15, "cT"],
                    "EV",
                    [15, "aX"],
                    "EX",
                    [15, "aY"],
                    "FF",
                    [15, "aZ"],
                    "FQ",
                    [15, "bA"],
                    "KL",
                    [15, "cU"],
                    "FU",
                    [15, "bB"],
                    "GC",
                    [15, "bC"],
                    "GG",
                    [15, "bD"],
                    "GU",
                    [15, "bE"],
                    "GV",
                    [15, "bF"],
                    "GW",
                    [15, "bG"],
                    "HA",
                    [15, "bH"],
                    "HD",
                    [15, "bI"],
                    "KJ",
                    [15, "cS"],
                    "HE",
                    [15, "bJ"],
                    "HF",
                    [15, "bK"],
                    "HG",
                    [15, "bL"],
                    "HO",
                    [15, "bM"],
                    "HQ",
                    [15, "bN"],
                    "HU",
                    [15, "bO"],
                    "IB",
                    [15, "bP"],
                    "ID",
                    [15, "bQ"],
                    "IE",
                    [15, "bR"],
                    "IG",
                    [15, "bS"],
                    "II",
                    [15, "bT"],
                    "IJ",
                    [15, "bU"],
                    "IL",
                    [15, "bV"],
                    "IM",
                    [15, "bW"],
                    "IQ",
                    [15, "bX"],
                    "IS",
                    [15, "bY"],
                    "IV",
                    [15, "bZ"],
                    "IW",
                    [15, "cA"],
                    "IX",
                    [15, "cB"],
                    "IZ",
                    [15, "cC"],
                    "JK",
                    [15, "cD"],
                    "JL",
                    [15, "cE"],
                    "JM",
                    [15, "cF"],
                    "JN",
                    [15, "cG"],
                    "JO",
                    [15, "cH"],
                    "JP",
                    [15, "cI"],
                    "JQ",
                    [15, "cJ"],
                    "JS",
                    [15, "cK"],
                    "JT",
                    [15, "cL"],
                    "JW",
                    [15, "cM"],
                    "JY",
                    [15, "cN"],
                    "KA",
                    [15, "cO"],
                    "KB",
                    [15, "cP"],
                    "KE",
                    [15, "cQ"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_metadataSchema",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", "accept_by_default"],
                [52, "c", "allow_ad_personalization"],
                [52, "d", "consent_state"],
                [52, "e", "consent_updated"],
                [52, "f", "conversion_marking_called"],
                [52, "g", "dedupe_id"],
                [52, "h", "em_event"],
                [52, "i", "enhanced_match_form_metadata"],
                [52, "j", "enhanced_match_form_metadata_latency"],
                [52, "k", "event_provenance"],
                [52, "l", "event_source"],
                [52, "m", "event_start_timestamp_ms"],
                [52, "n", "event_usage"],
                [52, "o", "extra_tag_experiment_ids"],
                [52, "p", "form_event_canceled"],
                [52, "q", "ga4_collection_subdomain"],
                [52, "r", "gtm_extracted_data"],
                [52, "s", "handle_internally"],
                [52, "t", "has_ga_conversion_consents"],
                [52, "u", "hit_type"],
                [52, "v", "hit_type_override"],
                [52, "w", "ignore_dupe_config"],
                [52, "x", "is_conversion"],
                [52, "y", "is_external_event"],
                [52, "z", "is_first_visit"],
                [52, "aA", "is_first_visit_conversion"],
                [52, "aB", "is_fpm_encryption"],
                [52, "aC", "is_fpm_split"],
                [52, "aD", "is_gcp_browser"],
                [52, "aE", "is_google_measurement_allowed"],
                [52, "aF", "is_server_side_destination"],
                [52, "aG", "is_session_start"],
                [52, "aH", "is_session_start_conversion"],
                [52, "aI", "is_sgtm_ga_ads_conversion_study_control_group"],
                [52, "aJ", "is_sgtm_prehit"],
                [52, "aK", "is_split_conversion"],
                [52, "aL", "is_syn"],
                [52, "aM", "is_test_event"],
                [52, "aN", "no_target_group"],
                [52, "aO", "prehit_for_retry"],
                [52, "aP", "redact_ads_data"],
                [52, "aQ", "redact_click_ids"],
                [52, "aR", "send_ccm_parallel_ping"],
                [52, "aS", "send_user_data_hit"],
                [52, "aT", "speculative"],
                [52, "aU", "syn_or_mod"],
                [52, "aV", "user_data_tr_ra"],
                [52, "aW", "user_data_tr_rp"],
                [52, "aX", "transient_ecsid"],
                [52, "aY", "user_data"],
                [52, "aZ", "user_data_from_automatic"],
                [52, "bA", "user_data_from_automatic_getter"],
                [52, "bB", "user_data_from_code"],
                [52, "bC", "user_data_from_manual"],
                [
                  36,
                  [
                    8,
                    "A",
                    [15, "b"],
                    "F",
                    [15, "c"],
                    "M",
                    [15, "d"],
                    "N",
                    [15, "e"],
                    "P",
                    [15, "f"],
                    "S",
                    [15, "g"],
                    "V",
                    [15, "h"],
                    "Y",
                    [15, "i"],
                    "Z",
                    [15, "j"],
                    "AD",
                    [15, "k"],
                    "AE",
                    [15, "l"],
                    "AF",
                    [15, "m"],
                    "AG",
                    [15, "n"],
                    "AH",
                    [15, "o"],
                    "AO",
                    [15, "p"],
                    "AP",
                    [15, "q"],
                    "AS",
                    [15, "r"],
                    "AT",
                    [15, "s"],
                    "AU",
                    [15, "t"],
                    "AW",
                    [15, "u"],
                    "AX",
                    [15, "v"],
                    "AY",
                    [15, "w"],
                    "BB",
                    [15, "x"],
                    "BE",
                    [15, "y"],
                    "BF",
                    [15, "z"],
                    "BG",
                    [15, "aA"],
                    "BI",
                    [15, "aB"],
                    "BJ",
                    [15, "aC"],
                    "BK",
                    [15, "aD"],
                    "BL",
                    [15, "aE"],
                    "BQ",
                    [15, "aF"],
                    "BR",
                    [15, "aG"],
                    "BS",
                    [15, "aH"],
                    "BT",
                    [15, "aI"],
                    "BU",
                    [15, "aJ"],
                    "BW",
                    [15, "aK"],
                    "BX",
                    [15, "aL"],
                    "BY",
                    [15, "aM"],
                    "CE",
                    [15, "aN"],
                    "CH",
                    [15, "aO"],
                    "CK",
                    [15, "aP"],
                    "CL",
                    [15, "aQ"],
                    "CN",
                    [15, "aR"],
                    "CW",
                    [15, "aS"],
                    "CZ",
                    [15, "aT"],
                    "DD",
                    [15, "aU"],
                    "DE",
                    [15, "aV"],
                    "DF",
                    [15, "aW"],
                    "DG",
                    [15, "aX"],
                    "DI",
                    [15, "aY"],
                    "DJ",
                    [15, "aZ"],
                    "DK",
                    [15, "bA"],
                    "DL",
                    [15, "bB"],
                    "DM",
                    [15, "bC"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_featureFlags",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", 45],
                [52, "c", 46],
                [52, "d", 47],
                [52, "e", 174],
                [52, "f", 276],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "b"],
                    "G",
                    [15, "c"],
                    "H",
                    [15, "d"],
                    "U",
                    [15, "e"],
                    "AA",
                    [15, "f"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_legacyUrls",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "h",
                  [46, "p"],
                  [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                  [
                    36,
                    [
                      39,
                      [23, [15, "q"], 0],
                      [15, "p"],
                      [2, [15, "p"], "substring", [7, 0, [15, "q"]]],
                    ],
                  ],
                ],
                [
                  50,
                  "i",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                  [
                    36,
                    [
                      39,
                      [15, "q"],
                      [2, [15, "q"], "replace", [7, ":", ""]],
                      "",
                    ],
                  ],
                ],
                [
                  50,
                  "j",
                  [46, "p", "q"],
                  [41, "r"],
                  [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                  [22, [28, [15, "r"]], [46, [36, ""]]],
                  [52, "s", ["b", ":[0-9]+"]],
                  [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                  [
                    22,
                    [15, "q"],
                    [
                      46,
                      [
                        53,
                        [52, "t", ["b", "^www\\d*\\."]],
                        [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                        [
                          22,
                          [1, [15, "u"], [16, [15, "u"], 0]],
                          [
                            46,
                            [
                              3,
                              "r",
                              [
                                2,
                                [15, "r"],
                                "substring",
                                [7, [17, [16, [15, "u"], 0], "length"]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "r"]],
                ],
                [
                  50,
                  "k",
                  [46, "p"],
                  [52, "q", ["e", [15, "p"]]],
                  [41, "r"],
                  [3, "r", ["f", [17, [15, "q"], "port"]]],
                  [
                    22,
                    [28, [15, "r"]],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [20, [17, [15, "q"], "protocol"], "http:"],
                          [46, [53, [3, "r", 80]]],
                          [
                            46,
                            [
                              22,
                              [20, [17, [15, "q"], "protocol"], "https:"],
                              [46, [53, [3, "r", 443]]],
                              [46, [53, [3, "r", ""]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, ["g", [15, "r"]]],
                ],
                [
                  50,
                  "l",
                  [46, "p", "q"],
                  [52, "r", ["e", [15, "p"]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [
                        20,
                        [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]],
                        0,
                      ],
                      [17, [15, "r"], "pathname"],
                      [0, "/", [17, [15, "r"], "pathName"]],
                    ],
                  ],
                  [
                    22,
                    [20, ["d", [15, "q"]], "array"],
                    [
                      46,
                      [
                        53,
                        [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                        [
                          22,
                          [
                            19,
                            [
                              2,
                              [15, "q"],
                              "indexOf",
                              [
                                7,
                                [
                                  16,
                                  [15, "t"],
                                  [37, [17, [15, "t"], "length"], 1],
                                ],
                              ],
                            ],
                            0,
                          ],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "t"],
                                [37, [17, [15, "t"], "length"], 1],
                                "",
                              ],
                              [3, "s", [2, [15, "t"], "join", [7, "/"]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "s"]],
                ],
                [
                  50,
                  "m",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                  [52, "r", [2, [15, "q"], "split", [7, "."]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [18, [17, [15, "r"], "length"], 1],
                      [16, [15, "r"], [37, [17, [15, "r"], "length"], 1]],
                      "",
                    ],
                  ],
                  [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]],
                ],
                [
                  50,
                  "n",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "hash"]],
                  [36, [2, [15, "q"], "replace", [7, "#", ""]]],
                ],
                [
                  50,
                  "o",
                  [46, "p", "q"],
                  [
                    50,
                    "s",
                    [46, "t"],
                    [
                      36,
                      [
                        "c",
                        [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]],
                      ],
                    ],
                  ],
                  [
                    52,
                    "r",
                    [
                      2,
                      [17, ["e", [15, "p"]], "search"],
                      "replace",
                      [7, "?", ""],
                    ],
                  ],
                  [
                    65,
                    "t",
                    [2, [15, "r"], "split", [7, "&"]],
                    [
                      46,
                      [
                        53,
                        [52, "u", [2, [15, "t"], "split", [7, "="]]],
                        [
                          22,
                          [21, ["s", [16, [15, "u"], 0]], [15, "q"]],
                          [46, [6]],
                        ],
                        [
                          36,
                          [
                            "s",
                            [
                              2,
                              [2, [15, "u"], "slice", [7, 1]],
                              "join",
                              [7, "="],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36],
                ],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "decodeUriComponent"]],
                [52, "d", ["require", "getType"]],
                [52, "e", ["require", "internal.legacyParseUrl"]],
                [52, "f", ["require", "makeNumber"]],
                [52, "g", ["require", "makeString"]],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "m"],
                    "H",
                    [15, "o"],
                    "G",
                    [15, "n"],
                    "C",
                    [15, "j"],
                    "E",
                    [15, "l"],
                    "D",
                    [15, "k"],
                    "B",
                    [15, "i"],
                    "A",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_gtag",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "n",
                  [46, "r", "s", "t"],
                  [
                    65,
                    "u",
                    [15, "s"],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [2, [15, "r"], "hasOwnProperty", [7, [15, "u"]]],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "r"],
                                [15, "u"],
                                ["t", [16, [15, "r"], [15, "u"]]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                ],
                [
                  50,
                  "o",
                  [46, "r", "s"],
                  [
                    "n",
                    [15, "r"],
                    [15, "s"],
                    [
                      51,
                      "",
                      [7, "t"],
                      [
                        36,
                        [
                          39,
                          [
                            20,
                            "false",
                            [2, ["e", [15, "t"]], "toLowerCase", [7]],
                          ],
                          false,
                          [28, [28, [15, "t"]]],
                        ],
                      ],
                    ],
                  ],
                ],
                [
                  50,
                  "p",
                  [46, "r", "s"],
                  ["n", [15, "r"], [15, "s"], [15, "d"]],
                ],
                [
                  50,
                  "q",
                  [46, "r", "s"],
                  [52, "t", ["h"]],
                  [
                    22,
                    [
                      1,
                      [15, "t"],
                      [18, [2, [15, "t"], "indexOf", [7, [15, "s"]]], [27, 1]],
                    ],
                    [46, [53, [43, [15, "r"], [17, [15, "i"], "AT"], true]]],
                  ],
                ],
                [52, "b", ["require", "Object"]],
                [52, "c", [15, "__module_gtagSchema"]],
                [52, "d", ["require", "makeNumber"]],
                [52, "e", ["require", "makeString"]],
                [52, "f", ["require", "internal.isFeatureEnabled"]],
                [52, "g", [15, "__module_featureFlags"]],
                [52, "h", ["require", "internal.getDestinationIds"]],
                [52, "i", [15, "__module_metadataSchema"]],
                [
                  52,
                  "j",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "BK"],
                        [17, [15, "c"], "BO"],
                        [17, [15, "c"], "DE"],
                        [17, [15, "c"], "GG"],
                        [17, [15, "c"], "IZ"],
                        [17, [15, "c"], "EX"],
                        [17, [15, "c"], "IB"],
                        [17, [15, "c"], "ID"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "k",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "BK"],
                        [17, [15, "c"], "BO"],
                        [17, [15, "c"], "DE"],
                        [17, [15, "c"], "GG"],
                        [17, [15, "c"], "IZ"],
                        [17, [15, "c"], "EX"],
                        [17, [15, "c"], "IB"],
                        [17, [15, "c"], "ID"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "l",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "CZ"],
                        [17, [15, "c"], "ER"],
                        [17, [15, "c"], "IG"],
                        [17, [15, "c"], "II"],
                        [17, [15, "c"], "ED"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "m",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "CZ"],
                        [17, [15, "c"], "ER"],
                        [17, [15, "c"], "IG"],
                        [17, [15, "c"], "II"],
                        [17, [15, "c"], "ED"],
                      ],
                    ],
                  ],
                ],
                [
                  36,
                  [
                    8,
                    "B",
                    [15, "k"],
                    "D",
                    [15, "m"],
                    "A",
                    [15, "j"],
                    "C",
                    [15, "l"],
                    "F",
                    [15, "o"],
                    "G",
                    [15, "p"],
                    "E",
                    [15, "n"],
                    "H",
                    [15, "q"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
    ],
    entities: {
      __e: { 2: true, 6: true },
      __f: { 2: true, 6: true },
      __googtag: { 1: 10, 6: true },
      __u: { 2: true, 6: true },
    },

    blob: {
      1: "2",
      10: "GTM-TG5DKRQ5",
      14: "69m0",
      15: "0",
      16: "ChEI8PHN1QYQrMq/nNH04uGhARIdAPhEerf3aCBl2/F2K9mGECjmdZX2CKiDFLN8aIoaAmj6",
      19: "dataLayer",
      20: "",
      21: "www.googletagmanager.com",
      22: "eyIwIjoiTkwiLCIxIjoiTkwtR0UiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5ubCIsIjQiOiJyZWdpb24xIiwiNSI6ZmFsc2UsIjYiOnRydWUsIjciOiJhZF9zdG9yYWdlfGFuYWx5dGljc19zdG9yYWdlfGFkX3VzZXJfZGF0YXxhZF9wZXJzb25hbGl6YXRpb24iLCI5Ijp0cnVlfQ",
      23: "google.tagmanager.debugui2.queue",
      24: "tagassistant.google.com",
      27: 0.005,
      3: "www.googletagmanager.com",
      30: "NL",
      31: "NL-GE",
      32: false,
      33: "region1",
      36: "https://adservice.google.com/pagead/regclk",
      37: "__TAGGY_INSTALLED",
      38: "cct.google",
      39: "googTaggyReferrer",
      40: "https://cct.google/taggy/agent.js",
      41: "google.tagmanager.ta.prodqueue",
      42: 0.01,
      43: '{"keys":[{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BJgbMWS2kRqrNVndzU4RPdXeJOQDm2R6T1UCmn8OjN1fKFKEAzlICwWav/WLqEJXO92t2z6oRDq9fZqCb6EYinI=","version":0},"id":"f3e06995-d46d-4142-9abe-4d9dc65c923c"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BG/35VFWNFPPxu50Ca/fNlV3KveeoGGFCNoT2deXxvxdsJEprghN8MlZbgy5es8kbpOiAQ7P12ZcL30rEDYmDdk=","version":0},"id":"dd5c7ea0-67f2-43b7-a7ae-69dd93c4f917"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BNCe+bTaSiOy2aCkivFdW+3qyY3YtpQzjdntE9XlVr/h4E6h5MTHFowjocmCepP2rOQPvt+X/6ouAV/TOQT1T3c=","version":0},"id":"b1499e44-b59a-4748-b870-9d033cccea77"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BNVQkRgxZlM9jFUlbyoIiBbMSn6TvA+SxZmR7ArFoAtvJt4avxukjHZ596tVNRBVWuMee6n6BcZHS4pHKgTF6kg=","version":0},"id":"3b407774-a5c9-44a3-8abc-c3575db78e70"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BJPmllGOi4OVv/hvYTiDC/b2w2jss9rkzsnZ14X6iwoCoFMnKKtL48l2/YD5liA1narwy2PakAjKG47R7CTlCGQ=","version":0},"id":"15774f39-83f5-44e1-aafc-aec0fa992e07"}]}',
      44: "118897920~118897930~120469145~120469153",
      46: {
        1: "1000",
        10: "69f0",
        11: "69f0",
        14: "1000",
        16: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        17: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        2: "9",
        20: "5000",
        21: "5000",
        22: "4.4.0",
        23: "0.0.0",
        25: "1",
        26: "4000",
        27: "100",
        3: "5",
        4: "ad_storage|analytics_storage|ad_user_data|ad_personalization",
        44: "15000",
        48: "30000",
        5: "ad_storage|analytics_storage|ad_user_data",
        6: "1",
        61: "1000",
        62: "A6ONHRY7/bvBro+IMZd/a6LNjn7SSv999SkN/hFAE9L6vMr34dNgfdSVdYmv4U+NHZg1sxd38RtciRpRUtIRPgQAAACCeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiU2hhcmVkV29ya2VyRXh0ZW5kZWRMaWZldGltZSIsImV4cGlyeSI6MTc3NjcyOTYwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
        63: "1000",
        66: "100",
        7: "10",
      },
      48: true,
      5: "GTM-TG5DKRQ5",
      55: ["GTM-TG5DKRQ5"],
      56: [
        { 1: 403, 3: 0.5, 4: 115938465, 5: 115938466, 6: 0, 7: 2 },
        { 1: 404, 3: 0.5, 4: 115938468, 5: 115938469, 6: 0, 7: 1 },
        { 1: 585, 2: true },
        { 1: 619, 2: true },
        { 1: 474, 3: 0.1, 4: 117776795, 5: 117776796, 6: 0, 7: 3 },
        { 1: 609, 3: 0.01, 4: 120420416, 5: 120420414, 6: 120420415, 7: 1 },
        { 1: 635, 2: true },
        { 1: 633, 2: true },
        { 1: 607, 3: 0.01, 4: 121191155, 5: 121191153, 6: 121191154, 7: 3 },
        { 1: 502, 2: true },
        { 1: 568, 3: 0.01, 4: 119791749, 5: 119791748, 6: 0, 7: 1 },
        { 1: 490, 2: true },
        { 1: 491, 3: 0.01, 4: 118012007, 5: 118012008, 6: 118012009, 7: 1 },
        { 1: 480, 2: true },
        { 1: 622, 2: true },
        { 1: 594, 3: 0.01, 4: 119793974, 5: 119793972, 6: 119793973, 7: 1 },
        { 1: 550, 2: true },
        { 1: 613, 3: 0.1, 4: 121280971, 5: 121280969, 6: 121280970, 7: 2 },
        { 1: 592, 3: 0.01, 4: 121153387, 5: 121153385, 6: 121153386, 7: 3 },
        { 1: 567, 3: 0.05, 4: 120895657, 5: 120895655, 6: 120895656, 7: 3 },
        { 1: 413, 2: true },
        { 1: 616, 3: 0.001, 4: 121046857, 5: 121046856, 6: 0, 7: 1 },
        { 1: 553, 2: true },
        { 1: 608, 3: 0.01, 4: 120412528, 5: 120412526, 6: 120412527, 7: 1 },
        { 1: 593, 2: true },
        { 1: 506, 2: true },
        { 1: 604, 2: true },
        { 1: 561, 2: true },
        { 1: 481, 2: true },
        { 1: 562, 3: 0.001, 4: 119404697, 5: 119404696, 6: 0, 7: 1 },
        { 1: 482, 2: true },
        { 1: 612, 3: 0.01, 4: 120912673, 5: 120912672, 6: 0, 7: 1 },
        { 1: 450, 3: 0.01, 4: 117227714, 5: 117227715, 6: 117227716, 7: 3 },
        { 1: 458, 2: true },
        { 1: 582, 3: 0.01, 4: 119381664, 5: 119381662, 6: 119381663, 7: 3 },
        { 1: 570, 2: true },
        { 1: 498, 3: 0.2, 4: 115616985, 5: 115616986, 6: 0, 7: 1 },
        { 1: 630, 2: true },
        { 1: 495, 3: 0.05, 4: 118131810, 5: 118131808, 6: 118131809, 7: 3 },
        { 1: 564, 3: 0.0001, 4: 119205317, 5: 119205315, 6: 119205316, 7: 1 },
        { 1: 610, 3: 0.5, 4: 120385423, 5: 120385422, 6: 0, 7: 1 },
        { 1: 576, 3: 0.01, 4: 119317810, 5: 119317811, 6: 119318177, 7: 3 },
        { 1: 629, 2: true },
        { 1: 605, 3: 0.001, 4: 120032690, 5: 120032689, 6: 120032691, 7: 1 },
        { 1: 524, 2: true },
      ],
      59: ["GTM-TG5DKRQ5"],
      6: "200632407",
      62: false,
      63: 0.005,
    },
    permissions: {
      __e: {
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __f: {
        read_data_layer: { keyPatterns: ["gtm.referrer"] },
        get_referrer: { urlParts: "any" },
      },
      __googtag: {
        logging: { environments: "debug" },
        access_globals: {
          keys: [
            { key: "gtag", read: true, write: true, execute: true },
            { key: "dataLayer", read: true, write: true, execute: false },
          ],
        },
        configure_google_tags: { allowedTagIds: "any" },
        load_google_tags: {
          allowedTagIds: "any",
          allowFirstPartyUrls: true,
          allowedFirstPartyUrls: "any",
        },
      },
      __u: {
        read_data_layer: { keyPatterns: ["gtm.url"] },
        get_url: { urlParts: "any" },
      },
    },

    security_groups: {
      google: ["__e", "__f", "__googtag", "__u"],
    },
  };

  var l,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      for (
        var b = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ],
          c = 0;
        c < b.length;
        ++c
      ) {
        var d = b[c];
        if (d && d.Math == Math) return d;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    ha = {},
    la = {},
    ma = function (a, b, c) {
      if (!c || a != null) {
        var d = la[b];
        if (d == null) return a[b];
        var e = a[d];
        return e !== void 0 ? e : a[b];
      }
    },
    na = function (a, b, c) {
      if (b)
        a: {
          var d = a.split("."),
            e = d.length === 1,
            f = d[0],
            g;
          !e && f in ha ? (g = ha) : (g = da);
          for (var h = 0; h < d.length - 1; h++) {
            var k = d[h];
            if (!(k in g)) break a;
            g = g[k];
          }
          var m = d[d.length - 1],
            p = fa && c === "es6" ? g[m] : null,
            q = b(p);
          if (q != null)
            if (e) ba(ha, m, { configurable: !0, writable: !0, value: q });
            else if (q !== p) {
              if (la[m] === void 0) {
                var r = (Math.random() * 1e9) >>> 0;
                la[m] = fa ? da.Symbol(m) : "$jscp$" + r + "$" + m;
              }
              ba(g, la[m], { configurable: !0, writable: !0, value: q });
            }
        }
    },
    oa;
  if (fa && typeof Object.setPrototypeOf == "function")
    oa = Object.setPrototypeOf;
  else {
    var pa;
    a: {
      var qa = { a: !0 },
        ra = {};
      try {
        ra.__proto__ = qa;
        pa = ra.a;
        break a;
      } catch (a) {}
      pa = !1;
    }
    oa = pa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var sa = oa,
    ta = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (sa) sa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.iu = b.prototype;
    },
    ua = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    n = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: ua(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    wa = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    xa = function (a) {
      return a instanceof Array ? a : wa(n(a));
    },
    za = function (a) {
      return ya(a, a);
    },
    ya = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    Aa =
      fa && typeof ma(Object, "assign") == "function"
        ? ma(Object, "assign")
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d)
                for (var e in d)
                  Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  na(
    "Object.assign",
    function (a) {
      return a || Aa;
    },
    "es6"
  );
  var Ba = function (a) {
      if (!(a instanceof Object))
        throw new TypeError("Iterator result " + a + " is not an object");
    },
    Ca = function () {
      this.la = !1;
      this.M = null;
      this.aa = void 0;
      this.D = 1;
      this.U = this.fa = 0;
      this.La = this.J = null;
    },
    Da = function (a) {
      if (a.la) throw new TypeError("Generator is already running");
      a.la = !0;
    };
  Ca.prototype.Da = function (a) {
    this.aa = a;
  };
  var Ea = function (a, b) {
    a.J = { exception: b, isException: !0 };
    a.D = a.fa || a.U;
  };
  Ca.prototype.getNextAddressJsc = function () {
    return this.D;
  };
  Ca.prototype.getYieldResultJsc = function () {
    return this.aa;
  };
  Ca.prototype.return = function (a) {
    this.J = { return: a };
    this.D = this.U;
  };
  Ca.prototype["return"] = Ca.prototype.return;
  Ca.prototype.uj = function (a) {
    this.J = { Fc: a };
    this.U < a ? ((this.D = a), (this.J = null)) : (this.D = this.U);
  };
  Ca.prototype.jumpThroughFinallyBlocks = Ca.prototype.uj;
  Ca.prototype.yield = function (a, b) {
    this.D = b;
    return { value: a };
  };
  Ca.prototype.yield = Ca.prototype.yield;
  Ca.prototype.Ts = function (a, b) {
    var c = n(a),
      d = c.next();
    Ba(d);
    if (d.done) (this.aa = d.value), (this.D = b);
    else return (this.M = c), this.yield(d.value, b);
  };
  Ca.prototype.yieldAll = Ca.prototype.Ts;
  Ca.prototype.Fc = function (a) {
    this.D = a;
  };
  Ca.prototype.jumpTo = Ca.prototype.Fc;
  Ca.prototype.yj = function () {
    this.D = 0;
  };
  Ca.prototype.jumpToEnd = Ca.prototype.yj;
  Ca.prototype.sg = function (a, b) {
    this.fa = a;
    b != void 0 && (this.U = b);
  };
  Ca.prototype.setCatchFinallyBlocks = Ca.prototype.sg;
  Ca.prototype.Jh = function (a) {
    this.fa = 0;
    this.U = a || 0;
  };
  Ca.prototype.setFinallyBlock = Ca.prototype.Jh;
  Ca.prototype.Cj = function (a, b) {
    this.D = a;
    this.fa = b || 0;
  };
  Ca.prototype.leaveTryBlock = Ca.prototype.Cj;
  Ca.prototype.Rb = function (a) {
    this.fa = a || 0;
    var b = this.J.exception;
    this.J = null;
    return b;
  };
  Ca.prototype.enterCatchBlock = Ca.prototype.Rb;
  Ca.prototype.jd = function (a, b, c) {
    c ? (this.La[c] = this.J) : (this.La = [this.J]);
    this.fa = a || 0;
    this.U = b || 0;
    this.J = null;
  };
  Ca.prototype.enterFinallyBlock = Ca.prototype.jd;
  Ca.prototype.Wd = function (a, b) {
    var c = this.La.splice(b || 0)[0],
      d = (this.J = this.J || c);
    d
      ? d.isException
        ? (this.D = this.fa || this.U)
        : d.Fc != void 0 && this.U < d.Fc
        ? ((this.D = d.Fc), (this.J = null))
        : (this.D = this.U)
      : (this.D = a);
  };
  Ca.prototype.leaveFinallyBlock = Ca.prototype.Wd;
  Ca.prototype.Vd = function (a) {
    return new Fa(a);
  };
  Ca.prototype.forIn = Ca.prototype.Vd;
  var Fa = function (a) {
    this.J = a;
    this.D = [];
    for (var b in a) this.D.push(b);
    this.D.reverse();
  };
  Fa.prototype.Qn = function () {
    for (; this.D.length > 0; ) {
      var a = this.D.pop();
      if (a in this.J) return a;
    }
    return null;
  };
  Fa.prototype.getNext = Fa.prototype.Qn;
  var Ha = function (a) {
      this.D = new Ca();
      this.J = a;
    },
    Ka = function (a, b) {
      Da(a.D);
      var c = a.D.M;
      if (c)
        return Ia(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.D.return
        );
      a.D.return(b);
      return Ja(a);
    },
    Ia = function (a, b, c, d) {
      try {
        var e = b.call(a.D.M, c);
        Ba(e);
        if (!e.done) return (a.D.la = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.D.M = null), Ea(a.D, g), Ja(a);
      }
      a.D.M = null;
      d.call(a.D, f);
      return Ja(a);
    },
    Ja = function (a) {
      for (; a.D.D; )
        try {
          var b = a.J(a.D);
          if (b) return (a.D.la = !1), { value: b.value, done: !1 };
        } catch (d) {
          (a.D.aa = void 0), Ea(a.D, d);
        }
      a.D.la = !1;
      if (a.D.J) {
        var c = a.D.J;
        a.D.J = null;
        if (c.isException) throw c.exception;
        return { value: c.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    La = function (a) {
      this.next = function (b) {
        var c;
        Da(a.D);
        a.D.M ? (c = Ia(a, a.D.M.next, b, a.D.Da)) : (a.D.Da(b), (c = Ja(a)));
        return c;
      };
      this.throw = function (b) {
        var c;
        Da(a.D);
        if (a.D.M) {
          var d = a.D.M["throw"];
          if (d) c = Ia(a, d, b, a.D.Da);
          else {
            var e = a.D.M;
            a.D.M = null;
            try {
              if (e["return"]) {
                var f = e["return"]();
                Ba(f);
              }
              Ea(
                a.D,
                new TypeError("The iterator does not provide a 'throw' method.")
              );
            } catch (g) {
              Ea(a.D, g);
            }
            c = Ja(a);
          }
        } else Ea(a.D, b), (c = Ja(a));
        return c;
      };
      this.return = function (b) {
        return Ka(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ma = function (a, b) {
      var c = new La(new Ha(b));
      sa && a.prototype && sa(c, a.prototype);
      return c;
    },
    Na = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Oa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    },
    Pa = function (a) {
      return a;
    }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Qa = this || self,
    Ra = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.iu = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.base = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Sa = function (a, b) {
    this.type = a;
    this.data = b;
  };
  var Ta = function () {
    this.map = {};
    this.D = {};
  };
  Ta.prototype.get = function (a) {
    return this.map["dust." + a];
  };
  Ta.prototype.set = function (a, b) {
    var c = "dust." + a;
    this.D.hasOwnProperty(c) || (this.map[c] = b);
  };
  Ta.prototype.has = function (a) {
    return this.map.hasOwnProperty("dust." + a);
  };
  Ta.prototype.remove = function (a) {
    var b = "dust." + a;
    this.D.hasOwnProperty(b) || delete this.map[b];
  };
  var Ua = function (a, b) {
    var c = [],
      d;
    for (d in a.map)
      if (a.map.hasOwnProperty(d)) {
        var e = d.substring(5);
        switch (b) {
          case 1:
            c.push(e);
            break;
          case 2:
            c.push(a.map[d]);
            break;
          case 3:
            c.push([e, a.map[d]]);
        }
      }
    return c;
  };
  Ta.prototype.Ga = function () {
    return Ua(this, 1);
  };
  Ta.prototype.fc = function () {
    return Ua(this, 2);
  };
  Ta.prototype.bc = function () {
    return Ua(this, 3);
  };
  var Va = function () {};
  Va.prototype.reset = function () {};
  var Wa = function () {
    this.value = {};
    this.prefix = "gtm.";
  };
  da.Object.defineProperties(Wa.prototype, {
    size: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.keys(this.value).length;
      },
    },
  });
  l = Wa.prototype;
  l.set = function (a, b) {
    this.value[this.prefix + String(a)] = b;
  };
  l.get = function (a) {
    return this.value[this.prefix + String(a)];
  };
  l.has = function (a) {
    return this.value.hasOwnProperty(this.prefix + String(a));
  };
  l.delete = function (a) {
    var b = this.prefix + String(a);
    return this.value.hasOwnProperty(b) ? (delete this.value[b], !0) : !1;
  };
  l.clear = function () {
    this.value = {};
  };
  l.values = function () {
    var a = this;
    return (function c() {
      var d, e, f;
      return Ma(c, function (g) {
        switch (g.D) {
          case 1:
            g.Jh(2), (e = g.Vd(a.value));
          case 4:
            if ((d = e.Qn()) == null) {
              g.Fc(2);
              break;
            }
            if (!a.value.hasOwnProperty(d)) {
              g.Fc(4);
              break;
            }
            f = Pa;
            return g.yield(a.value[d], 8);
          case 8:
            f(g.aa);
            g.Fc(4);
            break;
          case 2:
            g.jd(), g.Wd(0);
        }
      });
    })();
  };
  function Xa() {
    try {
      if (Map) return new Map();
    } catch (a) {}
    return new Wa();
  }
  var Ya = function () {
    this.values = [];
  };
  Ya.prototype.add = function (a) {
    this.values.indexOf(a) === -1 && this.values.push(a);
  };
  Ya.prototype.has = function (a) {
    return this.values.indexOf(a) > -1;
  };
  var Za = function (a, b) {
    this.aa = a;
    this.parent = b;
    this.M = this.D = void 0;
    this.Jb = !1;
    this.J = function (d, e, f) {
      return d.apply(e, f);
    };
    this.variables = Xa();
    var c;
    a: {
      try {
        if (Set) {
          c = new Set();
          break a;
        }
      } catch (d) {}
      c = new Ya();
    }
    this.U = c;
  };
  Za.prototype.add = function (a, b) {
    $a(this, a, b, !1);
  };
  Za.prototype.Kh = function (a, b) {
    $a(this, a, b, !0);
  };
  var $a = function (a, b, c, d) {
    a.Jb || a.U.has(b) || (d && a.U.add(b), a.variables.set(b, c));
  };
  l = Za.prototype;
  l.set = function (a, b) {
    this.Jb ||
      (!this.variables.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.U.has(a) || this.variables.set(a, b));
  };
  l.get = function (a) {
    return this.variables.has(a)
      ? this.variables.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  l.has = function (a) {
    return !!this.variables.has(a) || !(!this.parent || !this.parent.has(a));
  };
  l.yb = function () {
    var a = new Za(this.aa, this);
    this.D && a.Tb(this.D);
    a.rd(this.J);
    a.he(this.M);
    return a;
  };
  l.Xd = function () {
    return this.aa;
  };
  l.Tb = function (a) {
    this.D = a;
  };
  l.Pn = function () {
    return this.D;
  };
  l.rd = function (a) {
    this.J = a;
  };
  l.Fj = function () {
    return this.J;
  };
  l.Ya = function () {
    this.Jb = !0;
  };
  l.he = function (a) {
    this.M = a;
  };
  l.lb = function () {
    return this.M;
  };
  var bb = function (a, b, c) {
    c = c === void 0 ? !1 : c;
    var d;
    d = Error.call(this, a.message);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.Wj = a;
    this.zn = c;
    this.debugInfo = [];
    this.D = b;
  };
  ta(bb, Error);
  var cb = function (a) {
    return a instanceof bb ? a : new bb(a, void 0, !0);
  };
  var db = Xa();
  function eb(a, b) {
    var c,
      d = n(b),
      e = d.next(),
      f;
    try {
      for (; !e.done && !((c = fb(a, e.value)), c instanceof Sa); e = d.next());
    } finally {
      e && !e.done && (f = d.return) && f.call(d);
    }
    return c;
  }
  function fb(a, b) {
    try {
      var c = b[0],
        d = b.slice(1),
        e = String(c),
        f = db.has(e) ? db.get(e) : a.get(e);
      if (!f || typeof f.invoke !== "function")
        throw cb(Error("Attempting to execute non-function " + b[0] + "."));
      return f.apply(a, d);
    } catch (h) {
      var g = a.Pn();
      g && g(h, b.context ? { id: b[0], line: b.context.line } : null);
      throw h;
    }
  }
  var hb = function () {
    this.J = new Va();
    this.D = new Za(this.J);
  };
  l = hb.prototype;
  l.Xd = function () {
    return this.J;
  };
  l.Tb = function (a) {
    this.D.Tb(a);
  };
  l.rd = function (a) {
    this.D.rd(a);
  };
  l.execute = function (a) {
    return this.run([a].concat(xa(Oa.apply(1, arguments))));
  };
  l.run = function () {
    var a,
      b = n(Oa.apply(0, arguments)),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next()) a = fb(this.D, c.value);
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
    return a;
  };
  l.Cq = function (a) {
    var b = Oa.apply(1, arguments),
      c = this.D.yb();
    c.he(a);
    var d,
      e = n(b),
      f = e.next(),
      g;
    try {
      for (; !f.done; f = e.next()) d = fb(c, f.value);
    } finally {
      f && !f.done && (g = e.return) && g.call(e);
    }
    return d;
  };
  l.Ya = function () {
    this.D.Ya();
  };
  var ib = function (a, b) {
    this.U = a;
    this.parent = b;
    this.M = this.D = void 0;
    this.Jb = !1;
    this.J = function (c, d, e) {
      return c.apply(d, e);
    };
    this.values = new Ta();
  };
  ib.prototype.add = function (a, b) {
    jb(this, a, b, !1);
  };
  ib.prototype.Kh = function (a, b) {
    jb(this, a, b, !0);
  };
  var jb = function (a, b, c, d) {
    if (!a.Jb)
      if (d) {
        var e = a.values;
        e.set(b, c);
        e.D["dust." + b] = !0;
      } else a.values.set(b, c);
  };
  l = ib.prototype;
  l.set = function (a, b) {
    this.Jb ||
      (!this.values.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.values.set(a, b));
  };
  l.get = function (a) {
    return this.values.has(a)
      ? this.values.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  l.has = function (a) {
    return !!this.values.has(a) || !(!this.parent || !this.parent.has(a));
  };
  l.yb = function () {
    var a = new ib(this.U, this);
    this.D && a.Tb(this.D);
    a.rd(this.J);
    a.he(this.M);
    return a;
  };
  l.Xd = function () {
    return this.U;
  };
  l.Tb = function (a) {
    this.D = a;
  };
  l.Pn = function () {
    return this.D;
  };
  l.rd = function (a) {
    this.J = a;
  };
  l.Fj = function () {
    return this.J;
  };
  l.Ya = function () {
    this.Jb = !0;
  };
  l.he = function (a) {
    this.M = a;
  };
  l.lb = function () {
    return this.M;
  };
  var kb = function () {
    this.Pa = !1;
    this.na = new Ta();
  };
  l = kb.prototype;
  l.get = function (a) {
    return this.na.get(a);
  };
  l.set = function (a, b) {
    this.Pa || this.na.set(a, b);
  };
  l.has = function (a) {
    return this.na.has(a);
  };
  l.remove = function (a) {
    this.Pa || this.na.remove(a);
  };
  l.Ga = function () {
    return this.na.Ga();
  };
  l.fc = function () {
    return this.na.fc();
  };
  l.bc = function () {
    return this.na.bc();
  };
  l.Ya = function () {
    this.Pa = !0;
  };
  l.Jb = function () {
    return this.Pa;
  };
  function lb() {
    for (var a = mb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
    return b;
  }
  function nb() {
    var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    a += a.toLowerCase() + "0123456789-_";
    return a + ".";
  }
  var mb, ob;
  function pb(a) {
    mb = mb || nb();
    ob = ob || lb();
    for (var b = [], c = 0; c < a.length; c += 3) {
      var d = c + 1 < a.length,
        e = c + 2 < a.length,
        f = a.charCodeAt(c),
        g = d ? a.charCodeAt(c + 1) : 0,
        h = e ? a.charCodeAt(c + 2) : 0,
        k = f >> 2,
        m = ((f & 3) << 4) | (g >> 4),
        p = ((g & 15) << 2) | (h >> 6),
        q = h & 63;
      e || ((q = 64), d || (p = 64));
      b.push(mb[k], mb[m], mb[p], mb[q]);
    }
    return b.join("");
  }
  function qb(a) {
    function b(k) {
      for (; d < a.length; ) {
        var m = a.charAt(d++),
          p = ob[m];
        if (p != null) return p;
        if (!/^[\s\xa0]*$/.test(m))
          throw Error("Unknown base64 encoding at char: " + m);
      }
      return k;
    }
    mb = mb || nb();
    ob = ob || lb();
    for (var c = "", d = 0; ; ) {
      var e = b(-1),
        f = b(0),
        g = b(64),
        h = b(64);
      if (h === 64 && e === -1) return c;
      c += String.fromCharCode((e << 2) | (f >> 4));
      g !== 64 &&
        ((c += String.fromCharCode(((f << 4) & 240) | (g >> 2))),
        h !== 64 && (c += String.fromCharCode(((g << 6) & 192) | h)));
    }
  }
  var rb = {};
  function sb(a, b) {
    var c = rb[a];
    c || (c = rb[a] = []);
    c[b] = !0;
  }
  function tb() {
    delete rb.GA4_EVENT;
  }
  function ub(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++)
      d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), (c = 0)),
        a[d] && (c |= 1 << d % 8);
    c > 0 && b.push(String.fromCharCode(c));
    return pb(b.join("")).replace(/\.+$/, "");
  } /*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
  var xb = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    yb = function (a) {
      if (a == null) return String(a);
      var b = xb.exec(Object.prototype.toString.call(Object(a)));
      return b ? b[1].toLowerCase() : "object";
    },
    zb = function (a, b) {
      return Object.prototype.hasOwnProperty.call(Object(a), b);
    },
    Ab = function (a) {
      if (!a || yb(a) != "object" || a.nodeType || a == a.window) return !1;
      try {
        if (
          a.constructor &&
          !zb(a, "constructor") &&
          !zb(a.constructor.prototype, "isPrototypeOf")
        )
          return !1;
      } catch (c) {
        return !1;
      }
      for (var b in a);
      return b === void 0 || zb(a, b);
    },
    Bb = function (a, b) {
      var c = b || (yb(a) == "array" ? [] : {}),
        d;
      for (d in a)
        if (zb(a, d) && d !== "__proto__") {
          var e = a[d];
          yb(e) == "array"
            ? (yb(c[d]) != "array" && (c[d] = []), (c[d] = Bb(e, c[d])))
            : Ab(e)
            ? (Ab(c[d]) || (c[d] = {}), (c[d] = Bb(e, c[d])))
            : (c[d] = e);
        }
      return c;
    };
  function Cb() {}
  function Db(a) {
    return typeof a === "function";
  }
  function Eb(a) {
    return typeof a === "string";
  }
  function Fb(a) {
    return typeof a === "number" && !isNaN(a);
  }
  function Gb(a) {
    return Array.isArray(a) ? a : [a];
  }
  function Hb(a, b) {
    if (a && Array.isArray(a))
      for (var c = 0; c < a.length; c++) if (a[c] && b(a[c])) return a[c];
  }
  function Ib(a, b) {
    if (!Fb(a) || !Fb(b) || a > b) (a = 0), (b = 2147483647);
    return Math.floor(Math.random() * (b - a + 1) + a);
  }
  function Jb(a, b) {
    for (var c = new Kb(), d = 0; d < a.length; d++) c.set(a[d], !0);
    for (var e = 0; e < b.length; e++) if (c.get(b[e])) return !0;
    return !1;
  }
  function Lb(a, b) {
    for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c]);
  }
  function Mb(a) {
    return (
      !!a &&
      (Object.prototype.toString.call(a) === "[object Arguments]" ||
        Object.prototype.hasOwnProperty.call(a, "callee"))
    );
  }
  function Nb(a) {
    return Math.round(Number(a)) || 0;
  }
  function Ob(a) {
    return "false" === String(a).toLowerCase() ? !1 : !!a;
  }
  function Pb(a) {
    var b = [];
    if (Array.isArray(a))
      for (var c = 0; c < a.length; c++) b.push(String(a[c]));
    return b;
  }
  function Qb(a) {
    return a ? a.replace(/^\s+|\s+$/g, "") : "";
  }
  function Rb() {
    return new Date(Date.now());
  }
  function Sb() {
    return Rb().getTime();
  }
  var Kb = function () {
    this.prefix = "gtm.";
    this.values = {};
  };
  Kb.prototype.set = function (a, b) {
    this.values[this.prefix + a] = b;
  };
  Kb.prototype.get = function (a) {
    return this.values[this.prefix + a];
  };
  Kb.prototype.contains = function (a) {
    return this.get(a) !== void 0;
  };
  function Tb(a, b, c) {
    return a && a.hasOwnProperty(b) ? a[b] : c;
  }
  function Wb(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = void 0;
        try {
          c();
        } catch (d) {}
      }
    };
  }
  function Xb(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
  }
  function Yb(a, b) {
    for (var c = [], d = 0; d < a.length; d++)
      c.push(a[d]), c.push.apply(c, b[a[d]] || []);
    return c;
  }
  function Zb(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b;
  }
  function $b(a, b) {
    return (
      a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    );
  }
  function ac(a, b, c) {
    c = c || [];
    for (var d = a, e = 0; e < b.length - 1; e++) {
      if (!d.hasOwnProperty(b[e])) return;
      d = d[b[e]];
      if (c.indexOf(d) >= 0) return;
    }
    return d;
  }
  function bc(a, b) {
    for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++)
      d = d[e[f]] = {};
    d[e[e.length - 1]] = b;
    return c;
  }
  var cc = /^\w{1,9}$/;
  function dc(a, b) {
    a = a || {};
    b = b || ",";
    var c = [];
    Lb(a, function (d, e) {
      cc.test(d) && e && c.push(d);
    });
    return c.join(b);
  }
  function ec(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      d < 128
        ? b.push(d)
        : d < 2048
        ? b.push(192 | (d >> 6), 128 | (d & 63))
        : d < 55296 || d >= 57344
        ? b.push(224 | (d >> 12), 128 | ((d >> 6) & 63), 128 | (d & 63))
        : ((d = 65536 + (((d & 1023) << 10) | (a.charCodeAt(++c) & 1023))),
          b.push(
            240 | (d >> 18),
            128 | ((d >> 12) & 63),
            128 | ((d >> 6) & 63),
            128 | (d & 63)
          ));
    }
    return new Uint8Array(b);
  }
  function fc(a) {
    if (!a) return a;
    var b = a;
    try {
      b = decodeURIComponent(a);
    } catch (d) {}
    var c = b.split(",");
    return c.length === 2 && c[0] === c[1] ? c[0] : a;
  }
  function ic(a, b, c) {
    function d(m) {
      var p = m.split("=")[0];
      if (a.indexOf(p) < 0) return m;
      if (c !== void 0) return p + "=" + c;
    }
    function e(m) {
      return m
        .split("&")
        .map(d)
        .filter(function (p) {
          return p !== void 0;
        })
        .join("&");
    }
    var f = b.href.split(/[?#]/)[0],
      g = b.search,
      h = b.hash;
    g[0] === "?" && (g = g.substring(1));
    h[0] === "#" && (h = h.substring(1));
    g = e(g);
    h = e(h);
    g !== "" && (g = "?" + g);
    h !== "" && (h = "#" + h);
    var k = "" + f + g + h;
    k[k.length - 1] === "/" && (k = k.substring(0, k.length - 1));
    return k;
  }
  function jc(a) {
    for (var b = 0; b < 3; ++b)
      try {
        var c = decodeURIComponent(a).replace(/\+/g, " ");
        if (c === a) break;
        a = c;
      } catch (d) {
        return "";
      }
    return a;
  }
  function kc() {
    var a = x,
      b;
    a: {
      var c = a.crypto || a.msCrypto;
      if (c && c.getRandomValues)
        try {
          var d = new Uint8Array(25);
          c.getRandomValues(d);
          b = lc(String.fromCharCode.apply(String, xa(d)));
          break a;
        } catch (e) {}
      b = void 0;
    }
    return b;
  }
  function lc(a) {
    return btoa(a).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function mc(a) {
    var b = a;
    for (b.length > 95 && (b = b.substring(0, 95)); b.length > 0; )
      try {
        var c = encodeURIComponent(b).replace(
            /%([0-9A-F]{2})/g,
            function (e, f) {
              return String.fromCharCode(Number("0x" + f));
            }
          ),
          d = lc(c);
        if (d.length <= 95) return d;
        b = b.slice(0, -1);
      } catch (e) {
        if (e instanceof URIError && b.length > 0) b = b.slice(0, -1);
        else throw e;
      }
    return "";
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var nc = globalThis.trustedTypes,
    oc;
  function pc() {
    var a = null;
    if (!nc) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = nc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function qc() {
    oc === void 0 && (oc = pc());
    return oc;
  }
  var rc = function (a) {
    this.D = a;
  };
  rc.prototype.toString = function () {
    return this.D + "";
  };
  function sc(a) {
    var b = a,
      c = qc(),
      d = c ? c.createScriptURL(b) : b;
    return new rc(d);
  }
  function tc(a) {
    if (a instanceof rc) return a.D;
    throw Error("");
  }
  var uc = za([""]),
    vc = ya(["\x00"], ["\\0"]),
    wc = ya(["\n"], ["\\n"]),
    xc = ya(["\x00"], ["\\u0000"]);
  function yc(a) {
    return a.toString().indexOf("`") === -1;
  }
  yc(function (a) {
    return a(uc);
  }) ||
    yc(function (a) {
      return a(vc);
    }) ||
    yc(function (a) {
      return a(wc);
    }) ||
    yc(function (a) {
      return a(xc);
    });
  var zc = function (a) {
    this.D = a;
  };
  zc.prototype.toString = function () {
    return this.D;
  };
  var Ac = function (a) {
    this.isValid = a;
  };
  function Bc(a) {
    return new Ac(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var Cc = [
    Bc("data"),
    Bc("http"),
    Bc("https"),
    Bc("mailto"),
    Bc("ftp"),
    new Ac(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function Dc(a) {
    var b;
    b = b === void 0 ? Cc : b;
    if (a instanceof zc) return a;
    for (var c = 0; c < b.length; ++c) {
      var d = b[c];
      if (d instanceof Ac && d.isValid(a)) return new zc(a);
    }
  }
  var Ec = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Fc(a) {
    var b;
    if (a instanceof zc)
      if (a instanceof zc) b = a.D;
      else throw Error("");
    else b = Ec.test(a) ? a : void 0;
    return b;
  }
  function Gc(a, b) {
    var c = Fc(b);
    c !== void 0 && (a.action = c);
  }
  function Hc(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var Ic = function (a) {
    this.D = a;
  };
  Ic.prototype.toString = function () {
    return this.D + "";
  };
  var Kc = function () {
    this.D = Jc[0].toLowerCase();
  };
  Kc.prototype.toString = function () {
    return this.D;
  };
  function Lc(a, b) {
    var c = [new Kc()];
    if (c.length === 0) throw Error("");
    var d = c.map(function (f) {
        var g;
        if (f instanceof Kc) g = f.D;
        else throw Error("");
        return g;
      }),
      e = b.toLowerCase();
    if (
      d.every(function (f) {
        return e.indexOf(f) !== 0;
      })
    )
      throw Error(
        'Attribute "' + b + '" does not match any of the allowed prefixes.'
      );
    a.setAttribute(b, "true");
  }
  var Mc = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Nc(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var x = window,
    Oc = [],
    Pc = window.history,
    A = document,
    Qc = navigator;
  function Rc() {
    var a;
    try {
      a = Qc.serviceWorker;
    } catch (b) {
      return;
    }
    return a;
  }
  var Sc,
    Tc = A.currentScript,
    Uc = (Sc = Tc && Tc.tagName === "SCRIPT" ? Tc : null) && Sc.src;
  function Vc(a, b) {
    var c = x,
      d = c[a];
    c[a] = d === void 0 ? b : d;
    return c[a];
  }
  function Wc(a) {
    return (Qc.userAgent || "").indexOf(a) !== -1;
  }
  function Xc() {
    return Wc("Firefox") || Wc("FxiOS");
  }
  function Yc() {
    return (Wc("GSA") || Wc("GoogleApp")) && (Wc("iPhone") || Wc("iPad"));
  }
  function Zc() {
    return Wc("Edg/") || Wc("EdgA/") || Wc("EdgiOS/");
  }
  var $c = { async: 1, nonce: 1, onerror: 1, onload: 1, src: 1, type: 1 },
    ad = { height: 1, onload: 1, src: 1, style: 1, width: 1 };
  function bd(a, b, c) {
    b &&
      Lb(b, function (d, e) {
        d = d.toLowerCase();
        c.hasOwnProperty(d) || a.setAttribute(d, e);
      });
  }
  function cd(a, b, c, d, e) {
    var f = A.createElement("script");
    bd(f, d, $c);
    f.type = "text/javascript";
    f.async = d && d.async === !1 ? !1 : !0;
    var g;
    g = sc(Nc(a));
    f.src = tc(g);
    var h,
      k = f.ownerDocument;
    k = k === void 0 ? document : k;
    var m,
      p,
      q =
        (p = (m = k).querySelector) == null
          ? void 0
          : p.call(m, "script[nonce]");
    (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") &&
      f.setAttribute("nonce", h);
    b && (f.onload = b);
    c && (f.onerror = c);
    e ? e.appendChild(f) : dd.Ys(f);
    return f;
  }
  function fd() {
    if (Uc) {
      var a = Uc.toLowerCase();
      if (a.indexOf("https://") === 0) return 2;
      if (a.indexOf("http://") === 0) return 3;
    }
    return 1;
  }
  function gd(a, b, c, d, e, f) {
    f = f === void 0 ? !0 : f;
    var g = e,
      h = !1;
    g || ((g = A.createElement("iframe")), (h = !0));
    bd(g, c, ad);
    d &&
      Lb(d, function (m, p) {
        g.dataset[m] = p;
      });
    f &&
      ((g.height = "0"),
      (g.width = "0"),
      (g.style.display = "none"),
      (g.style.visibility = "hidden"));
    a !== void 0 && (g.src = a);
    if (h) {
      var k = (A.body && A.body.lastChild) || A.body || A.head;
      k.parentNode.insertBefore(g, k);
    }
    b && (g.onload = b);
    return g;
  }
  function hd() {
    return dd.bs.apply(dd, xa(Oa.apply(0, arguments)));
  }
  function id(a, b, c, d) {
    a.addEventListener && a.addEventListener(b, c, !!d);
  }
  function jd(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1);
  }
  function kd(a) {
    x.setTimeout(a, 0);
  }
  function ld(a, b) {
    var c = Oa.apply(2, arguments),
      d,
      e = (d = x).setInterval.apply(d, [a, b].concat(xa(c)));
    Oc.push(e);
    return e;
  }
  function md(a) {
    var b = x;
    if (Db(b.queueMicrotask))
      try {
        b.queueMicrotask(a);
        return;
      } catch (d) {}
    var c;
    Db((c = b.Promise) == null ? void 0 : c.resolve)
      ? b.Promise.resolve()
          .then(function () {
            a();
          })
          .catch(function () {})
      : kd(a);
  }
  function nd(a, b) {
    return a && b && a.attributes && a.attributes[b]
      ? a.attributes[b].value
      : null;
  }
  function od(a) {
    var b = a.innerText || a.textContent || "";
    b &&
      b !== " " &&
      ((b = b.replace(/^[\s\xa0]+/g, "")), (b = b.replace(/[\s\xa0]+$/g, "")));
    b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
    return b;
  }
  function pd(a) {
    var b = A.createElement("div"),
      c = b,
      d,
      e;
    e = Nc("A<div>" + a + "</div>");
    var f = e,
      g = qc(),
      h = g ? g.createHTML(f) : f;
    d = new Ic(h);
    if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
      throw Error("");
    var k;
    if (d instanceof Ic) k = d.D;
    else throw Error("");
    c.innerHTML = k;
    b = b.lastChild;
    for (var m = []; b && b.firstChild; ) m.push(b.removeChild(b.firstChild));
    return m;
  }
  function qd(a, b, c) {
    c = c || 100;
    for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
    for (var f = a, g = 0; f && g <= c; g++) {
      if (d[String(f.tagName).toLowerCase()]) return f;
      f = f.parentElement;
    }
    return null;
  }
  function rd(a, b, c) {
    var d;
    try {
      d = Qc.sendBeacon && Qc.sendBeacon(a);
    } catch (e) {
      sb("TAGGING", 15);
    }
    d ? b == null || b() : hd(a, b, c);
  }
  function sd(a, b) {
    try {
      if (Qc.sendBeacon !== void 0) return Qc.sendBeacon(a, b);
    } catch (c) {
      sb("TAGGING", 15);
    }
    return !1;
  }
  function td() {
    return Qc.sendBeacon !== void 0;
  }
  var ud = {
    cache: "no-store",
    credentials: "include",
    keepalive: !0,
    method: "POST",
    mode: "no-cors",
    redirect: "follow",
  };
  function vd(a, b, c, d, e) {
    if (wd()) {
      var f = ma(Object, "assign").call(Object, {}, ud);
      b && (f.body = b);
      c &&
        (c.attributionReporting &&
          (f.attributionReporting = c.attributionReporting),
        c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics),
        c.credentials && (f.credentials = c.credentials),
        c.keepalive !== void 0 && (f.keepalive = c.keepalive),
        c.method && (f.method = c.method),
        c.mode && (f.mode = c.mode));
      try {
        var g = x.fetch(a, f);
        if (g)
          return (
            g
              .then(function (k) {
                k && (k.ok || k.status === 0)
                  ? d == null || d()
                  : e == null || e();
              })
              .catch(function () {
                e == null || e();
              }),
            !0
          );
      } catch (k) {}
    }
    if (
      (c == null ? 0 : c.Zn) ||
      ((c == null ? 0 : c.credentials) && c.credentials !== "include")
    )
      return e == null || e(), !1;
    if (b) {
      var h = sd(a, b);
      h ? d == null || d() : e == null || e();
      return h;
    }
    dd.Xt(a, d, e);
    return !0;
  }
  function wd() {
    return Db(x.fetch);
  }
  function xd(a, b) {
    var c = a[b];
    c && typeof c.animVal === "string" && (c = c.animVal);
    return c;
  }
  function yd() {
    var a = x.performance;
    if (a && Db(a.now)) return a.now();
  }
  function zd() {
    var a,
      b = x.performance;
    if (b && b.getEntriesByType)
      try {
        var c = b.getEntriesByType("navigation");
        c && c.length > 0 && (a = c[0].type);
      } catch (d) {
        return "e";
      }
    if (!a) return "u";
    switch (a) {
      case "navigate":
        return "n";
      case "back_forward":
        return "h";
      case "reload":
        return "r";
      case "prerender":
        return "p";
      default:
        return "x";
    }
  }
  function Ad() {
    return x.performance || void 0;
  }
  function Bd() {
    var a = x.webPixelsManager;
    return a ? a.createShopifyExtend !== void 0 : !1;
  }
  var dd = {
    bs: function (a, b, c, d) {
      var e = new Image(1, 1);
      bd(e, d, {});
      e.onload = function () {
        e.onload = null;
        b && b();
      };
      e.onerror = function () {
        e.onerror = null;
        c && c();
      };
      e.src = a;
      return e;
    },
    Ys: function (a) {
      var b = A.getElementsByTagName("script")[0] || A.body || A.head;
      b.parentNode.insertBefore(a, b);
    },
    Xt: rd,
  };
  function Cd(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function Dd(a, b) {
    return this.evaluate(a) === this.evaluate(b);
  }
  function Ed(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Fd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    return String(c).indexOf(String(d)) > -1;
  }
  function Gd(a, b) {
    var c = String(this.evaluate(a)),
      d = String(this.evaluate(b));
    return c.substring(0, d.length) === d;
  }
  function Hd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    switch (c) {
      case "pageLocation":
        var e = x.location.href;
        d instanceof kb &&
          d.get("stripProtocol") &&
          (e = e.replace(/^https?:\/\//, ""));
        return e;
    }
  }
  function Id(a) {
    return (
      (typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0) ||
      (typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a))
    );
  }
  var Jd = function (a) {
    a = a === void 0 ? [] : a;
    this.na = new Ta();
    this.values = [];
    this.Pa = !1;
    for (var b in a)
      a.hasOwnProperty(b) &&
        (Id(b)
          ? (this.values[Number(b)] = a[Number(b)])
          : this.na.set(b, a[b]));
  };
  l = Jd.prototype;
  l.toString = function (a) {
    if (a && a.indexOf(this) >= 0) return "";
    for (var b = [], c = 0; c < this.values.length; c++) {
      var d = this.values[c];
      d === null || d === void 0
        ? b.push("")
        : d instanceof Jd
        ? ((a = a || []), a.push(this), b.push(d.toString(a)), a.pop())
        : b.push(String(d));
    }
    return b.join(",");
  };
  l.set = function (a, b) {
    if (!this.Pa)
      if (a === "length") {
        if (!Id(b))
          throw cb(
            Error("RangeError: Length property must be a valid integer.")
          );
        this.values.length = Number(b);
      } else Id(a) ? (this.values[Number(a)] = b) : this.na.set(a, b);
  };
  l.get = function (a) {
    return a === "length"
      ? this.length()
      : Id(a)
      ? this.values[Number(a)]
      : this.na.get(a);
  };
  l.length = function () {
    return this.values.length;
  };
  l.Ga = function () {
    for (var a = this.na.Ga(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(String(b));
    return a;
  };
  l.fc = function () {
    for (var a = this.na.fc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(this.values[b]);
    return a;
  };
  l.bc = function () {
    for (var a = this.na.bc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
    return a;
  };
  l.remove = function (a) {
    Id(a) ? delete this.values[Number(a)] : this.Pa || this.na.remove(a);
  };
  l.pop = function () {
    return this.values.pop();
  };
  l.push = function () {
    return this.values.push.apply(this.values, xa(Oa.apply(0, arguments)));
  };
  l.shift = function () {
    return this.values.shift();
  };
  l.splice = function (a, b) {
    var c = Oa.apply(2, arguments);
    return b === void 0 && c.length === 0
      ? new Jd(this.values.splice(a))
      : new Jd(
          this.values.splice.apply(this.values, [a, b || 0].concat(xa(c)))
        );
  };
  l.unshift = function () {
    return this.values.unshift.apply(this.values, xa(Oa.apply(0, arguments)));
  };
  l.has = function (a) {
    return (Id(a) && this.values.hasOwnProperty(a)) || this.na.has(a);
  };
  l.Ya = function () {
    this.Pa = !0;
    Object.freeze(this.values);
  };
  l.Jb = function () {
    return this.Pa;
  };
  function Kd(a) {
    for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
    return b;
  }
  var Ld = function (a, b) {
    this.functionName = a;
    this.fn = b;
    this.na = new Ta();
    this.Pa = !1;
  };
  l = Ld.prototype;
  l.toString = function () {
    return this.functionName;
  };
  l.getName = function () {
    return this.functionName;
  };
  l.getKeys = function () {
    return new Jd(this.Ga());
  };
  l.invoke = function (a) {
    return this.fn.call.apply(
      this.fn,
      [new Md(this, a)].concat(xa(Oa.apply(1, arguments)))
    );
  };
  l.apply = function (a, b) {
    return this.fn.apply(new Md(this, a), b);
  };
  l.Jc = function (a) {
    var b = Oa.apply(1, arguments);
    try {
      return this.invoke.apply(this, [a].concat(xa(b)));
    } catch (c) {}
  };
  l.get = function (a) {
    return this.na.get(a);
  };
  l.set = function (a, b) {
    this.Pa || this.na.set(a, b);
  };
  l.has = function (a) {
    return this.na.has(a);
  };
  l.remove = function (a) {
    this.Pa || this.na.remove(a);
  };
  l.Ga = function () {
    return this.na.Ga();
  };
  l.fc = function () {
    return this.na.fc();
  };
  l.bc = function () {
    return this.na.bc();
  };
  l.Ya = function () {
    this.Pa = !0;
  };
  l.Jb = function () {
    return this.Pa;
  };
  var Nd = function (a, b) {
    Ld.call(this, a, b);
  };
  ta(Nd, Ld);
  var Od = function (a, b) {
    Ld.call(this, a, b);
  };
  ta(Od, Ld);
  var Md = function (a, b) {
    this.fn = a;
    this.T = b;
  };
  Md.prototype.evaluate = function (a) {
    var b = this.T;
    return Array.isArray(a) ? fb(b, a) : a;
  };
  Md.prototype.getName = function () {
    return this.fn.getName();
  };
  Md.prototype.Xd = function () {
    return this.T.Xd();
  };
  var Pd = function () {
    this.map = new Map();
  };
  Pd.prototype.set = function (a, b) {
    this.map.set(a, b);
  };
  Pd.prototype.get = function (a) {
    return this.map.get(a);
  };
  var Qd = function () {
    this.keys = [];
    this.values = [];
  };
  Qd.prototype.set = function (a, b) {
    this.keys.push(a);
    this.values.push(b);
  };
  Qd.prototype.get = function (a) {
    var b = this.keys.indexOf(a);
    if (b > -1) return this.values[b];
  };
  function Rd() {
    try {
      return Map ? new Pd() : new Qd();
    } catch (a) {
      return new Qd();
    }
  }
  var Sd = function (a) {
    if (a instanceof Sd) return a;
    var b;
    a: if (a == void 0 || Array.isArray(a) || Ab(a)) b = !0;
    else {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "function":
          b = !0;
          break a;
      }
      b = !1;
    }
    if (b) throw Error("Type of given value has an equivalent Pixie type.");
    this.value = a;
  };
  Sd.prototype.getValue = function () {
    return this.value;
  };
  Sd.prototype.toString = function () {
    return String(this.value);
  };
  var Ud = function (a) {
    this.promise = a;
    this.Pa = this.Tn = !1;
    this.na = new Ta();
    this.na.set("then", Td(this));
    this.na.set("catch", Td(this, !0));
    this.na.set("finally", Td(this, !1, !0));
  };
  l = Ud.prototype;
  l.get = function (a) {
    return this.na.get(a);
  };
  l.set = function (a, b) {
    this.Pa || this.na.set(a, b);
  };
  l.has = function (a) {
    return this.na.has(a);
  };
  l.remove = function (a) {
    this.Pa || this.na.remove(a);
  };
  l.Ga = function () {
    return this.na.Ga();
  };
  l.fc = function () {
    return this.na.fc();
  };
  l.bc = function () {
    return this.na.bc();
  };
  var Td = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    return new Nd("", function (d, e) {
      a.Tn = !0;
      b && ((e = d), (d = void 0));
      c && (e = d);
      d instanceof Nd || (d = void 0);
      e instanceof Nd || (e = void 0);
      var f = this.T.yb(),
        g = function (k) {
          return function (m) {
            try {
              return c ? (k.invoke(f), a.promise) : k.invoke(f, m);
            } catch (p) {
              return Promise.reject(p instanceof Error ? new Sd(p) : String(p));
            }
          };
        },
        h = a.promise.then(d && g(d), e && g(e));
      return new Ud(h);
    });
  };
  Ud.prototype.Ya = function () {
    this.Pa = !0;
  };
  Ud.prototype.Jb = function () {
    return this.Pa;
  };
  function B(a, b, c) {
    var d = Rd(),
      e = function (g, h) {
        for (var k = g.Ga(), m = 0; m < k.length; m++) h[k[m]] = f(g.get(k[m]));
      },
      f = function (g) {
        if (g === null || g === void 0) return g;
        var h = d.get(g);
        if (h) return h;
        if (g instanceof Jd) {
          var k = [];
          d.set(g, k);
          for (var m = g.Ga(), p = 0; p < m.length; p++)
            k[m[p]] = f(g.get(m[p]));
          return k;
        }
        if (g instanceof Ud)
          return g.promise.then(
            function (u) {
              return B(u, b, 1);
            },
            function (u) {
              return Promise.reject(B(u, b, 1));
            }
          );
        if (g instanceof kb) {
          var q = {};
          d.set(g, q);
          e(g, q);
          return q;
        }
        if (g instanceof Nd) {
          var r = function () {
            for (var u = [], v = 0; v < arguments.length; v++)
              u[v] = Vd(arguments[v], b, c);
            var w = new ib(b ? b.Xd() : new Va());
            b && w.he(b.lb());
            return f(g.apply(w, u));
          };
          d.set(g, r);
          e(g, r);
          return r;
        }
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          case 3:
            t = !1;
            break;
          default:
        }
        if (g instanceof Sd && t) return g.getValue();
        switch (typeof g) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return g;
          case "object":
            if (g === null) return null;
        }
      };
    return f(a);
  }
  function Vd(a, b, c) {
    var d = Rd(),
      e = function (g, h) {
        for (var k in g) g.hasOwnProperty(k) && h.set(k, f(g[k]));
      },
      f = function (g) {
        var h = d.get(g);
        if (h) return h;
        if (Array.isArray(g) || Mb(g)) {
          var k = new Jd();
          d.set(g, k);
          for (var m in g) g.hasOwnProperty(m) && k.set(m, f(g[m]));
          return k;
        }
        if (Ab(g)) {
          var p = new kb();
          d.set(g, p);
          e(g, p);
          return p;
        }
        if (typeof g === "function") {
          var q = new Nd("", function () {
            for (
              var u = Oa.apply(0, arguments), v = [], w = 0;
              w < u.length;
              w++
            )
              v[w] = B(this.evaluate(u[w]), b, c);
            return f(this.T.Fj()(g, g, v));
          });
          d.set(g, q);
          e(g, q);
          return q;
        }
        var r = typeof g;
        if (g === null || r === "string" || r === "number" || r === "boolean")
          return g;
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          default:
        }
        if (g !== void 0 && t) return new Sd(g);
      };
    return f(a);
  }
  var Wd = {
    supportedMethods:
      "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(
        " "
      ),
    concat: function (a) {
      for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
      for (var d = 1; d < arguments.length; d++)
        if (arguments[d] instanceof Jd)
          for (var e = arguments[d], f = 0; f < e.length(); f++)
            b.push(e.get(f));
        else b.push(arguments[d]);
      return new Jd(b);
    },
    every: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
      return !0;
    },
    filter: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
      return new Jd(d);
    },
    forEach: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        this.has(d) && b.invoke(a, this.get(d), d, this);
    },
    hasOwnProperty: function (a, b) {
      return this.has(b);
    },
    indexOf: function (a, b, c) {
      var d = this.length(),
        e = c === void 0 ? 0 : Number(c);
      e < 0 && (e = Math.max(d + e, 0));
      for (var f = e; f < d; f++)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    join: function (a, b) {
      for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
      return c.join(b);
    },
    lastIndexOf: function (a, b, c) {
      var d = this.length(),
        e = d - 1;
      c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
      for (var f = e; f >= 0; f--)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    map: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
      return new Jd(d);
    },
    pop: function () {
      return this.pop();
    },
    push: function (a) {
      return this.push.apply(this, xa(Oa.apply(1, arguments)));
    },
    reduce: function (a, b, c) {
      var d = this.length(),
        e,
        f = 0;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw cb(Error("TypeError: Reduce on List with no elements."));
        for (var g = 0; g < d; g++)
          if (this.has(g)) {
            e = this.get(g);
            f = g + 1;
            break;
          }
        if (g === d)
          throw cb(Error("TypeError: Reduce on List with no elements."));
      }
      for (var h = f; h < d; h++)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reduceRight: function (a, b, c) {
      var d = this.length(),
        e,
        f = d - 1;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw cb(Error("TypeError: ReduceRight on List with no elements."));
        for (var g = 1; g <= d; g++)
          if (this.has(d - g)) {
            e = this.get(d - g);
            f = d - (g + 1);
            break;
          }
        if (g > d)
          throw cb(Error("TypeError: ReduceRight on List with no elements."));
      }
      for (var h = f; h >= 0; h--)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reverse: function () {
      for (var a = Kd(this), b = a.length - 1, c = 0; b >= 0; b--, c++)
        a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
      return this;
    },
    shift: function () {
      return this.shift();
    },
    slice: function (a, b, c) {
      var d = this.length();
      b === void 0 && (b = 0);
      b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
      c = c === void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
      c = Math.max(b, c);
      for (var e = [], f = b; f < c; f++) e.push(this.get(f));
      return new Jd(e);
    },
    some: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
      return !1;
    },
    sort: function (a, b) {
      var c = Kd(this);
      b === void 0
        ? c.sort()
        : c.sort(function (e, f) {
            return Number(b.invoke(a, e, f));
          });
      for (var d = 0; d < c.length; d++)
        c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
      return this;
    },
    splice: function (a, b, c) {
      return this.splice.apply(this, [b, c].concat(xa(Oa.apply(3, arguments))));
    },
    toString: function () {
      return this.toString();
    },
    unshift: function (a) {
      return this.unshift.apply(this, xa(Oa.apply(1, arguments)));
    },
  };
  var Xd = {
      charAt: 1,
      concat: 1,
      indexOf: 1,
      lastIndexOf: 1,
      match: 1,
      replace: 1,
      search: 1,
      slice: 1,
      split: 1,
      substring: 1,
      toLowerCase: 1,
      toLocaleLowerCase: 1,
      toString: 1,
      toUpperCase: 1,
      toLocaleUpperCase: 1,
      trim: 1,
    },
    Yd = new Sa("break"),
    Zd = new Sa("continue");
  function $d(a, b) {
    return this.evaluate(a) + this.evaluate(b);
  }
  function ae(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function be(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!(f instanceof Jd))
      throw Error("Error: Non-List argument given to Apply instruction.");
    if (d === null || d === void 0)
      throw cb(Error("TypeError: Can't read property " + e + " of " + d + "."));
    var g = typeof d === "number";
    if (typeof d === "boolean" || g) {
      if (e === "toString") {
        if (g && f.length()) {
          var h = B(f.get(0));
          try {
            return d.toString(h);
          } catch (u) {}
        }
        return d.toString();
      }
      throw cb(Error("TypeError: " + d + "." + e + " is not a function."));
    }
    if (typeof d === "string") {
      if (Xd.hasOwnProperty(e)) {
        var k = B(f, void 0, 1);
        return Vd(d[e].apply(d, k), this.T);
      }
      throw cb(Error("TypeError: " + e + " is not a function"));
    }
    if (d instanceof Jd) {
      if (d.has(e)) {
        var m = d.get(String(e));
        if (m instanceof Nd) {
          var p = Kd(f);
          return m.apply(this.T, p);
        }
        throw cb(Error("TypeError: " + e + " is not a function"));
      }
      if (Wd.supportedMethods.indexOf(e) >= 0) {
        var q = Kd(f);
        return Wd[e].call.apply(Wd[e], [d, this.T].concat(xa(q)));
      }
    }
    if (d instanceof Nd || d instanceof kb || d instanceof Ud) {
      if (d.has(e)) {
        var r = d.get(e);
        if (r instanceof Nd) {
          var t = Kd(f);
          return r.apply(this.T, t);
        }
        throw cb(Error("TypeError: " + e + " is not a function"));
      }
      if (e === "toString") return d instanceof Nd ? d.getName() : d.toString();
      if (e === "hasOwnProperty") return d.has(f.get(0));
    }
    if (d instanceof Sd && e === "toString") return d.toString();
    throw cb(Error("TypeError: Object has no '" + e + "' property."));
  }
  function ce(a, b) {
    a = this.evaluate(a);
    if (typeof a !== "string")
      throw Error("Invalid key name given for assignment.");
    var c = this.T;
    if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
    var d = this.evaluate(b);
    c.set(a, d);
    return d;
  }
  function de() {
    var a = Oa.apply(0, arguments),
      b = this.T.yb(),
      c = eb(b, a);
    if (c instanceof Sa) return c;
  }
  function ee() {
    return Yd;
  }
  function fe(a) {
    for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
      var d = this.evaluate(b[c]);
      if (d instanceof Sa) return d;
    }
  }
  function ge() {
    for (var a = this.T, b = 0; b < arguments.length - 1; b += 2) {
      var c = arguments[b];
      if (typeof c === "string") {
        var d = this.evaluate(arguments[b + 1]);
        a.Kh(c, d);
      }
    }
  }
  function he() {
    return Zd;
  }
  function ie(a, b) {
    return new Sa(a, this.evaluate(b));
  }
  function je(a, b) {
    var c = Oa.apply(2, arguments),
      d;
    d = new Jd();
    for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
    var g = [51, a, d].concat(xa(c));
    this.T.add(a, this.evaluate(g));
  }
  function ke(a, b) {
    return this.evaluate(a) / this.evaluate(b);
  }
  function le(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b),
      e = c instanceof Sd,
      f = d instanceof Sd;
    return e || f ? (e && f ? c.getValue() === d.getValue() : !1) : c == d;
  }
  function me() {
    for (var a, b = 0; b < arguments.length; b++)
      a = this.evaluate(arguments[b]);
    return a;
  }
  function ne(a, b, c, d) {
    for (var e = 0; e < b(); e++) {
      var f = a(c(e)),
        g = eb(f, d);
      if (g instanceof Sa) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
    }
  }
  function oe(a, b, c) {
    if (typeof b === "string")
      return ne(
        a,
        function () {
          return b.length;
        },
        function (f) {
          return f;
        },
        c
      );
    if (
      b instanceof kb ||
      b instanceof Ud ||
      b instanceof Jd ||
      b instanceof Nd
    ) {
      var d = b.Ga(),
        e = d.length;
      return ne(
        a,
        function () {
          return e;
        },
        function (f) {
          return d[f];
        },
        c
      );
    }
  }
  function pe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return oe(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function qe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return oe(
      function (h) {
        var k = g.yb();
        k.Kh(d, h);
        return k;
      },
      e,
      f
    );
  }
  function re(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return oe(
      function (h) {
        var k = g.yb();
        k.add(d, h);
        return k;
      },
      e,
      f
    );
  }
  function se(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return te(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function ue(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return te(
      function (h) {
        var k = g.yb();
        k.Kh(d, h);
        return k;
      },
      e,
      f
    );
  }
  function ve(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.T;
    return te(
      function (h) {
        var k = g.yb();
        k.add(d, h);
        return k;
      },
      e,
      f
    );
  }
  function te(a, b, c) {
    if (typeof b === "string")
      return ne(
        a,
        function () {
          return b.length;
        },
        function (d) {
          return b[d];
        },
        c
      );
    if (b instanceof Jd)
      return ne(
        a,
        function () {
          return b.length();
        },
        function (d) {
          return b.get(d);
        },
        c
      );
    throw cb(Error("The value is not iterable."));
  }
  function we(a, b, c, d) {
    function e(q, r) {
      for (var t = 0; t < f.length(); t++) {
        var u = f.get(t);
        r.add(u, q.get(u));
      }
    }
    var f = this.evaluate(a);
    if (!(f instanceof Jd))
      throw Error("TypeError: Non-List argument given to ForLet instruction.");
    var g = this.T,
      h = this.evaluate(d),
      k = g.yb();
    for (e(g, k); fb(k, b); ) {
      var m = eb(k, h);
      if (m instanceof Sa) {
        if (m.type === "break") break;
        if (m.type === "return") return m;
      }
      var p = g.yb();
      e(k, p);
      fb(p, c);
      k = p;
    }
  }
  function xe(a, b) {
    var c = Oa.apply(2, arguments),
      d = this.T,
      e = this.evaluate(b);
    if (!(e instanceof Jd))
      throw Error("Error: non-List value given for Fn argument names.");
    return new Nd(
      a,
      (function () {
        return function () {
          var f = Oa.apply(0, arguments),
            g = d.yb();
          g.lb() === void 0 && g.he(this.T.lb());
          for (var h = [], k = 0; k < f.length; k++) {
            var m = this.evaluate(f[k]);
            h[k] = m;
          }
          for (var p = e.get("length"), q = 0; q < p; q++)
            q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
          g.add("arguments", new Jd(h));
          var r = eb(g, c);
          if (r instanceof Sa) return r.type === "return" ? r.data : r;
        };
      })()
    );
  }
  function ye(a) {
    var b = this.evaluate(a),
      c = this.T;
    if (ze && !c.has(b)) throw new ReferenceError(b + " is not defined.");
    return c.get(b);
  }
  function Ae(a, b) {
    var c,
      d = this.evaluate(a),
      e = this.evaluate(b);
    if (d === void 0 || d === null)
      throw cb(
        Error(
          "TypeError: Cannot read properties of " + d + " (reading '" + e + "')"
        )
      );
    if (
      d instanceof kb ||
      d instanceof Ud ||
      d instanceof Jd ||
      d instanceof Nd
    )
      c = d.get(e);
    else if (typeof d === "string")
      e === "length" ? (c = d.length) : Id(e) && (c = d[e]);
    else if (d instanceof Sd) return;
    return c;
  }
  function Be(a, b) {
    return this.evaluate(a) > this.evaluate(b);
  }
  function Ce(a, b) {
    return this.evaluate(a) >= this.evaluate(b);
  }
  function De(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    c instanceof Sd && (c = c.getValue());
    d instanceof Sd && (d = d.getValue());
    return c === d;
  }
  function Ee(a, b) {
    return !De.call(this, a, b);
  }
  function Fe(a, b, c) {
    var d = [];
    this.evaluate(a) ? (d = this.evaluate(b)) : c && (d = this.evaluate(c));
    var e = eb(this.T, d);
    if (e instanceof Sa) return e;
  }
  var ze = !1;
  function Ge(a, b) {
    return this.evaluate(a) < this.evaluate(b);
  }
  function He(a, b) {
    return this.evaluate(a) <= this.evaluate(b);
  }
  function Ie() {
    for (var a = new Jd(), b = 0; b < arguments.length; b++) {
      var c = this.evaluate(arguments[b]);
      a.push(c);
    }
    return a;
  }
  function Je() {
    for (var a = new kb(), b = 0; b < arguments.length - 1; b += 2) {
      var c = String(this.evaluate(arguments[b])),
        d = this.evaluate(arguments[b + 1]);
      a.set(c, d);
    }
    return a;
  }
  function Ke(a, b) {
    return this.evaluate(a) % this.evaluate(b);
  }
  function Le(a, b) {
    return this.evaluate(a) * this.evaluate(b);
  }
  function Me(a) {
    return -this.evaluate(a);
  }
  function Ne(a) {
    return !this.evaluate(a);
  }
  function Oe(a, b) {
    return !le.call(this, a, b);
  }
  function Pe() {
    return null;
  }
  function Qe(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Re(a, b) {
    var c = this.evaluate(a);
    this.evaluate(b);
    return c;
  }
  function Se(a) {
    return this.evaluate(a);
  }
  function Te() {
    return Oa.apply(0, arguments);
  }
  function Ue(a) {
    return new Sa("return", this.evaluate(a));
  }
  function Ve(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (d === null || d === void 0)
      throw cb(Error("TypeError: Can't set property " + e + " of " + d + "."));
    (d instanceof Nd || d instanceof Jd || d instanceof kb) &&
      d.set(String(e), f);
    return f;
  }
  function We(a, b) {
    return this.evaluate(a) - this.evaluate(b);
  }
  function Xe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!Array.isArray(e) || !Array.isArray(f))
      throw Error("Error: Malformed switch instruction.");
    for (var g, h = !1, k = 0; k < e.length; k++)
      if (h || d === this.evaluate(e[k]))
        if (((g = this.evaluate(f[k])), g instanceof Sa)) {
          var m = g.type;
          if (m === "break") return;
          if (m === "return" || m === "continue") return g;
        } else h = !0;
    if (
      f.length === e.length + 1 &&
      ((g = this.evaluate(f[f.length - 1])),
      g instanceof Sa && (g.type === "return" || g.type === "continue"))
    )
      return g;
  }
  function Ye(a, b, c) {
    return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c);
  }
  function Ze(a) {
    var b = this.evaluate(a);
    return b instanceof Nd ? "function" : typeof b;
  }
  function $e() {
    for (var a = this.T, b = 0; b < arguments.length; b++) {
      var c = arguments[b];
      typeof c !== "string" || a.add(c, void 0);
    }
  }
  function af(a, b, c, d) {
    var e = this.evaluate(d);
    if (this.evaluate(c)) {
      var f = eb(this.T, e);
      if (f instanceof Sa) {
        if (f.type === "break") return;
        if (f.type === "return") return f;
      }
    }
    for (; this.evaluate(a); ) {
      var g = eb(this.T, e);
      if (g instanceof Sa) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
      this.evaluate(b);
    }
  }
  function bf(a) {
    return ~Number(this.evaluate(a));
  }
  function cf(a, b) {
    return Number(this.evaluate(a)) << Number(this.evaluate(b));
  }
  function df(a, b) {
    return Number(this.evaluate(a)) >> Number(this.evaluate(b));
  }
  function ef(a, b) {
    return Number(this.evaluate(a)) >>> Number(this.evaluate(b));
  }
  function ff(a, b) {
    return Number(this.evaluate(a)) & Number(this.evaluate(b));
  }
  function gf(a, b) {
    return Number(this.evaluate(a)) ^ Number(this.evaluate(b));
  }
  function hf(a, b) {
    return Number(this.evaluate(a)) | Number(this.evaluate(b));
  }
  function jf() {}
  function kf(a, b, c) {
    try {
      var d = this.evaluate(b);
      if (d instanceof Sa) return d;
    } catch (h) {
      if (!(h instanceof bb && h.zn)) throw h;
      var e = this.T.yb();
      a !== "" && (h instanceof bb && (h = h.Wj), e.add(a, new Sd(h)));
      var f = this.evaluate(c),
        g = eb(e, f);
      if (g instanceof Sa) return g;
    }
  }
  function lf(a, b) {
    var c, d;
    try {
      d = this.evaluate(a);
    } catch (f) {
      if (!(f instanceof bb && f.zn)) throw f;
      c = f;
    }
    var e = this.evaluate(b);
    if (e instanceof Sa) return e;
    if (c) throw c;
    if (d instanceof Sa) return d;
  }
  var nf = function () {
    this.D = new hb();
    mf(this);
  };
  nf.prototype.execute = function (a) {
    return this.D.run(a);
  };
  var mf = function (a) {
    var b = function (c, d) {
      var e = new Od(String(c), d);
      e.Ya();
      var f = String(c);
      a.D.D.set(f, e);
      db.set(f, e);
    };
    b("map", Je);
    b("and", Cd);
    b("contains", Fd);
    b("equals", Dd);
    b("or", Ed);
    b("startsWith", Gd);
    b("variable", Hd);
  };
  nf.prototype.Tb = function (a) {
    this.D.Tb(a);
  };
  var pf = function () {
    this.J = !1;
    this.D = new hb();
    of(this);
    this.J = !0;
  };
  pf.prototype.execute = function (a) {
    return qf(this.D.run(a));
  };
  var rf = function (a, b, c) {
    return qf(a.D.Cq(b, c));
  };
  pf.prototype.Ya = function () {
    this.D.Ya();
  };
  var of = function (a) {
    var b = function (c, d) {
      var e = String(c),
        f = new Od(e, d);
      f.Ya();
      a.D.D.set(e, f);
      db.set(e, f);
    };
    b(0, $d);
    b(1, ae);
    b(2, be);
    b(3, ce);
    b(56, ff);
    b(57, cf);
    b(58, bf);
    b(59, hf);
    b(60, df);
    b(61, ef);
    b(62, gf);
    b(53, de);
    b(4, ee);
    b(5, fe);
    b(68, kf);
    b(52, ge);
    b(6, he);
    b(49, ie);
    b(7, Ie);
    b(8, Je);
    b(9, fe);
    b(50, je);
    b(10, ke);
    b(12, le);
    b(13, me);
    b(67, lf);
    b(51, xe);
    b(47, pe);
    b(54, qe);
    b(55, re);
    b(63, we);
    b(64, se);
    b(65, ue);
    b(66, ve);
    b(15, ye);
    b(16, Ae);
    b(17, Ae);
    b(18, Be);
    b(19, Ce);
    b(20, De);
    b(21, Ee);
    b(22, Fe);
    b(23, Ge);
    b(24, He);
    b(25, Ke);
    b(26, Le);
    b(27, Me);
    b(28, Ne);
    b(29, Oe);
    b(45, Pe);
    b(30, Qe);
    b(32, Re);
    b(33, Re);
    b(34, Se);
    b(35, Se);
    b(46, Te);
    b(36, Ue);
    b(43, Ve);
    b(37, We);
    b(38, Xe);
    b(39, Ye);
    b(40, Ze);
    b(44, jf);
    b(41, $e);
    b(42, af);
  };
  pf.prototype.Xd = function () {
    return this.D.Xd();
  };
  pf.prototype.Tb = function (a) {
    this.D.Tb(a);
  };
  pf.prototype.rd = function (a) {
    this.D.rd(a);
  };
  function qf(a) {
    if (
      a instanceof Sa ||
      a instanceof Nd ||
      a instanceof Jd ||
      a instanceof kb ||
      a instanceof Ud ||
      a instanceof Sd ||
      a === null ||
      a === void 0 ||
      typeof a === "string" ||
      typeof a === "number" ||
      typeof a === "boolean"
    )
      return a;
  }
  var sf = function (a) {
    this.message = a;
  };
  function tf(a) {
    a.Rv = !0;
    return a;
  }
  var uf = tf(function (a) {
      return typeof a === "number";
    }),
    vf = tf(function (a) {
      return typeof a === "string";
    }),
    wf = tf(function (a) {
      return typeof a === "boolean";
    });
  function xf(a) {
    var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
      a
    ];
    return b === void 0
      ? new sf(
          "Value " + a + " can not be encoded in web-safe base64 dictionary."
        )
      : b;
  }
  function yf(a) {
    switch (a) {
      case 1:
        return "1";
      case 2:
      case 4:
        return "0";
      default:
        return "-";
    }
  }
  var zf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;
  function Af(a, b) {
    for (var c = "", d = !0; a > 7; ) {
      var e = a & 31;
      a >>= 5;
      d ? (d = !1) : (e |= 32);
      c = "" + xf(e) + c;
    }
    a <<= 2;
    d || (a |= 32);
    return (c = "" + xf(a | b) + c);
  }
  function Bf(a, b) {
    return b === void 0 || b === 0 ? "" : "" + Af(a, 1) + xf(b);
  }
  function Cf(a, b) {
    var c;
    var d = a.di,
      e = a.Pj;
    d === void 0
      ? (c = "")
      : (e || (e = 0), (c = "" + Af(1, 1) + xf((d << 2) | e)));
    var f = "4" + c + Bf(2, a.Pr),
      g,
      h = a.runtimeVersion;
    g = h && zf.test(h) ? "" + Af(3, 2) + h : "";
    var k;
    var m = a.ctid;
    if (m && b) {
      var p = Af(5, 3),
        q = m.split("-"),
        r = q[0].toUpperCase();
      if (r !== "GTM" && r !== "OPT") k = "";
      else {
        var t = q[1];
        k = "" + p + xf(1 + t.length) + (a.nt || 0) + t;
      }
    } else k = "";
    var u = a.canonicalId,
      v = a.Ub,
      w = a.bw,
      y =
        f +
        g +
        Bf(4, a.releaseExperiment) +
        k +
        Bf(6, a.fu) +
        (u ? "" + Af(7, 3) + xf(u.length) + u : "") +
        (v ? "" + Af(8, 3) + xf(v.length) + v : "") +
        (w ? "" + Af(9, 3) + xf(w.length) + w : ""),
      z;
    var C = a.Wr;
    C = C === void 0 ? {} : C;
    var D = [],
      G = n(Object.keys(C)),
      F = G.next(),
      I;
    try {
      for (; !F.done; F = G.next()) {
        var L = F.value;
        D[Number(L)] = C[L];
      }
    } finally {
      F && !F.done && (I = G.return) && I.call(G);
    }
    if (D.length) {
      var P = Af(10, 3),
        R;
      if (D.length === 0) R = xf(0);
      else {
        for (var U = [], X = 0, ea = !1, ja = 0; ja < D.length; ja++) {
          ea = !0;
          var va = ja % 6;
          D[ja] && (X |= 1 << va);
          va === 5 && (U.push(xf(X)), (X = 0), (ea = !1));
        }
        ea && U.push(xf(X));
        R = U.join("");
      }
      var Ga = R;
      z = "" + P + xf(Ga.length) + Ga;
    } else z = "";
    var ka = a.Dt,
      ia = a.Rt;
    return (
      y +
      z +
      (ka ? "" + Af(11, 3) + xf(ka.length) + ka : "") +
      (ia ? "" + Af(13, 3) + xf(ia.length) + ia : "") +
      Bf(14, a.gu) +
      Bf(15, a.Vh) +
      Bf(16, a.Ao)
    );
  }
  function Df(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    return b;
  }
  function Ef(a, b) {
    for (var c = qb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++)
      d[e] = c.charCodeAt(e);
    if (d.length !== 32) throw Error("Key is not 32 bytes.");
    return Ff(a, d);
  }
  function Ff(a, b) {
    if (a === "") return "";
    var c = ec(a),
      d = b.slice(-2),
      e = [].concat(xa(d), xa(c)).map(function (g, h) {
        return g ^ b[h % b.length];
      }),
      f = new Uint8Array([].concat(xa(e), xa(d)));
    return pb(String.fromCharCode.apply(String, xa(f))).replace(/\.+$/, "");
  }
  function Gf(a, b) {
    var c = {};
    c["function"] = "__" + a;
    for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
    return c;
  }
  function Hf(a, b) {
    b = b === void 0 ? !1 : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? !!data.blob[a]
      : b;
  }
  function E(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? String(data.blob[a])
      : b;
  }
  function If(a) {
    var b, c;
    return (
      (b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)
    )
      ? Number(data.blob[a])
      : 0;
  }
  function Jf(a) {
    var b;
    b = b === void 0 ? [] : b;
    var c,
      d,
      e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
    return Array.isArray(e) ? e : b;
  }
  function Kf(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c = Lf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b;
  }
  function Mf(a, b) {
    var c = Lf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b;
  }
  function Lf(a) {
    var b, c;
    return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a];
  }
  var Nf = function (a, b, c) {
    var d;
    d = Error.call(this, c);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.permissionId = a;
    this.parameters = b;
    this.name = "PermissionError";
  };
  ta(Nf, Error);
  Nf.prototype.getMessage = function () {
    return this.message;
  };
  function Of(a, b) {
    if (Array.isArray(a)) {
      Object.defineProperty(a, "context", { value: { line: b[0] } });
      for (var c = 1; c < a.length; c++) Of(a[c], b[c]);
    }
  }
  function Pf() {
    return function (a, b) {
      var c;
      var d = Qf;
      a instanceof bb ? ((a.D = d), (c = a)) : (c = new bb(a, d));
      var e = c;
      b && e.debugInfo.push(b);
      throw e;
    };
  }
  function Qf(a) {
    if (!a.length) return a;
    a.push({ id: "main", line: 0 });
    for (var b = a.length - 1; b > 0; b--) Fb(a[b].id) && a.splice(b++, 1);
    for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
    a.splice(0, 1);
    return a;
  }
  var Rf = RegExp("[^0-9\\.+-]", "g"),
    Sf = RegExp("[^0-9\\,+-]", "g"),
    Tf = RegExp("[^0-9+-]", "g");
  function Uf(a, b) {
    if (typeof a === "number") return a;
    var c = String(a),
      d;
    if (b === "AUTOMATIC") {
      var e = (c.match(/\./g) || []).length,
        f = (c.match(/,/g) || []).length,
        g = "NONE";
      if (e > 0 && f > 0) {
        var h = c.lastIndexOf(".") > c.lastIndexOf(",");
        h && e === 1 ? (g = "PERIOD") : h || f !== 1 || (g = "COMMA");
      } else
        e === 1
          ? (g =
              (c.split(".")[1].match(/[0-9]/g) || []).length !== 3
                ? "PERIOD"
                : "NONE")
          : f === 1 &&
            (g =
              (c.split(",")[1].match(/[0-9]/g) || []).length !== 3
                ? "COMMA"
                : "NONE");
      d = g;
    } else d = b === "COMMA" ? "COMMA" : "PERIOD";
    var k, m;
    d === "PERIOD"
      ? ((k = "."), (m = Rf))
      : d === "COMMA"
      ? ((k = ","), (m = Sf))
      : ((k = ""), (m = Tf));
    var p = c.replace(m, "");
    if (k !== "" && p.split(k).length > 2) return a;
    var q = p.replace(/,/g, ".");
    if (q === "") return a;
    var r = Number(q);
    return isNaN(r) ? a : r;
  }
  var Vf = function () {
      this.D = {};
    },
    Wf = function (a, b, c) {
      var d;
      (d = a.D)[b] != null || (d[b] = []);
      a.D[b].push(function () {
        return c.apply(null, xa(Oa.apply(0, arguments)));
      });
    };
  function Xf(a, b, c, d) {
    if (a)
      for (var e = 0; e < a.length; e++) {
        var f = void 0,
          g = "A policy function denied the permission request";
        try {
          (f = a[e](b, c, d)), (g += ".");
        } catch (h) {
          g =
            typeof h === "string"
              ? g + (": " + h)
              : h instanceof Error
              ? g + (": " + h.message)
              : g + ".";
        }
        if (!f) throw new Nf(c, d, g);
      }
  }
  function Yf(a, b, c) {
    var d = Zf(a, c, function () {
      return {};
    });
    try {
      return d(b), !0;
    } catch (e) {
      return !1;
    }
  }
  function Zf(a, b, c) {
    return function (d) {
      if (d) {
        var e = a.D[d],
          f = a.D.all;
        if (e || f) {
          var g = c.apply(void 0, [d].concat(xa(Oa.apply(1, arguments))));
          Xf(e, b, d, g);
          Xf(f, b, d, g);
        }
      }
    };
  }
  var bg = function (a, b, c) {
      var d = this;
      this.J = {};
      this.D = new Vf();
      var e = {},
        f = {},
        g = Zf(this.D, a, function (h) {
          return h && e[h]
            ? e[h].apply(void 0, [h].concat(xa(Oa.apply(1, arguments))))
            : {};
        });
      Lb(b, function (h, k) {
        function m(q) {
          var r = Oa.apply(1, arguments);
          if (!p[q])
            throw $f(
              q,
              {},
              "The requested additional permission " + q + " is not configured."
            );
          g.apply(null, [q].concat(xa(r)));
        }
        var p = {};
        Lb(k, function (q, r) {
          var t = ag(q, r, c);
          p[q] = t.assert;
          e[q] || (e[q] = t.ba);
          t.wn && !f[q] && (f[q] = t.wn);
        });
        d.J[h] = function (q, r) {
          var t = p[q];
          if (!t)
            throw $f(
              q,
              {},
              "The requested permission " + q + " is not configured."
            );
          var u = Array.prototype.slice.call(arguments, 0);
          t.apply(void 0, u);
          g.apply(void 0, u);
          var v = f[q];
          v && v.apply(null, [m].concat(xa(u.slice(1))));
        };
      });
    },
    dg = function (a) {
      return cg.J[a] || function () {};
    };
  function ag(a, b, c) {
    try {
      var d = c["__" + a];
      if (!d) throw Error("No function found for permission: " + a + ".");
      var e = Gf(a, b);
      e.vtp_permissionName = a;
      e.vtp_createPermissionError = $f;
      delete e["function"];
      return d(e);
    } catch (f) {
      return {
        assert: function (g) {
          throw new Nf(g, {}, "Permission " + g + " is unknown.");
        },
        ba: function () {
          throw new Nf(a, {}, "Permission " + a + " is unknown.");
        },
      };
    }
  }
  function $f(a, b, c) {
    return new Nf(a, b, c);
  }
  function eg(a) {
    var b = 1,
      c,
      d,
      e;
    if (a)
      for (b = 0, d = a.length - 1; d >= 0; d--)
        (e = a.charCodeAt(d)),
          (b = ((b << 6) & 268435455) + e + (e << 14)),
          (c = b & 266338304),
          (b = c !== 0 ? b ^ (c >> 21) : b);
    return b;
  }
  var fg = function (a) {
    this.cache = a;
  };
  fg.prototype.get = function (a) {
    var b = eg(a),
      c = this.cache.get(b);
    if (!c) return { promise: void 0, Aj: 0 };
    if (Date.now() >= c.timestamp + 9e5)
      return this.cache.delete(b), { promise: void 0, Aj: 3 };
    var d = c.resolvedValue ? 2 : 1;
    return {
      promise: c.resolvedValue ? Promise.resolve(c.resolvedValue) : c.promise,
      Aj: d,
    };
  };
  fg.prototype.set = function (a, b) {
    var c = eg(a),
      d = { promise: b, resolvedValue: void 0, timestamp: Date.now() };
    this.cache.set(c, d);
    b.then(function (e) {
      d.resolvedValue = e;
    });
  };
  function gg(a) {
    switch (a) {
      case 0:
        break;
      case 9:
        return "e4";
      case 6:
        return "e5";
      case 14:
        return "e6";
      default:
        return "e7";
    }
  }
  var H = {
    A: {
      Wa: "ad_personalization",
      ja: "ad_storage",
      ma: "ad_user_data",
      wa: "analytics_storage",
      nc: "region",
      sa: "consent_updated",
      Vg: "wait_for_update",
      Zg: "endpoint_type",
      bp: "_&emfm",
      fp: "app_remove",
      hp: "app_store_refund",
      jp: "app_store_subscription_cancel",
      kp: "app_store_subscription_convert",
      lp: "app_store_subscription_renew",
      mp: "consent_update",
      np: "conversion",
      Wk: "add_payment_info",
      Xk: "add_shipping_info",
      me: "add_to_cart",
      ne: "remove_from_cart",
      Yk: "view_cart",
      vd: "begin_checkout",
      Iu: "generate_lead",
      oe: "select_item",
      Nc: "view_item_list",
      wd: "select_promotion",
      Oc: "view_promotion",
      Lb: "purchase",
      pe: "refund",
      oc: "view_item",
      Zk: "add_to_wishlist",
      pp: "exception",
      qp: "first_open",
      rp: "first_visit",
      ya: "gtag.config",
      Mb: "gtag.get",
      up: "in_app_purchase",
      qc: "page_view",
      vp: "screen_view",
      wp: "session_start",
      xp: "source_update",
      yp: "timing_complete",
      zp: "track_social",
      pf: "user_engagement",
      Ap: "user_id_update",
      ah: "braid_link_decoration_source",
      bh: "braid_storage_source",
      xd: "gclid_link_decoration_source",
      yd: "gclid_storage_source",
      Wb: "gclgb",
      pb: "gclid",
      bl: "gclid_len",
      qe: "gclgs",
      se: "gcllp",
      te: "gclst",
      qb: "ads_data_redaction",
      qf: "gad_source",
      rf: "gad_source_src",
      zd: "gclid_url",
      fl: "gclsrc",
      tf: "gbraid",
      ue: "wbraid",
      Pc: "allow_ad_personalization_signals",
      ji: "allow_custom_scripts",
      eh: "allow_display_features",
      ki: "allow_enhanced_conversions",
      Qc: "allow_google_signals",
      li: "allow_interest_groups",
      Bp: "app_id",
      Cp: "app_installer_id",
      Dp: "app_name",
      Ep: "app_version",
      Ad: "auid",
      Ju: "auto_detection_enabled",
      il: "auto_event",
      jl: "aw_remarketing",
      fh: "aw_remarketing_only",
      uf: "discount",
      vf: "aw_feed_country",
      wf: "aw_feed_language",
      Ia: "items",
      xf: "aw_merchant_id",
      mi: "aw_basket_type",
      yf: "campaign_content",
      zf: "campaign_id",
      Af: "campaign_medium",
      Bf: "campaign_name",
      Cf: "campaign",
      Df: "campaign_source",
      Ef: "campaign_term",
      Nb: "client_id",
      kl: "rnd",
      ni: "consent_update_type",
      Fp: "content_group",
      Gp: "content_type",
      Bd: "conversion_cookie_prefix",
      oi: "conversion_id",
      rc: "conversion_linker",
      gh: "conversion_linker_disabled",
      ve: "conversion_api",
      ri: "_&rcb",
      hh: "cookie_deprecation",
      Ob: "cookie_domain",
      Cb: "cookie_expires",
      Xb: "cookie_flags",
      Dd: "cookie_name",
      sc: "cookie_path",
      rb: "cookie_prefix",
      Ed: "cookie_update",
      Rc: "country",
      fb: "currency",
      we: "customer_lifetime_value",
      ih: "customer_type",
      xe: "custom_map",
      si: "gcldc_link_decoration_source",
      ui: "gcldc_storage_source",
      Ff: "gcldc",
      Fd: "dclid",
      wi: "debug_mode",
      Qa: "developer_id",
      Hp: "disable_merchant_reported_purchases",
      Sc: "dc_custom_params",
      Ip: "dc_natural_search",
      Jp: "dynamic_event_settings",
      ml: "affiliation",
      jh: "checkout_option",
      xi: "checkout_step",
      nl: "coupon",
      Gf: "item_list_name",
      yi: "list_name",
      Kp: "promotions",
      Gd: "shipping",
      ol: "tax",
      kh: "engagement_time_msec",
      mh: "enhanced_client_id",
      Lp: "enhanced_conversions",
      Ku: "enhanced_conversions_automatic_settings",
      ye: "estimated_delivery_date",
      Hf: "event_callback",
      Mp: "event_category",
      Hd: "event_developer_id_string",
      ze: "event_id",
      zi: "_event_join_id",
      Np: "event_label",
      uc: "event",
      pl: "_&ae",
      Ai: "event_settings",
      nh: "event_timeout",
      Op: "description",
      Pp: "fatal",
      Qp: "experiments",
      Ae: "ext_client_id",
      Bi: "firebase_id",
      If: "first_party_collection",
      Jf: "_x_20",
      Yb: "_x_19",
      Rp: "flight_error_code",
      Sp: "flight_error_message",
      Ci: "fl_activity_category",
      Di: "fl_activity_group",
      oh: "fl_advertiser_id",
      Ei: "match_id",
      ql: "fl_random_number",
      rl: "tran",
      sl: "u",
      ph: "gac_gclid",
      Be: "gac_wbraid",
      tl: "gac_wbraid_multiple_conversions",
      Tp: "ga_restrict_domain",
      wl: "ga_temp_client_id",
      Up: "ga_temp_ecid",
      Ce: "gdpr_applies",
      qh: "_gt_metadata",
      xl: "geo_granularity",
      Kf: "value_callback",
      Lf: "value_key",
      Ra: "google_analysis_params",
      Jd: "_google_ng",
      yl: "_ono",
      Mf: "google_signals",
      Vp: "google_tld",
      Nf: "gpp_sid",
      Of: "gpp_string",
      Kd: "groups",
      zl: "gsa_experiment_id",
      Pf: "gtag_event_feature_usage",
      Al: "gtm_up",
      De: "iframe_state",
      Qf: "ignore_referrer",
      Bl: "internal_traffic_results",
      Cl: "_is_fpm",
      Uc: "is_legacy_converted",
      Vc: "is_legacy_loaded",
      Fi: "is_passthrough",
      Rf: "_lps",
      wb: "language",
      Gi: "legacy_developer_id_string",
      Db: "linker",
      Sf: "accept_incoming",
      vc: "decorate_forms",
      Ba: "domains",
      Wc: "url_position",
      Ld: "merchant_feed_label",
      Md: "merchant_feed_language",
      Nd: "merchant_id",
      Dl: "method",
      Wp: "name",
      El: "navigation_type",
      Ee: "new_customer",
      Hi: "non_interaction",
      Xp: "optimize_id",
      Fl: "page_hostname",
      Tf: "page_path",
      Ja: "page_referrer",
      Pb: "page_title",
      Yp: "passengers",
      Gl: "phone_conversion_callback",
      Zp: "phone_conversion_country_code",
      Hl: "phone_conversion_css_class",
      aq: "phone_conversion_ids",
      Il: "phone_conversion_number",
      Jl: "phone_conversion_options",
      bq: "_platinum_request_status",
      cq: "_protected_audience_enabled",
      rh: "quantity",
      sh: "redact_device_info",
      Kl: "referral_exclusion_definition",
      Lu: "_request_start_time",
      xb: "restricted_data_processing",
      fq: "retoken",
      gq: "sample_rate",
      Ii: "screen_name",
      Xc: "screen_resolution",
      Ll: "_script_source",
      hq: "search_term",
      Od: "send_page_view",
      Zb: "send_to",
      Ji: "server_container_3p_enrichment",
      wc: "server_container_url",
      iq: "session_attributes_encoded",
      th: "session_duration",
      uh: "session_engaged",
      Ki: "session_engaged_time",
      xc: "session_id",
      wh: "session_number",
      Uf: "_shared_user_id",
      Pd: "delivery_postal_code",
      Mu: "_tag_firing_delay",
      Nu: "_tag_firing_time",
      Ou: "temporary_client_id",
      Ml: "testonly",
      jq: "_timezone",
      Ge: "topmost_url",
      xh: "tracking_id",
      Li: "traffic_type",
      Sa: "transaction_id",
      Nl: "transaction_id_source",
      yc: "transport_url",
      kq: "trip_type",
      Qd: "update",
      zc: "url_passthrough",
      Ol: "uptgs",
      Vf: "_user_agent_architecture",
      Wf: "_user_agent_bitness",
      Xf: "_user_agent_full_version_list",
      Yf: "_user_agent_mobile",
      Zf: "_user_agent_model",
      cg: "_user_agent_platform",
      dg: "_user_agent_platform_version",
      eg: "_user_agent_wow64",
      Yc: "user_data",
      Pl: "user_data_auto_latency",
      Ql: "user_data_auto_meta",
      Rl: "user_data_auto_multi",
      Sl: "user_data_auto_selectors",
      Tl: "user_data_auto_status",
      He: "user_data_mode",
      Ul: "user_data_settings",
      hb: "user_id",
      yh: "user_properties",
      Vl: "_user_region",
      fg: "us_privacy_string",
      Ta: "value",
      Wl: "wbraid_multiple_conversions",
      Zc: "_fpm_parameters",
      yq: "_&gtb",
      Qi: "_host_name",
      Fm: "_in_page_command",
      Si: "_ip_override",
      Jm: "_is_passthrough_cid",
      Yi: "_measurement_type",
      Sd: "non_personalized_ads",
      fj: "_sst_parameters",
      Rq: "sgtm_geo_user_country",
      Cd: "conversion_label",
      Ca: "page_location",
      Tc: "_extracted_data",
      Id: "global_developer_id_string",
      Fe: "tc_privacy_string",
    },
  };
  var J = {
    H: {
      fi: "accept_by_default",
      nk: "add_tag_timing",
      gi: "ads_consent_granted",
      ke: "ads_event_page_view",
      Lc: "ads_page_view_params",
      mc: "allow_ad_personalization",
      vu: "auto_event",
      xk: "batch_on_navigation",
      yk: "biscotti_join_id",
      Dk: "client_id_source",
      Tg: "consent_event_id",
      Ug: "consent_priority_id",
      Jk: "consent_state",
      sa: "consent_updated",
      nf: "conversion_linker_enabled",
      xu: "conversion_marking_called",
      Ha: "cookie_options",
      Sk: "dc_random",
      Cu: "dedupe_id",
      Vo: "do_ec_unification",
      Tk: "ec_feature_mask",
      Mc: "em_event",
      Eu: "endpoint_for_debug",
      Vk: "enhanced_client_id_source",
      Fu: "enhanced_match_form_metadata",
      Gu: "enhanced_match_form_metadata_latency",
      ep: "enhanced_match_result",
      Xl: "euid_logged_in_state",
      gg: "euid_mode_enabled",
      lq: "event_provenance",
      Qu: "event_source",
      Eb: "event_start_timestamp_ms",
      mq: "event_usage",
      Ie: "extra_tag_experiment_ids",
      ib: "fail_on_abort",
      Tu: "add_parameter",
      Oi: "counting_method",
      Ah: "send_as_iframe",
      Uu: "parameter_order",
      Bh: "parsed_target",
      Wu: "form_event_canceled",
      sq: "ga4_collection_subdomain",
      Pi: "ga4_request_flags",
      zm: "gbraid_cookie_marked",
      Bm: "gtm_extracted_data",
      Ac: "handle_internally",
      Yu: "has_ga_conversion_consents",
      HEADERS: "headers",
      ka: "hit_type",
      bd: "hit_type_override",
      Aq: "ignore_dupe_config",
      xv: "is_config_command",
      Dh: "is_consent_update",
      hg: "is_conversion",
      Gm: "is_ecommerce",
      Hm: "is_ec_cm_split",
      dd: "is_external_event",
      ig: "is_first_visit",
      Im: "is_first_visit_conversion",
      Ti: "is_fl_fallback_conversion_flow_allowed",
      Le: "is_fpm_encryption",
      Ui: "is_fpm_split",
      ab: "is_gcp_browser",
      Vi: "is_google_measurement_allowed",
      Wi: "is_google_signals_enabled",
      Rd: "is_merchant_center",
      Eh: "is_new_to_site",
      Km: "is_server_container_destination",
      Lm: "is_server_side_destination",
      Me: "is_session_start",
      Mm: "is_session_start_conversion",
      yv: "is_sgtm_ga_ads_conversion_study_control_group",
      zv: "is_sgtm_prehit",
      Nm: "is_sgtm_service_worker",
      jg: "is_split_conversion",
      Bq: "is_syn",
      kg: "is_test_event",
      lg: "join_id",
      Xi: "join_elapsed",
      mg: "join_timer_sec",
      Pm: "local_storage_aw_conversion_counters",
      ng: "mav_updated",
      Iq: "no_target_group",
      bj: "pending_pv_claim",
      Td: "tunnel_updated",
      Bv: "prehit_for_retry",
      Cv: "promises",
      Dv: "record_aw_latency",
      Pe: "redact_ads_data",
      Ud: "redact_click_ids",
      Wm: "remarketing_only",
      Ym: "send_ccm_parallel_ping",
      Qe: "send_doubleclick_join",
      Gh: "send_fpm_geo_join",
      Hh: "send_fpm_google_join",
      Ev: "send_ccm_parallel_test_ping",
      Zm: "send_google_measurement",
      pg: "send_tld_join",
      qg: "send_to_destinations",
      dj: "send_to_targets",
      bn: "send_user_data_hit",
      gj: "service_worker_context",
      Gb: "source_canonical_id",
      Ua: "speculative",
      hn: "speculative_in_message",
      lj: "suppressed_tag_experiment_ids",
      kn: "suppress_script_load",
      ln: "syn_or_mod",
      qj: "user_data_tr_ra",
      Zq: "user_data_tr_rp",
      rj: "transient_ecsid",
      rg: "transmission_type",
      jb: "user_data",
      Iv: "user_data_from_automatic",
      Jv: "user_data_from_automatic_getter",
      pn: "user_data_from_code",
      er: "user_data_from_manual",
      Kv: "user_data_mode",
      Re: "user_id_updated",
    },
  };
  var K = {
    V: {
      So: 1,
      Yo: 2,
      nn: 3,
      Um: 4,
      Wo: 5,
      Xo: 6,
      xq: 7,
      Zo: 8,
      wq: 9,
      Ro: 10,
      Qo: 11,
      gn: 12,
      dn: 13,
      Bk: 14,
      Go: 15,
      Io: 16,
      Qm: 17,
      Uk: 18,
      Om: 19,
      Uo: 20,
      Hq: 21,
      No: 22,
      Ho: 23,
      Jo: 24,
      Rk: 25,
      zk: 26,
      Uq: 27,
      tm: 28,
      Em: 29,
      Dm: 30,
      Cm: 31,
      ym: 32,
      wm: 33,
      xm: 34,
      om: 35,
      lm: 36,
      qm: 37,
      sm: 38,
      tq: 39,
      uq: 40,
      Lq: 41,
    },
  };
  K.V[K.V.So] = "CREATE_EVENT_SOURCE";
  K.V[K.V.Yo] = "EDIT_EVENT";
  K.V[K.V.nn] = "TRAFFIC_TYPE";
  K.V[K.V.Um] = "REFERRAL_EXCLUSION";
  K.V[K.V.Wo] = "ECOMMERCE_FROM_GTM_TAG";
  K.V[K.V.Xo] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
  K.V[K.V.xq] = "GA_SEND";
  K.V[K.V.Zo] = "EM_FORM";
  K.V[K.V.wq] = "GA_GAM_LINK";
  K.V[K.V.Ro] = "CREATE_EVENT_AUTO_PAGE_PATH";
  K.V[K.V.Qo] = "CREATED_EVENT";
  K.V[K.V.gn] = "SIDELOADED";
  K.V[K.V.dn] = "SGTM_LEGACY_CONFIGURATION";
  K.V[K.V.Bk] = "CCD_EM_EVENT";
  K.V[K.V.Go] = "AUTO_REDACT_EMAIL";
  K.V[K.V.Io] = "AUTO_REDACT_QUERY_PARAM";
  K.V[K.V.Qm] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
  K.V[K.V.Uk] = "EM_EVENT_SENT_BEFORE_CONFIG";
  K.V[K.V.Om] = "LOADED_VIA_CST_OR_SIDELOADING";
  K.V[K.V.Uo] = "DECODED_PARAM_MATCH";
  K.V[K.V.Hq] = "NON_DECODED_PARAM_MATCH";
  K.V[K.V.No] = "CCD_EVENT_SGTM";
  K.V[K.V.Ho] = "AUTO_REDACT_EMAIL_SGTM";
  K.V[K.V.Jo] = "AUTO_REDACT_QUERY_PARAM_SGTM";
  K.V[K.V.Rk] = "DAILY_LIMIT_REACHED";
  K.V[K.V.zk] = "BURST_LIMIT_REACHED";
  K.V[K.V.Uq] = "SHARED_USER_ID_SET_AFTER_REQUEST";
  K.V[K.V.tm] = "GA4_MULTIPLE_SESSION_COOKIES";
  K.V[K.V.Em] = "INVALID_GA4_SESSION_COUNT";
  K.V[K.V.Dm] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
  K.V[K.V.Cm] = "INVALID_GA4_JOIN_TIMER";
  K.V[K.V.ym] = "GA4_STALE_SESSION_COOKIE_SELECTED";
  K.V[K.V.wm] = "GA4_SESSION_COOKIE_GS1_READ";
  K.V[K.V.xm] = "GA4_SESSION_COOKIE_GS2_READ";
  K.V[K.V.om] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
  K.V[K.V.lm] = "GA4_DL_PARAM_RECOVERY_APPLIED";
  K.V[K.V.qm] = "GA4_GOOGLE_MEASUREMENT_ALLOWED";
  K.V[K.V.sm] = "GA4_GOOGLE_SIGNALS_ENABLED";
  K.V[K.V.tq] = "GA4_FALLBACK_REQUEST";
  K.V[K.V.uq] = "GA_ADS_LINK_BEFORE_CONVERSION_MARKING";
  K.V[K.V.Lq] = "PLATINUM_ELIGIBLE";
  var pg = {},
    qg =
      ((pg.uaa = !0),
      (pg.uab = !0),
      (pg.uafvl = !0),
      (pg.uamb = !0),
      (pg.uam = !0),
      (pg.uap = !0),
      (pg.uapv = !0),
      (pg.uaw = !0),
      pg);
  var wg = function (a, b) {
      for (var c = 0; c < b.length; c++) {
        var d = a,
          e = b[c];
        if (!ug.exec(e)) throw Error("Invalid key wildcard");
        var f = e.indexOf(".*"),
          g = f !== -1 && f === e.length - 2,
          h = g ? e.slice(0, e.length - 2) : e,
          k;
        a: if (d.length === 0) k = !1;
        else {
          for (var m = d.split("."), p = 0; p < m.length; p++)
            if (!vg.exec(m[p])) {
              k = !1;
              break a;
            }
          k = !0;
        }
        if (
          !k || h.length > d.length || (!g && d.length !== e.length)
            ? 0
            : g
            ? Zb(d, h) && (d === h || d.charAt(h.length) === ".")
            : d === h
        )
          return !0;
      }
      return !1;
    },
    vg = /^[a-z$_][\w-$]*$/i,
    ug = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
  var xg = [
    "matches",
    "webkitMatchesSelector",
    "mozMatchesSelector",
    "msMatchesSelector",
    "oMatchesSelector",
  ];
  function yg(a, b) {
    if (!a) return !1;
    try {
      for (var c = 0; c < xg.length; c++) {
        var d = xg[c];
        if (a[d] != null) return a[d](b);
      }
    } catch (e) {}
    return !1;
  }
  function zg(a, b) {
    var c = String(a),
      d = String(b),
      e = c.length - d.length;
    return e >= 0 && c.indexOf(d, e) === e;
  }
  function Ag(a, b) {
    return String(a).split(",").indexOf(String(b)) >= 0;
  }
  function Bg(a, b, c, d) {
    var e = c ? "i" : void 0;
    try {
      var f = String(b) + String(e),
        g = d == null ? void 0 : d.get(f);
      g || ((g = new RegExp(b, e)), d == null || d.set(f, g));
      return g.test(a);
    } catch (h) {
      return !1;
    }
  }
  function Cg(a, b) {
    return String(a).indexOf(String(b)) >= 0;
  }
  function Dg(a, b) {
    return String(a) === String(b);
  }
  function Eg(a, b) {
    return Number(a) >= Number(b);
  }
  function Fg(a, b) {
    return Number(a) <= Number(b);
  }
  function Gg(a, b) {
    return Number(a) > Number(b);
  }
  function Hg(a, b) {
    return Number(a) < Number(b);
  }
  function Ig(a, b) {
    return Zb(String(a), String(b));
  }
  function Pg(a) {
    var b = a.search;
    return (
      a.protocol +
      "//" +
      a.hostname +
      a.pathname +
      (b ? b + "&richsstsse" : "?richsstsse")
    );
  }
  var Qg = function () {
      this.U = "";
    },
    Sg = function (a, b) {
      return function () {
        var c = b.fallback_url,
          d = b.fallback_url_method;
        if (c && d) {
          var e = {};
          Rg(a, ((e[d] = [c]), (e.options = {}), e));
        }
      };
    },
    Tg = function (a, b, c) {
      if (Array.isArray(a)) {
        var d = n(a),
          e = d.next(),
          f;
        try {
          for (; !e.done; e = d.next()) {
            var g = e.value;
            typeof g === "string" && c(g, b);
          }
        } finally {
          e && !e.done && (f = d.return) && f.call(d);
        }
      }
    },
    Rg = function (a, b) {
      if (b) {
        var c = Ab(b.options) ? b.options : {},
          d = n(Object.keys(b)),
          e = d.next(),
          f;
        try {
          for (; !e.done; e = d.next()) {
            var g = e.value,
              h = b[g];
            switch (g) {
              case "send_pixel":
                Tg(h, c, function (k, m) {
                  return void a.J(k, m);
                });
                break;
              case "fetch":
                Tg(h, c, function (k, m) {
                  return void a.D(k, m);
                });
            }
          }
        } finally {
          e && !e.done && (f = d.return) && f.call(d);
        }
      }
    };
  var Ug =
      /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
    Vg = { Fn: "function", PixieMap: "Object", List: "Array" };
  function Wg(a, b) {
    for (var c = ["input:!*"], d = 0; d < c.length; d++) {
      var e = Ug.exec(c[d]);
      if (!e) throw Error("Internal Error in " + a);
      var f = e[1],
        g = e[2] === "!",
        h = e[3],
        k = b[d];
      if (k == null) {
        if (g)
          throw Error(
            "Error in " + a + ". Required argument " + f + " not supplied."
          );
      } else if (h !== "*") {
        var m = typeof k;
        k instanceof Nd
          ? (m = "Fn")
          : k instanceof Jd
          ? (m = "List")
          : k instanceof kb
          ? (m = "PixieMap")
          : k instanceof Ud
          ? (m = "PixiePromise")
          : k instanceof Sd && (m = "OpaqueValue");
        if (m !== h)
          throw Error(
            "Error in " +
              a +
              ". Argument " +
              f +
              " has type " +
              ((Vg[m] || m) + ", which does not match required type ") +
              ((Vg[h] || h) + ".")
          );
      }
    }
  }
  function M(a, b, c) {
    var d = [],
      e = n(c),
      f = e.next(),
      g;
    try {
      for (; !f.done; f = e.next()) {
        var h = f.value;
        h instanceof Nd
          ? d.push("function")
          : h instanceof Jd
          ? d.push("Array")
          : h instanceof kb
          ? d.push("Object")
          : h instanceof Ud
          ? d.push("Promise")
          : h instanceof Sd
          ? d.push("OpaqueValue")
          : d.push(typeof h);
      }
    } finally {
      f && !f.done && (g = e.return) && g.call(e);
    }
    return Error(
      "Argument error in " +
        a +
        ". Expected argument types [" +
        (b.join(",") + "], but received [") +
        (d.join(",") + "].")
    );
  }
  function Xg(a) {
    return a instanceof kb;
  }
  function Yg(a) {
    return Xg(a) || a === null || Zg(a);
  }
  function $g(a) {
    return a instanceof Nd;
  }
  function ah(a) {
    return $g(a) || a === null || Zg(a);
  }
  function bh(a) {
    return a instanceof Jd;
  }
  function ch(a) {
    return a instanceof Sd;
  }
  function dh(a) {
    return typeof a === "string";
  }
  function eh(a) {
    return dh(a) || a === null || Zg(a);
  }
  function fh(a) {
    return typeof a === "boolean";
  }
  function gh(a) {
    return fh(a) || Zg(a);
  }
  function hh(a) {
    return fh(a) || a === null || Zg(a);
  }
  function ih(a) {
    return typeof a === "number";
  }
  function Zg(a) {
    return a === void 0;
  }
  function jh(a) {
    return "" + a;
  }
  function kh(a, b) {
    var c = [];
    return c;
  }
  function lh(a, b) {
    var c = new Nd(a, function () {
      for (
        var d = Array.prototype.slice.call(arguments, 0), e = 0;
        e < d.length;
        e++
      )
        d[e] = this.evaluate(d[e]);
      try {
        return b.apply(this, d);
      } catch (g) {
        throw cb(g);
      }
    });
    c.Ya();
    return c;
  }
  function mh(a, b) {
    var c = new kb(),
      d;
    for (d in b)
      if (b.hasOwnProperty(d)) {
        var e = b[d];
        Db(e)
          ? c.set(d, lh(a + "_" + d, e))
          : Ab(e)
          ? c.set(d, mh(a + "_" + d, e))
          : (Fb(e) || Eb(e) || typeof e === "boolean") && c.set(d, e);
      }
    c.Ya();
    return c;
  }
  function nh(a, b) {
    if (!dh(a)) throw M(this.getName(), ["string"], arguments);
    if (!eh(b)) throw M(this.getName(), ["string", "undefined"], arguments);
    var c = {},
      d = new kb();
    return (d = mh("AssertApiSubject", c));
  }
  function oh(a, b) {
    if (!eh(b)) throw M(this.getName(), ["string", "undefined"], arguments);
    if (a instanceof Ud)
      throw Error(
        "Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported."
      );
    var c = {},
      d = new kb();
    return (d = mh("AssertThatSubject", c));
  }
  function ph(a) {
    return function () {
      for (
        var b = Oa.apply(0, arguments), c = [], d = this.T, e = 0;
        e < b.length;
        ++e
      )
        c.push(B(b[e], d));
      return Vd(a.apply(null, c));
    };
  }
  function qh() {
    for (var a = Math, b = rh, c = {}, d = 0; d < b.length; d++) {
      var e = b[d];
      a.hasOwnProperty(e) && (c[e] = ph(a[e].bind(a)));
    }
    return c;
  }
  function sh(a) {
    return a != null && Zb(a, "__cvt_");
  }
  function th(a) {
    var b;
    return b;
  }
  function uh(a) {
    var b;
    if (!dh(a)) throw M(this.getName(), ["string"], arguments);
    var c;
    try {
      c = decodeURIComponent(a);
    } catch (d) {}
    b = c;
    return b;
  }
  function vh(a) {
    try {
      return encodeURI(a);
    } catch (b) {}
  }
  function wh(a) {
    var b;
    a: {
      try {
        b = encodeURIComponent(String(a));
        break a;
      } catch (c) {}
      b = void 0;
    }
    return b;
  }
  function xh(a, b) {
    var c = !1;
    return c;
  }
  function Dh(a) {
    if (!eh(a)) throw M(this.getName(), ["string|undefined"], arguments);
  }
  function Eh(a) {
    var b = B(a);
    return eg(b ? "" + b : "");
  }
  function Fh(a, b) {
    if (!ih(a) || !ih(b))
      throw M(this.getName(), ["number", "number"], arguments);
    return Ib(a, b);
  }
  function Gh() {
    return new Date().getTime();
  }
  function Hh(a) {
    if (a === null) return "null";
    if (a instanceof Jd) return "array";
    if (a instanceof Nd) return "function";
    if (a instanceof Sd) {
      var b = a.getValue();
      if (
        (b == null ? void 0 : b.constructor) === void 0 ||
        b.constructor.name === void 0
      ) {
        var c = String(b);
        return c.substring(8, c.length - 1);
      }
      return String(b.constructor.name);
    }
    return typeof a;
  }
  function Ih(a) {
    function b(c) {
      return function (d) {
        try {
          return c(d);
        } catch (e) {
          (Hf(71) || Hf(29)) && a.call(this, e.message);
        }
      };
    }
    return {
      parse: b(function (c) {
        return Vd(JSON.parse(c));
      }),
      stringify: b(function (c) {
        return JSON.stringify(B(c));
      }),
      publicName: "JSON",
    };
  }
  function Jh(a) {
    return Nb(B(a, this.T));
  }
  function Kh(a) {
    return Number(B(a, this.T));
  }
  function Lh(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a.toString();
  }
  var Mh = [],
    Nh = {};
  function Oh(a) {
    return Mh[a] === void 0 ? !1 : Mh[a];
  }
  var Ph = new Set();
  Qh(2);
  Qh(13);
  Qh(435);
  Qh(29);

  function Qh(a) {
    Ph.add(a);
    var b;
    a: {
      switch (a) {
        case 400:
          b = 0;
          break a;
      }
      b = void 0;
    }
    var c = b;
    c !== void 0 && (Mh[c] = !0);
  }
  var Rh = {
      Mo: E(6),
      To: E(5),
      Oq: E(15),
      Pq: E(14),
      Xq: E(12),
      Yq: E(13),
      gr: E(43),
      hr: Mf(37, 10),
      ir: Mf(38, 100),
      jr: Mf(41, 6),
      kr: Mf(39, 1382400),
      lr: Mf(40, 15),
      mr: Ph.has(13) ? 100 : Mf(42, 0),
      nr: Mf(43, 60),
      qr: Mf(44, 15e3),
      rr: Mf(45, 0),
      ur: Mf(46, 0),
      vr: Mf(64, 2),
      wr: Mf(65, 250),
      xr: Mf(47, 50),
      yr: Mf(30, 432e5),
      zr: Mf(48, 5e3),
      Ar: Mf(49, 15),
      Br: Mf(50, 2e4),
      Cr: Mf(25, 0),
      Dr: Mf(26, 0),
      Er: Kf(23),
      Fr: Kf(22),
      Gr: Mf(51, 5e3),
      Hr: Mf(52, 20),
      VERSION: E(1),
    },
    Sh = {
      canonicalContainerId: Rh.Mo,
      ctid: Rh.To,
      Zv: Rh.Oq,
      runtimeVersion: Rh.Pq,
      cw: Rh.Xq,
      dw: Rh.Yq,
      fw: Rh.gr,
      gw: Rh.hr,
      hw: Rh.ir,
      iw: Rh.jr,
      jw: Rh.kr,
      kw: Rh.lr,
      lw: Rh.mr,
      mw: Rh.nr,
      nw: Rh.qr,
      ow: Rh.rr,
      pw: Rh.ur,
      qw: Rh.vr,
      rw: Rh.wr,
      tw: Rh.xr,
      uw: Rh.yr,
      ww: Rh.zr,
      xw: Rh.Ar,
      yw: Rh.Br,
      zw: Rh.Cr,
      Aw: Rh.Dr,
      Bw: Rh.Er,
      Cw: Rh.Fr,
      ru: Rh.Gr,
      Dw: Rh.Hr,
      version: Rh.VERSION,
    };
  ma(Object, "assign").call(Object, {}, Sh);
  function Th(a, b, c, d) {
    var e = B(a),
      f = d > 0 ? Uh(e, d) : e,
      g = Vd(f);
    g.promise.then(c, function (k) {
      c();
      if (!g.Tn) {
        var m = B(k, void 0, 1);
        m = m instanceof bb ? m.Wj.message : m instanceof Error ? m.message : m;
        b("error", "Unhandled rejection - " + JSON.stringify(m));
      }
    });
    var h = function (k) {
      var m = g.get(k);
      g.set(
        k,
        new Nd("", function (p, q) {
          var r = this.T.lb(),
            t = r.su("25"),
            u = m.invoke(this.T, p, q);
          return Th(u, r.log, t, d);
        })
      );
    };
    h("then");
    h("catch");
    h("finally");
    g.Ya();
    return g;
  }
  function Uh(a, b) {
    var c,
      d = Promise.race([
        a,
        new Promise(function (e, f) {
          var g = setTimeout(function () {
            return void f({ reason: "promise_timed_out" });
          }, b);
          c = function () {
            clearTimeout(g);
            e();
          };
        }),
      ]);
    a.then(c, c);
    return d;
  }
  function Vh(a, b, c) {
    var d;
    if (!bh(a) || !dh(b) || !dh(c))
      throw M(this.getName(), ["Array", "string", "string"], arguments);
    var e = B(a, this.T, 1),
      f = b,
      g = c,
      h = {},
      k = !1;
    if (Array.isArray(e)) {
      var m = n(e),
        p = m.next(),
        q;
      try {
        for (; !p.done; p = m.next()) {
          var r = p.value;
          r !== null &&
            typeof r === "object" &&
            Object.prototype.hasOwnProperty.call(r, f) &&
            Object.prototype.hasOwnProperty.call(r, g) &&
            ((h[String(r[f])] = r[g]), (k = !0));
        }
      } finally {
        p && !p.done && (q = m.return) && q.call(m);
      }
    }
    d = k ? h : null;
    var t;
    var u = this.T;
    if (d instanceof Promise)
      if (u) {
        var v = u == null ? void 0 : u.lb(),
          w = v.log,
          y = v.su("23"),
          z;
        z = z === void 0 ? Sh.ru : z;
        var C = Vd(d);
        t = Th(C, w, y, z);
      } else t = Vd(d, u, 1);
    else t = Vd(d, u, 1);
    return t;
  }
  var rh = "floor ceil round max min abs pow sqrt".split(" ");
  function Wh() {
    var a = {};
    return {
      Cs: function (b) {
        return a.hasOwnProperty(b) ? a[b] : void 0;
      },
      yo: function (b, c) {
        a[b] = c;
      },
      reset: function () {
        a = {};
      },
    };
  }
  function Xh(a, b) {
    return function () {
      return Nd.prototype.invoke.apply(
        a,
        [b].concat(xa(Oa.apply(0, arguments)))
      );
    };
  }
  function Yh(a, b) {
    if (!dh(a)) throw M(this.getName(), ["string", "any"], arguments);
  }
  function Zh(a, b) {
    if (!dh(a) || !Xg(b))
      throw M(this.getName(), ["string", "PixieMap"], arguments);
  }
  var $h = {};
  var ai = function (a) {
    var b = new kb();
    if (a instanceof Jd)
      for (var c = a.Ga(), d = 0; d < c.length; d++) {
        var e = c[d];
        a.has(e) && b.set(e, a.get(e));
      }
    else if (a instanceof Nd)
      for (var f = a.Ga(), g = 0; g < f.length; g++) {
        var h = f[g];
        b.set(h, a.get(h));
      }
    else for (var k = 0; k < a.length; k++) b.set(k, a[k]);
    return b;
  };
  $h.keys = function (a) {
    Wg(this.getName(), arguments);
    if (a instanceof Jd || a instanceof Nd || typeof a === "string") a = ai(a);
    if (a instanceof kb || a instanceof Ud) return new Jd(a.Ga());
    return new Jd();
  };
  $h.values = function (a) {
    Wg(this.getName(), arguments);
    if (a instanceof Jd || a instanceof Nd || typeof a === "string") a = ai(a);
    if (a instanceof kb || a instanceof Ud) return new Jd(a.fc());
    return new Jd();
  };
  $h.entries = function (a) {
    Wg(this.getName(), arguments);
    if (a instanceof Jd || a instanceof Nd || typeof a === "string") a = ai(a);
    if (a instanceof kb || a instanceof Ud)
      return new Jd(
        a.bc().map(function (b) {
          return new Jd(b);
        })
      );
    return new Jd();
  };
  $h.freeze = function (a) {
    (a instanceof kb ||
      a instanceof Ud ||
      a instanceof Jd ||
      a instanceof Nd) &&
      a.Ya();
    return a;
  };
  $h.delete = function (a, b) {
    if (a instanceof kb && !a.Jb()) return a.remove(b), !0;
    return !1;
  };
  function N(a, b) {
    var c = Oa.apply(2, arguments),
      d = a.T.lb();
    if (!d) throw Error("Missing program state.");
    if (d.ai) {
      try {
        d.yn.apply(null, [b].concat(xa(c)));
      } catch (e) {
        throw (sb("TAGGING", 21), e);
      }
      return;
    }
    d.yn.apply(null, [b].concat(xa(c)));
  }
  var bi = function () {
    this.J = {};
    this.D = {};
    this.M = !0;
  };
  bi.prototype.get = function (a, b) {
    var c = this.contains(a) ? this.J[a] : void 0;
    return c;
  };
  bi.prototype.contains = function (a) {
    return this.J.hasOwnProperty(a);
  };
  bi.prototype.add = function (a, b, c) {
    if (this.contains(a))
      throw Error(
        "Attempting to add a function which already exists: " + a + "."
      );
    if (this.D.hasOwnProperty(a))
      throw Error(
        "Attempting to add an API with an existing private API name: " + a + "."
      );
    this.J[a] = c ? void 0 : Db(b) ? lh(a, b) : mh(a, b);
  };
  function ci(a, b) {
    var c = void 0;
    return c;
  }
  function di() {
    var a = {};
    return a;
  }
  var ei = {},
    fi =
      ((ei[H.A.sa] = "gcu"),
      (ei[H.A.Zg] = "ept"),
      (ei[H.A.Wb] = "gclgb"),
      (ei[H.A.pb] = "gclaw"),
      (ei[H.A.bl] = "gclid_len"),
      (ei[H.A.qe] = "gclgs"),
      (ei[H.A.se] = "gcllp"),
      (ei[H.A.te] = "gclst"),
      (ei[H.A.Ad] = "auid"),
      (ei[H.A.il] = "ae"),
      (ei[H.A.uf] = "dscnt"),
      (ei[H.A.vf] = "fcntr"),
      (ei[H.A.wf] = "flng"),
      (ei[H.A.xf] = "mid"),
      (ei[H.A.mi] = "bttype"),
      (ei[H.A.Nb] = "gacid"),
      (ei[H.A.Cd] = "label"),
      (ei[H.A.ve] = "capi"),
      (ei[H.A.hh] = "pscdl"),
      (ei[H.A.fb] = "currency_code"),
      (ei[H.A.we] = "vdltv"),
      (ei[H.A.ih] = "cloct"),
      (ei[H.A.wi] = "_dbg"),
      (ei[H.A.ye] = "oedeld"),
      (ei[H.A.Hd] = "edid"),
      (ei[H.A.ze] = "evnid"),
      (ei[H.A.zi] = "evjid"),
      (ei[H.A.Ae] = "excid"),
      (ei[H.A.ph] = "gac"),
      (ei[H.A.Be] = "gacgb"),
      (ei[H.A.tl] = "gacmcov"),
      (ei[H.A.Ce] = "gdpr"),
      (ei[H.A.Id] = "gdid"),
      (ei[H.A.Jd] = "_ng"),
      (ei[H.A.yl] = "_ono"),
      (ei[H.A.Nf] = "gpp_sid"),
      (ei[H.A.Of] = "gpp"),
      (ei[H.A.zl] = "gsaexp"),
      (ei[H.A.Pf] = "_tu"),
      (ei[H.A.De] = "frm"),
      (ei[H.A.Fi] = "gtm_up"),
      (ei[H.A.Rf] = "lps"),
      (ei[H.A.Gi] = "did"),
      (ei[H.A.Ld] = "fcntr"),
      (ei[H.A.Md] = "flng"),
      (ei[H.A.Nd] = "mid"),
      (ei[H.A.Ee] = void 0),
      (ei[H.A.Pb] = "tiba"),
      (ei[H.A.xb] = "rdp"),
      (ei[H.A.xc] = "ecsid"),
      (ei[H.A.Uf] = "ga_uid"),
      (ei[H.A.Pd] = "delopc"),
      (ei[H.A.Fe] = "gdpr_consent"),
      (ei[H.A.Sa] = "oid"),
      (ei[H.A.Nl] = "oidsrc"),
      (ei[H.A.Ol] = "uptgs"),
      (ei[H.A.Vf] = "uaa"),
      (ei[H.A.Wf] = "uab"),
      (ei[H.A.Xf] = "uafvl"),
      (ei[H.A.Yf] = "uamb"),
      (ei[H.A.Zf] = "uam"),
      (ei[H.A.cg] = "uap"),
      (ei[H.A.dg] = "uapv"),
      (ei[H.A.eg] = "uaw"),
      (ei[H.A.Pl] = "ec_lat"),
      (ei[H.A.Ql] = "ec_meta"),
      (ei[H.A.Rl] = "ec_m"),
      (ei[H.A.Sl] = "ec_sel"),
      (ei[H.A.Tl] = "ec_s"),
      (ei[H.A.He] = "ec_mode"),
      (ei[H.A.hb] = "userId"),
      (ei[H.A.fg] = "us_privacy"),
      (ei[H.A.Ta] = "value"),
      (ei[H.A.Wl] = "mcov"),
      (ei[H.A.Qi] = "hn"),
      (ei[H.A.Fm] = "gtm_ee"),
      (ei[H.A.Si] = "uip"),
      (ei[H.A.Yi] = "mt"),
      (ei[H.A.Sd] = "npa"),
      (ei[H.A.Rq] = "sg_uc"),
      (ei[H.A.oi] = null),
      (ei[H.A.Xc] = null),
      (ei[H.A.wb] = null),
      (ei[H.A.Ia] = null),
      (ei[H.A.Ca] = null),
      (ei[H.A.Ja] = null),
      (ei[H.A.Ge] = null),
      (ei[H.A.Zc] = null),
      (ei[H.A.qh] = null),
      (ei[H.A.xd] = null),
      (ei[H.A.yd] = null),
      (ei[H.A.ah] = null),
      (ei[H.A.bh] = null),
      (ei[H.A.Ra] = null),
      (ei[H.A.Tc] = null),
      ei);
  function gi(a, b) {
    if (a) {
      var c = a.split("x");
      c.length === 2 && (hi(b, "u_w", c[0]), hi(b, "u_h", c[1]));
    }
  }
  function ii(a) {
    var b = ji;
    b = b === void 0 ? ki : b;
    return li(mi(a, b));
  }
  function li(a) {
    return (a || [])
      .filter(function (b) {
        return !!b;
      })
      .map(function (b) {
        return (
          "(" +
          [
            ni(b.value),
            ni(b.quantity),
            ni(b.item_id),
            ni(b.start_date),
            ni(b.end_date),
          ].join("*") +
          ")"
        );
      })
      .join("");
  }
  function mi(a, b) {
    return (a || [])
      .filter(function (c) {
        return !!c;
      })
      .map(function (c) {
        return {
          item_id: b(c),
          quantity: c.quantity,
          value: c.price,
          start_date: c.start_date,
          end_date: c.end_date,
        };
      });
  }
  function ki(a) {
    return [a.item_id, a.id, a.item_name].find(function (b) {
      return b != null;
    });
  }
  function oi(a) {
    if (a && a.length)
      return a
        .map(function (b) {
          return b && b.estimated_delivery_date
            ? b.estimated_delivery_date
            : "";
        })
        .join(",");
  }
  function hi(a, b, c) {
    c === void 0 || c === null || (c === "" && !qg[b]) || (a[b] = c);
  }
  function ni(a) {
    return typeof a !== "number" && typeof a !== "string" ? "" : a.toString();
  }
  function pi() {
    this.blockSize = -1;
  }
  function qi(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.M = Qa.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.U = this.J = 0;
    this.D = [];
    this.fa = a;
    this.aa = b;
    this.la = Qa.Int32Array ? new Int32Array(64) : Array(64);
    ri === void 0 && (Qa.Int32Array ? (ri = new Int32Array(si)) : (ri = si));
    this.reset();
  }
  Ra(qi, pi);
  for (var ti = [], ui = 0; ui < 63; ui++) ti[ui] = 0;
  var vi = [].concat(128, ti);
  qi.prototype.reset = function () {
    this.U = this.J = 0;
    var a;
    if (Qa.Int32Array) a = new Int32Array(this.aa);
    else {
      var b = this.aa,
        c = b.length;
      if (c > 0) {
        for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
        a = d;
      } else a = [];
    }
    this.D = a;
  };
  var wi = function (a) {
    for (var b = a.M, c = a.la, d = 0, e = 0; e < b.length; )
      (c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4);
    for (var f = 16; f < 64; f++) {
      var g = c[f - 15] | 0,
        h = c[f - 2] | 0;
      c[f] =
        ((((c[f - 16] | 0) +
          (((g >>> 7) | (g << 25)) ^ ((g >>> 18) | (g << 14)) ^ (g >>> 3))) |
          0) +
          (((c[f - 7] | 0) +
            (((h >>> 17) | (h << 15)) ^
              ((h >>> 19) | (h << 13)) ^
              (h >>> 10))) |
            0)) |
        0;
    }
    for (
      var k = a.D[0] | 0,
        m = a.D[1] | 0,
        p = a.D[2] | 0,
        q = a.D[3] | 0,
        r = a.D[4] | 0,
        t = a.D[5] | 0,
        u = a.D[6] | 0,
        v = a.D[7] | 0,
        w = 0;
      w < 64;
      w++
    ) {
      var y =
          ((((k >>> 2) | (k << 30)) ^
            ((k >>> 13) | (k << 19)) ^
            ((k >>> 22) | (k << 10))) +
            ((k & m) ^ (k & p) ^ (m & p))) |
          0,
        z =
          (((v +
            (((r >>> 6) | (r << 26)) ^
              ((r >>> 11) | (r << 21)) ^
              ((r >>> 25) | (r << 7)))) |
            0) +
            ((((((r & t) ^ (~r & u)) + (ri[w] | 0)) | 0) + (c[w] | 0)) | 0)) |
          0;
      v = u;
      u = t;
      t = r;
      r = (q + z) | 0;
      q = p;
      p = m;
      m = k;
      k = (z + y) | 0;
    }
    a.D[0] = (a.D[0] + k) | 0;
    a.D[1] = (a.D[1] + m) | 0;
    a.D[2] = (a.D[2] + p) | 0;
    a.D[3] = (a.D[3] + q) | 0;
    a.D[4] = (a.D[4] + r) | 0;
    a.D[5] = (a.D[5] + t) | 0;
    a.D[6] = (a.D[6] + u) | 0;
    a.D[7] = (a.D[7] + v) | 0;
  };
  qi.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.J;
    if (typeof a === "string")
      for (; c < b; )
        (this.M[d++] = a.charCodeAt(c++)),
          d == this.blockSize && (wi(this), (d = 0));
    else {
      var e,
        f = typeof a;
      e = f != "object" ? f : a ? (Array.isArray(a) ? "array" : f) : "null";
      if (e == "array" || (e == "object" && typeof a.length == "number"))
        for (; c < b; ) {
          var g = a[c++];
          if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0)))
            throw Error("message must be a byte array");
          this.M[d++] = g;
          d == this.blockSize && (wi(this), (d = 0));
        }
      else throw Error("message must be string or array");
    }
    this.J = d;
    this.U += b;
  };
  qi.prototype.digest = function () {
    var a = [],
      b = this.U * 8;
    this.J < 56
      ? this.update(vi, 56 - this.J)
      : this.update(vi, this.blockSize - (this.J - 56));
    for (var c = 63; c >= 56; c--) (this.M[c] = b & 255), (b /= 256);
    wi(this);
    for (var d = 0, e = 0; e < this.fa; e++)
      for (var f = 24; f >= 0; f -= 8) a[d++] = (this.D[e] >> f) & 255;
    return a;
  };
  var si = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    ri;
  function xi() {
    qi.call(this, 8, yi);
  }
  Ra(xi, qi);
  var yi = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var zi = /^[0-9A-Fa-f]{64}$/;
  function Ai(a) {
    try {
      return new TextEncoder().encode(a);
    } catch (b) {
      return ec(a);
    }
  }
  function Bi(a) {
    var b = x;
    if (a === "" || a === "e0") return Promise.resolve(a);
    var c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
      if (zi.test(a)) return Promise.resolve(a);
      try {
        var d = Ai(a);
        return b.crypto.subtle
          .digest("SHA-256", d)
          .then(function (e) {
            return Ci(e, b);
          })
          .catch(function () {
            return "e2";
          });
      } catch (e) {
        return Promise.resolve("e2");
      }
    } else return Promise.resolve("e1");
  }
  function Di(a) {
    try {
      var b = new xi();
      b.update(Ai(a));
      return b.digest();
    } catch (c) {
      return "e2";
    }
  }
  function Ei(a) {
    var b = x;
    if (a === "" || a === "e0" || zi.test(a)) return a;
    var c = Di(a);
    if (c === "e2") return "e2";
    try {
      return Ci(c, b);
    } catch (d) {
      return "e2";
    }
  }
  function Ci(a, b) {
    var c = Array.from(new Uint8Array(a))
      .map(function (d) {
        return String.fromCharCode(d);
      })
      .join("");
    return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function Fi() {
    for (var a = !1, b = !1, c = 0; a === b; )
      if (((a = Ib(0, 1) === 0), (b = Ib(0, 1) === 0), c++, c > 30)) return;
    return a;
  }
  var Hi = {
      gk: function (a, b, c) {
        return Gi.gk(a, b, c);
      },
    },
    Ii = function () {
      this.studies = {};
      this.D = Fi;
    };
  Ii.prototype.gk = function (a, b, c) {
    var d = this.studies[b];
    if (
      !(
        (c === void 0 ? Ib(0, 9999) : c % 1e4) <
        d.probability * (d.controlId2 ? 4 : 2) * 1e4
      )
    )
      return a;
    a: {
      var e = d.studyId,
        f = d.experimentId,
        g = d.controlId,
        h = d.controlId2;
      if (!((a.exp || {})[f] || (a.exp || {})[g] || (h && (a.exp || {})[h]))) {
        var k = c !== void 0 ? c % 2 === 0 : this.D();
        if (k !== void 0) {
          var m = k ? 0 : 1;
          if (h) {
            var p = c !== void 0 ? (c >> 1) % 2 === 0 : this.D();
            if (p === void 0) break a;
            m |= (p ? 0 : 1) << 1;
          }
          m === 0
            ? Ji(a, f, e)
            : m === 1
            ? Ji(a, g, e)
            : m === 2 && Ji(a, h, e);
        }
      }
    }
    return a;
  };
  var Li = function (a, b) {
      var c = Gi;
      return c.studies[b]
        ? Ki(c, b) || !!(a.exp || {})[c.studies[b].experimentId]
        : !1;
    },
    Mi = function (a, b) {
      var c = Gi;
      return c.studies[b] && c.studies[b].controlId && !Ki(c, b)
        ? !!(a.exp || {})[c.studies[b].controlId]
        : !1;
    },
    Ni = function (a, b) {
      var c = Gi;
      return c.studies[b] && c.studies[b].controlId2 && !Ki(c, b)
        ? !!(a.exp || {})[c.studies[b].controlId2]
        : !1;
    },
    Oi = function (a, b) {
      var c = (a == null ? void 0 : a.exp) || {},
        d = n(Object.keys(c).map(Number)),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = e.value;
          if (c[g] === b) return g;
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
    },
    Ki = function (a, b) {
      return !!a.studies[b].active || a.studies[b].probability > 0.5;
    },
    Ji = function (a, b, c) {
      var d = a.exp || {};
      d[b] = c;
      a.exp = d;
    },
    Gi = new Ii();
  var Pi = function (a) {
      switch (a) {
        case 400:
          return 0;
        case 491:
          return 8;
        case 480:
          return 7;
        case 421:
          return 6;
        case 561:
          return 12;
        case 482:
          return 10;
        case 570:
          return 13;
        case 495:
          return 9;
        case 514:
          return 11;
        case 53:
          return 1;
        case 54:
          return 2;
        case 52:
          return 4;
        case 75:
          return 3;
      }
    },
    Qi = function (a, b) {
      a.M.add(b);
      var c = Pi(b);
      c !== void 0 && (Mh[c] = !0);
    },
    O = function (a) {
      return Ri.M.has(a);
    },
    Ri = new (function () {
      this.M = new Set();
      this.J = new Set();
      this.D = new Set();
      Qi(this, 132);
      var a = Mf(69, 1776448920);
      Nh[1] = a;
      Qi(this, 435);
      Qi(this, 603);
    })();
  function Wi(a, b) {
    var c = (b == null ? void 0 : b.Ue) !== !1;
    return Object.keys(a)
      .map(function (d) {
        var e = a[d];
        if (e != null) {
          if (e === "") {
            var f;
            if (
              !(typeof (b == null ? void 0 : b.Se) === "boolean"
                ? b.Se
                : b == null
                ? 0
                : (f = b.Se) == null
                ? 0
                : f[d])
            )
              return;
          }
          e =
            e === !0
              ? "1"
              : e === !1
              ? "0"
              : c
              ? encodeURIComponent(String(e))
              : String(e);
          return d + "=" + e;
        }
      })
      .filter(function (d) {
        return !!d;
      })
      .join("&");
  }
  var Xi = function () {
    this.storage = Xa();
  };
  Xi.prototype.set = function (a, b) {
    this.storage.set(String(a), b);
  };
  Xi.prototype.get = function (a) {
    return this.storage.get(String(a));
  };
  var Yi;
  function Zi(a, b) {
    Yi || (Yi = new Xi());
    Yi.set(a, b);
  }
  function $i(a) {
    Yi || (Yi = new Xi());
    return Yi.get(a);
  }
  function aj(a, b) {
    Yi || (Yi = new Xi());
    var c = Yi;
    c.storage.has(String(a)) || c.storage.set(String(a), b());
    return c.storage.get(String(a));
  }
  var bj = {},
    cj =
      ((bj.tdp = 1),
      (bj.exp = 1),
      (bj.gtm = 1),
      (bj.pid = 1),
      (bj.dl = 1),
      (bj.seq = 1),
      (bj.t = 1),
      (bj.v = 1),
      bj),
    ej = function () {
      var a = dj;
      return Object.keys(a.D).filter(function (b) {
        return a.D[b];
      });
    },
    fj = function (a, b, c) {
      if (a.D[b] === void 0 || (c === void 0 ? 0 : c)) a.D[b] = !0;
    },
    gj = function (a) {
      var b = dj;
      a.forEach(function (c) {
        cj[c] || (b.D[c] = !1);
      });
    },
    dj = new (function () {
      this.D = {};
      this.J = {};
    })();
  function hj(a, b, c) {
    var d = c === void 0 ? !0 : c,
      e = dj;
    d = d === void 0 ? !0 : d;
    e.J[a] = b;
    d && fj(e, a);
  }
  var ij = function () {
      this.D = new Set();
      this.J = new Set();
    },
    mj = function (a) {
      var b = lj.D;
      a = a === void 0 ? [] : a;
      var c = []
        .concat(xa(b.D))
        .concat([].concat(xa(b.J)))
        .concat(a);
      c.sort(function (d, e) {
        return d - e;
      });
      return c;
    },
    nj = function () {
      var a = [].concat(xa(lj.D.D));
      a.sort(function (b, c) {
        return b - c;
      });
      return a;
    },
    pj = function () {
      var a = lj.D,
        b = E(44);
      a.D = new Set();
      if (b) {
        var c = n(b.split("~")),
          d = c.next(),
          e;
        try {
          for (; !d.done; d = c.next()) oj(a, d.value);
        } finally {
          d && !d.done && (e = c.return) && e.call(c);
        }
      }
    },
    qj = function () {
      var a = lj.D,
        b = Jf(67);
      if (b) {
        var c = n(b),
          d = c.next(),
          e;
        try {
          for (; !d.done; d = c.next()) oj(a, d.value);
        } finally {
          d && !d.done && (e = c.return) && e.call(c);
        }
      }
    },
    oj = function (a, b) {
      var c = b.trim();
      if (c !== "") {
        var d = Number(c);
        isNaN(d) || a.D.add(d);
      }
    };
  var rj = {},
    sj = {
      __cl: 1,
      __ecl: 1,
      __ehl: 1,
      __evl: 1,
      __fal: 1,
      __fil: 1,
      __fsl: 1,
      __hl: 1,
      __jel: 1,
      __lcl: 1,
      __sdl: 1,
      __tl: 1,
      __ytl: 1,
    },
    tj = ma(Object, "assign").call(Object, {}, { __paused: 1, __tg: 1 }, sj),
    uj,
    wj = !1;
  uj = wj;
  var xj = "";
  rj.ij = xj;
  var lj = new (function () {
    this.D = new ij();
  })();
  var yj = /:[0-9]+$/,
    zj = /^\d+\.fls\.doubleclick\.net$/;
  function Aj(a, b, c, d) {
    var e = Bj(a, !!d, b),
      f,
      g;
    return c
      ? (g = e[b]) != null
        ? g
        : []
      : (f = e[b]) == null
      ? void 0
      : f[0];
  }
  function Bj(a, b, c) {
    var d = {},
      e = n(a.split("&")),
      f = e.next(),
      g;
    try {
      for (; !f.done; f = e.next()) {
        var h = n(f.value.split("=")),
          k = h.next().value,
          m = wa(h),
          p = decodeURIComponent(k.replace(/\+/g, " "));
        if (c === void 0 || p === c) {
          var q = m.join("=");
          d[p] || (d[p] = []);
          d[p].push(b ? q : decodeURIComponent(q.replace(/\+/g, " ")));
        }
      }
    } finally {
      f && !f.done && (g = e.return) && g.call(e);
    }
    return d;
  }
  function Cj(a) {
    try {
      return decodeURIComponent(a);
    } catch (b) {}
  }
  function Dj(a, b, c, d, e) {
    b && (b = String(b).toLowerCase());
    if (b === "protocol" || b === "port")
      a.protocol = Ej(a.protocol) || Ej(x.location.protocol);
    b === "port"
      ? (a.port = String(
          Number(a.hostname ? a.port : x.location.port) ||
            (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")
        ))
      : b === "host" &&
        (a.hostname = (a.hostname || x.location.hostname)
          .replace(yj, "")
          .toLowerCase());
    return Fj(a, b, c, d, e);
  }
  function Fj(a, b, c, d, e) {
    var f,
      g = Ej(a.protocol);
    b && (b = String(b).toLowerCase());
    switch (b) {
      case "url_no_fragment":
        f = Gj(a);
        break;
      case "protocol":
        f = g;
        break;
      case "host":
        f = a.hostname.replace(yj, "").toLowerCase();
        if (c) {
          var h = /^www\d*\./.exec(f);
          h && h[0] && (f = f.substring(h[0].length));
        }
        break;
      case "port":
        f = String(
          Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : "")
        );
        break;
      case "path":
        a.pathname || a.hostname || sb("TAGGING", 1);
        f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
        var k = f.split("/");
        (d || []).indexOf(k[k.length - 1]) >= 0 && (k[k.length - 1] = "");
        f = k.join("/");
        break;
      case "query":
        f = a.search.replace("?", "");
        e && (f = Aj(f, e, !1));
        break;
      case "extension":
        var m = a.pathname.split(".");
        f = m.length > 1 ? m[m.length - 1] : "";
        f = f.split("/")[0];
        break;
      case "fragment":
        f = a.hash.replace("#", "");
        break;
      default:
        f = a && a.href;
    }
    return f;
  }
  function Ej(a) {
    return a ? a.replace(":", "").toLowerCase() : "";
  }
  function Gj(a) {
    var b = "";
    if (a && a.href) {
      var c = a.href.indexOf("#");
      b = c < 0 ? a.href : a.href.substring(0, c);
    }
    return b;
  }
  var Hj = {},
    Ij = 0;
  function Jj(a) {
    var b = Hj[a];
    if (!b) {
      var c = A.createElement("a");
      a && (c.href = a);
      var d = c.pathname;
      d[0] !== "/" && (a || sb("TAGGING", 1), (d = "/" + d));
      var e = c.hostname.replace(yj, "");
      b = {
        href: c.href,
        protocol: c.protocol,
        host: c.host,
        hostname: e,
        pathname: d,
        search: c.search,
        hash: c.hash,
        port: c.port,
      };
      Ij < 5 && ((Hj[a] = b), Ij++);
    }
    return b;
  }
  function Kj(a, b, c) {
    var d = Jj(a);
    return ic(b, d, c);
  }
  function Lj(a) {
    var b = Jj(x.location.href),
      c = Dj(b, "host", !1);
    if (c && c.match(zj)) {
      var d = Dj(b, "path");
      if (d) {
        var e = d.split(a + "=");
        if (e.length > 1) return e[1].split(";")[0].split("?")[0];
      }
    }
  }
  var Mj = {
      "https://www.google.com": "/g",
      "https://www.googleadservices.com": "/as",
      "https://pagead2.googlesyndication.com": "/gs",
    },
    Nj = [
      "/as/d/ccm/conversion",
      "/g/d/ccm/conversion",
      "/gs/ccm/conversion",
      "/d/ccm/form-data",
    ];
  function Oj() {
    return Hf(47) ? If(54) !== 1 : !1;
  }
  function Pj() {
    var a = E(18),
      b = a.length;
    return a[b - 1] === "/" ? a.substring(0, b - 1) : a;
  }
  function Qj(a, b) {
    if (a) {
      var c = "" + a;
      c.indexOf("http://") !== 0 &&
        c.indexOf("https://") !== 0 &&
        (c = "https://" + c);
      c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
      return Jj("" + c + b).href;
    }
  }
  function Rj(a) {
    if (Sj()) return Qj(a, "/analytics.js");
  }
  function Tj(a) {
    return a === 2 || a === 3;
  }
  function Uj(a) {
    return O(588) && a === 3;
  }
  function Sj() {
    return Oj() || Hf(50);
  }
  function Vj() {
    return !!rj.ij && rj.ij.split("@@").join("") !== "SGTM_TOKEN";
  }
  function Wj(a) {
    var b = n([H.A.wc, H.A.yc]),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next()) {
        var e = Q(a, c.value);
        if (e) return e;
      }
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
  }
  function Xj(a, b, c) {
    c = c === void 0 ? "" : c;
    if (!Oj()) return a;
    var d = b ? Mj[a] || "" : "";
    d === "/gs" && (c = "");
    return "" + Pj() + d + c;
  }
  function Yj(a) {
    if (Oj()) {
      var b = n(Nj),
        c = b.next(),
        d;
      try {
        for (; !c.done; c = b.next()) {
          var e = c.value;
          if (Zb(a, "" + Pj() + e)) return "::";
        }
      } finally {
        c && !c.done && (d = b.return) && d.call(b);
      }
    }
  }
  function Zj() {
    var a = x;
    if (!a) return !1;
    try {
      if (a === a.top) return !1;
      var b = a.location.pathname;
      return b.indexOf("/_/service_worker/") !== -1 && $b(b, "/sw_iframe.html");
    } catch (c) {
      return !1;
    }
  }
  function ak(a, b, c) {
    var d = "https://" + a + b;
    return c
      ? function () {
          return Oj() ? Pj() + c + b : d;
        }
      : function () {
          return d;
        };
  }
  var bk = {},
    ck =
      ((bk[22] = ak("www.googleadservices.com", "/ccm/conversion", "/as/d")),
      (bk[60] = ak("pagead2.googlesyndication.com", "/ccm/conversion", "/gs")),
      (bk[23] = ak("www.google.com", "/ccm/conversion", "/g/d")),
      bk);
  var dk = {},
    ek =
      ((dk[5] = ak("www.googleadservices.com", "/pagead/conversion")),
      (dk[6] = ak(
        "pagead2.googlesyndication.com",
        "/pagead/conversion",
        "/gs"
      )),
      (dk[8] = ak("www.google.com", "/pagead/1p-conversion")),
      (dk[66] = ak("www.google.com", "/pagead/uconversion")),
      (dk[63] = ak("www.googleadservices.com", "/pagead/conversion")),
      (dk[64] = ak(
        "pagead2.googlesyndication.com",
        "/pagead/conversion",
        "/gs"
      )),
      (dk[65] = ak("www.google.com", "/pagead/1p-conversion")),
      (dk[76] = ak("www.google.com", "/measurement/enhanced", "/d")),
      (dk[74] = function () {
        return Pj() + "/as/p/c";
      }),
      dk);
  var fk = {},
    gk =
      ((fk[45] = ak("www.google.com", "/ccm/collect")),
      (fk[46] = ak("pagead2.googlesyndication.com", "/ccm/collect", "/gs")),
      (fk[69] = ak("ad.doubleclick.net", "/ccm/s/collect")),
      (fk[58] = ak("www.google.com", "/pagead/set_partitioned_cookie")),
      (fk[57] = ak(
        "www.googleadservices.com",
        "/pagead/set_partitioned_cookie"
      )),
      fk);
  var hk = {},
    ik =
      ((hk[9] = ak(
        "googleads.g.doubleclick.net",
        "/pagead/viewthroughconversion"
      )),
      (hk[68] = ak("www.google.com", "/rmkt/collect")),
      hk);
  var jk = {},
    kk =
      ((jk[11] = ak("www.google.com", "/pagead/form-data", "/d")),
      (jk[21] = ak("www.google.com", "/ccm/form-data", "/d")),
      (jk[72] = ak("google.com", "/pagead/form-data", "/d")),
      (jk[73] = ak("google.com", "/ccm/form-data", "/d")),
      jk);
  var lk = {},
    mk =
      ((lk[51] = ak("www.google.com", "/travel/flights/click/conversion")), lk);
  var nk = {},
    ok =
      ((nk[1] = function () {
        return "https://ad.doubleclick.net/activity;";
      }),
      (nk[2] = function () {
        return (
          (Oj() ? Pj() : "https://ade.googlesyndication.com") +
          "/ddm/activity" +
          (O(467) ? ";" : "/")
        );
      }),
      (nk[3] = function (a) {
        return "https://" + a.Lr + ".fls.doubleclick.net/activityi;";
      }),
      nk);
  function pk(a) {
    sb("HEALTH", a);
  }
  function S(a) {
    sb("GTM", a);
  }
  var qk = {
    da: {
      uu: "aw_user_data_cache",
      Xg: "cookie_deprecation_label",
      Yg: "diagnostics_page_id",
      ap: "ememo",
      Hu: "em_registry",
      Mi: "eab",
      Vu: "fl_user_data_cache",
      Xu: "ga4_user_data_cache",
      tv: "idc_pv_claim",
      Ke: "ip_geo_data_cache",
      Ri: "ip_geo_fetch_in_progress",
      og: "mtt_study_state",
      Rm: "nb_data",
      Kq: "page_experiment_ids",
      Sm: "pld",
      Oe: "pt_data",
      Tm: "pt_listener_set",
      cj: "retry_containers",
      Ih: "service_worker_endpoint",
      Sq: "shared_user_id",
      Tq: "shared_user_id_requested",
      kj: "shared_user_id_source",
      Fv: "awh",
      ar: "universal_claim_registry",
    },
  };
  var rk = (function (a) {
    return tf(function (b) {
      for (var c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  })(qk.da);
  function sk(a, b) {
    b = b === void 0 ? !1 : b;
    if (rk(a)) {
      var c,
        d,
        e =
          (d = (c = Vc("google_tag_data", {})).xcd) != null ? d : (c.xcd = {});
      if (e[a]) return e[a];
      if (b) {
        var f = void 0,
          g = 1,
          h = {},
          k = {
            set: function (m) {
              f = m;
              k.notify();
            },
            get: function () {
              return f;
            },
            subscribe: function (m) {
              h[String(g)] = m;
              return g++;
            },
            unsubscribe: function (m) {
              var p = String(m);
              return h.hasOwnProperty(p) ? (delete h[p], !0) : !1;
            },
            notify: function () {
              var m = n(Object.keys(h)),
                p = m.next(),
                q;
              try {
                for (; !p.done; p = m.next()) {
                  var r = p.value;
                  try {
                    h[r](a, f);
                  } catch (t) {}
                }
              } finally {
                p && !p.done && (q = m.return) && q.call(m);
              }
            },
          };
        return (e[a] = k);
      }
    }
  }
  function tk(a, b) {
    var c = sk(a, !0);
    c && c.set(b);
  }
  function uk(a) {
    var b;
    return (b = sk(a)) == null ? void 0 : b.get();
  }
  function vk(a, b) {
    var c = sk(a, !0);
    if (c) return c.get() === void 0 && c.set(b), c.get();
  }
  function wk(a, b) {
    if (typeof b === "function") {
      var c;
      return (c = sk(a, !0)) == null ? void 0 : c.subscribe(b);
    }
  }
  function xk(a, b) {
    var c = sk(a);
    return c ? c.unsubscribe(b) : !1;
  }
  function yk(a) {
    if (rk(a)) {
      var b;
      (b = sk(a)) == null || b.notify();
    }
  }
  var zk = function () {
    this.D = {};
    this.J = !1;
  };
  zk.prototype.bind = function () {
    this.J ||
      ((this.D = Ak()), this.D["0"] && vk(qk.da.Ke, JSON.stringify(this.D)));
  };
  var Ek = function () {
      var a = Bk,
        b = Ck,
        c = void 0,
        d = function () {
          c !== void 0 && xk(qk.da.Ke, c);
          try {
            var f = uk(qk.da.Ke);
            b.D = JSON.parse(f);
          } catch (g) {
            S(123), pk(2), (b.D = {});
          }
          b.J = !0;
          a();
        },
        e = uk(qk.da.Ke);
      e ? d(e) : ((c = wk(qk.da.Ke, d)), Dk());
    },
    Dk = function () {
      if (!uk(qk.da.Ri)) {
        tk(qk.da.Ri, !0);
        var a = function (b) {
          tk(qk.da.Ke, b || "{}");
          tk(qk.da.Ri, !1);
        };
        try {
          x.fetch("https://www.google.com/ccm/geo", {
            method: "GET",
            cache: "no-store",
            mode: "cors",
            credentials: "omit",
          }).then(
            function (b) {
              b.ok
                ? b.text().then(
                    function (c) {
                      a(c);
                    },
                    function () {
                      a();
                    }
                  )
                : a();
            },
            function () {
              a();
            }
          );
        } catch (b) {
          a();
        }
      }
    },
    Ak = function () {
      var a = E(22);
      try {
        return JSON.parse(qb(a));
      } catch (b) {
        return S(123), pk(2), {};
      }
    },
    Fk = function () {
      return Ck.D["0"] || "";
    },
    Gk = function () {
      return Ck.D["1"] || "";
    },
    Hk = function () {
      var a = Ck,
        b = !1;
      return b;
    },
    Ik = function () {
      return Ck.D["6"] !== !1;
    },
    Jk = function () {
      var a = Ck,
        b = "";
      return b;
    },
    Kk = function () {
      var a = Ck,
        b = "";
      return b;
    },
    Ck = new zk();
  function Lk(a) {
    a = a === void 0 ? "g/collect" : a;
    return "https://" + (Jk() || "www") + ".google-analytics.com/" + a;
  }
  function Mk(a) {
    a = a === void 0 ? "g/collect" : a;
    var b = Jk();
    return "https://" + (b ? b + "." : "") + "analytics.google.com/" + a;
  }
  var Nk = {},
    Ok =
      ((Nk[17] = function () {
        return Oj() && !Jk() ? Pj() + "/ag/g/c" : Mk();
      }),
      (Nk[16] = function () {
        return Oj() && !Jk() ? Pj() + "/ga/g/c" : Lk();
      }),
      (Nk[67] = function () {
        var a;
        a = a === void 0 ? "g/collect" : a;
        return Jk() ? "" : "https://www.google.com/" + a;
      }),
      Nk);
  function Pk(a, b, c) {
    var d = ak(b, "/measurement/conversion", c);
    return function () {
      return Jk() ? a("measurement/conversion") : d();
    };
  }
  var Qk = {},
    Rk =
      ((Qk[55] = Pk(Lk, "pagead2.googlesyndication.com", "/gs")),
      (Qk[54] = Pk(Mk, "www.google.com", "/g")),
      Qk);
  function Sk(a) {
    return function () {
      return "" + (Oj() ? Pj() : "https://" + E(21)) + a;
    };
  }
  var Tk = {},
    Uk = ((Tk[61] = Sk("/td")), (Tk[56] = Sk("/a")), Tk);
  var Vk = ma(Object, "assign").call(
    Object,
    {},
    ck,
    ek,
    gk,
    ik,
    kk,
    mk,
    ok,
    Rk,
    Ok,
    Uk
  );
  function Wk(a) {
    var b = 0;
    a.Bc.forEach(function (c) {
      b |= 1 << c;
    });
    return b;
  }
  function Xk() {
    return { total: 0, nb: 0, Bc: new Set(), df: {} };
  }
  function Yk(a, b, c, d) {
    var e = Object.keys(a.ef)
      .sort(function (f, g) {
        return Number(f) - Number(g);
      })
      .map(function (f) {
        return [f, b(a.ef[f])];
      })
      .filter(function (f) {
        return f[1] !== void 0;
      })
      .map(function (f) {
        return f.join(c);
      })
      .join(d);
    return e ? e : void 0;
  }
  function Zk(a, b) {
    var c, d, e;
    c = c === void 0 ? "_" : c;
    d = d === void 0 ? ";" : d;
    e = e === void 0 ? "~" : e;
    var f = [],
      g = n(Object.keys(a.df).sort()),
      h = g.next(),
      k;
    try {
      for (; !h.done; h = g.next()) {
        var m = h.value,
          p = Yk(a.df[m], b, c, d);
        if (p) {
          var q = void 0;
          f.push("" + ((q = m) != null ? q : "") + d + p);
        }
      }
    } finally {
      h && !h.done && (k = g.return) && k.call(g);
    }
    return f.length ? f.join(e) : void 0;
  }
  function $k(a) {
    a.nb = 0;
    a.Bc.clear();
    var b = n(Object.keys(a.df)),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next()) {
        var e = a.df[c.value];
        e.nb = 0;
        e.Bc.clear();
        var f = n(Object.keys(e.ef)),
          g = f.next(),
          h;
        try {
          for (; !g.done; g = f.next()) {
            var k = e.ef[g.value];
            k.nb = 0;
            k.Bc.clear();
          }
        } finally {
          g && !g.done && (h = f.return) && h.call(f);
        }
      }
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
  }
  function al(a, b, c, d, e) {
    d = d === void 0 ? 1 : d;
    a.total += d;
    a.nb += d;
    var f,
      g = b === void 0 ? "" : b;
    f = a.df[g] || (a.df[g] = { total: 0, nb: 0, Bc: new Set(), ef: {} });
    f.total += d;
    f.nb += d;
    var h,
      k = String(c);
    h = f.ef[k] || (f.ef[k] = { total: 0, nb: 0, Bc: new Set() });
    h.total += d;
    h.nb += d;
    e !== void 0 && (a.Bc.add(e), f.Bc.add(e), h.Bc.add(e));
  }
  var bl = function () {
    this.D = Xk();
  };
  bl.prototype.increment = function (a, b) {
    al(this.D, a, b);
  };
  var cl = new bl();
  function dl(a) {
    var b = String(a["function"] || "").replace(/_/g, "");
    return Zb(b, "cvt") ? "cvt" : b;
  }
  var el =
    x.location.search.indexOf("?gtm_latency=") >= 0 ||
    x.location.search.indexOf("&gtm_latency=") >= 0;
  var gl = function () {
      var a = fl;
      return O(603) && Hf(65, !1) && !a.aa;
    },
    fl = new (function (a) {
      this.U = a();
      var b = If(27);
      this.M = el || this.U < b;
      var c = If(42);
      this.aa = el || this.U >= 1 - c;
      var d = O(603) && Hf(65, !1);
      this.J = this.aa || d;
      var e = If(27),
        f = If(63);
      this.D = el || f === 1 || (this.U >= e && this.U < e + f);
    })(function () {
      return Math.random();
    });
  var hl = function () {
    this.D = {};
  };
  hl.prototype.register = function (a, b, c) {
    if (fl.J) {
      var d = il(b, c);
      if (d) {
        var e,
          f = b;
        f === 4 && (f = 5);
        var g = this.D[f];
        g || (g = this.D[f] = {});
        e = g;
        var h = e[d];
        h || (h = e[d] = []);
        h.push(ma(Object, "assign").call(Object, {}, a));
        cl.increment(a.destinationId, a.endpoint);
        a.endpoint !== 56 && a.endpoint !== 61 && fj(dj, "mde", !0);
      }
    }
  };
  var ll = function (a, b) {
      var c = jl,
        d = il(a, b);
      if (d) {
        var e = kl(c, a);
        if (e) {
          var f = e[d];
          f &&
            (e[d] = f.filter(function (g) {
              return !g.so;
            }));
        }
      }
    },
    kl = function (a, b) {
      b === 4 && (b = 5);
      return a.D[b];
    },
    il = function (a, b) {
      var c = b;
      if (b[0] === "/") {
        var d;
        c = ((d = x.location) == null ? void 0 : d.origin) + b;
      }
      try {
        var e = new URL(c);
        return a === 2 ? e.origin : e.origin + e.pathname;
      } catch (f) {}
    },
    jl = new hl();
  function ml(a) {
    switch (a) {
      case "script-src":
        return 4;
      case "script-src-elem":
        return 5;
      case "frame-src":
        return 2;
      case "connect-src":
        return 1;
      case "img-src":
        return 3;
    }
  }
  function nl(a, b, c) {
    var d,
      e = a.GooglebQhCsO;
    e || ((e = {}), (a.GooglebQhCsO = e));
    d = e;
    if (d[b]) return !1;
    d[b] = [];
    d[b][0] = c;
    return !0;
  }
  var ol, pl;
  a: {
    for (var ql = ["CLOSURE_FLAGS"], rl = Qa, sl = 0; sl < ql.length; sl++)
      if (((rl = rl[ql[sl]]), rl == null)) {
        pl = null;
        break a;
      }
    pl = rl;
  }
  var tl = pl && pl[610401301];
  ol = tl != null ? tl : !1;
  function ul() {
    var a = Qa.navigator;
    if (a) {
      var b = a.userAgent;
      if (b) return b;
    }
    return "";
  }
  var vl,
    wl = Qa.navigator;
  vl = wl ? wl.userAgentData || null : null;
  function xl(a) {
    if (!ol || !vl) return !1;
    for (var b = 0; b < vl.brands.length; b++) {
      var c = vl.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function yl(a) {
    return ul().indexOf(a) != -1;
  }
  function zl() {
    return ol ? !!vl && vl.brands.length > 0 : !1;
  }
  function Al() {
    return zl() ? !1 : yl("Opera");
  }
  function Bl() {
    return yl("Firefox") || yl("FxiOS");
  }
  function Cl() {
    return zl()
      ? xl("Chromium")
      : ((yl("Chrome") || yl("CriOS")) && !(zl() ? 0 : yl("Edge"))) ||
          yl("Silk");
  }
  function Dl() {
    return ol ? !!vl && !!vl.platform : !1;
  }
  function El() {
    return yl("iPhone") && !yl("iPod") && !yl("iPad");
  }
  function Fl() {
    El() || yl("iPad") || yl("iPod");
  }
  var Gl = function (a) {
    Gl[" "](a);
    return a;
  };
  Gl[" "] = function () {};
  Al();
  zl() || yl("Trident") || yl("MSIE");
  yl("Edge");
  !yl("Gecko") ||
    (ul().toLowerCase().indexOf("webkit") != -1 && !yl("Edge")) ||
    yl("Trident") ||
    yl("MSIE") ||
    yl("Edge");
  ul().toLowerCase().indexOf("webkit") != -1 && !yl("Edge") && yl("Mobile");
  Dl() || yl("Macintosh");
  Dl() || yl("Windows");
  (Dl() ? vl.platform === "Linux" : yl("Linux")) || Dl() || yl("CrOS");
  Dl() || yl("Android");
  El();
  yl("iPad");
  yl("iPod");
  Fl();
  ul().toLowerCase().indexOf("kaios");
  Bl();
  El() || yl("iPod");
  yl("iPad");
  !yl("Android") || Cl() || Bl() || Al() || yl("Silk");
  Cl();
  !yl("Safari") ||
    Cl() ||
    (zl() ? 0 : yl("Coast")) ||
    Al() ||
    (zl() ? 0 : yl("Edge")) ||
    (zl() ? xl("Microsoft Edge") : yl("Edg/")) ||
    (zl() ? xl("Opera") : yl("OPR")) ||
    Bl() ||
    yl("Silk") ||
    yl("Android") ||
    Fl();
  var Hl = {},
    Il = null;
  function Jl(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e > 255 && ((b[c++] = e & 255), (e >>= 8));
      b[c++] = e;
    }
    var f = 4;
    f === void 0 && (f = 0);
    if (!Il) {
      Il = {};
      for (
        var g =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          h = ["+/=", "+/", "-_=", "-_.", "-_"],
          k = 0;
        k < 5;
        k++
      ) {
        var m = g.concat(h[k].split(""));
        Hl[k] = m;
        for (var p = 0; p < m.length; p++) {
          var q = m[p];
          Il[q] === void 0 && (Il[q] = p);
        }
      }
    }
    for (
      var r = Hl[f],
        t = Array(Math.floor(b.length / 3)),
        u = r[64] || "",
        v = 0,
        w = 0;
      v < b.length - 2;
      v += 3
    ) {
      var y = b[v],
        z = b[v + 1],
        C = b[v + 2],
        D = r[y >> 2],
        G = r[((y & 3) << 4) | (z >> 4)],
        F = r[((z & 15) << 2) | (C >> 6)],
        I = r[C & 63];
      t[w++] = "" + D + G + F + I;
    }
    var L = 0,
      P = u;
    switch (b.length - v) {
      case 2:
        (L = b[v + 1]), (P = r[(L & 15) << 2] || u);
      case 1:
        var R = b[v];
        t[w] = "" + r[R >> 2] + r[((R & 3) << 4) | (L >> 4)] + P + u;
    }
    return t.join("");
  }
  var Kl = function (a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  };
  var Ll = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Ml(a, b, c, d) {
    for (var e = b, f = c.length; (e = a.indexOf(c, e)) >= 0 && e < d; ) {
      var g = a.charCodeAt(e - 1);
      if (g == 38 || g == 63) {
        var h = a.charCodeAt(e + f);
        if (!h || h == 61 || h == 38 || h == 35) return e;
      }
      e += f + 1;
    }
    return -1;
  }
  var Nl = /#|$/;
  function Ol(a, b) {
    var c = a.search(Nl),
      d = Ml(a, 0, b, c);
    if (d < 0) return null;
    var e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return Kl(a.slice(d, e !== -1 ? e : 0));
  }
  var Pl = /[?&]($|#)/;
  function Ql(a, b, c) {
    for (var d, e = a.search(Nl), f = 0, g, h = []; (g = Ml(a, f, b, e)) >= 0; )
      h.push(a.substring(f, g)), (f = Math.min(a.indexOf("&", g) + 1 || e, e));
    h.push(a.slice(f));
    d = h.join("").replace(Pl, "$1");
    var k,
      m = c != null ? "=" + encodeURIComponent(String(c)) : "";
    var p = b + m;
    if (p) {
      var q,
        r = d.indexOf("#");
      r < 0 && (r = d.length);
      var t = d.indexOf("?"),
        u;
      t < 0 || t > r ? ((t = r), (u = "")) : (u = d.substring(t + 1, r));
      q = [d.slice(0, t), u, d.slice(r)];
      var v = q[1];
      q[1] = p ? (v ? v + "&" + p : p) : v;
      k = q[0] + (q[1] ? "?" + q[1] : "") + q[2];
    } else k = d;
    return k;
  }
  function Rl(a, b, c, d, e, f, g) {
    var h = Ol(c, "fmt");
    if (d) {
      var k = Ol(c, "random"),
        m = Ol(c, "label") || "";
      if (!k) return;
      var p = Jl(Kl(m) + ":" + Kl(k));
      if (!nl(a, p, d)) return;
    }
    h && Number(h) !== 4
      ? ((c = Ql(c, "rfmt", h)), (c = Ql(c, "fmt", 4)))
      : h || (c = Ql(c, "fmt", 4));
    cd(
      c,
      function () {
        g == null || Sl(g, c);
        a.google_noFurtherRedirects &&
          d &&
          ((a.google_noFurtherRedirects = null), d());
      },
      function () {
        g == null || Sl(g, c);
        e == null || e();
      },
      f,
      b.getElementsByTagName("script")[0].parentElement || void 0
    );
    return c;
  }
  function Ul(a) {
    var b = Oa.apply(1, arguments);
    jl.register(a, 1, b[0]);
    rd.apply(null, xa(b));
  }
  function Vl(a) {
    var b = Oa.apply(1, arguments);
    jl.register(a, 1, b[0]);
    sd.apply(null, xa(b));
  }
  function Wl(a) {
    var b = Oa.apply(1, arguments);
    jl.register(a, 3, b[0]);
    hd.apply(null, xa(b));
  }
  function Xl(a) {
    var b = Oa.apply(1, arguments);
    jl.register(a, 1, b[0]);
    return vd.apply(null, xa(b));
  }
  function Yl(a) {
    var b = Oa.apply(1, arguments);
    jl.register(a, 5, b[0]);
    cd.apply(null, xa(b));
  }
  function Zl(a) {
    var b = Oa.apply(1, arguments);
    b[0] && jl.register(a, 2, b[0]);
    gd.apply(null, xa(b));
  }
  function $l(a) {
    var b = Rl.apply(null, xa(Oa.apply(1, arguments)));
    b && jl.register(a, 4, b);
    return b;
  }
  var am = /gtag[.\/]js/,
    bm = /gtm[.\/]js/,
    dm = function (a) {
      var b = cm;
      if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
        var c;
        a: {
          var d,
            e = (d = a.scriptElement) == null ? void 0 : d.src;
          if (e) {
            for (
              var f = Hf(47),
                g = Jj(e),
                h = f ? g.pathname : "" + g.hostname + g.pathname,
                k = A.scripts,
                m = "",
                p = 0;
              p < k.length;
              ++p
            ) {
              var q = k[p];
              if (
                !(
                  q.innerHTML.length === 0 ||
                  (!f &&
                    q.innerHTML.indexOf(
                      a.scriptContainerId || "SHOULD_NOT_BE_SET"
                    ) < 0) ||
                  q.innerHTML.indexOf(h) < 0
                )
              ) {
                if (q.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                  c = String(p);
                  break a;
                }
                m = String(p);
              }
            }
            if (m) {
              c = m;
              break a;
            }
          }
          c = void 0;
        }
        var r = c;
        if (r) return (b.D = !0), r;
      }
      var t = [].slice.call(A.scripts);
      return a.scriptElement ? String(t.indexOf(a.scriptElement)) : "-1";
    },
    em = function (a) {
      if (cm.D) return "1";
      var b,
        c = (b = a.scriptElement) == null ? void 0 : b.src;
      if (c) {
        if (am.test(c)) return "3";
        if (bm.test(c)) return "2";
      }
      return "0";
    },
    cm = new (function () {
      this.D = !1;
    })();
  function fm(a) {
    var b = gm().destinationArray[a],
      c = gm().destination[a];
    return b && b.length > 0 ? b[0] : c;
  }
  function hm(a, b) {
    var c = gm();
    c.pending || (c.pending = []);
    Hb(c.pending, function (d) {
      return (
        d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
      );
    }) || c.pending.push({ target: a, onLoad: b });
  }
  function im() {
    var a = x.google_tags_first_party;
    Array.isArray(a) || (a = []);
    var b = {},
      c = n(a),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) b[d.value] = !0;
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    return Object.freeze(b);
  }
  var jm = function () {
    this.container = {};
    this.destination = {};
    this.destinationArray = {};
    this.canonical = {};
    this.pending = [];
    this.injectedFirstPartyContainers = {};
    this.injectedFirstPartyContainers = im();
  };
  function gm() {
    var a = Vc("google_tag_data", {}),
      b = a.tidr;
    (b && typeof b === "object") || ((b = new jm()), (a.tidr = b));
    var c = b;
    c.container || (c.container = {});
    c.destination || (c.destination = {});
    c.destinationArray || (c.destinationArray = {});
    c.canonical || (c.canonical = {});
    c.pending || (c.pending = []);
    c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = im());
    return c;
  }
  function km() {
    return (
      Hf(7) &&
      lm().some(function (a) {
        return a === E(5);
      })
    );
  }
  function mm() {
    var a;
    return (a = Jf(55)) != null ? a : [];
  }
  function nm() {
    return E(6) || "_" + E(5);
  }
  function om() {
    var a = E(10);
    return a ? a.split("|") : [E(5)];
  }
  function lm() {
    var a = Jf(59);
    return Array.isArray(a)
      ? a
          .filter(function (b) {
            return typeof b === "string";
          })
          .filter(function (b) {
            return b.indexOf("GTM-") !== 0;
          })
      : [];
  }
  function pm() {
    var a = qm(rm()),
      b = a && a.parent;
    if (b) return qm(b);
  }
  function um() {
    var a = qm(rm());
    if (a) {
      for (; a.parent; ) {
        var b = qm(a.parent);
        if (!b) break;
        a = b;
      }
      return a;
    }
  }
  function qm(a) {
    var b = gm();
    return a.isDestination ? fm(a.ctid) : b.container[a.ctid];
  }
  function wm() {
    var a = gm();
    if (a.pending) {
      for (
        var b, c = [], d = !1, e = om(), f = lm(), g = {}, h = 0;
        h < a.pending.length;
        g = { Og: void 0 }, h++
      )
        (g.Og = a.pending[h]),
          Hb(
            g.Og.target.isDestination ? f : e,
            (function (k) {
              return function (m) {
                return m === k.Og.target.ctid;
              };
            })(g)
          )
            ? d || ((b = g.Og.onLoad), (d = !0))
            : c.push(g.Og);
      a.pending = c;
      if (b)
        try {
          b(nm());
        } catch (k) {}
    }
  }
  function xm() {
    var a = E(5),
      b = om(),
      c = lm(),
      d = mm(),
      e = function (t, u) {
        var v = {
          canonicalContainerId: E(6),
          scriptContainerId: a,
          state: 2,
          containers: b.slice(),
          destinations: c.slice(),
        };
        Sc && (v.scriptElement = Sc);
        Uc && (v.scriptSource = Uc);
        pm() === void 0 &&
          ((v.htmlLoadOrder = dm(v)), (v.loadScriptType = em(v)));
        var w, y;
        switch (u) {
          case 0:
            w = function (D) {
              f.container[t] = D;
            };
            y = f.container[t];
            break;
          case 1:
            w = function (D) {
              f.destinationArray[t] = f.destinationArray[t] || [];
              f.destinationArray[t].unshift(D);
            };
            var z,
              C =
                ((z = f.destinationArray[t]) == null ? void 0 : z[0]) ||
                f.destination[t];
            !C || (C.state !== 0 && C.state !== 1) || (y = C);
            break;
          case 2:
            (w = function (D) {
              f.destinationArray[t] = f.destinationArray[t] || [];
              f.destinationArray[t].push(D);
            }),
              (y = void 0);
        }
        w &&
          (y
            ? (y.state === 0 && S(93), ma(Object, "assign").call(Object, y, v))
            : w(v));
      },
      f = gm(),
      g = n(b),
      h = g.next(),
      k;
    try {
      for (; !h.done; h = g.next()) e(h.value, 0);
    } finally {
      h && !h.done && (k = g.return) && k.call(g);
    }
    var m = n(c),
      p = m.next(),
      q;
    try {
      for (; !p.done; p = m.next()) {
        var r = p.value;
        d.includes(r) ? e(r, 1) : e(r, 2);
      }
    } finally {
      p && !p.done && (q = m.return) && q.call(m);
    }
    f.canonical[nm()] = {};
    wm();
  }
  function ym() {
    var a = nm();
    return !!gm().canonical[a];
  }
  function zm(a) {
    return !!gm().container[a];
  }
  function Am() {
    var a = rm(),
      b = qm(a);
    return b && b.context;
  }
  function Bm(a) {
    var b = fm(a);
    return b ? b.state !== 0 : !1;
  }
  function rm() {
    return { ctid: E(5), isDestination: Hf(7) };
  }
  function Cm(a, b, c) {
    var d = rm(),
      e = gm().container[a];
    (e && e.state !== 3) ||
      ((gm().container[a] = { state: 1, context: b, parent: d }),
      hm({ ctid: a, isDestination: !1 }, c));
  }
  function Dm(a, b, c) {
    var d = gm(),
      e = fm(a);
    e
      ? (e.state = 1)
      : ((e = { context: b, state: 1, parent: rm() }),
        (d.destinationArray[a] = [e]));
    hm({ ctid: a, isDestination: !0 }, c);
  }
  function Em(a, b, c, d) {
    var e = gm(),
      f = fm(a);
    f
      ? (f.state = 0)
      : ((f = { state: 0, transportUrl: b, context: c, parent: rm() }),
        (e.destinationArray[a] = [f]));
    hm({ ctid: a, isDestination: !0 }, d);
    S(91);
  }
  function Fm() {
    var a = gm().container,
      b;
    for (b in a) if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
    return !1;
  }
  function Gm() {
    var a = {};
    Lb(gm().destination, function (b, c) {
      (c == null ? void 0 : c.state) === 0 && (a[b] = c);
    });
    Lb(gm().destinationArray, function (b, c) {
      var d = c[0];
      (d == null ? void 0 : d.state) === 0 && (a[b] = d);
    });
    return a;
  }
  function Hm(a) {
    return !!(
      a &&
      a.parent &&
      a.context &&
      a.context.source === 1 &&
      a.parent.ctid.indexOf("GTM-") !== 0
    );
  }
  function Im() {
    var a = gm(),
      b = n(om()),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next())
        if (a.injectedFirstPartyContainers[c.value]) return !0;
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
    return !1;
  }
  var Jm = { Oa: { Je: 0, Ne: 1, Fh: 2 } };
  Jm.Oa[Jm.Oa.Je] = "FULL_TRANSMISSION";
  Jm.Oa[Jm.Oa.Ne] = "LIMITED_TRANSMISSION";
  Jm.Oa[Jm.Oa.Fh] = "NO_TRANSMISSION";
  var Km = { ia: { ed: 0, eb: 1, sd: 2, Qb: 3 } };
  Km.ia[Km.ia.ed] = "NO_QUEUE";
  Km.ia[Km.ia.eb] = "ADS";
  Km.ia[Km.ia.sd] = "ANALYTICS";
  Km.ia[Km.ia.Qb] = "MONITORING";
  function Lm() {
    var a = Vc("google_tag_data", {});
    return (a.ics = a.ics || new Mm());
  }
  var Mm = function () {
    this.entries = {};
    this.waitPeriodTimedOut =
      this.wasSetLate =
      this.accessedAny =
      this.accessedDefault =
      this.usedImplicit =
      this.usedUpdate =
      this.usedDefault =
      this.usedDeclare =
      this.active =
        !1;
    this.listeners = [];
  };
  Mm.prototype.default = function (a, b, c, d, e, f, g) {
    this.usedDefault ||
      this.usedDeclare ||
      (!this.accessedDefault && !this.accessedAny) ||
      (this.wasSetLate = !0);
    this.usedDefault = this.active = !0;
    sb("TAGGING", 19);
    b == null ? sb("TAGGING", 18) : Nm(this, a, b === "granted", c, d, e, f, g);
  };
  Mm.prototype.waitForUpdate = function (a, b, c) {
    for (var d = 0; d < a.length; d++)
      Nm(this, a[d], void 0, void 0, "", "", b, c);
  };
  var Nm = function (a, b, c, d, e, f, g, h) {
    var k = a.entries,
      m = k[b] || {},
      p = m.region,
      q = d && Eb(d) ? d.toUpperCase() : void 0;
    e = e.toUpperCase();
    f = f.toUpperCase();
    if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
      var r = !!(g && g > 0 && m.update === void 0),
        t = {
          region: q,
          declare_region: m.declare_region,
          implicit: m.implicit,
          default: c !== void 0 ? c : m.default,
          declare: m.declare,
          update: m.update,
          quiet: r,
        };
      if (e !== "" || m.default !== !1) k[b] = t;
      r &&
        x.setTimeout(function () {
          k[b] === t &&
            t.quiet &&
            (sb("TAGGING", 2),
            (a.waitPeriodTimedOut = !0),
            a.clearTimeout(b, void 0, h),
            a.notifyListeners());
        }, g);
    }
  };
  l = Mm.prototype;
  l.clearTimeout = function (a, b, c) {
    var d = [a],
      e = c.delegatedConsentTypes,
      f;
    for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
    var g = this.entries[a] || {},
      h = this.getConsentState(a, c);
    if (g.quiet) {
      g.quiet = !1;
      var k = n(d),
        m = k.next(),
        p;
      try {
        for (; !m.done; m = k.next()) Om(this, m.value);
      } finally {
        m && !m.done && (p = k.return) && p.call(k);
      }
    } else if (b !== void 0 && h !== b) {
      var q = n(d),
        r = q.next(),
        t;
      try {
        for (; !r.done; r = q.next()) Om(this, r.value);
      } finally {
        r && !r.done && (t = q.return) && t.call(q);
      }
    }
  };
  l.update = function (a, b, c) {
    this.usedDefault ||
      this.usedDeclare ||
      this.usedUpdate ||
      !this.accessedAny ||
      (this.wasSetLate = !0);
    this.usedUpdate = this.active = !0;
    if (b != null) {
      var d = this.getConsentState(a, c),
        e = this.entries;
      (e[a] = e[a] || {}).update = b === "granted";
      this.clearTimeout(a, d, c);
    }
  };
  l.declare = function (a, b, c, d, e) {
    this.usedDeclare = this.active = !0;
    var f = this.entries,
      g = f[a] || {},
      h = g.declare_region,
      k = c && Eb(c) ? c.toUpperCase() : void 0;
    d = d.toUpperCase();
    e = e.toUpperCase();
    if (d === "" || k === e || (k === d ? h !== e : !k && !h)) {
      var m = {
        region: g.region,
        declare_region: k,
        declare: b === "granted",
        implicit: g.implicit,
        default: g.default,
        update: g.update,
        quiet: g.quiet,
      };
      if (d !== "" || g.declare !== !1) f[a] = m;
    }
  };
  l.implicit = function (a, b) {
    this.usedImplicit = !0;
    var c = this.entries,
      d = (c[a] = c[a] || {});
    d.implicit !== !1 && (d.implicit = b === "granted");
  };
  l.getConsentState = function (a, b) {
    var c = this.entries,
      d = c[a] || {},
      e = d.update;
    if (e !== void 0) return e ? 1 : 2;
    if (b.usedContainerScopedDefaults) {
      var f = b.containerScopedDefaults[a];
      if (f === 3) return 1;
      if (f === 2) return 2;
    } else if (((e = d.default), e !== void 0)) return e ? 1 : 2;
    if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
      var g = b.delegatedConsentTypes[a],
        h = c[g] || {};
      e = h.update;
      if (e !== void 0) return e ? 1 : 2;
      if (b.usedContainerScopedDefaults) {
        var k = b.containerScopedDefaults[g];
        if (k === 3) return 1;
        if (k === 2) return 2;
      } else if (((e = h.default), e !== void 0)) return e ? 1 : 2;
    }
    e = d.declare;
    if (e !== void 0) return e ? 1 : 2;
    e = d.implicit;
    return e !== void 0 ? (e ? 3 : 4) : 0;
  };
  l.addListener = function (a, b) {
    this.listeners.push({ consentTypes: a, fn: b });
  };
  var Om = function (a, b) {
    for (var c = 0; c < a.listeners.length; ++c) {
      var d = a.listeners[c];
      Array.isArray(d.consentTypes) &&
        d.consentTypes.indexOf(b) !== -1 &&
        (d.mo = !0);
    }
  };
  Mm.prototype.notifyListeners = function (a, b) {
    for (var c = 0; c < this.listeners.length; ++c) {
      var d = this.listeners[c];
      if (d.mo) {
        d.mo = !1;
        try {
          d.fn({ consentEventId: a, consentPriorityId: b });
        } catch (e) {}
      }
    }
  };
  var Pm = !1,
    Qm = !1,
    Rm = {},
    Sm = {
      delegatedConsentTypes: {},
      corePlatformServices: {},
      usedCorePlatformServices: !1,
      selectedAllCorePlatformServices: !1,
      containerScopedDefaults:
        ((Rm.ad_storage = 1),
        (Rm.analytics_storage = 1),
        (Rm.ad_user_data = 1),
        (Rm.ad_personalization = 1),
        Rm),
      usedContainerScopedDefaults: !1,
    };
  function Tm(a) {
    var b = Lm();
    b.accessedAny = !0;
    return (Eb(a) ? [a] : a).every(function (c) {
      switch (b.getConsentState(c, Sm)) {
        case 1:
        case 3:
          return !0;
        case 2:
        case 4:
          return !1;
        default:
          return !0;
      }
    });
  }
  function Um(a) {
    var b = Lm();
    b.accessedAny = !0;
    return b.getConsentState(a, Sm);
  }
  function Vm(a) {
    var b = Lm();
    b.accessedAny = !0;
    return !(b.entries[a] || {}).quiet;
  }
  function Wm() {
    if (!Oh(5)) return !1;
    var a = Lm();
    a.accessedAny = !0;
    if (a.active) return !0;
    if (!Sm.usedContainerScopedDefaults) return !1;
    var b = n(Object.keys(Sm.containerScopedDefaults)),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next())
        if (Sm.containerScopedDefaults[c.value] !== 1) return !0;
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
    return !1;
  }
  function Xm(a, b) {
    Lm().addListener(a, b);
  }
  function Ym(a, b) {
    Lm().notifyListeners(a, b);
  }
  function Zm(a, b) {
    if (b.every(Vm)) a({});
    else {
      var c = !1;
      Xm(b, function (d) {
        !c && b.every(Vm) && ((c = !0), a(d));
      });
    }
  }
  function $m(a, b) {
    var c = Eb(b) ? [b] : b,
      d = {},
      e = function () {
        return c.filter(function (h) {
          return Tm(h) && !d[h];
        });
      },
      f = e();
    if (f.length !== c.length) {
      var g = function (h) {
        var k = n(h),
          m = k.next(),
          p;
        try {
          for (; !m.done; m = k.next()) d[m.value] = !0;
        } finally {
          m && !m.done && (p = k.return) && p.call(k);
        }
      };
      g(f);
      Xm(c, function (h) {
        function k(q) {
          q.length !== 0 && (g(q), (h.consentTypes = q), a(h));
        }
        var m = e();
        if (m.length !== 0) {
          var p = Object.keys(d).length;
          m.length + p >= c.length
            ? k(m)
            : x.setTimeout(function () {
                k(e());
              }, 500);
        }
      });
    }
  }
  var an = function (a, b) {
    this.D = a;
    this.consentTypes = b;
  };
  an.prototype.isConsentGranted = function () {
    switch (this.D) {
      case 0:
        return this.consentTypes.every(function (a) {
          return Tm(a);
        });
      case 1:
        return this.consentTypes.some(function (a) {
          return Tm(a);
        });
      default:
        Hc(this.D, "consentsRequired had an unknown type");
    }
  };
  var bn = new (function () {
    var a = {};
    this.D =
      ((a[Km.ia.ed] = Jm.Oa.Je),
      (a[Km.ia.eb] = Jm.Oa.Je),
      (a[Km.ia.sd] = Jm.Oa.Je),
      (a[Km.ia.Qb] = Jm.Oa.Je),
      a);
    var b = {};
    this.J =
      ((b[Km.ia.ed] = new an(0, [])),
      (b[Km.ia.eb] = new an(0, ["ad_storage"])),
      (b[Km.ia.sd] = new an(0, ["analytics_storage"])),
      (b[Km.ia.Qb] = new an(1, ["ad_storage", "analytics_storage"])),
      b);
  })();
  var dn = function (a) {
    var b = this;
    this.type = a;
    this.D = [];
    Xm(bn.J[a].consentTypes, function () {
      cn(b) || b.flush();
    });
  };
  dn.prototype.flush = function () {
    var a = n(this.D),
      b = a.next(),
      c;
    try {
      for (; !b.done; b = a.next()) {
        var d = b.value;
        d();
      }
    } finally {
      b && !b.done && (c = a.return) && c.call(a);
    }
    this.D = [];
  };
  var cn = function (a) {
      return bn.D[a.type] === Jm.Oa.Fh && !bn.J[a.type].isConsentGranted();
    },
    en = function (a, b) {
      cn(a) ? a.D.push(b) : b();
    },
    fn = function () {
      this.D = new Map();
    },
    hn = function (a) {
      var b = gn;
      b.D.has(a) || b.D.set(a, new dn(a));
      return b.D.get(a);
    };
  fn.prototype.reset = function () {
    this.D.clear();
  };
  var gn = new fn();
  var jn = ["fin", "mcc", "ncc"],
    kn = function (a) {
      a = a === void 0 ? !1 : a;
      var b = ej(),
        c = dj.J,
        d = b.filter(function (q) {
          return c[q] !== void 0 && (a || !jn.includes(q));
        });
      gj(d);
      var e = {},
        f = n(d),
        g = f.next(),
        h;
      try {
        for (; !g.done; g = f.next()) {
          var k = g.value,
            m = c[k];
          typeof m === "function" && (m = m());
          m && (e[k] = m);
        }
      } finally {
        g && !g.done && (h = f.return) && h.call(f);
      }
      var p = Wi(e, { Ue: !1 });
      return p ? "&" + p + "&z=0" : "&z=0";
    },
    ln = function (a, b, c) {
      b = b === void 0 ? !1 : b;
      c = c === void 0 ? !1 : c;
      if ($i(14) && fl.J && E(5) && (c || !gl())) {
        var d = hn(Km.ia.Qb);
        if (cn(d))
          a.D ||
            ((a.D = !0),
            en(d, function () {
              ln(a);
            }));
        else {
          b && hj("fin", "1");
          var e = kn(b),
            f = Vk[61](void 0) + "?id=" + E(5) + e,
            g = { destinationId: E(5), endpoint: 61 };
          b
            ? Xl(g, f, void 0, { Zn: !0 }, void 0, function () {
                hd(f + "&img=1");
              })
            : Wl(g, f);
          a.D = !1;
          mn(e);
        }
      }
    },
    mn = function (a) {
      if (
        Uc &&
        (Zb(Uc, "https://www.googletagmanager.com/") || Hf(47)) &&
        !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)
      ) {
        var b;
        a: {
          try {
            if (Uc) {
              b = new URL(Uc);
              break a;
            }
          } catch (c) {}
          b = void 0;
        }
        b && cd("" + Uc + (Uc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a);
      }
    },
    nn = function (a) {
      ej().some(function (b) {
        return !cj[b];
      }) && ln(a, !0);
    },
    on = new (function () {
      var a = this;
      this.D = !1;
      id(x, "pagehide", function () {
        nn(a);
      });
    })();
  function pn(a, b) {
    ln(on, a === void 0 ? !1 : a, b === void 0 ? !1 : b);
  }
  var qn = [
      "ad_storage",
      "analytics_storage",
      "ad_user_data",
      "ad_personalization",
    ],
    rn = [
      H.A.wc,
      H.A.yc,
      H.A.If,
      H.A.Nb,
      H.A.xc,
      H.A.hb,
      H.A.Db,
      H.A.rb,
      H.A.Ob,
      H.A.sc,
    ],
    un = function () {
      var a = sn;
      !a.U &&
        a.D &&
        (qn.some(function (b) {
          return Sm.containerScopedDefaults[b] !== 1;
        }) ||
          tn("mbc"));
      a.U = !0;
    },
    tn = function (a) {
      fl.J && (hj(a, "1"), pn());
    },
    vn = function (a, b) {
      var c = sn;
      if (!c.M[b] && ((c.M[b] = !0), c.J[b])) {
        var d = n(rn),
          e = d.next(),
          f;
        try {
          for (; !e.done; e = d.next())
            if (Q(a, e.value)) {
              tn("erc");
              break;
            }
        } finally {
          e && !e.done && (f = d.return) && f.call(d);
        }
      }
    },
    sn = new (function () {
      this.U = this.D = !1;
      this.M = {};
      this.J = {};
    })();
  var wn = {},
    xn = Object.freeze(
      ((wn[H.A.Pc] = 1),
      (wn[H.A.eh] = 1),
      (wn[H.A.ki] = 1),
      (wn[H.A.Qc] = 1),
      (wn[H.A.Ia] = 1),
      (wn[H.A.Ob] = 1),
      (wn[H.A.Cb] = 1),
      (wn[H.A.Xb] = 1),
      (wn[H.A.Dd] = 1),
      (wn[H.A.sc] = 1),
      (wn[H.A.rb] = 1),
      (wn[H.A.Ed] = 1),
      (wn[H.A.xe] = 1),
      (wn[H.A.Qa] = 1),
      (wn[H.A.Jp] = 1),
      (wn[H.A.Hf] = 1),
      (wn[H.A.Ai] = 1),
      (wn[H.A.nh] = 1),
      (wn[H.A.Tc] = 1),
      (wn[H.A.If] = 1),
      (wn[H.A.Tp] = 1),
      (wn[H.A.Ra] = 1),
      (wn[H.A.Mf] = 1),
      (wn[H.A.Vp] = 1),
      (wn[H.A.Kd] = 1),
      (wn[H.A.Bl] = 1),
      (wn[H.A.Uc] = 1),
      (wn[H.A.Vc] = 1),
      (wn[H.A.Db] = 1),
      (wn[H.A.Kl] = 1),
      (wn[H.A.xb] = 1),
      (wn[H.A.Od] = 1),
      (wn[H.A.Zb] = 1),
      (wn[H.A.Ji] = 1),
      (wn[H.A.wc] = 1),
      (wn[H.A.th] = 1),
      (wn[H.A.Ki] = 1),
      (wn[H.A.Pd] = 1),
      (wn[H.A.yc] = 1),
      (wn[H.A.Qd] = 1),
      (wn[H.A.Ul] = 1),
      (wn[H.A.yh] = 1),
      (wn[H.A.Zc] = 1),
      (wn[H.A.fj] = 1),
      wn)
    );
  Object.freeze([
    H.A.Ca,
    H.A.Ja,
    H.A.Pb,
    H.A.wb,
    H.A.Ii,
    H.A.hb,
    H.A.Bi,
    H.A.Fp,
  ]);
  var yn = {},
    zn = Object.freeze(
      ((yn[H.A.fp] = 1),
      (yn[H.A.hp] = 1),
      (yn[H.A.jp] = 1),
      (yn[H.A.kp] = 1),
      (yn[H.A.lp] = 1),
      (yn[H.A.qp] = 1),
      (yn[H.A.rp] = 1),
      (yn[H.A.up] = 1),
      (yn[H.A.wp] = 1),
      (yn[H.A.pf] = 1),
      yn)
    ),
    An = {},
    Bn = Object.freeze(
      ((An[H.A.Wk] = 1),
      (An[H.A.Xk] = 1),
      (An[H.A.me] = 1),
      (An[H.A.ne] = 1),
      (An[H.A.Yk] = 1),
      (An[H.A.vd] = 1),
      (An[H.A.oe] = 1),
      (An[H.A.Nc] = 1),
      (An[H.A.wd] = 1),
      (An[H.A.Oc] = 1),
      (An[H.A.Lb] = 1),
      (An[H.A.pe] = 1),
      (An[H.A.oc] = 1),
      (An[H.A.Zk] = 1),
      An)
    ),
    Cn = Object.freeze([
      H.A.Pc,
      H.A.Qc,
      H.A.Ed,
      H.A.If,
      H.A.Qf,
      H.A.Od,
      H.A.Ji,
      H.A.Qd,
    ]),
    Dn = Object.freeze([].concat(xa(Cn))),
    En = Object.freeze([H.A.Cb, H.A.nh, H.A.th, H.A.Ki, H.A.kh]),
    Fn = Object.freeze([].concat(xa(En))),
    Gn = {},
    Hn =
      ((Gn[H.A.ja] = "1"),
      (Gn[H.A.wa] = "2"),
      (Gn[H.A.ma] = "3"),
      (Gn[H.A.Wa] = "4"),
      Gn),
    In = {},
    Jn = Object.freeze(
      ((In.search = "s"),
      (In.youtube = "y"),
      (In.playstore = "p"),
      (In.shopping = "h"),
      (In.ads = "a"),
      (In.maps = "m"),
      In)
    );
  function Kn(a) {
    return typeof a !== "object" || a === null ? {} : a;
  }
  function Ln(a) {
    return a === void 0 || a === null
      ? ""
      : typeof a === "object"
      ? a.toString()
      : String(a);
  }
  function Mn(a) {
    if (a !== void 0 && a !== null) return Ln(a);
  }
  var io = function () {
      this.D = x.google_tag_manager = x.google_tag_manager || {};
    },
    jo;
  function ko(a, b) {
    lo();
    var c = jo;
    return (c.D[a] = c.D[a] || b());
  }
  function mo(a) {
    lo();
    return jo.D[a];
  }
  function no(a, b) {
    lo();
    jo.D[a] = b;
  }
  function oo(a) {
    var b = E(5);
    lo();
    var c = jo;
    c.D[b] = c.D[b] || a;
  }
  function po() {
    var a = E(19);
    lo();
    var b = jo;
    return (b.D[a] = b.D[a] || {});
  }
  function qo() {
    var a = E(19);
    lo();
    return jo.D[a];
  }
  function ro() {
    lo();
    var a = jo,
      b = a.D.sequence || 1;
    a.D.sequence = b + 1;
    return b;
  }
  function lo() {
    jo || (jo = new io());
  }
  var so = function () {};
  so.prototype.toString = function () {
    return "undefined";
  };
  var to = new so();
  function Bo(a, b) {
    function c(g) {
      var h = Jj(g),
        k = Dj(h, "protocol"),
        m = Dj(h, "host", !0),
        p = Dj(h, "port"),
        q = Dj(h, "path").toLowerCase().replace(/\/$/, "");
      if (
        k === void 0 ||
        (k === "http" && p === "80") ||
        (k === "https" && p === "443")
      )
        (k = "web"), (p = "default");
      return [k, m, p, q];
    }
    for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
      if (d[f] !== e[f]) return !1;
    return !0;
  }
  function Co(a) {
    return Do(a) ? 1 : 0;
  }
  function Do(a) {
    var b = a.arg0,
      c = a.arg1;
    if (a.any_of && Array.isArray(c)) {
      for (var d = 0; d < c.length; d++) {
        var e = Bb(a, {});
        Bb({ arg1: c[d], any_of: void 0 }, e);
        if (Co(e)) return !0;
      }
      return !1;
    }
    switch (a["function"]) {
      case "_cn":
        return Cg(b, c);
      case "_css":
        return yg(b, c);
      case "_ew":
        return zg(b, c);
      case "_eq":
        return Dg(b, c);
      case "_ge":
        return Eg(b, c);
      case "_gt":
        return Gg(b, c);
      case "_lc":
        return Ag(b, c);
      case "_le":
        return Fg(b, c);
      case "_lt":
        return Hg(b, c);
      case "_re":
        return Bg(
          b,
          c,
          a.ignore_case,
          aj(20, function () {
            return new Map();
          })
        );
      case "_sw":
        return Ig(b, c);
      case "_um":
        return Bo(b, c);
    }
    return !1;
  }
  function Eo(a, b, c, d, e) {
    if (Array.isArray(a)) {
      var f;
      switch (a[0]) {
        case "function_id":
          return a[1];
        case "list":
          f = [];
          for (var g = 1; g < a.length; g++) f.push(Eo(a[g], b, c, d, e));
          return f;
        case "macro":
          var h = d[a[1]];
          return h ? h.evaluate(b, e) : void 0;
        case "map":
          f = {};
          for (var k = 1; k < a.length; k += 2)
            f[Eo(a[k], b, c, d, e)] = Eo(a[k + 1], b, c, d, e);
          return f;
        case "template":
          f = [];
          for (var m = !1, p = 1; p < a.length; p++) {
            var q = Eo(a[p], b, c, d, e);
            f.push(q);
          }
          return f.join("");
        case "escape":
          f = Eo(a[1], b, c, d, e);
          f = String(f);
          for (var y = 2; y < a.length; y++) Tn[a[y]] && (f = Tn[a[y]](f));
          return f;
        case "tag":
          var z = a[1];
          if (!c[z]) throw Error("Unable to resolve tag reference " + z + ".");
          return { Ln: a[2], index: z };
        case "zb":
          var C = {},
            D =
              ((C["function"] = a[1]),
              (C.arg0 = Eo(a[2], b, c, d, e)),
              (C.arg1 = Eo(a[3], b, c, d, e)),
              (C.ignore_case = Eo(a[5], b, c, d, e)),
              C),
            G = Co(D),
            F = !!a[4];
          return F || G !== 2 ? F !== (G === 1) : null;
        default:
          throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
      }
    }
    return a;
  }
  var Go = function (a, b) {
      this.D = !1;
      this.U = [];
      this.eventData = { tags: [] };
      this.aa = !1;
      this.J = this.M = 0;
      Fo(this, a, b);
    },
    Ho = function (a, b, c, d) {
      if (tj.hasOwnProperty(b) || b === "__zone") return -1;
      var e = {};
      Ab(d) && (e = Bb(d, e));
      e.id = c;
      e.status = "timeout";
      return a.eventData.tags.push(e) - 1;
    },
    Io = function (a, b, c, d) {
      var e = a.eventData.tags[b];
      e && ((e.status = c), (e.executionTime = d));
    },
    Jo = function (a) {
      if (!a.D) {
        for (var b = a.U, c = 0; c < b.length; c++) b[c]();
        a.D = !0;
        a.U.length = 0;
      }
    },
    Fo = function (a, b, c) {
      b !== void 0 && a.ug(b);
      c &&
        x.setTimeout(function () {
          Jo(a);
        }, Number(c));
    };
  Go.prototype.ug = function (a) {
    var b = this,
      c = Wb(function () {
        kd(function () {
          a(E(5), b.eventData);
        });
      });
    this.D ? c() : this.U.push(c);
  };
  var Ko = function (a) {
      a.M++;
      return Wb(function () {
        a.J++;
        a.aa && a.J >= a.M && Jo(a);
      });
    },
    Lo = function (a) {
      a.aa = !0;
      a.J >= a.M && Jo(a);
    };
  function Mo(a) {
    return a && a.indexOf("pending:") === 0 ? No(a.substr(8)) : !1;
  }
  function No(a) {
    if (a == null || a.length === 0) return !1;
    var b = Number(a),
      c = Sb();
    return b < c + 3e5 && b > c - 9e5;
  }
  var Oo = !1,
    Po = !1,
    Qo = !1,
    Ro = 0,
    So = !1,
    To = void 0,
    Uo = [];
  function Vo(a) {
    if (Ro === 0) So && Uo && (Uo.length >= 100 && Uo.shift(), Uo.push(a));
    else if (Wo()) {
      var b = E(41),
        c = Vc(b, []);
      c.length >= 50 && c.shift();
      c.push(a);
    }
  }
  function Xo() {
    Po || (Yo(), Zo(Ro));
  }
  function Zo(a) {
    if (!Po || (Ro === 2 && a === 1))
      if (
        ((Po = !0),
        Qo && (jd(A, "TAProdDebugSignal", Xo), (Qo = !1)),
        To !== void 0 && (x.clearTimeout(To), (To = void 0)),
        (Ro = a),
        a === 1)
      ) {
        var b = Uo;
        Uo = void 0;
        b == null ||
          b.forEach(function (c) {
            Vo(c);
          });
      }
  }
  function Yo() {
    var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
    No(a)
      ? (Ro = 1)
      : !Mo(a) || Oo || Qo
      ? (Ro = 2)
      : ((Qo = !0),
        id(A, "TAProdDebugSignal", Xo, !1),
        (To = x.setTimeout(function () {
          Po || (Yo(), Zo(Ro));
          Oo = !0;
        }, 200)));
  }
  function Wo() {
    if (!So) return !1;
    switch (Ro) {
      case 1:
      case 0:
        return !0;
      case 2:
        return !1;
      default:
        return !1;
    }
  }
  var $o = !1;
  function ap(a, b) {
    var c = om(),
      d = lm();
    E(26);
    var e = Hf(47) ? 0 : Hf(50) ? 1 : 3,
      f = Pj();
    if (Wo()) {
      var g = bp("INIT");
      g.containerLoadSource = a != null ? a : 0;
      b && (g.parentTargetReference = b);
      g.aliases = c;
      g.destinations = d;
      e !== void 0 && (g.gtg = { source: e, mPath: f != null ? f : "" });
      Vo(g);
    }
  }
  function cp(a) {
    var b, c, d, e;
    b = a.targetId;
    c = a.request;
    d = a.zb;
    e = a.isBatched;
    var f;
    if ((f = Wo())) {
      var g;
      a: switch (c.endpoint) {
        case 68:
        case 69:
        case 19:
        case 62:
        case 47:
          g = !0;
          break a;
        default:
          g = !1;
      }
      f = !g;
    }
    if (f) {
      var h = bp("GTAG_HIT", { eventId: d.eventId, priorityId: d.priorityId });
      h.target = b;
      h.url = c.url;
      c.postBody && (h.postBody = c.postBody);
      h.parameterEncoding = c.parameterEncoding;
      h.endpoint = c.endpoint;
      e !== void 0 && (h.isBatched = e);
      Vo(h);
    }
  }
  function dp(a) {
    Wo() && cp(a());
  }
  function bp(a, b) {
    b = b === void 0 ? {} : b;
    b.groupId = ep;
    var c,
      d = b,
      e = fp,
      f = { publicId: gp };
    d.eventId != null && (f.eventId = d.eventId);
    d.priorityId != null && (f.priorityId = d.priorityId);
    d.eventName && (f.eventName = d.eventName);
    d.groupId && (f.groupId = d.groupId);
    d.tagName && (f.tagName = d.tagName);
    c = { containerProduct: "GTM", key: f, version: e, messageType: a };
    c.containerProduct = $o ? "OGT" : "GTM";
    c.key.targetRef = hp;
    return c;
  }
  var gp = "",
    fp = "",
    hp = { ctid: "", isDestination: !1 },
    ep;
  function ip(a) {
    var b = E(5),
      c = Hf(45),
      d = km(),
      e = E(6),
      f = E(1);
    E(23);
    Po || So ? (So = !0) : ((Ro = 0), (So = !0), Yo());
    ep = a;
    gp = b;
    fp = f;
    $o = c;
    hp = { ctid: b, isDestination: d, canonicalId: e };
  }
  var jp = [H.A.ja, H.A.wa, H.A.ma, H.A.Wa];
  function kp(a) {
    var b = n(a[H.A.nc] || [""]),
      c = b.next(),
      d;
    try {
      for (var e = {}; !c.done; e = { qo: void 0 }, c = b.next())
        (e.qo = c.value),
          Lb(
            a,
            (function (f) {
              return function (g, h) {
                if (g !== H.A.nc) {
                  var k = Ln(h),
                    m = f.qo,
                    p = Fk(),
                    q = Gk();
                  Qm = !0;
                  Pm && sb("TAGGING", 20);
                  Lm().declare(g, k, m, p, q);
                }
              };
            })(e)
          );
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
  }
  function lp(a) {
    un();
    var b = aj(32, function () {
        return !1;
      }),
      c = aj(33, function () {
        return !1;
      });
    !b && c && tn("crc");
    Zi(32, !0);
    var d = a[H.A.Vg];
    d && S(41);
    var e = a[H.A.nc];
    e ? S(40) : (e = [""]);
    var f = n(e),
      g = f.next(),
      h;
    try {
      for (var k = {}; !g.done; k = { ro: void 0 }, g = f.next())
        (k.ro = g.value),
          Lb(
            a,
            (function (m) {
              return function (p, q) {
                if (p !== H.A.nc && p !== H.A.Vg) {
                  var r = Mn(q),
                    t = m.ro,
                    u = Number(d),
                    v = Fk(),
                    w = Gk();
                  u = u === void 0 ? 0 : u;
                  Pm = !0;
                  Qm && sb("TAGGING", 20);
                  Lm().default(p, r, t, v, w, u, Sm);
                }
              };
            })(k)
          );
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
  }
  function mp(a) {
    Sm.usedContainerScopedDefaults = !0;
    var b = a[H.A.nc];
    if (b) {
      var c = Array.isArray(b) ? b : [b];
      if (!c.includes(Gk()) && !c.includes(Fk())) return;
    }
    Lb(a, function (d, e) {
      switch (d) {
        case "ad_storage":
        case "analytics_storage":
        case "ad_user_data":
        case "ad_personalization":
          break;
        default:
          return;
      }
      Sm.usedContainerScopedDefaults = !0;
      Sm.containerScopedDefaults[d] = e === "granted" ? 3 : 2;
    });
  }
  function np(a, b) {
    un();
    Zi(33, !0);
    Lb(a, function (c, d) {
      var e = Ln(d);
      Pm = !0;
      Qm && sb("TAGGING", 20);
      Lm().update(c, e, Sm);
    });
    Ym(b.eventId, b.priorityId);
  }
  function op(a) {
    a.hasOwnProperty("all") &&
      ((Sm.selectedAllCorePlatformServices = !0),
      Lb(Jn, function (b) {
        Sm.corePlatformServices[b] = a.all === "granted";
        Sm.usedCorePlatformServices = !0;
      }));
    Lb(a, function (b, c) {
      b !== "all" &&
        ((Sm.corePlatformServices[b] = c === "granted"),
        (Sm.usedCorePlatformServices = !0));
    });
  }
  function pp(a) {
    Array.isArray(a) || (a = [a]);
    return a.every(function (b) {
      return Tm(b);
    });
  }
  function qp() {
    var a = rp;
    Array.isArray(a) || (a = [a]);
    return a.some(function (b) {
      return Tm(b);
    });
  }
  function sp(a, b) {
    Xm(a, b);
  }
  function tp(a, b) {
    $m(a, b);
  }
  function up(a, b) {
    Zm(a, b);
  }
  function vp() {
    var a = [H.A.ja, H.A.Wa, H.A.ma];
    Lm().waitForUpdate(a, 500, Sm);
  }
  function wp(a) {
    var b = n(a),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next()) {
        var e = c.value;
        Lm().clearTimeout(e, void 0, Sm);
      }
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
    Ym();
  }
  function xp(a) {
    var b = {},
      c = n(a.split("|")),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) b[d.value] = !0;
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    return b;
  }
  var yp = function (a, b, c, d, e) {
    this.endpoint = a;
    this.fa = c;
    this.Da = d;
    this.parameterEncoding = e;
    this.aa = b.slice();
  };
  yp.prototype.J = function () {
    return !this.aa.length || pp(this.aa);
  };
  yp.prototype.isSupported = function () {
    return !0;
  };
  yp.prototype.U = function () {
    var a = Vk[this.endpoint](void 0);
    return Zb(a, "https://")
      ? a.substring(8)
      : Zb(a, "http://")
      ? a.substring(7)
      : a;
  };
  var zp = function (a, b) {
    this.methodName = a;
    this.U = b;
  };
  zp.prototype.sendRequest = function (a, b, c) {
    if (this.isSupported())
      if ((c == null ? void 0 : c.body) === void 0 || this.D())
        try {
          this.J(a, b, c);
        } catch (d) {
          a.pd(d);
        }
      else
        a.pd(
          "Request method " +
            this.methodName +
            " does not support a request body."
        );
    else a.pd("Request method " + this.methodName + " is not supported.");
  };
  var Ap = function () {
    zp.call(this, "ImagePixel", 3);
  };
  ta(Ap, zp);
  Ap.prototype.isSupported = function () {
    return !0;
  };
  Ap.prototype.D = function () {
    return !1;
  };
  Ap.prototype.J = function (a, b, c) {
    hd(
      b,
      function () {
        a.bf();
      },
      function () {
        a.onFailure(void 0);
      },
      c == null ? void 0 : c.Te
    );
  };
  var Bp = function () {
    zp.call(this, "SendBeacon", 1);
  };
  ta(Bp, zp);
  Bp.prototype.isSupported = function () {
    return td();
  };
  Bp.prototype.D = function () {
    return !0;
  };
  Bp.prototype.J = function (a, b, c) {
    sd(b, c == null ? void 0 : c.body) ? a.bf() : a.pd(void 0);
  };
  var Cp = function () {
    zp.call(this, "Fetch", 1);
  };
  ta(Cp, zp);
  Cp.prototype.isSupported = function () {
    return Db(x.fetch);
  };
  Cp.prototype.D = function () {
    return !0;
  };
  Cp.prototype.J = function (a, b, c) {
    x.fetch(b, c == null ? void 0 : c.Ib)
      .then(function (d) {
        if (d.ok) a.be(d);
        else if (d.status === 0) a.bf();
        else a.onFailure("Fetch failed with status code " + d.status + ".");
      })
      .catch(function (d) {
        a.pd(d);
      });
  };
  var Dp = new Ap(),
    Ep = new Bp(),
    Fp = new Cp();
  var Gp = function () {};
  Gp.prototype.J = function () {
    return [];
  };
  function Up(a, b) {
    if (b != null && b !== "") {
      var c = b === !0 ? "1" : b === !1 ? "0" : encodeURIComponent(String(b));
      if (Zb(a, "_&")) return { key: a.substring(2), value: c };
      var d = Tp[a];
      if (d !== null)
        return d
          ? { key: d, value: c }
          : { key: Fb(b) ? "epn." + a : "ep." + a, value: c };
    }
  }
  function Vp(a) {
    a = a === void 0 ? [] : a;
    return mj(a).join("~");
  }
  var Wp = function () {
      this.J = {};
      this.D = {};
      this.M = {};
      this.U = new Set();
    },
    Xp = function (a, b, c, d) {
      var e = Gi;
      if (e.studies[c]) {
        var f = e.studies[c],
          g = f.experimentId,
          h = f.probability;
        if (!(b.studies || {})[c]) {
          var k = b.studies || {};
          k[c] = !0;
          b.studies = k;
          if (!e.studies[c].active)
            if (e.studies[c].probability > 0.5) Ji(b, g, c);
            else if (!(h <= 0 || h > 1)) {
              var m = void 0;
              if (d) {
                var p = Di(d + "~" + c);
                if (p === "e2") m = -1;
                else {
                  var q = new Uint8Array(p),
                    r = BigInt(0),
                    t = n(q),
                    u = t.next(),
                    v;
                  try {
                    for (; !u.done; u = t.next())
                      r = (r << BigInt(8)) | BigInt(u.value);
                  } finally {
                    u && !u.done && (v = t.return) && v.call(t);
                  }
                  m = Number(r % BigInt(Number.MAX_SAFE_INTEGER));
                }
              }
              Hi.gk(b, c, m);
            }
        }
      }
      if (!a.J[c]) {
        var w = Oi(b, c);
        w && lj.D.J.add(w);
      }
    },
    Yp = function () {
      return vk(qk.da.Kq, {});
    },
    cq = function (a, b) {
      var c = Zp;
      Xp(c, Yp(), a, b);
      $p(c, a) ? Qi(Ri, a) : aq(c, a) ? Ri.J.add(a) : bq(c, a) && Ri.D.add(a);
    },
    $p = function (a, b) {
      var c;
      if (!(c = !!a.M[b])) {
        var d = Yp();
        c = Li(d, b);
      }
      return c || Li(a.D, b);
    },
    aq = function (a, b) {
      var c = Yp();
      return Mi(c, b) || Mi(a.D, b);
    },
    bq = function (a, b) {
      var c = Yp();
      return Ni(c, b) || Ni(a.D, b);
    },
    dq = function (a, b) {
      var c = Yp();
      return Oi(c, b) || Oi(a.D, b);
    },
    eq = function (a, b, c) {
      if (a.J[b]) {
        var d = dq(a, b);
        if (d)
          if (c) {
            var e = T(c, J.H.Ie) || [];
            e.includes(d) || e.push(d);
            V(c, J.H.Ie, e);
          } else a.U.add(d);
      }
    },
    Zp;
  function fq() {
    if (!Zp) {
      var a = (Zp = new Wp()),
        b,
        c,
        d =
          ((b = x) == null
            ? void 0
            : (c = b.location) == null
            ? void 0
            : c.hash) || "";
      if (
        d[0] === "#" &&
        d[1] === "_" &&
        d[2] === "t" &&
        d[3] === "e" &&
        d[4] === "="
      ) {
        var e = d.substring(5);
        if (e) {
          var f = n(e.split("~")),
            g = f.next(),
            h;
          try {
            for (; !g.done; g = f.next()) {
              var k = g.value.split(":"),
                m = Number(k[0]);
              if (m)
                if (k.length > 1) {
                  var p = Number(k[1]);
                  if (p) {
                    var q = Yp();
                    Ji(q, p, m);
                    q.studies = q.studies || {};
                    q.studies[m] = !0;
                    Ji(a.D, p, m);
                    a.D.studies = a.D.studies || {};
                    a.D.studies[m] = !0;
                  }
                } else (a.M[m] = !0), Qi(Ri, m);
            }
          } finally {
            g && !g.done && (h = f.return) && h.call(f);
          }
        }
      }
      var r = [],
        t = n(Lf(56) || []),
        u = t.next(),
        v;
      try {
        for (; !u.done; u = t.next()) {
          var w = u.value,
            y = {
              studyId: w[1],
              active: !!w[2],
              probability: w[3] || 0,
              experimentId: w[4] || 0,
              controlId: w[5] || 0,
              controlId2: w[6] || 0,
            },
            z = 0;
          switch (w[7]) {
            case 2:
              z = 1;
              break;
            case 3:
              z = 2;
              break;
            case 1:
            case 4:
            case 5:
            case 0:
              z = 0;
          }
          var C;
          a: switch (y.studyId) {
            case 613:
            case 567:
            case 612:
              C = !0;
              break a;
            default:
              C = !1;
          }
          var D = ma(Object, "assign").call(Object, {}, y, {
            En: z,
            focused: C,
          });
          (D.active ||
            (D.probability > 0.5 && D.experimentId) ||
            (D.experimentId && D.controlId)) &&
            r.push(D);
        }
      } finally {
        u && !u.done && (v = t.return) && v.call(t);
      }
      var G = n(r),
        F = G.next(),
        I;
      try {
        for (; !F.done; F = G.next()) {
          var L = a,
            P = F.value,
            R = P,
            U = (P = L.M[R.studyId]
              ? ma(Object, "assign").call(Object, {}, R, { active: !0 })
              : R),
            X = Gi;
          (U.controlId2 && U.probability <= 0.25) ||
            (U = ma(Object, "assign").call(Object, {}, U, { controlId2: 0 }));
          X.studies[U.studyId] = U;
          P.focused && (L.J[P.studyId] = !0);
          if (P.En === 1) {
            var ea = L,
              ja = P.studyId;
            Xp(ea, Yp(), ja);
            $p(ea, ja)
              ? Qi(Ri, ja)
              : aq(ea, ja)
              ? Ri.J.add(ja)
              : bq(ea, ja) && Ri.D.add(ja);
          } else if (P.En === 0) {
            var va = L,
              Ga = P.studyId;
            Xp(va, va.D, Ga);
            $p(va, Ga)
              ? Qi(Ri, Ga)
              : aq(va, Ga)
              ? Ri.J.add(Ga)
              : bq(va, Ga) && Ri.D.add(Ga);
          }
        }
      } finally {
        F && !F.done && (I = G.return) && I.call(G);
      }
    }
  }
  function gq(a) {
    fq();
    var b = Zp,
      c = $p(b, 567);
    eq(b, 567, a);
    return c;
  }
  function hq(a) {
    fq();
    var b = Zp,
      c = $p(b, a);
    eq(b, a);
    return c;
  }
  function iq(a) {
    fq();
    var b = new Set(Zp.U);
    if (a) {
      var c = T(a, J.H.Ie) || [],
        d = n(c),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) b.add(e.value);
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      var g = T(a, J.H.lj) || [],
        h = n(g),
        k = h.next(),
        m;
      try {
        for (; !k.done; k = h.next()) b.delete(k.value);
      } finally {
        k && !k.done && (m = h.return) && m.call(h);
      }
    }
    return Vp([].concat(xa(b)));
  }
  function jq() {
    fq();
    var a;
    var b = Zp;
    try {
      a = !!dq(b, 567);
    } catch (c) {
      a = !1;
    }
    return a;
  }
  var kq = Object.freeze([H.A.ja, H.A.ma]);
  function lq(a) {
    var b = a.location.href;
    if (a === a.top) return { url: b, jt: !0 };
    var c = !1,
      d = a.document;
    d && d.referrer && ((b = d.referrer), a.parent === a.top && (c = !0));
    var e = a.location.ancestorOrigins;
    if (e) {
      var f = e[e.length - 1],
        g;
      f &&
        ((g = b) == null ? void 0 : g.indexOf(f)) === -1 &&
        ((c = !1), (b = f));
    }
    return { url: b, jt: c };
  }
  function mq(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Gl(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function nq() {
    for (var a = x, b = a; a && a !== a.parent; )
      (a = a.parent), mq(a) && (b = a);
    return b;
  }
  var oq = function (a, b) {
      var c = function () {};
      c.prototype = a.prototype;
      var d = new c();
      a.apply(d, Array.prototype.slice.call(arguments, 1));
      return d;
    },
    pq = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    };
  function qq(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function rq(a) {
    var b = a.split(/[?#]/),
      c = /[?]/.test(a) ? "?" + b[1] : "";
    return {
      lk: b[0],
      params: c,
      fragment: /[#]/.test(a) ? "#" + (c ? b[2] : b[1]) : "",
    };
  }
  function sq(a) {
    var b = Oa.apply(1, arguments);
    if (b.length === 0) return sc(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return sc(c);
  }
  function tq(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (k) {
              return e(k, h);
            })
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return sc(a + b + c);
  }
  function uq(a, b) {
    var c = rq(tc(a).toString()),
      d = c.lk.slice(-1) === "/" ? "" : "/",
      e = c.lk + d + encodeURIComponent(b);
    return sc(e + c.params + c.fragment);
  }
  var vq = function (a, b) {
      for (var c = a, d = 0; d < 50; ++d) {
        var e;
        try {
          e = !(!c.frames || !c.frames[b]);
        } catch (h) {
          e = !1;
        }
        if (e) return c;
        var f;
        a: {
          try {
            var g = c.parent;
            if (g && g !== c) {
              f = g;
              break a;
            }
          } catch (h) {}
          f = null;
        }
        if (!(c = f)) break;
      }
      return null;
    },
    wq = function (a) {
      var b = x;
      if (b.top == b) return 0;
      if (a === void 0 ? 0 : a) {
        var c = b.location.ancestorOrigins;
        if (c) return c[c.length - 1] == b.location.origin ? 1 : 2;
      }
      return mq(b.top) ? 1 : 2;
    },
    xq = function (a) {
      a = a === void 0 ? document : a;
      return a.createElement("img");
    };
  function yq(a) {
    for (
      var b = [],
        c = A.cookie.split(";"),
        d = new RegExp(
          "^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"
        ),
        e = 0;
      e < c.length;
      e++
    ) {
      var f = c[e].match(d);
      f &&
        b.push({
          kf: f[1],
          value: f[2],
          timestamp: Number(f[2].split(".")[1]) || 0,
        });
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return b;
  }
  function zq(a, b) {
    var c = yq(a),
      d = {};
    if (!c || !c.length) return d;
    for (var e = 0; e < c.length; e++) {
      var f = c[e].value.split(".");
      if (
        !(f[0] !== "1" || (b && f.length < 3) || (!b && f.length !== 3)) &&
        Number(f[1])
      ) {
        d[c[e].kf] || (d[c[e].kf] = []);
        var g = { version: f[0], timestamp: Number(f[1]) * 1e3, gclid: f[2] };
        b && f.length > 3 && (g.labels = f.slice(3));
        d[c[e].kf].push(g);
      }
    }
    return d;
  }
  function Aq(a) {
    return a.origin !== "null";
  }
  var Bq = {},
    Cq =
      ((Bq.k = { oa: /^[\w-]+$/ }),
      (Bq.b = { oa: /^[\w-]+$/, ek: !0 }),
      (Bq.i = { oa: /^[1-9]\d*$/ }),
      (Bq.h = { oa: /^\d+$/ }),
      (Bq.t = { oa: /^[1-9]\d*$/ }),
      (Bq.d = { oa: /^[A-Za-z0-9_-]+$/ }),
      (Bq.j = { oa: /^\d+$/ }),
      (Bq.u = { oa: /^[1-9]\d*$/ }),
      (Bq.l = { oa: /^[01]$/ }),
      (Bq.o = { oa: /^[1-9]\d*$/ }),
      (Bq.g = { oa: /^[01]$/ }),
      (Bq.s = { oa: /^.+$/ }),
      (Bq.m = { oa: /^[01]$/ }),
      Bq);
  var Dq = {},
    Hq =
      ((Dq[5] = { versions: { 2: Eq }, Oj: "2", Lh: ["k", "i", "b", "u"] }),
      (Dq[4] = {
        versions: { 2: Eq, GCL: Fq },
        Oj: "2",
        Lh: ["k", "i", "b", "m"],
      }),
      (Dq[2] = {
        versions: { GS2: Eq, GS1: Gq },
        Oj: "GS2",
        Lh: "sogtjlhd".split(""),
      }),
      Dq);
  function Iq(a, b, c) {
    var d = Hq[b];
    if (d) {
      var e = a.split(".")[0];
      c == null || c(e);
      if (e) {
        var f = d.versions[e];
        if (f) return f(a, b);
      }
    }
  }
  function Eq(a, b) {
    var c = a.split(".");
    if (c.length === 3) {
      var d = c[2];
      if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1)
        try {
          d = decodeURIComponent(d);
        } catch (u) {}
      var e = {},
        f = Hq[b];
      if (f) {
        var g = f.Lh,
          h = n(d.split("$")),
          k = h.next(),
          m;
        try {
          for (; !k.done; k = h.next()) {
            var p = k.value,
              q = p[0];
            if (g.indexOf(q) !== -1)
              try {
                var r = decodeURIComponent(p.substring(1)),
                  t = Cq[q];
                t && (t.ek ? ((e[q] = e[q] || []), e[q].push(r)) : (e[q] = r));
              } catch (u) {}
          }
        } finally {
          k && !k.done && (m = h.return) && m.call(h);
        }
        return e;
      }
    }
  }
  function Jq(a, b, c) {
    var d = Hq[b];
    if (d) return [d.Oj, c || "1", Kq(a, b)].join(".");
  }
  function Kq(a, b) {
    var c = Hq[b];
    if (c) {
      var d = [],
        e = n(c.Lh),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value,
            k = Cq[h];
          if (k) {
            var m = a[h];
            if (m !== void 0)
              if (k.ek && Array.isArray(m)) {
                var p = n(m),
                  q = p.next(),
                  r;
                try {
                  for (; !q.done; q = p.next())
                    d.push(encodeURIComponent("" + h + q.value));
                } finally {
                  q && !q.done && (r = p.return) && r.call(p);
                }
              } else d.push(encodeURIComponent("" + h + m));
          }
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
      return d.join("$");
    }
  }
  function Fq(a) {
    var b = a.split(".");
    b.shift();
    var c = b.shift(),
      d = b.shift(),
      e = {};
    return (e.k = d), (e.i = c), (e.b = b), e;
  }
  function Gq(a) {
    var b = a.split(".").slice(2);
    if (!(b.length < 5 || b.length > 7)) {
      var c = {};
      return (
        (c.s = b[0]),
        (c.o = b[1]),
        (c.g = b[2]),
        (c.t = b[3]),
        (c.j = b[4]),
        (c.l = b[5]),
        (c.h = b[6]),
        c
      );
    }
  }
  function Lq(a, b, c, d) {
    var e;
    return (e = Mq(
      function (f) {
        return f === a;
      },
      b,
      c,
      d
    )[a]) != null
      ? e
      : [];
  }
  function Mq(a, b, c, d) {
    var e;
    if (Nq(d)) {
      for (
        var f = {}, g = String(b || Oq()).split(";"), h = 0;
        h < g.length;
        h++
      ) {
        var k = g[h].split("="),
          m = k[0].trim();
        if (m && a(m)) {
          var p = k.slice(1).join("=").trim();
          p && c && (p = decodeURIComponent(p));
          var q = void 0,
            r = void 0;
          ((q = f)[(r = m)] || (q[r] = [])).push(p);
        }
      }
      e = f;
    } else e = {};
    return e;
  }
  function Pq(a, b, c, d, e) {
    if (Nq(e)) {
      var f = Qq(a, d, e);
      if (f.length === 1) return f[0];
      if (f.length !== 0) {
        f = Rq(
          f,
          function (g) {
            return g.ls;
          },
          b
        );
        if (f.length === 1) return f[0];
        f = Rq(
          f,
          function (g) {
            return g.Ft;
          },
          c
        );
        return f[0];
      }
    }
  }
  function Sq(a, b, c, d) {
    var e = Oq(),
      f = x;
    Aq(f) && (f.document.cookie = a);
    var g = Oq();
    return e !== g || (c !== void 0 && Lq(b, g, !1, d).indexOf(c) >= 0);
  }
  function Tq(a, b, c, d) {
    function e(w, y, z) {
      if (z == null) return delete h[y], w;
      h[y] = z;
      return w + "; " + y + "=" + z;
    }
    function f(w, y) {
      if (y == null) return w;
      h[y] = !0;
      return w + "; " + y;
    }
    if (!Nq(c.Ic)) return 2;
    var g;
    b == null
      ? (g = a + "=deleted; expires=" + new Date(0).toUTCString())
      : (c.encode && (b = encodeURIComponent(b)),
        (b = Uq(b)),
        (g = a + "=" + b));
    var h = {};
    g = e(g, "path", c.path);
    var k;
    c.expires instanceof Date
      ? (k = c.expires.toUTCString())
      : c.expires != null && (k = "" + c.expires);
    g = e(g, "expires", k);
    g = e(g, "max-age", c.vt);
    g = e(g, "samesite", c.Tt);
    c.secure && (g = f(g, "secure"));
    var m = c.domain;
    if (m && m.toLowerCase() === "auto") {
      for (var p = Vq(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
        var u = p[t] !== "none" ? p[t] : void 0,
          v = e(g, "domain", u);
        v = f(v, c.flags);
        try {
          d && d(a, h);
        } catch (w) {
          q = w;
          continue;
        }
        r = !0;
        if (!Wq(u, c.path) && Sq(v, a, b, c.Ic)) return 0;
      }
      if (q && !r) throw q;
      return 1;
    }
    m && m.toLowerCase() !== "none" && (g = e(g, "domain", m));
    g = f(g, c.flags);
    d && d(a, h);
    return Wq(m, c.path) ? 1 : Sq(g, a, b, c.Ic) ? 0 : 1;
  }
  function Xq(a, b, c) {
    c.path == null && (c.path = "/");
    c.domain || (c.domain = "auto");
    return Tq(a, b, c);
  }
  function Rq(a, b, c) {
    for (var d = [], e = [], f, g = 0; g < a.length; g++) {
      var h = a[g],
        k = b(h);
      k === c
        ? d.push(h)
        : f === void 0 || k < f
        ? ((e = [h]), (f = k))
        : k === f && e.push(h);
    }
    return d.length > 0 ? d : e;
  }
  function Qq(a, b, c) {
    for (var d = [], e = Lq(a, void 0, void 0, c), f = 0; f < e.length; f++) {
      var g = e[f].split("."),
        h = g.shift();
      if (!b || !h || b.indexOf(h) !== -1) {
        var k = g.shift();
        if (k) {
          var m = k.split("-");
          d.push({
            Xr: e[f],
            Yr: g.join("."),
            ls: Number(m[0]) || 1,
            Ft: Number(m[1]) || 1,
          });
        }
      }
    }
    return d;
  }
  function Uq(a) {
    a && a.length > 1200 && (a = a.substring(0, 1200));
    return a;
  }
  var Yq = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    Zq = /(^|\.)doubleclick\.net$/i;
  function Wq(a, b) {
    return (
      a !== void 0 &&
      (Zq.test(x.document.location.hostname) || (b === "/" && Yq.test(a)))
    );
  }
  function $q(a) {
    if (!a) return 1;
    var b = a;
    Oh(4) && a === "none" && (b = x.document.location.hostname);
    b = b.indexOf(".") === 0 ? b.substring(1) : b;
    return b.split(".").length;
  }
  function ar(a) {
    if (!a || a === "/") return 1;
    a[0] !== "/" && (a = "/" + a);
    a[a.length - 1] !== "/" && (a += "/");
    return a.split("/").length - 1;
  }
  function br(a, b) {
    var c = "" + $q(a),
      d = ar(b);
    d > 1 && (c += "-" + d);
    return c;
  }
  var Oq = function () {
      var a = x;
      return Aq(a) ? a.document.cookie : "";
    },
    Nq = function (a) {
      return a && Oh(5)
        ? (Array.isArray(a) ? a : [a]).every(function (b) {
            return Vm(b) && Tm(b);
          })
        : !0;
    },
    Vq = function () {
      var a = [],
        b = x.document.location.hostname.split(".");
      if (b.length === 4) {
        var c = b[b.length - 1];
        if (Number(c).toString() === c) return ["none"];
      }
      for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
      var e = x.document.location.hostname;
      Zq.test(e) || Yq.test(e) || a.push("none");
      return a;
    };
  function cr(a, b, c, d) {
    var e,
      f = Number(a.od != null ? a.od : void 0);
    f !== 0 && (e = new Date((b || Sb()) + 1e3 * (f || 7776e3)));
    return {
      path: a.path,
      domain: a.domain,
      flags: a.flags,
      encode: !!c,
      expires: e,
      Ic: d,
    };
  }
  var dr = new Map([
    [5, "ad_storage"],
    [4, ["ad_storage", "ad_user_data"]],
    [2, "analytics_storage"],
  ]);
  function er(a, b, c) {
    if (Hq[b]) {
      var d = [],
        e = Lq(a, void 0, void 0, dr.get(b)),
        f = n(e),
        g = f.next(),
        h;
      try {
        for (; !g.done; g = f.next()) {
          var k = Iq(g.value, b, c);
          k && d.push(fr(k));
        }
      } finally {
        g && !g.done && (h = f.return) && h.call(f);
      }
      return d;
    }
  }
  function gr(a) {
    var b = hr;
    if (Hq[2]) {
      var c = {},
        d = Mq(a, void 0, void 0, dr.get(2)),
        e = Object.keys(d).sort(),
        f = n(e),
        g = f.next(),
        h;
      try {
        for (; !g.done; g = f.next()) {
          var k = g.value,
            m = n(d[k]),
            p = m.next(),
            q;
          try {
            for (; !p.done; p = m.next()) {
              var r = Iq(p.value, 2, b);
              r && (c[k] || (c[k] = []), c[k].push(fr(r)));
            }
          } finally {
            p && !p.done && (q = m.return) && q.call(m);
          }
        }
      } finally {
        g && !g.done && (h = f.return) && h.call(f);
      }
      return c;
    }
  }
  function ir(a, b, c, d, e) {
    d = d || {};
    var f = br(d.domain, d.path),
      g = Jq(b, c, f);
    if (!g) return 1;
    var h = cr(d, e, void 0, dr.get(c));
    return Xq(a, g, h);
  }
  function jr(a, b) {
    var c = b.oa;
    return typeof c === "function" ? c(a) : c.test(a);
  }
  function fr(a) {
    var b = n(Object.keys(a)),
      c = b.next(),
      d;
    try {
      for (var e = {}; !c.done; e = { yg: void 0 }, c = b.next()) {
        var f = c.value,
          g = a[f];
        e.yg = Cq[f];
        e.yg
          ? e.yg.ek
            ? Array.isArray(g)
              ? (a[f] = g.filter(
                  (function (h) {
                    return function (k) {
                      return jr(k, h.yg);
                    };
                  })(e)
                ))
              : (a[f] = void 0)
            : (typeof g === "string" && jr(g, e.yg)) || (a[f] = void 0)
          : (a[f] = void 0);
      }
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
    return a;
  }
  var kr;
  function lr() {
    function a(g) {
      c(g.target || g.srcElement || {});
    }
    function b(g) {
      d(g.target || g.srcElement || {});
    }
    var c = mr,
      d = nr,
      e = or();
    if (!e.init) {
      id(A, "mousedown", a);
      id(A, "keyup", a);
      id(A, "submit", b);
      var f = HTMLFormElement.prototype.submit;
      HTMLFormElement.prototype.submit = function () {
        d(this);
        f.call(this);
      };
      e.init = !0;
    }
  }
  function pr(a, b, c, d, e) {
    var f = {
      callback: a,
      domains: b,
      fragment: c === 2,
      placement: c,
      forms: d,
      sameHost: e,
    };
    or().decorators.push(f);
  }
  function qr(a, b, c) {
    for (var d = or().decorators, e = {}, f = 0; f < d.length; ++f) {
      var g = d[f],
        h;
      if ((h = !c || g.forms))
        a: {
          var k = g.domains,
            m = a,
            p = !!g.sameHost;
          if (k && (p || m !== A.location.hostname))
            for (var q = 0; q < k.length; q++)
              if (k[q] instanceof RegExp) {
                if (k[q].test(m)) {
                  h = !0;
                  break a;
                }
              } else if (m.indexOf(k[q]) >= 0 || (p && k[q].indexOf(m) >= 0)) {
                h = !0;
                break a;
              }
          h = !1;
        }
      if (h) {
        var r = g.placement;
        r === void 0 && (r = g.fragment ? 2 : 1);
        r === b && Xb(e, g.callback());
      }
    }
    return e;
  }
  function or() {
    var a = Vc("google_tag_data", {}),
      b = a.gl;
    (b && b.decorators) || ((b = { decorators: [] }), (a.gl = b));
    return b;
  }
  var rr = /(.*?)\*(.*?)\*(.*)/,
    sr = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
    tr = /^(?:www\.|m\.|amp\.)+/,
    ur = /([^?#]+)(\?[^#]*)?(#.*)?/;
  function vr(a) {
    var b = ur.exec(a);
    if (b) return { Vj: b[1], query: b[2], fragment: b[3] };
  }
  function wr(a) {
    return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)");
  }
  function xr(a, b) {
    b = b === void 0 ? 0 : b;
    var c = Sb(),
      d = [
        Qc.userAgent,
        new Date().getTimezoneOffset(),
        Qc.userLanguage || Qc.language,
        Math.floor(c / 60 / 1e3) - b,
        a,
      ].join("*"),
      e;
    if (!(e = kr)) {
      for (var f = Array(256), g = 0; g < 256; g++) {
        for (var h = g, k = 0; k < 8; k++)
          h = h & 1 ? (h >>> 1) ^ 3988292384 : h >>> 1;
        f[g] = h;
      }
      e = f;
    }
    kr = e;
    for (var m = 4294967295, p = 0; p < d.length; p++)
      m = (m >>> 8) ^ kr[(m ^ d.charCodeAt(p)) & 255];
    return ((m ^ -1) >>> 0).toString(36);
  }
  function yr(a) {
    return function (b) {
      var c = Jj(x.location.href),
        d = c.search.replace("?", ""),
        e = Aj(d, "_gl", !1, !0) || "";
      b.query = zr(e) || {};
      var f = Dj(c, "fragment"),
        g;
      var h = -1;
      if (Zb(f, "_gl=")) h = 4;
      else {
        var k = f.indexOf("&_gl=");
        k > 0 && (h = k + 3 + 2);
      }
      if (h < 0) g = void 0;
      else {
        var m = f.indexOf("&", h);
        g = m < 0 ? f.substring(h) : f.substring(h, m);
      }
      b.fragment = zr(g || "") || {};
      a && Ar(c, d, f);
    };
  }
  function Br(a, b) {
    var c = wr(a).exec(b),
      d = b;
    if (c) {
      var e = c[2],
        f = c[4];
      d = c[1];
      f && (d = d + e + f);
    }
    return d;
  }
  function Ar(a, b, c) {
    function d(g, h) {
      var k = Br("_gl", g);
      k.length && (k = h + k);
      return k;
    }
    if (Pc && Pc.replaceState) {
      var e = wr("_gl");
      if (e.test(b) || e.test(c)) {
        var f = Dj(a, "path");
        b = d(b, "?");
        c = d(c, "#");
        Pc.replaceState({}, "", "" + f + b + c);
      }
    }
  }
  function Cr(a, b) {
    var c = yr(!!b),
      d = or();
    d.data || ((d.data = { query: {}, fragment: {} }), c(d.data));
    var e = {},
      f = d.data;
    f && (Xb(e, f.query), a && Xb(e, f.fragment));
    return e;
  }
  var zr = function (a) {
    try {
      var b = Dr(a, 3);
      if (b !== void 0) {
        for (
          var c = {}, d = b ? b.split("*") : [], e = 0;
          e + 1 < d.length;
          e += 2
        ) {
          var f = d[e],
            g = qb(d[e + 1]);
          c[f] = g;
        }
        sb("TAGGING", 6);
        return c;
      }
    } catch (h) {
      sb("TAGGING", 8);
    }
  };
  function Dr(a, b) {
    if (a) {
      var c;
      a: {
        for (var d = a, e = 0; e < 3; ++e) {
          var f = rr.exec(d);
          if (f) {
            c = f;
            break a;
          }
          d = Cj(d) || "";
        }
        c = void 0;
      }
      var g = c;
      if (g && g[1] === "1") {
        var h = g[3],
          k;
        a: {
          for (var m = g[2], p = 0; p < b; ++p)
            if (m === xr(h, p)) {
              k = !0;
              break a;
            }
          k = !1;
        }
        if (k) return h;
        sb("TAGGING", 7);
      }
    }
  }
  function Er(a, b, c, d, e) {
    function f(p) {
      p = Br(a, p);
      var q = p.charAt(p.length - 1);
      p && q !== "&" && (p += "&");
      return p + m;
    }
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var g = vr(c);
    if (!g) return "";
    var h = g.query || "",
      k = g.fragment || "",
      m = a + "=" + b;
    d
      ? (k.substring(1).length !== 0 && e) || (k = "#" + f(k.substring(1)))
      : (h = "?" + f(h.substring(1)));
    return "" + g.Vj + h + k;
  }
  function Fr(a, b) {
    function c(m, p, q) {
      var r;
      a: {
        for (var t in m)
          if (m.hasOwnProperty(t)) {
            r = !0;
            break a;
          }
        r = !1;
      }
      if (r) {
        var u,
          v = [],
          w;
        for (w in m)
          if (m.hasOwnProperty(w)) {
            var y = m[w];
            y !== void 0 &&
              y === y &&
              y !== null &&
              y.toString() !== "[object Object]" &&
              (v.push(w), v.push(pb(String(y))));
          }
        var z = v.join("*");
        u = ["1", xr(z), z].join("*");
        d
          ? (Oh(3) || Oh(1) || !p) && Gr("_gl", u, a, p, q)
          : Hr("_gl", u, a, p, q);
      }
    }
    var d = (a.tagName || "").toUpperCase() === "FORM",
      e = qr(b, 1, d),
      f = qr(b, 2, d),
      g = qr(b, 4, d),
      h = qr(b, 3, d);
    c(e, !1, !1);
    c(f, !0, !1);
    Oh(1) && c(g, !0, !0);
    for (var k in h) h.hasOwnProperty(k) && Ir(k, h[k], a);
  }
  function Ir(a, b, c) {
    c.tagName.toLowerCase() === "a"
      ? Hr(a, b, c)
      : c.tagName.toLowerCase() === "form" && Gr(a, b, c);
  }
  function Hr(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var f;
    if ((f = c.href)) {
      var g;
      if (!(g = d)) {
        var h = x.location.href,
          k = vr(c.href),
          m = vr(h);
        g = !(k && m && k.Vj === m.Vj && k.query === m.query && k.fragment);
      }
      f = g;
    }
    if (f) {
      var p = Er(a, b, c.href, d, e);
      Ec.test(p) && (c.href = p);
    }
  }
  function Gr(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    if (c) {
      var f = c.getAttribute("action") || "";
      if (f) {
        var g = (c.method || "").toLowerCase();
        if (g !== "get" || d) {
          if (g === "get" || g === "post") {
            var h = Er(a, b, f, d, e);
            Ec.test(h) && (c.action = h);
          }
        } else {
          for (var k = c.childNodes || [], m = !1, p = 0; p < k.length; p++) {
            var q = k[p];
            if (q.name === a) {
              q.setAttribute("value", b);
              m = !0;
              break;
            }
          }
          if (!m) {
            var r = A.createElement("input");
            r.setAttribute("type", "hidden");
            r.setAttribute("name", a);
            r.setAttribute("value", b);
            c.appendChild(r);
          }
        }
      }
    }
  }
  function mr(a) {
    try {
      var b;
      a: {
        for (var c = a, d = 100; c && d > 0; ) {
          if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
            b = c;
            break a;
          }
          c = c.parentNode;
          d--;
        }
        b = null;
      }
      var e = b;
      if (e) {
        var f = e.protocol;
        (f !== "http:" && f !== "https:") || Fr(e, e.hostname);
      }
    } catch (g) {}
  }
  function nr(a) {
    try {
      var b = a.getAttribute("action");
      if (b) {
        var c = Dj(Jj(b), "host");
        Fr(a, c);
      }
    } catch (d) {}
  }
  function Jr(a, b, c, d) {
    lr();
    var e = c === "fragment" ? 2 : 1;
    d = !!d;
    pr(a, b, e, d, !1);
    e === 2 && sb("TAGGING", 23);
    d && sb("TAGGING", 24);
  }
  function Kr(a, b) {
    lr();
    pr(a, [Fj(x.location, "host", !0)], b, !0, !0);
  }
  function Lr() {
    var a = A.location.hostname,
      b = sr.exec(A.referrer);
    if (!b) return !1;
    var c = b[2],
      d = b[1],
      e = "";
    if (c) {
      var f = c.split("/"),
        g = f[1];
      e = g === "s" ? Cj(f[2]) || "" : Cj(g) || "";
    } else if (d) {
      if (d.indexOf("xn--") === 0) return !1;
      e = d.replace(/-/g, ".").replace(/\.\./g, "-");
    }
    var h = a.replace(tr, ""),
      k = e.replace(tr, "");
    return h === k || $b(h, "." + k);
  }
  function Mr(a, b) {
    return a === !1 ? !1 : a || b || Lr();
  }
  var Nr = function (a) {
    a = a === void 0 ? 0 : a;
    this.value = 0;
    this.value = a;
  };
  Nr.prototype.set = function (a) {
    return (this.value |= 1 << a);
  };
  var Or = function (a, b) {
    b <= 0 || (a.value |= 1 << (b - 1));
  };
  l = Nr.prototype;
  l.get = function () {
    return this.value;
  };
  l.isSet = function (a) {
    return (this.value & (1 << a)) !== 0;
  };
  l.clear = function (a) {
    this.value &= ~(1 << a);
  };
  l.clearAll = function () {
    this.value = 0;
  };
  l.equals = function (a) {
    return this.value === a.value;
  };
  function Pr(a) {
    if (a)
      try {
        return new Uint8Array(
          atob(a.replace(/-/g, "+").replace(/_/g, "/"))
            .split("")
            .map(function (b) {
              return b.charCodeAt(0);
            })
        );
      } catch (b) {}
  }
  function Qr(a, b) {
    var c = 0,
      d = 0,
      e,
      f = b;
    do {
      if (f >= a.length) return;
      e = a[f++];
      c |= (e & 127) << d;
      d += 7;
    } while (e & 128);
    return [c, f];
  }
  function Rr() {
    var a = String,
      b = x.location.hostname,
      c = x.location.pathname,
      d = (b = jc(b));
    d.split(".").length > 2 &&
      (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
    b = d;
    c = jc(c);
    var e = c.split(";")[0];
    e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
    return a(eg(("" + b + e).toLowerCase()));
  }
  var Sr = ["ad_storage", "ad_user_data"];
  function Tr(a, b) {
    if (!a) return sb("TAGGING", 32), 10;
    if (b === null || b === void 0 || b === "") return sb("TAGGING", 33), 11;
    var c = Ur(!1);
    if (c.error !== 0) return sb("TAGGING", 34), c.error;
    if (!c.value) return sb("TAGGING", 35), 2;
    c.value[a] = b;
    var d = Vr(c);
    d !== 0 && sb("TAGGING", 36);
    return d;
  }
  function Wr(a) {
    if (!a) return sb("TAGGING", 27), { error: 10 };
    var b = Ur();
    if (b.error !== 0) return sb("TAGGING", 29), b;
    if (!b.value) return sb("TAGGING", 30), { error: 2 };
    if (!(a in b.value)) return sb("TAGGING", 31), { value: void 0, error: 15 };
    var c = b.value[a];
    return c === null || c === void 0 || c === ""
      ? (sb("TAGGING", 28), { value: void 0, error: 11 })
      : { value: c, error: 0 };
  }
  function Xr(a) {
    if (a) {
      var b = Ur(!1);
      b.error !== 0
        ? sb("TAGGING", 38)
        : b.value
        ? a in b.value
          ? (delete b.value[a], Vr(b) !== 0 && sb("TAGGING", 41))
          : sb("TAGGING", 40)
        : sb("TAGGING", 39);
    } else sb("TAGGING", 37);
  }
  function Ur(a) {
    a = a === void 0 ? !0 : a;
    if (!Tm(Sr)) return sb("TAGGING", 43), { error: 3 };
    try {
      if (!x.localStorage) return sb("TAGGING", 44), { error: 1 };
    } catch (f) {
      return sb("TAGGING", 45), { error: 14 };
    }
    var b = { schema: "gcl", version: 1 },
      c = void 0;
    try {
      c = x.localStorage.getItem("_gcl_ls");
    } catch (f) {
      return sb("TAGGING", 46), { error: 13 };
    }
    try {
      if (c) {
        var d = JSON.parse(c);
        if (d && typeof d === "object") b = d;
        else return sb("TAGGING", 47), { error: 12 };
      }
    } catch (f) {
      return sb("TAGGING", 48), { error: 8 };
    }
    if (b.schema !== "gcl") return sb("TAGGING", 49), { error: 4 };
    if (b.version !== 1) return sb("TAGGING", 50), { error: 5 };
    try {
      var e = Yr(b);
      a && e && Vr({ value: b, error: 0 });
    } catch (f) {
      return sb("TAGGING", 48), { error: 8 };
    }
    return { value: b, error: 0 };
  }
  function Yr(a) {
    if (!a || typeof a !== "object") return !1;
    if ("expires" in a && "value" in a) {
      var b;
      typeof a.expires === "number"
        ? (b = a.expires)
        : (b = typeof a.expires === "string" ? Number(a.expires) : NaN);
      if (isNaN(b) || !(Date.now() <= b))
        return (a.value = null), (a.error = 9), sb("TAGGING", 54), !0;
    } else {
      var c = !1,
        d = n(Object.keys(a)),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) c = Yr(a[e.value]) || c;
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      return c;
    }
    return !1;
  }
  function Vr(a) {
    if (a.error) return a.error;
    if (!a.value) return sb("TAGGING", 42), 2;
    var b = a.value,
      c;
    try {
      c = JSON.stringify(b);
    } catch (d) {
      return sb("TAGGING", 52), 6;
    }
    try {
      x.localStorage.setItem("_gcl_ls", c);
    } catch (d) {
      return sb("TAGGING", 53), 7;
    }
    return 0;
  }
  var Zr = {},
    $r =
      ((Zr.gclid = !0),
      (Zr.dclid = !0),
      (Zr.gbraid = !0),
      (Zr.wbraid = !0),
      Zr),
    as = /^\w+$/,
    bs = /^[\w-]+$/,
    cs = {},
    ds = ((cs.aw = "FPGCLAW"), cs),
    es = {},
    gs =
      ((es.ag = "_ag"),
      (es.gb = "_gb"),
      (es.aw = "_aw"),
      (es.dc = "_dc"),
      (es.gf = "_gf"),
      (es.ha = "_ha"),
      (es.gp = "_gp"),
      (es.gs = "_gs"),
      es),
    hs = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
    is = /^www\.googleadservices\.com$/;
  function js() {
    return ["ad_storage", "ad_user_data"];
  }
  function ks(a) {
    return !Oh(5) || Tm(a);
  }
  function ls(a, b) {
    function c() {
      var d = ks(b);
      d && a();
      return d;
    }
    Zm(function () {
      c() || $m(c, b);
    }, b);
  }
  function ms(a) {
    return ns(a).map(function (b) {
      return b.gclid;
    });
  }
  function ps(a) {
    return qs(a)
      .filter(function (b) {
        return b.gclid;
      })
      .map(function (b) {
        return b.gclid;
      });
  }
  function qs(a, b) {
    b = b === void 0 ? !1 : b;
    var c = rs(a.prefix),
      d = ss("gb", c),
      e = ss("ag", c);
    if (!e || !d) return [];
    var f = function (k) {
        return function (m) {
          m.xg = k;
          return m;
        };
      },
      g = ns(d, b).map(f("gb")),
      h = ts(e).map(f("ag"));
    return g.concat(h).sort(function (k, m) {
      return m.timestamp - k.timestamp;
    });
  }
  function us(a, b, c, d, e) {
    var f = Hb(a, function (g) {
      return g.gclid === b;
    });
    f
      ? (f.timestamp < c && ((f.timestamp = c), (f.nd = e)),
        (f.labels = vs(f.labels || [], d || [])))
      : a.push({ version: "2", gclid: b, timestamp: c, labels: d, nd: e });
  }
  function ws(a) {
    var b = er(a, 5) || [],
      c = [],
      d = n(b),
      e = d.next(),
      f;
    try {
      for (; !e.done; e = d.next()) {
        var g = e.value,
          h = g,
          k = xs(g);
        k && us(c, h.k, k, h.b || [], g.u);
      }
    } finally {
      e && !e.done && (f = d.return) && f.call(d);
    }
    return c.sort(function (m, p) {
      return p.timestamp - m.timestamp;
    });
  }
  function ns(a, b) {
    b = b === void 0 ? !1 : b;
    var c = [];
    ys(c, a, 1);
    if (b)
      if ($b(a, "_aw")) {
        var d = zs();
        d && ((d.nd = void 0), (d.ra = d.ra || [2]), As(c, d));
        ys(c, "gcl_aw", 2);
      } else $b(a, "_gb") && ys(c, "gcl_gb", 2);
    c.sort(function (e, f) {
      return f.timestamp - e.timestamp;
    });
    return Bs(c);
  }
  function Cs(a, b) {
    var c = [],
      d = n(a),
      e = d.next(),
      f;
    try {
      for (; !e.done; e = d.next()) {
        var g = e.value;
        c.includes(g) || c.push(g);
      }
    } finally {
      e && !e.done && (f = d.return) && f.call(d);
    }
    var h = n(b),
      k = h.next(),
      m;
    try {
      for (; !k.done; k = h.next()) {
        var p = k.value;
        c.includes(p) || c.push(p);
      }
    } finally {
      k && !k.done && (m = h.return) && m.call(h);
    }
    return c;
  }
  function As(a, b, c) {
    c = c === void 0 ? !1 : c;
    var d,
      e,
      f = n(a),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) {
        var k = g.value;
        if (k.gclid === b.gclid) {
          d = k;
          break;
        }
        k.qa && b.qa && k.qa.equals(b.qa) && (e = k);
      }
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
    if (d) {
      var m = d,
        p,
        q,
        r = (p = d.qa) != null ? p : new Nr(),
        t = (q = b.qa) != null ? q : new Nr();
      r.value |= t.value;
      m.qa = r;
      d.timestamp < b.timestamp && ((d.timestamp = b.timestamp), (d.nd = b.nd));
      d.labels = Cs(d.labels || [], b.labels || []);
      d.ra = Cs(d.ra || [], b.ra || []);
    } else c && e ? ma(Object, "assign").call(Object, e, b) : a.push(b);
  }
  function Ds(a) {
    if (!a) return new Nr();
    var b = new Nr();
    if (a === 1) return Or(b, 2), Or(b, 3), b;
    Or(b, a);
    return b;
  }
  function zs() {
    var a = Wr("gclid");
    if (!a || a.error || !a.value || typeof a.value !== "object") return null;
    var b = a.value;
    try {
      if (!("value" in b && b.value) || typeof b.value !== "object")
        return null;
      var c = b.value,
        d = c.value;
      if (!d || !d.match(bs)) return null;
      var e = c.linkDecorationSource,
        f = c.linkDecorationSources,
        g = new Nr();
      typeof e === "number"
        ? (g = Ds(e))
        : typeof f === "number" && (g.value = f);
      return {
        version: "",
        gclid: d,
        timestamp: Number(c.creationTimeMs) || 0,
        labels: [],
        qa: g,
        ra: [2],
      };
    } catch (h) {
      return null;
    }
  }
  function Es(a) {
    var b = Wr(a);
    if (b.error !== 0) return null;
    try {
      return b.value.reduce(function (c, d) {
        if (!d.value || typeof d.value !== "object") return c;
        var e = d.value,
          f = e.value;
        if (!f || !f.match(bs)) return c;
        var g = new Nr(),
          h = e.linkDecorationSources;
        typeof h === "number" && (g.value = h);
        var k;
        c.push({
          version: "",
          gclid: f,
          timestamp: Number(e.creationTimeMs) || 0,
          expires: Number(d.expires) || 0,
          labels: (k = e.labels) != null ? k : [],
          qa: g,
          ra: [2],
        });
        return c;
      }, []);
    } catch (c) {
      return null;
    }
  }
  function ys(a, b, c) {
    if (c === 1) {
      var d = Lq(b, A.cookie, void 0, js()),
        e = n(d),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = Fs(f.value.split(".")),
            k =
              h.length === 0
                ? null
                : {
                    version: h[0],
                    gclid: h[2],
                    timestamp: (Number(h[1]) || 0) * 1e3,
                    labels: h.slice(3),
                  };
          k != null &&
            ((k.nd = void 0), (k.qa = new Nr()), (k.ra = [c]), As(a, k));
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
    } else if (c === 2) {
      var m = Es(b);
      if (m) {
        var p = n(m),
          q = p.next(),
          r;
        try {
          for (; !q.done; q = p.next()) {
            var t = q.value;
            t.nd = void 0;
            As(a, t);
          }
        } finally {
          q && !q.done && (r = p.return) && r.call(p);
        }
      }
    }
  }
  function Gs(a) {
    var b = ns(a),
      c = Es("gcl_dc");
    if (c) {
      var d = n(c),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = e.value;
          g.nd = void 0;
          g.ra = g.ra || [2];
          As(b, g);
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
    }
    b.sort(function (h, k) {
      var m = h.ra && h.ra.includes(1),
        p = k.ra && k.ra.includes(1);
      return m && !p ? -1 : !m && p ? 1 : k.timestamp - h.timestamp;
    });
    return Bs(b);
  }
  function ts(a) {
    return ws(a).map(function (b) {
      b.qa = new Nr();
      b.ra = [1];
      return b;
    });
  }
  function vs(a, b) {
    if (!a.length) return b;
    if (!b.length) return a;
    var c = {};
    return a.concat(b).filter(function (d) {
      return c.hasOwnProperty(d) ? !1 : (c[d] = !0);
    });
  }
  function rs(a) {
    return a && typeof a === "string" && a.match(as) ? a : "_gcl";
  }
  function Hs(a, b) {
    if (a) {
      var c = { value: a, qa: new Nr() };
      Or(c.qa, b);
      return c;
    }
  }
  function Is(a, b, c) {
    var d = Jj(a),
      e = Dj(d, "query", !1, void 0, "gclsrc"),
      f = Hs(Dj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
    if (b && (!f || !e)) {
      var g = d.hash.replace("#", "");
      f || (f = Hs(Aj(g, "gclid", !1), 3));
      e || (e = Aj(g, "gclsrc", !1));
    }
    return !f || (e !== void 0 && e !== "aw" && e !== "aw.ds") ? [] : [f];
  }
  function Js(a, b) {
    var c = Jj(a),
      d = Dj(c, "query", !1, void 0, "gclid"),
      e = Dj(c, "query", !1, void 0, "gclsrc"),
      f = Dj(c, "query", !1, void 0, "wbraid");
    f = fc(f);
    var g = Dj(c, "query", !1, void 0, "gbraid"),
      h = Dj(c, "query", !1, void 0, "gad_source"),
      k = Dj(c, "query", !1, void 0, "dclid");
    if (b && !(d && e && f && g)) {
      var m = c.hash.replace("#", "");
      d = d || Aj(m, "gclid", !1);
      e = e || Aj(m, "gclsrc", !1);
      f = f || Aj(m, "wbraid", !1);
      g = g || Aj(m, "gbraid", !1);
      h = h || Aj(m, "gad_source", !1);
    }
    return Ks(d, e, k, f, g, h);
  }
  function Ls(a, b, c) {
    var d = Jj(a),
      e = Dj(d, "query", !1, void 0, "gclsrc"),
      f = Hs(Dj(d, "query", !1, void 0, "gclid"), c ? 4 : 2),
      g = Hs(Dj(d, "query", !1, void 0, "dclid"), c ? 4 : 2);
    if (b && (!e || !f)) {
      var h = d.hash.replace("#", "");
      f || (f = Hs(Aj(h, "gclid", !1), 3));
      e || (e = Aj(h, "gclsrc", !1));
    }
    return f && e && (e === "aw.ds" || e === "3p.ds" || e === "ds")
      ? [f]
      : g
      ? [g]
      : [];
  }
  function Ms() {
    return Js(x.location.href, !0);
  }
  function Ks(a, b, c, d, e, f) {
    var g = {},
      h = function (k, m) {
        g[m] || (g[m] = []);
        g[m].push(k);
      };
    g.gclid = a;
    g.gclsrc = b;
    g.dclid = c;
    if (a !== void 0 && a.match(bs))
      switch (b) {
        case void 0:
          h(a, "aw");
          break;
        case "aw.ds":
          h(a, "aw");
          h(a, "dc");
          break;
        case "ds":
          h(a, "dc");
          break;
        case "3p.ds":
          h(a, "dc");
          break;
        case "gf":
          h(a, "gf");
          break;
        case "ha":
          h(a, "ha");
      }
    c && h(c, "dc");
    d !== void 0 && bs.test(d) && ((g.wbraid = d), h(d, "gb"));
    e !== void 0 && bs.test(e) && ((g.gbraid = e), h(e, "ag"));
    f !== void 0 && bs.test(f) && ((g.gad_source = f), h(f, "gs"));
    return g;
  }
  function Ns() {
    var a = Ms(),
      b = !0,
      c = n(Object.keys(a)),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next())
        if (a[d.value] !== void 0) {
          b = !1;
          break;
        }
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    b && ((a = Js(x.document.referrer, !1)), (a.gad_source = void 0));
    return a;
  }
  function Os(a) {
    var b = Ns();
    Ps(b, !1, a);
  }
  function Qs(a) {
    var b = Is(x.location.href, !0, !1);
    b.length || (b = Is(x.document.referrer, !1, !0));
    a = a || {};
    Rs(a);
    if (b.length) {
      var c = b[0],
        d = Sb(),
        e = cr(a, d, !0),
        f = js(),
        g = function () {
          ks(f) &&
            e.expires !== void 0 &&
            Tr("gclid", {
              value: {
                value: c.value,
                creationTimeMs: d,
                linkDecorationSources: c.qa.get(),
              },
              expires: Number(e.expires),
            });
        };
      Zm(function () {
        g();
        ks(f) || $m(g, f);
      }, f);
    }
  }
  function Rs(a) {
    var b = A.referrer ? Dj(Jj(A.referrer), "host") : "";
    if (hs.test(b) || is.test(b) || Ss()) {
      var c;
      a: {
        var d = Jj(x.location.href),
          e = Bj(Dj(d, "query")),
          f = n(Object.keys(e)),
          g = f.next(),
          h;
        try {
          for (; !g.done; g = f.next()) {
            var k = g.value;
            if (!$r[k]) {
              var m = e[k][0] || "",
                p;
              if (!m || m.length < 50 || m.length > 200) p = !1;
              else {
                var q = Pr(m),
                  r;
                if (q)
                  c: {
                    var t = void 0,
                      u = q;
                    if (u && u.length !== 0) {
                      var v = 0;
                      try {
                        for (var w = 10; v < u.length && !(w-- <= 0); ) {
                          t = Qr(u, v);
                          if (t === void 0) break;
                          var y = n(t),
                            z = y.next().value,
                            C = y.next().value,
                            D = z,
                            G = C,
                            F = D & 7;
                          if (D >> 3 === 16382) {
                            if (F !== 0) break;
                            var I = Qr(u, G);
                            if (I === void 0) break;
                            r = n(I).next().value === 1;
                            break c;
                          }
                          var L;
                          d: {
                            var P = void 0,
                              R = u,
                              U = G;
                            switch (F) {
                              case 0:
                                L = (P = Qr(R, U)) == null ? void 0 : P[1];
                                break d;
                              case 1:
                                L = U + 8;
                                break d;
                              case 2:
                                var X = Qr(R, U);
                                if (X === void 0) break;
                                var ea = n(X),
                                  ja = ea.next().value;
                                L = ea.next().value + ja;
                                break d;
                              case 5:
                                L = U + 4;
                                break d;
                            }
                            L = void 0;
                          }
                          if (L === void 0 || L > u.length || L <= v) break;
                          v = L;
                        }
                      } catch (Ga) {}
                    }
                    r = !1;
                  }
                else r = !1;
                p = r;
              }
              if (p) {
                c = m;
                break a;
              }
            }
          }
        } finally {
          g && !g.done && (h = f.return) && h.call(f);
        }
        c = void 0;
      }
      var va = c;
      va && Ts("gcl_aw", va, 7, a);
    }
  }
  function Ts(a, b, c, d) {
    Us(a, [{ version: "", gclid: b, timestamp: Sb(), qa: Ds(c) }], d);
  }
  function Us(a, b, c) {
    c = c || {};
    var d = js(),
      e = function () {
        if (ks(d) && b.length > 0) {
          var f = Es(a) || [];
          b.forEach(function (g) {
            var h = cr(c, g.timestamp, !0);
            h.expires !== void 0 &&
              As(
                f,
                {
                  version: "",
                  gclid: g.gclid,
                  timestamp: g.timestamp,
                  expires: Number(h.expires),
                  qa: g.qa,
                  labels: g.labels,
                },
                !0
              );
          });
          f.length &&
            Tr(
              a,
              f.map(function (g) {
                var h = {
                    value: g.gclid,
                    creationTimeMs: g.timestamp,
                    linkDecorationSources: g.qa ? g.qa.get() : 0,
                  },
                  k;
                if ((k = g.labels) == null ? 0 : k.length) h.labels = g.labels;
                return { value: h, expires: Number(g.expires) };
              })
            );
        }
      };
    Zm(function () {
      ks(d) ? e() : $m(e, d);
    }, d);
  }
  function Ps(a, b, c, d, e) {
    c = c || {};
    e = e || [];
    var f = rs(c.prefix),
      g = d || Sb(),
      h = Math.round(g / 1e3),
      k = js(),
      m = !1,
      p = !1,
      q = Oh(6),
      r = function () {
        if (ks(k)) {
          var t = cr(c, g, !0);
          t.Ic = k;
          var u = function (R, U) {
              var X = ss(R, f);
              X && (Xq(X, U, t), R !== "gb" && (m = !0));
            },
            v = function (R) {
              var U = ["GCL", h, R];
              e.length > 0 && U.push(e.join("."));
              return U.join(".");
            },
            w = n(["aw", "dc", "gf", "ha", "gp"]),
            y = w.next(),
            z;
          try {
            for (; !y.done; y = w.next()) {
              var C = y.value;
              a[C] && u(C, v(a[C][0]));
            }
          } finally {
            y && !y.done && (z = w.return) && z.call(w);
          }
          if ((!m || q) && a.gb) {
            var D = a.gb[0],
              G = ss("gb", f);
            (!b &&
              ns(G).some(function (R) {
                return R.gclid === D && R.labels && R.labels.length > 0;
              })) ||
              u("gb", v(D));
          }
        }
        if (!p && a.gbraid && ks("ad_storage") && ((p = !0), !m || q)) {
          var F = a.gbraid,
            I = ss("ag", f);
          if (
            b ||
            !ts(I).some(function (R) {
              return R.gclid === F && R.labels && R.labels.length > 0;
            })
          ) {
            var L = {},
              P = ((L.k = F), (L.i = "" + h), (L.b = e), L);
            ir(I, P, 5, c, g);
          }
        }
        Vs(a, f, g, c);
      };
    Zm(function () {
      r();
      ks(k) || $m(r, k);
    }, k);
  }
  function Vs(a, b, c, d) {
    if (a.gad_source !== void 0 && ks("ad_storage")) {
      var e = zd();
      if (e !== "r" && e !== "h") {
        var f = a.gad_source,
          g = ss("gs", b);
        if (g) {
          var h = yd() || 0,
            k = Math.floor((Sb() - h) / 1e3),
            m,
            p = Rr(),
            q = {};
          m = ((q.k = f), (q.i = "" + k), (q.u = p), q);
          ir(g, m, 5, d, c);
        }
      }
    }
  }
  function Ws(a, b, c) {
    for (var d = er(b, c), e = 0; e < d.length; ++e)
      if (xs(d[e]) > a) return !0;
    return !1;
  }
  function Xs(a) {
    var b = Ys,
      c = Zs(a.prefix);
    ls(function () {
      var d = rs(a.prefix),
        e = n(b),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value,
            k = c[h];
          if (k) {
            var m = Math.min($s(k), Sb()),
              p = cr(a, m, !0);
            p.Ic = js();
            var q = ss(h, d);
            q && Xq(q, k, p);
          }
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
      var r = Cr(!0);
      Ps(Ks(r.gclid, r.gclsrc), !1, a);
    }, js());
  }
  function Zs(a) {
    var b = Cr(!0),
      c = rs(a),
      d = {},
      e;
    for (e in gs)
      if (gs.hasOwnProperty(e)) {
        var f = e,
          g = ss(f, c);
        if (g !== void 0) {
          var h = b[g];
          if (h) {
            var k = $s(h),
              m = Math.min(k, Sb()) || Sb(),
              p;
            a: {
              for (
                var q = Lq(g, A.cookie, void 0, js()), r = 0;
                r < q.length;
                ++r
              )
                if ($s(q[r]) > m) {
                  p = !0;
                  break a;
                }
              p = !1;
            }
            p || (d[f] = h);
          }
        }
      }
    return d;
  }
  function at(a) {
    var b = ["ag"],
      c = Cr(!0),
      d = rs(a.prefix);
    ls(
      function () {
        for (var e = 0; e < b.length; ++e) {
          var f = ss(b[e], d);
          if (f) {
            var g = c[f];
            if (g) {
              var h = Iq(g, 5);
              if (h) {
                var k = xs(h);
                k || (k = Sb());
                if (Ws(k, f, 5)) break;
                h.i = "" + Math.round(k / 1e3);
                ir(f, h, 5, a, k);
              }
            }
          }
        }
      },
      ["ad_storage"]
    );
  }
  function ss(a, b) {
    var c = gs[a];
    if (c !== void 0) return b + c;
  }
  function $s(a) {
    return Fs(a.split(".")).length !== 0
      ? (Number(a.split(".")[1]) || 0) * 1e3
      : 0;
  }
  function xs(a) {
    return a ? (Number(a.i) || 0) * 1e3 : 0;
  }
  function Fs(a) {
    return a.length < 3 ||
      (a[0] !== "GCL" && a[0] !== "1") ||
      !/^\d+$/.test(a[1]) ||
      !bs.test(a[2])
      ? []
      : a;
  }
  function bt(a, b, c, d) {
    var e = Ys;
    if (Array.isArray(a) && Aq(x)) {
      var f = rs(d),
        g = function () {
          for (var h = {}, k = 0; k < e.length; ++k) {
            var m = ss(e[k], f);
            if (m) {
              var p = Lq(m, A.cookie, void 0, js());
              p.length && (h[m] = p.sort()[p.length - 1]);
            }
          }
          return h;
        };
      ls(function () {
        Jr(g, a, b, c);
      }, js());
    }
  }
  function ct(a, b, c) {
    var d = Ys;
    if (Oh(9) && Array.isArray(a) && Aq(x)) {
      var e = function () {
        for (var f = {}, g = 0; g < d.length; ++g) {
          var h = ds[d[g]];
          if (h) {
            var k = Lq(h, A.cookie, void 0, js());
            if (k.length) {
              var m = void 0,
                p = 0,
                q = n(k),
                r = q.next(),
                t;
              try {
                for (; !r.done; r = q.next()) {
                  var u = r.value,
                    v = Iq(u, 4);
                  if (v && (v.m === "1" || Oh(11))) {
                    var w = xs(v);
                    w >= p && ((p = w), (m = u));
                  }
                }
              } finally {
                r && !r.done && (t = q.return) && t.call(q);
              }
              m && (f[h] = m);
            }
          }
        }
        return f;
      };
      ls(function () {
        Jr(e, a, b, c);
      }, js());
    }
  }
  function dt(a, b, c, d) {
    if (Array.isArray(a) && Aq(x)) {
      var e = ["ag"],
        f = rs(d),
        g = function () {
          for (var h = {}, k = 0; k < e.length; ++k) {
            var m = ss(e[k], f);
            if (!m) return {};
            var p = er(m, 5);
            if (p.length) {
              var q = p.sort(function (r, t) {
                return xs(t) - xs(r);
              })[0];
              h[m] = Jq(q, 5);
            }
          }
          return h;
        };
      ls(
        function () {
          Jr(g, a, b, c);
        },
        ["ad_storage"]
      );
    }
  }
  function Bs(a) {
    return a.filter(function (b) {
      return bs.test(b.gclid);
    });
  }
  function et(a, b) {
    if (Aq(x)) {
      for (var c = rs(b.prefix), d = {}, e = 0; e < a.length; e++)
        gs[a[e]] && (d[a[e]] = gs[a[e]]);
      ls(function () {
        Lb(d, function (f, g) {
          var h = Lq(c + g, A.cookie, void 0, js());
          h.sort(function (t, u) {
            return $s(u) - $s(t);
          });
          if (h.length) {
            var k = h[0],
              m = $s(k),
              p = Fs(k.split(".")).length !== 0 ? k.split(".").slice(3) : [],
              q = {},
              r;
            r = Fs(k.split(".")).length !== 0 ? k.split(".")[2] : void 0;
            q[f] = [r];
            Ps(q, !0, b, m, p);
          }
        });
      }, js());
    }
  }
  function ft(a) {
    var b = ["ag"],
      c = ["gbraid"];
    ls(
      function () {
        for (var d = rs(a.prefix), e = 0; e < b.length; ++e) {
          var f = ss(b[e], d);
          if (!f) break;
          var g = er(f, 5);
          if (g.length) {
            var h = g.sort(function (q, r) {
                return xs(r) - xs(q);
              })[0],
              k = xs(h),
              m = h.b,
              p = {};
            p[c[e]] = h.k;
            Ps(p, !0, a, k, m);
          }
        }
      },
      ["ad_storage"]
    );
  }
  function gt(a, b) {
    for (var c = 0; c < b.length; ++c) if (a[b[c]]) return !0;
    return !1;
  }
  function ht(a) {
    function b(h, k, m) {
      m && (h[k] = m);
    }
    if (Wm()) {
      var c = Ms(),
        d;
      a.includes("gad_source") &&
        (d = c.gad_source !== void 0 ? c.gad_source : Cr(!1)._gs);
      if (gt(c, a) || d) {
        var e = {};
        b(e, "gclid", c.gclid);
        b(e, "dclid", c.dclid);
        b(e, "gclsrc", c.gclsrc);
        b(e, "wbraid", c.wbraid);
        b(e, "gbraid", c.gbraid);
        Kr(function () {
          return e;
        }, 3);
        var f = {},
          g = ((f._up = "1"), f);
        b(g, "_gs", d);
        Kr(function () {
          return g;
        }, 1);
      }
    }
  }
  function Ss() {
    var a = Jj(x.location.href);
    return Dj(a, "query", !1, void 0, "gad_source");
  }
  function it(a) {
    if (!Oh(1)) return null;
    var b = Cr(!0).gad_source;
    if (b != null) return (x.location.hash = ""), b;
    if (Oh(2)) {
      b = Ss();
      if (b != null) return b;
      var c = Ms();
      if (gt(c, a)) return "0";
    }
    return null;
  }
  function jt(a) {
    var b = it(a);
    b != null &&
      Kr(function () {
        var c = {};
        return (c.gad_source = b), c;
      }, 4);
  }
  function kt(a, b, c) {
    var d = [];
    if (b.length === 0) return d;
    for (var e = {}, f = 0; f < b.length; f++) {
      var g = b[f],
        h = g.xg ? g.xg : "gcl";
      if ((g.labels || []).indexOf(c) === -1) {
        a.push(0);
        var k = !1,
          m = void 0;
        if ((m = g.ra) == null ? 0 : m.includes(2)) k = !0;
        var p = void 0;
        ((p = g.ra) == null ? 0 : p.includes(1)) &&
          !e[h] &&
          ((k = !0), (e[h] = !0));
        k && d.push(g);
      } else {
        a.push(1);
        var q = void 0;
        if ((q = g.ra) == null ? 0 : q.includes(1)) e[h] = !0;
      }
    }
    return d;
  }
  function lt(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    var f = [];
    c = c || {};
    if (!ks(js())) return f;
    var g = ns(a, e),
      h = kt(f, g, b);
    if (h.length && !d) {
      var k = [],
        m = !1,
        p = n(h),
        q = p.next(),
        r;
      try {
        for (; !q.done; q = p.next()) {
          var t = q.value,
            u = t,
            v = u.version,
            w = u.gclid,
            y = u.timestamp,
            z = u.ra,
            C = (u.labels || []).concat([b]),
            D = void 0;
          if (((D = z) == null ? 0 : D.includes(1)) && !m) {
            var G = [v, Math.round(y / 1e3), w].concat(C).join("."),
              F = cr(c, y, !0);
            F.Ic = js();
            Xq(a, G, F);
            m = !0;
          }
          var I = void 0;
          e &&
            ((I = z) == null ? 0 : I.includes(2)) &&
            k.push(ma(Object, "assign").call(Object, {}, t, { labels: C }));
        }
      } finally {
        q && !q.done && (r = p.return) && r.call(p);
      }
      k.length && Us("gcl_gb", k, c);
    }
    return f;
  }
  function mt(a, b, c) {
    c = c === void 0 ? !1 : c;
    var d = [];
    b = b || {};
    var e = qs(b, c),
      f = kt(d, e, a);
    if (f.length) {
      var g = [],
        h = {},
        k = n(f),
        m = k.next(),
        p;
      try {
        for (; !m.done; m = k.next()) {
          var q = m.value,
            r = rs(b.prefix),
            t = ss(q.xg, r);
          if (!t) return d;
          var u = q,
            v = u.version,
            w = u.gclid,
            y = u.timestamp,
            z = u.ra,
            C = Math.round(y / 1e3),
            D = vs(u.labels || [], [a]),
            G = void 0;
          if ((G = z) == null ? 0 : G.includes(1))
            if (q.xg === "ag" && !h.ag) {
              var F = {},
                I = ((F.k = w), (F.i = "" + C), (F.b = D), F);
              ir(t, I, 5, b, y);
              h.ag = !0;
            } else if (q.xg === "gb" && !h.gb) {
              var L = [v, C, w].concat(D).join("."),
                P = cr(b, y, !0);
              P.Ic = js();
              Xq(t, L, P);
              h.gb = !0;
            }
          var R = void 0;
          c &&
            ((R = z) == null ? 0 : R.includes(2)) &&
            g.push(ma(Object, "assign").call(Object, {}, q, { labels: D }));
        }
      } finally {
        m && !m.done && (p = k.return) && p.call(k);
      }
      g.length && Us("gcl_gb", g, b);
    }
    return d;
  }
  function nt(a, b) {
    var c = rs(b),
      d = ss(a, c);
    if (!d) return 0;
    var e;
    e = a === "ag" ? ts(d) : ns(d);
    for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
    return f;
  }
  function ot(a) {
    var b = 0,
      c = n(Object.keys(a)),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next())
        for (var f = a[d.value], g = 0; g < f.length; g++)
          b = Math.max(b, Number(f[g].timestamp));
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    return b;
  }
  function pt(a) {
    var b = Math.max(nt("aw", a), ot(ks(js()) ? zq() : {})),
      c = Math.max(nt("gb", a), ot(ks(js()) ? zq("_gac_gb", !0) : {}));
    c = Math.max(c, nt("ag", a));
    return c > b;
  }
  var qt = RegExp(
      "^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"
    ),
    rt = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
    st = /^\d+\.fls\.doubleclick\.net$/,
    tt = /;gac=([^;?]+)/,
    ut = /;gacgb=([^;?]+)/;
  function vt(a, b, c) {
    if (st.test(a.location.host)) {
      var d = a.location.href.match(c);
      return d && d.length === 2 && d[1].match(qt) ? Cj(d[1]) || "" : "";
    }
    var e = [],
      f = n(Object.keys(b)),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) {
        for (var k = g.value, m = [], p = b[k], q = 0; q < p.length; q++)
          m.push(p[q].gclid);
        e.push(k + ":" + m.join(","));
      }
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
    return e.length > 0 ? e.join(";") : "";
  }
  function wt(a, b, c) {
    var d = ks(js()) ? zq("_gac_gb", !0) : {},
      e = [],
      f = !1,
      g = n(Object.keys(d)),
      h = g.next(),
      k;
    try {
      for (; !h.done; h = g.next()) {
        var m = h.value,
          p = lt("_gac_gb_" + m, a, b, c);
        f =
          f ||
          (p.length !== 0 &&
            p.some(function (q) {
              return q === 1;
            }));
        e.push(m + ":" + p.join(","));
      }
    } finally {
      h && !h.done && (k = g.return) && k.call(g);
    }
    return { xs: f ? e.join(";") : "", ws: vt(A, d, ut) };
  }
  function xt(a, b) {
    var c = a.location.href.match(new RegExp(";" + b + "=([^;?]+)"));
    return c && c.length === 2 && c[1].match(rt) ? c[1] : void 0;
  }
  function zt(a) {
    var b = {},
      c,
      d,
      e;
    st.test(A.location.host) &&
      ((c = xt(A, "gclgs")), (d = xt(A, "gclst")), (e = xt(A, "gcllp")));
    if (c && d && e) (b.Cg = c), (b.Ph = d), (b.Oh = e);
    else {
      var f = Sb(),
        g = ws((a || "_gcl") + "_gs"),
        h = g.map(function (p) {
          return p.gclid;
        }),
        k = g.map(function (p) {
          return f - p.timestamp;
        }),
        m = g.map(function (p) {
          return p.nd;
        });
      h.length > 0 &&
        k.length > 0 &&
        m.length > 0 &&
        ((b.Cg = h.join(".")), (b.Ph = k.join(".")), (b.Oh = m.join(".")));
    }
    return b;
  }
  function At(a, b) {
    var c = a.split("."),
      d = b ? b.split(".") : [],
      e = d.length === c.length ? d : void 0;
    return c.map(function (f, g) {
      var h = { gclid: f };
      if (e) {
        var k = e[g].split("_");
        if (k.length === 2) {
          h.qa = new Nr(Number(k[0]));
          var m;
          var p = Number(k[1]);
          if (p === 0) m = [0];
          else {
            var q = [];
            p & 1 && q.push(1);
            p & 2 && q.push(2);
            p & 4 && q.push(3);
            p & 8 && q.push(4);
            p & 16 && q.push(5);
            m = q;
          }
          h.ra = m;
        }
      }
      return h;
    });
  }
  function Bt(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    if (st.test(a.location.host)) {
      var f = xt(a, d);
      if (f) {
        if (Oh(12)) {
          var g = xt(a, d + "_src");
          return At(f, g);
        }
        if (e) {
          var h = new Nr();
          Or(h, 2);
          Or(h, 3);
          return f.split(".").map(function (u) {
            return { gclid: u, qa: h, ra: [1] };
          });
        }
        return f.split(".").map(function (u) {
          return { gclid: u, qa: new Nr(), ra: [1] };
        });
      }
    } else {
      if (c === "gclid") {
        var k = ns((b || "_gcl") + "_aw", e),
          m = Number(Nh[1] === void 0 ? 0 : Nh[1]),
          p = n(Ct()),
          q = p.next(),
          r;
        try {
          for (; !q.done; q = p.next()) {
            var t = q.value;
            t.timestamp > m && As(k, t);
          }
        } finally {
          q && !q.done && (r = p.return) && r.call(p);
        }
        return k;
      }
      if (c === "wbraid") return ns((b || "_gcl") + "_gb", e);
      if (c === "braids") return qs({ prefix: b }, e);
    }
    return [];
  }
  function Ct() {
    return (er(ds.aw, 4) || [])
      .filter(function (a) {
        return a.m === "1";
      })
      .map(function (a) {
        return { gclid: a.k, timestamp: Number(a.i), version: "", ra: [5] };
      });
  }
  function Dt(a) {
    var b = 0,
      c = n(a),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) {
        var f = d.value;
        f > 0 && (b |= 1 << (f - 1));
      }
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    return b.toString();
  }
  function Et(a) {
    return st.test(A.location.host) ? !(xt(A, "gclaw") || xt(A, "gac")) : pt(a);
  }
  function Ft(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e;
    e = c
      ? mt(a, b, d)
      : lt(((b && b.prefix) || "_gcl") + "_gb", a, b, void 0, d);
    return e.length === 0 ||
      e.every(function (f) {
        return f === 0;
      })
      ? ""
      : e.join(".");
  }
  function Qt(a, b, c) {
    var d = Si(a, H.A.Ra);
    if (d && typeof d === "object") {
      var e = n(Object.keys(d)),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value,
            k = d[h];
          if (k !== void 0) {
            k === null && (k = "");
            var m = "gap." + h,
              p = String(k);
            c ? c(m, p) : (b[m] = p);
          }
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
    }
  }
  var Rt = !1,
    St = [];
  function Tt() {
    if (!Rt) {
      Rt = !0;
      for (var a = St.length - 1; a >= 0; a--) St[a]();
      St = [];
    }
  }
  function Ut(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function Vt(a, b, c) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, !1), !0)
      : !1;
  }
  function Wt(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function Xt(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = xq(a.document);
    if (c) {
      var f = function () {
        if (c) {
          var g = a.google_image_requests,
            h = Mc(g, e);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        Wt(e, "load", f);
        Wt(e, "error", f);
      };
      Vt(e, "load", f);
      Vt(e, "error", f);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function Yt(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    qq(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    Zt(c, b);
  }
  function Zt(a, b) {
    var c = window,
      d;
    b = b === void 0 ? !1 : b;
    d = d === void 0 ? !1 : d;
    if (c.fetch) {
      var e = {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors",
      };
      d &&
        ((e.mode = "cors"),
        "setAttributionReporting" in XMLHttpRequest.prototype
          ? (e.attributionReporting = {
              eventSourceEligible: "true",
              triggerEligible: "false",
            })
          : (e.headers = { "Attribution-Reporting-Eligible": "event-source" }));
      c.fetch(a, e);
    } else Xt(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d);
  }
  function $t() {
    this.fa = this.fa;
    this.U = this.U;
  }
  $t.prototype.fa = !1;
  $t.prototype.dispose = function () {
    this.fa || ((this.fa = !0), this.M());
  };
  $t.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  $t.prototype.addOnDisposeCallback = function (a, b) {
    this.fa
      ? b !== void 0
        ? a.call(b)
        : a()
      : (this.U || (this.U = []), b && (a = a.bind(b)), this.U.push(a));
  };
  $t.prototype.M = function () {
    if (this.U) for (; this.U.length; ) this.U.shift()();
  };
  function au(a) {
    a.addtlConsent === void 0 ||
      vf(a.addtlConsent) ||
      (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || wf(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !vf(a.tcString)) ||
      (a.listenerId !== void 0 && !uf(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var bu = function (a, b) {
    b = b === void 0 ? {} : b;
    $t.call(this);
    this.D = null;
    this.la = {};
    this.Da = 0;
    this.aa = null;
    this.J = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.vj = (d = b.vj) != null ? d : !1;
  };
  ta(bu, $t);
  bu.prototype.M = function () {
    this.la = {};
    this.aa && (Wt(this.J, "message", this.aa), delete this.aa);
    delete this.la;
    delete this.J;
    delete this.D;
    $t.prototype.M.call(this);
  };
  var du = function (a) {
    return typeof a.J.__tcfapi === "function" || cu(a) != null;
  };
  bu.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.vj },
      d = pq(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = au(c)),
          (c.internalBlockOnErrors = b.vj),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      eu(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  bu.prototype.removeEventListener = function (a) {
    a && a.listenerId && eu(this, "removeEventListener", null, a.listenerId);
  };
  var gu = function (a, b, c) {
      var d;
      d = d === void 0 ? "755" : d;
      var e;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var f = a.publisher.restrictions[b];
          if (f !== void 0) {
            e = f[d === void 0 ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      var g = e;
      if (g === 0) return !1;
      var h = c;
      c === 2
        ? ((h = 0), g === 2 && (h = 1))
        : c === 3 && ((h = 1), g === 1 && (h = 0));
      var k;
      if (h === 0)
        if (a.purpose && a.vendor) {
          var m = fu(a.vendor.consents, d === void 0 ? "755" : d);
          k =
            m && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH"
              ? !0
              : m && fu(a.purpose.consents, b);
        } else k = !0;
      else
        k =
          h === 1
            ? a.purpose && a.vendor
              ? fu(a.purpose.legitimateInterests, b) &&
                fu(a.vendor.legitimateInterests, d === void 0 ? "755" : d)
              : !0
            : !0;
      return k;
    },
    fu = function (a, b) {
      return !(!a || !a[b]);
    },
    eu = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.J;
      if (typeof e.__tcfapi === "function") {
        var f = e.__tcfapi;
        f(b, 2, c, d);
      } else if (cu(a)) {
        hu(a);
        var g = ++a.Da;
        a.la[g] = c;
        if (a.D) {
          var h = {};
          a.D.postMessage(
            ((h.__tcfapiCall = {
              command: b,
              version: 2,
              callId: g,
              parameter: d,
            }),
            h),
            "*"
          );
        }
      } else c({}, !1);
    },
    cu = function (a) {
      if (a.D) return a.D;
      a.D = vq(a.J, "__tcfapiLocator");
      return a.D;
    },
    hu = function (a) {
      if (!a.aa) {
        var b = function (c) {
          if (c.source === a.D)
            try {
              var d;
              d = (vf(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
              a.la[d.callId](d.returnValue, d.success);
            } catch (e) {}
        };
        a.aa = b;
        Vt(a.J, "message", b);
      }
    },
    iu = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = au(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Yt({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus !== "loaded" ||
          (a.eventStatus !== "tcloaded" &&
            a.eventStatus !== "useractioncomplete")
        ? !1
        : !0;
    };
  var ju = { 1: 0, 3: 0, 4: 0, 7: 3, 9: 3, 10: 3 };
  function ku() {
    return ko("tcf", function () {
      return {};
    });
  }
  var lu = function () {
    return new bu(x, { timeoutMs: -1 });
  };
  function mu() {
    var a = ku(),
      b = lu();
    du(b) && !nu() && !ou() && S(124);
    if (!a.active && du(b)) {
      nu() &&
        ((a.active = !0),
        (a.purposes = {}),
        (a.cmpId = 0),
        (a.tcfPolicyVersion = 0),
        (Lm().active = !0),
        (a.tcString = "tcunavailable"));
      vp();
      try {
        b.addEventListener(function (c) {
          if (c.internalErrorState !== 0)
            pu(a), wp([H.A.ja, H.A.Wa, H.A.ma]), (Lm().active = !0);
          else if (
            ((a.gdprApplies = c.gdprApplies),
            (a.cmpId = c.cmpId),
            (a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode),
            ou() && (a.active = !0),
            !qu(c) || nu() || ou())
          ) {
            a.tcfPolicyVersion = c.tcfPolicyVersion;
            var d;
            if (c.gdprApplies === !1) {
              var e = {},
                f;
              for (f in ju) ju.hasOwnProperty(f) && (e[f] = !0);
              d = e;
              b.removeEventListener(c);
            } else if (qu(c)) {
              var g = {},
                h;
              for (h in ju)
                if (ju.hasOwnProperty(h))
                  if (h === "1") {
                    var k,
                      m = c,
                      p = { As: !0 };
                    p = p === void 0 ? {} : p;
                    k = iu(m)
                      ? m.gdprApplies === !1
                        ? !0
                        : m.tcString === "tcunavailable"
                        ? !p.idpcApplies
                        : (p.idpcApplies || m.gdprApplies !== void 0 || p.As) &&
                          (p.idpcApplies ||
                            (vf(m.tcString) && m.tcString.length))
                        ? gu(m, "1", 0)
                        : !0
                      : !1;
                    g["1"] = k;
                  } else g[h] = gu(c, h, ju[h]);
              d = g;
            }
            if (d) {
              a.tcString = c.tcString || "tcempty";
              a.purposes = d;
              var q = {},
                r = ((q[H.A.ja] = a.purposes["1"] ? "granted" : "denied"), q);
              a.gdprApplies !== !0
                ? (wp([H.A.ja, H.A.Wa, H.A.ma]), (Lm().active = !0))
                : ((r[H.A.Wa] =
                    a.purposes["3"] && a.purposes["4"] ? "granted" : "denied"),
                  typeof a.tcfPolicyVersion === "number" &&
                  a.tcfPolicyVersion >= 4
                    ? (r[H.A.ma] =
                        a.purposes["1"] && a.purposes["7"]
                          ? "granted"
                          : "denied")
                    : wp([H.A.ma]),
                  np(
                    r,
                    { eventId: 0 },
                    {
                      gdprApplies: a ? a.gdprApplies : void 0,
                      tcString: ru() || "",
                    }
                  ));
            }
          } else wp([H.A.ja, H.A.Wa, H.A.ma]);
        });
      } catch (c) {
        pu(a), wp([H.A.ja, H.A.Wa, H.A.ma]), (Lm().active = !0);
      }
    }
  }
  function pu(a) {
    a.type = "e";
    a.tcString = "tcunavailable";
  }
  function qu(a) {
    return (
      a.eventStatus === "tcloaded" ||
      a.eventStatus === "useractioncomplete" ||
      a.eventStatus === "cmpuishown"
    );
  }
  function nu() {
    return x.gtag_enable_tcf_support === !0;
  }
  function ou() {
    return ku().enableAdvertiserConsentMode === !0;
  }
  function ru() {
    var a = ku();
    if (a.active) return a.tcString;
  }
  function su() {
    var a = ku();
    if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0";
  }
  function tu(a) {
    if (!ju.hasOwnProperty(String(a))) return !0;
    var b = ku();
    return b.active && b.purposes ? !!b.purposes[String(a)] : !0;
  }
  var uu = [H.A.ja, H.A.wa, H.A.ma, H.A.Wa],
    vu = {},
    wu = ((vu[H.A.ja] = 1), (vu[H.A.wa] = 2), vu);
  function xu(a) {
    if (a === void 0) return 0;
    switch (Q(a, H.A.Pc)) {
      case void 0:
        return 1;
      case !1:
        return 3;
      default:
        return 2;
    }
  }
  function yu() {
    return (
      (O(624) ? Kf(16).split("~") : Kf(17).split("~")).indexOf(Gk()) !== -1 &&
      (Qc == null ? void 0 : Qc.globalPrivacyControl) === !0
    );
  }
  function zu(a) {
    if (yu()) return !1;
    var b = xu(a);
    if (b === 3) return !1;
    switch (Um(H.A.Wa)) {
      case 1:
      case 3:
        return !0;
      case 2:
        return !1;
      case 4:
        return b === 2;
      case 0:
        return !0;
      default:
        return !1;
    }
  }
  function Au() {
    return Wm() || !Tm(H.A.ja) || !Tm(H.A.wa);
  }
  function Bu() {
    var a = {},
      b;
    for (b in wu) wu.hasOwnProperty(b) && (a[wu[b]] = Um(b));
    return "G1" + yf(a[1] || 0) + yf(a[2] || 0);
  }
  var Cu = {},
    Du =
      ((Cu[H.A.ja] = 0),
      (Cu[H.A.wa] = 1),
      (Cu[H.A.ma] = 2),
      (Cu[H.A.Wa] = 3),
      Cu);
  function Eu(a) {
    switch (a) {
      case void 0:
        return 1;
      case !0:
        return 3;
      case !1:
        return 2;
      default:
        return 0;
    }
  }
  function Fu(a) {
    for (var b = "1", c = 0; c < uu.length; c++) {
      var d = b,
        e,
        f = uu[c],
        g = Sm.delegatedConsentTypes[f];
      e = g === void 0 ? 0 : Du.hasOwnProperty(g) ? 12 | Du[g] : 8;
      var h = Lm();
      h.accessedAny = !0;
      var k = h.entries[f] || {};
      e = (e << 2) | Eu(k.implicit);
      b =
        d +
        ("" +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            e
          ] +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            (Eu(k.declare) << 4) | (Eu(k.default) << 2) | Eu(k.update)
          ]);
    }
    var m = b,
      p = (yu() ? 1 : 0) << 3,
      q = (Wm() ? 1 : 0) << 2,
      r = xu(a);
    b =
      m +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        p | q | r
      ];
    return (b +=
      "" +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (Sm.containerScopedDefaults.ad_storage << 4) |
          (Sm.containerScopedDefaults.analytics_storage << 2) |
          Sm.containerScopedDefaults.ad_user_data
      ] +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        ((Sm.usedContainerScopedDefaults ? 1 : 0) << 2) |
          Sm.containerScopedDefaults.ad_personalization
      ]);
  }
  function Gu() {
    return Tm(H.A.ma) ? "a" : "-";
  }
  function Hu() {
    return Ik() || ((nu() || ou()) && su() === "1") ? "1" : "0";
  }
  function Iu() {
    return (Ik() ? !0 : !(!nu() && !ou()) && su() === "1") || !Tm(H.A.ma);
  }
  function Ju() {
    var a = "0",
      b = "0",
      c;
    var d = ku();
    c = d.active ? d.cmpId : void 0;
    typeof c === "number" &&
      c >= 0 &&
      c <= 4095 &&
      ((a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (c >> 6) & 63
      ]),
      (b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        c & 63
      ]));
    var e = "0",
      f;
    var g = ku();
    f = g.active ? g.tcfPolicyVersion : void 0;
    typeof f === "number" &&
      f >= 0 &&
      f <= 63 &&
      (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        f
      ]);
    var h = 0;
    Ik() && (h |= 1);
    su() === "1" && (h |= 2);
    nu() && (h |= 4);
    var k;
    var m = ku();
    k =
      m.enableAdvertiserConsentMode !== void 0
        ? m.enableAdvertiserConsentMode
          ? "1"
          : "0"
        : void 0;
    k === "1" && (h |= 8);
    Lm().waitPeriodTimedOut && (h |= 16);
    return (
      "1" +
      a +
      b +
      e +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]
    );
  }
  var Ku = { UA: 1, AW: 2, DC: 3, G: 4, GF: 5, GT: 12, GTM: 14, HA: 6, MC: 7 };
  function Lu() {
    if (!Uc) return 0;
    var a = Jj(Uc),
      b = a.hostname.toLowerCase();
    if (/(^|\.)googletagmanager\.com$/.test(b)) return 1;
    var c = x.location,
      d = c.hostname.toLowerCase();
    if (c.protocol.toLowerCase() === a.protocol.toLowerCase() && d === b)
      return 4;
    if (d === b) return 3;
    var e = b.split("."),
      f = d.split("."),
      g = /\.(co|com|org|net|gov|edu|ac|ne|or|go)\.[a-z]{2}$/.test(b) ? 3 : 2;
    if (e.length >= g && f.length >= g) {
      var h = e.slice(-g).join("."),
        k = f.slice(-g).join(".");
      if (h === k) return 3;
    }
    return 2;
  }
  function Mu() {
    var a = E(69);
    if (a)
      switch (a) {
        case "1":
          return 3;
        case "2":
          return 4;
        case "@@SGTM_SIG@@":
          return 2;
        default:
          return 1;
      }
  }
  function Nu(a) {
    a = a === void 0 ? {} : a;
    var b = E(5).split("-")[0].toUpperCase(),
      c = O(604),
      d,
      e = c ? ((d = a.Vh) != null ? d : Lu()) : void 0,
      f,
      g = c ? ((f = a.Ao) != null ? f : Mu()) : void 0,
      h,
      k = {
        ctid: E(5),
        releaseExperiment: If(15),
        runtimeVersion: E(14),
        nt: Hf(7) ? 2 : 1,
        fu: a.ff,
        canonicalId: E(6),
        Rt: (h = um()) == null ? void 0 : h.canonicalContainerId,
        gu: a.hf === void 0 ? void 0 : a.hf ? 10 : 12,
        Vh: e,
        Ao: g,
      };
    k.canonicalId !== a.Ub && (k.Ub = a.Ub);
    var m = pm();
    k.Dt = m ? m.canonicalContainerId : void 0;
    Hf(45) ? ((k.di = Ku[b]), k.di || (k.di = 0)) : (k.di = uj ? 13 : 10);
    Hf(47) ? ((k.Pj = 0), (k.Pr = 2)) : Hf(50) ? (k.Pj = 1) : (k.Pj = 3);
    var p = ma(Object, "assign").call(Object, {}, a, { Vh: e }),
      q = { 6: !1 };
    If(54) === 2 ? (q[7] = !0) : If(54) === 1 && (q[2] = !0);
    var r,
      t = (r = p.Vh) != null ? r : Lu();
    t !== void 0 && t !== 0 && (q[8] = t !== 1);
    var u;
    q[9] = (u = p.Ye) != null ? u : !1;
    var v = Am(),
      w;
    q[10] =
      (w = v == null ? void 0 : v.fromContainerExecution) != null ? w : !1;
    k.Wr = q;
    return Cf(k, a.xn);
  }
  function Pu(a, b) {
    var c = Wi(b, { Ue: !1 });
    return Vk[a](void 0) + "?" + c;
  }
  var Qu = {
    W: {
      Ak: "call_conversion",
      Ek: "common_aw",
      xa: "conversion",
      oq: "floodlight",
      ad: "ga_conversion",
      Na: "page_view",
      Fb: "remarketing",
      Hb: "user_data_lead",
      sb: "user_data_web",
    },
  };
  function Ru() {
    return O(550) && hq(613);
  }
  function Su(a, b) {
    a ? a.then(b) : b(void 0);
  }
  function Tu(a) {
    return Promise.allSettled(a).then(function (b) {
      return b
        .filter(function (c) {
          return c.status === "fulfilled";
        })
        .map(function (c) {
          return c.value;
        });
    });
  }
  function Uu() {
    var a, b;
    return {
      promise: new Promise(function (c, d) {
        a = c;
        b = d;
      }),
      resolve: a,
      reject: b,
    };
  }
  function Vu(a, b, c, d, e, f) {
    var g = c.slice(),
      h;
    d == null || (h = d.Uv) == null || h.call(d, a, b, c, e);
    var k = Uu(),
      m = k.promise,
      p = k.resolve,
      q = [],
      r = function () {
        p(q);
        var u;
        d == null || (u = d.At) == null || u.call(d, a, b, c, e, q);
      },
      t = function () {
        var u = g.shift();
        u
          ? u.method.isSupported()
            ? Wu(a, b, u.endpoint, d, q, u.method, e, f, t, r)
            : t()
          : r();
      };
    t();
    return m;
  }
  function Wu(a, b, c, d, e, f, g, h, k, m) {
    var p = c.U(a),
      q = { service: b, endpoint: c, isPrimary: g, kc: void 0, fk: f, Ot: {} },
      r = !1,
      t = function (z, C) {
        if (r) S(187);
        else if (((r = !0), !u)) {
          var D = C || {},
            G = D.body,
            F = D.Ib,
            I = D.Te;
          C = Object.freeze(
            ma(Object, "assign").call(
              Object,
              {},
              G ? { body: G } : {},
              F ? { Ib: F } : {},
              I ? { Te: I } : {}
            )
          );
          if (G && !f.D()) w(), k();
          else {
            var L = Xu(z),
              P = p[0] === "/" ? "" + p + L : "https://" + p + L;
            q.kc = P;
            q.Ot = C;
            var R;
            d == null ||
              (R = d.Bt) == null ||
              R.call(d, a, ma(Object, "assign").call(Object, {}, q));
            var U = {
              destinationId: a.target.destinationId,
              endpoint: c.endpoint,
              eventId: a.K.eventId,
              priorityId: a.K.priorityId,
            };
            f.U === void 0 ||
              (c.fa !== 2 && (c.fa !== 1 || e.length)) ||
              jl.register(U, f.U, P);
            var X = function (ja, va) {
                w();
                if (q.status !== void 0) return S(192), !1;
                q.status = ja;
                e.push(q);
                var Ga;
                d == null ||
                  (Ga = d.io) == null ||
                  Ga.call(d, a, ma(Object, "assign").call(Object, {}, q), va);
                return !0;
              },
              ea = {
                uo: U,
                pd: function () {
                  X(2) && k();
                },
                onFailure: function () {
                  X(3) && k();
                },
                be: function (ja) {
                  X(ja.status === 0 ? 1 : ja.ok ? 0 : 3, ja) && m();
                },
                bf: function () {
                  X(1) && m();
                },
              };
            Yu(c, a, P, L, G);
            f.sendRequest(
              ea,
              P,
              ma(Object, "assign").call(
                Object,
                {},
                G && { body: G },
                F && { Ib: F },
                I && { Te: I }
              )
            );
          }
        }
      },
      u = !1,
      v,
      w = function () {
        v !== void 0 && (x.clearTimeout(v), (v = void 0));
      };
    O(574) &&
      (v = x.setTimeout(function () {
        v = void 0;
        u = !0;
        if (q.status === void 0) {
          q.status = 4;
          q.kc === void 0 && (q.kc = "[failed to build] " + p);
          e.push(q);
          var z;
          d == null ||
            (z = d.io) == null ||
            z.call(d, a, ma(Object, "assign").call(Object, {}, q), void 0);
          k();
        }
      }, 5e3));
    var y = { Dc: p, method: f, Yv: e, isPrimary: g, eu: h };
    try {
      c.D(a, y, t);
    } catch (z) {
      w(), S(188), k();
    }
  }
  function Yu(a, b, c, d, e) {
    if (a.Da) {
      var f = b.target.destinationId,
        g = a.endpoint;
      if (g === 45 || g === 46 || g === 69 || g === 58 || g === 57) {
        var h = /[?&]tids=([^&]+)/.exec(d);
        f = h ? decodeURIComponent(h[1]).split("~") : [f];
      }
      cp({
        targetId: f,
        request: ma(Object, "assign").call(
          Object,
          {},
          {
            url: c,
            parameterEncoding: a.parameterEncoding,
            endpoint: a.endpoint,
          },
          e ? { postBody: e } : {}
        ),
        zb: { eventId: b.K.eventId, priorityId: b.K.priorityId },
        An: { eventId: T(b, J.H.Tg), priorityId: T(b, J.H.Ug) },
      });
    }
  }
  function Xu(a) {
    return a && a !== "?" ? (a[0] !== "?" ? "?".concat(a) : a) : "";
  }
  function Zu(a, b, c, d, e) {
    var f;
    e == null || (f = e.Vv) == null || f.call(e, a, b);
    if (!c.length) {
      var g;
      e == null || (g = e.Ct) == null || g.call(e, a, b, []);
      return Promise.resolve([]);
    }
    var h = [],
      k = { service: b, dk: c, Yj: d };
    h.push(Vu(a, b, c, e, !0, k));
    var m = n(d),
      p = m.next(),
      q;
    try {
      for (; !p.done; p = m.next()) h.push(Vu(a, b, p.value, e, !1, k));
    } finally {
      p && !p.done && (q = m.return) && q.call(m);
    }
    return Tu(h).then(function (r) {
      var t = [],
        u = n(r),
        v = u.next(),
        w;
      try {
        for (; !v.done; v = u.next()) t.push.apply(t, xa(v.value));
      } finally {
        v && !v.done && (w = u.return) && w.call(u);
      }
      var y;
      e == null || (y = e.Ct) == null || y.call(e, a, b, t);
      return t;
    });
  }
  function $u(a, b) {
    var c = Oa.apply(2, arguments),
      d;
    b == null || (d = b.Wv) == null || d.call(b, a, c);
    var e = [],
      f = n(c),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) e.push(av(a, g.value));
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
    var k = [],
      m = n(e),
      p = m.next(),
      q;
    try {
      for (; !p.done; p = m.next()) {
        var r = p.value;
        k.push(Zu(a, r.service, r.dk, r.Yj, b));
      }
    } finally {
      p && !p.done && (q = m.return) && q.call(m);
    }
    Tu(k).then(function (t) {
      var u = [],
        v = n(t),
        w = v.next(),
        y;
      try {
        for (; !w.done; w = v.next()) u.push.apply(u, xa(w.value));
      } finally {
        w && !w.done && (y = v.return) && y.call(v);
      }
      var z;
      b == null || (z = b.zt) == null || z.call(b, a, c, u);
    });
  }
  function av(a, b) {
    var c = function (f) {
        return (
          f.method.isSupported() && f.endpoint.isSupported(a) && f.endpoint.J(a)
        );
      },
      d = (b.D(a) || []).filter(c),
      e = [];
    d.length &&
      (e = (b.J(a) || [])
        .map(function (f) {
          return f.filter(c);
        })
        .filter(function (f) {
          return f.length > 0;
        }));
    return { service: b, dk: d, Yj: e };
  }
  function gv(a, b) {
    b &&
      Lb(b, function (c, d) {
        typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d));
      });
  }
  var rv = { Mg: "value", tb: "conversionCount", Ng: 1 },
    sv = { Mg: "timeouts", tb: "timeouts", Ng: 0 },
    tv = { Mg: "eopCount", tb: "endOfPageCount", Ng: 0 },
    uv = { Mg: "errors", tb: "errors", Ng: 0 },
    vv = [rv, sv, uv, tv];
  function wv(a, b) {
    b = b === void 0 ? 1 : b;
    if (!xv(a)) return {};
    var c = yv(vv),
      d = c[a.tb];
    if (d === void 0 || d === -1) return c;
    var e = {},
      f = ma(Object, "assign").call(Object, {}, c, ((e[a.tb] = d + b), e));
    return zv(f) ? f : c;
  }
  function yv(a) {
    var b;
    a: {
      var c = Wr("gcl_ctr");
      if (c.error === 0 && c.value && typeof c.value === "object") {
        var d = c.value;
        try {
          b = "value" in d && typeof d.value === "object" ? d.value : void 0;
          break a;
        } catch (q) {}
      }
      b = void 0;
    }
    var e = b,
      f = {},
      g = n(a),
      h = g.next(),
      k;
    try {
      for (; !h.done; h = g.next()) {
        var m = h.value;
        if (e && xv(m)) {
          var p = e[m.Mg];
          p === void 0 || Number.isNaN(p)
            ? (f[m.tb] = -1)
            : (f[m.tb] = Number(p));
        } else f[m.tb] = -1;
      }
    } finally {
      h && !h.done && (k = g.return) && k.call(g);
    }
    return f;
  }
  function zv(a, b) {
    b = b || {};
    var c = Sb(),
      d = cr(b, c, !0),
      e = {},
      f = n(vv),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) {
        var k = g.value,
          m = a[k.tb];
        m !== void 0 && m !== -1 && (e[k.Mg] = m);
      }
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
    e.creationTimeMs = c;
    return Tr("gcl_ctr", { value: e, expires: Number(d.expires) }) === 0
      ? !0
      : !1;
  }
  function xv(a) {
    return Tm(["ad_storage", "ad_user_data"]) ? !a.Nt || Oh(a.Nt) : !1;
  }
  function Av(a) {
    return Tm(["ad_storage", "ad_user_data"]) ? !a.Xs || Oh(a.Xs) : !1;
  }
  function Bv() {
    if (Cv()) {
      var a = Wr("last_convs");
      if (a.error === 0 && a.value && typeof a.value === "object") {
        var b = a.value;
        if (b.value && Array.isArray(b.value)) {
          var c = b.value;
          if (!(c.length > 1)) {
            var d = [],
              e = n(c),
              f = e.next(),
              g;
            try {
              for (; !f.done; f = e.next()) {
                var h = f.value;
                if (
                  typeof h !== "object" ||
                  h === null ||
                  typeof h.random !== "number" ||
                  typeof h.label !== "string" ||
                  h.label.length > 200
                )
                  return;
                d.push({ random: h.random, label: h.label });
              }
            } finally {
              f && !f.done && (g = e.return) && g.call(e);
            }
            return d;
          }
        }
      }
    }
  }
  function Dv(a, b) {
    if (
      !(!Cv() || a.length > 1 || (a.length === 1 && a[0].label.length > 200))
    ) {
      b = b || {};
      var c = cr(b);
      Tr("last_convs", { value: a, expires: Number(c.expires) });
    }
  }
  function Cv() {
    return Tm(["ad_storage", "ad_user_data"]) && Oh(7);
  }
  function Ev(a) {
    var b = Math.round(Math.random() * 2147483647);
    return a ? String(b ^ (eg(a) & 2147483647)) : String(b);
  }
  function Fv(a) {
    return [Ev(a), Math.round(Sb() / 1e3)].join(".");
  }
  function Gv(a, b, c, d, e) {
    var f = $q(b),
      g;
    return (g = Pq(a, f, ar(c), d, e)) == null ? void 0 : g.Yr;
  }
  var Hv = ["1"],
    Iv = {},
    Jv = {};
  function Kv(a) {
    return Jv[Lv(a)];
  }
  function Mv(a, b) {
    b = b === void 0 ? !0 : b;
    var c = Lv(a.prefix);
    if (Iv[c]) Nv(a), Ov(a);
    else if (Pv(c, a.path, a.domain)) {
      var d = Kv(a.prefix) || { id: void 0, jc: void 0 };
      b && Qv(a, d);
      Nv(a);
      Ov(a);
    } else {
      var e = Lj("auiddc");
      if (e) sb("TAGGING", 17), (Iv[c] = e);
      else if (b) {
        var f = Lv(a.prefix),
          g = Fv();
        Rv(f, g, a);
        Pv(c, a.path, a.domain);
        Nv(a, !0);
        Ov(a, !0);
      }
    }
  }
  function Nv(a, b) {
    (b === void 0 ? 0 : b) && xv(rv) && Xr("gcl_ctr");
    if (Av(rv) && yv([rv])[rv.tb] === -1) {
      var c = {},
        d = ((c[rv.tb] = 0), c),
        e = n(vv),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value;
          h !== rv && Av(h) && (d[h.tb] = 0);
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
      zv(d, a);
    }
  }
  function Ov(a, b) {
    (b === void 0 ? 0 : b) && Cv() && Xr("last_convs");
    !Tm(["ad_storage", "ad_user_data"]) || !Oh(8) || Bv() || Dv([], a);
  }
  function Qv(a, b) {
    var c = Lv(a.prefix),
      d = Iv[c];
    if (d) {
      var e = d.split(".");
      if (e.length === 2) {
        var f = Number(e[1]) || 0;
        if (f) {
          var g = d;
          if (Oh(13) && b.Yh) {
            var h = b.jc ? b.jc : Math.floor(Sb() / 1e3),
              k = b.Hc ? b.Hc : Math.floor(Sb() / 1e3);
            g =
              d + "." + (b.sessionId || "-.-") + "." + h + "." + b.Yh + "." + k;
          } else if (b.sessionId) {
            var m = b.jc ? b.jc : Math.floor(Sb() / 1e3);
            g = d + "." + b.sessionId + "." + m;
          }
          Rv(c, g, a, f * 1e3);
        }
      }
    }
  }
  function Rv(a, b, c, d) {
    var e;
    e = ["1", br(c.domain, c.path), b].join(".");
    var f = cr(c, d);
    f.Ic = Sv();
    Xq(a, e, f);
  }
  function Pv(a, b, c) {
    var d = Gv(a, b, c, Hv, Sv());
    if (!d) return !1;
    Tv(a, d);
    return !0;
  }
  function Tv(a, b) {
    var c = b.split(".");
    if (c.length === 3)
      Jv[a] = { sessionId: c[0] + "." + c[1], jc: Number(c[2]) || 0, Hc: 0 };
    else if (
      c.length >= 2 &&
      ((Iv[a] = c[0] + "." + c[1]), c.shift(), c.shift(), c.length >= 3)
    ) {
      var d = {
        sessionId: c[0] === "-" ? void 0 : c[0] + "." + c[1],
        jc: Number(c[2]) || 0,
        Hc: 0,
      };
      if (Oh(13) && c.length >= 6) {
        var e = c[3] + "." + c[4],
          f = Number(c[5]) || 0;
        e && f !== 0 && ((d.Yh = e), (d.Hc = f));
      }
      Jv[a] = d;
    }
  }
  function Lv(a) {
    return (a || "_gcl") + "_au";
  }
  function Uv(a) {
    function b() {
      Tm(c) && a();
    }
    var c = Sv();
    Zm(function () {
      b();
      Tm(c) || $m(b, c);
    }, c);
  }
  function Vv(a) {
    var b = Cr(!0),
      c = Lv(a.prefix);
    Uv(function () {
      var d = b[c];
      if (d) {
        Tv(c, d);
        var e = Number(Iv[c].split(".")[1]) * 1e3;
        if (e) {
          sb("TAGGING", 16);
          var f = cr(a, e);
          f.Ic = Sv();
          var g = ["1", br(a.domain, a.path), d].join(".");
          Xq(c, g, f);
        }
      }
    });
  }
  function Wv(a, b, c, d, e) {
    e = e || {};
    var f = function () {
      var g = {},
        h = Gv(a, e.path, e.domain, Hv, Sv());
      h && (g[a] = h);
      return g;
    };
    Uv(function () {
      Jr(f, b, c, d);
    });
  }
  function Sv() {
    return ["ad_storage", "ad_user_data"];
  }
  var $v = void 0;
  function aw() {
    if (!$v) {
      var a = vk(qk.da.ap, new Map());
      $v = new fg(a);
    }
    return $v;
  }
  var bw =
      "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(
        " "
      ),
    cw =
      "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(
        " "
      );
  function dw(a, b) {
    if (!b._tag_metadata) {
      for (var c = {}, d = 0, e = 0; e < a.length; e++)
        d += ew(a[e], b, c) ? 1 : 0;
      d > 0 && (b._tag_metadata = c);
    }
  }
  function ew(a, b, c) {
    var d = b[a];
    if (d === void 0 || d === null) return !1;
    Array.isArray(d)
      ? (c[a] = d.map(function () {
          return { mode: "c" };
        }))
      : (c[a] = { mode: "c" });
    return !0;
  }
  function fw(a) {
    if (a) {
      dw(bw, a);
      for (var b = Gb(a.address), c = 0; c < b.length; c++) {
        var d = b[c];
        d && dw(cw, d);
      }
      var e = a.home_address;
      e && dw(cw, e);
    }
  }
  function gw(a, b, c) {
    function d(k, m) {
      for (var p = String(m).substring(0, 100); p.length > 0; )
        try {
          e.push("" + k + encodeURIComponent(p));
          return;
        } catch (q) {
          if (q instanceof URIError && p.length > 0) p = p.slice(0, -1);
          else throw q;
        }
      e.push("" + k);
    }
    if (!c) return "";
    var e = [];
    d("i", String(a));
    d("f", b);
    c.mode && d("m", c.mode);
    c.isPreHashed && d("p", "1");
    c.rawLength && d("r", String(c.rawLength));
    c.normalizedLength && d("n", String(c.normalizedLength));
    c.location && d("l", c.location);
    if (c.selector) {
      var f = c.selector.substring(0, 100),
        g = !1;
      if (O(622))
        try {
          var h = mc(c.selector.substring(0, 71));
          h && (e.push("s!b64!" + h), (g = !0));
        } catch (k) {}
      g || d("s", f);
    }
    c.testReason &&
      c.testReason.length &&
      d(
        "t",
        c.testReason
          .slice()
          .sort(function (k, m) {
            return k - m;
          })
          .join("!")
      );
    return e.join(".");
  }
  var hw = /^[0-9A-Za-z_-]{43}$/;
  function iw(a) {
    return hw.test(a) || zi.test(a);
  }
  var ax = Object.freeze({
    cache: "no-store",
    credentials: "include",
    method: "GET",
    keepalive: !0,
    redirect: "follow",
  });
  function bx(a, b, c, d, e, f) {
    if (!Db(x.fetch)) return f == null || f(void 0, void 0), !1;
    var g = ma(Object, "assign").call(Object, {}, ax);
    b && ((g.body = b), (g.method = "POST"));
    ma(Object, "assign").call(Object, g, d);
    x.fetch(a, g)
      .then(function (h) {
        if (h.ok) {
          if (h.body) {
            var k = h.body.getReader(),
              m = new TextDecoder();
            return new Promise(function (p) {
              function q() {
                k.read()
                  .then(function (r) {
                    var t;
                    t = r.done;
                    var u = m.decode(r.value, { stream: !t });
                    u = c.U + u;
                    for (var v = u.indexOf("\n\n"); v !== -1; ) {
                      var w = Rg,
                        y;
                      a: {
                        var z = n(u.substring(0, v).split("\n")),
                          C = z.next().value,
                          D = z.next().value;
                        if (Zb(C, "event: message") && Zb(D, "data: ")) {
                          var G = D.substring(6);
                          try {
                            y = JSON.parse(G);
                            break a;
                          } catch (F) {}
                        }
                        y = void 0;
                      }
                      w(c, y);
                      u = u.substring(v + 2);
                      v = u.indexOf("\n\n");
                    }
                    c.U = u;
                    t ? (e == null || e(h), p()) : q();
                  })
                  .catch(function () {
                    e == null || e(h);
                    p();
                  });
              }
              q();
            });
          }
          e == null || e(h);
        } else f == null || f(h, void 0);
      })
      .catch(function (h) {
        f == null || f(void 0, h);
      });
    return !0;
  }
  var cx = function (a) {
    zp.call(this, "FetchRichResponse", 1);
    this.M = a;
  };
  ta(cx, zp);
  cx.prototype.isSupported = function () {
    return Db(x.fetch);
  };
  cx.prototype.D = function () {
    return !0;
  };
  cx.prototype.J = function (a, b, c) {
    bx(
      b,
      c == null ? void 0 : c.body,
      this.M,
      c == null ? void 0 : c.Ib,
      a.be,
      function (d, e) {
        a.onFailure(e);
      }
    );
  };
  var ux = Object.freeze({ attributionsrc: "" }),
    vx = Object.freeze({ eventSourceEligible: !1, triggerEligible: !0 });
  function wx() {
    var a = XMLHttpRequest.prototype;
    return a && Db(a.setAttributionReporting);
  }
  var Jx = function () {
    Qg.apply(this, arguments);
  };
  ta(Jx, Qg);
  Jx.prototype.J = function (a, b) {
    hd(a, void 0, Sg(this, b), b.attribution_reporting && wx() ? ux : {});
  };
  Jx.prototype.D = function (a, b) {
    var c = b.attribution_reporting && wx() ? { attributionReporting: vx } : {},
      d = Sg(this, b);
    b.process_response
      ? bx(a, void 0, this, c, void 0, d)
      : vd(a, void 0, c, void 0, d);
  };
  var Ux = function (a, b) {
      this.D = a;
      this.timeoutMs = b;
      this.Vb = void 0;
    },
    Vx = function (a) {
      a.Vb ||
        (a.Vb = setTimeout(function () {
          a.D();
          a.Vb = void 0;
        }, a.timeoutMs));
    },
    Wx = function (a) {
      a.Vb && (clearTimeout(a.Vb), (a.Vb = void 0));
    };
  var Xx = function () {
      var a = Mf(66, 0);
      this.J = [];
      this.U = a;
      this.D = Xa();
    },
    Zx = function (a) {
      var b = Yx;
      b.J.push(a);
      b.M ||
        ((b.M = function () {
          var c = n(b.J),
            d = c.next(),
            e;
          try {
            for (; !d.done; d = c.next()) {
              var f = d.value;
              try {
                f();
              } catch (p) {}
            }
          } finally {
            d && !d.done && (e = c.return) && e.call(c);
          }
          var g = n(b.D.values()),
            h = g.next(),
            k;
          try {
            for (; !h.done; h = g.next()) {
              var m = void 0;
              (m = h.value.kk) == null || Wx(m);
            }
          } finally {
            h && !h.done && (k = g.return) && k.call(g);
          }
          b.D.clear();
        }),
        id(x, "pagehide", b.M));
    },
    $x = function (a) {
      var b = a.match(Ll)[3] || null,
        c = (b ? decodeURI(b) : b) || "",
        d = Ol(a, "label") || "",
        e = Ol(a, "random") || "";
      return c + ":" + Kl(d) + ":" + Kl(e);
    };
  Xx.prototype.addRequest = function (a, b, c) {
    var d = $x(a);
    if (!(this.D.has(d) || this.D.size >= this.U)) {
      var e = {};
      b && b > 0 && c && (e.kk = new Ux(c, b));
      this.D.set(d, e);
      var f;
      (f = e.kk) == null || Vx(f);
    }
  };
  var Sl = function (a, b) {
    var c = $x(b),
      d,
      e;
    (d = a.D.get(c)) == null || (e = d.kk) == null || Wx(e);
    a.D.delete(c);
  };
  Xx.prototype.getSize = function () {
    return this.D.size;
  };
  var ly = function () {
      var a = 5;
      ky.Eo > 0 && (a = ky.Eo);
      this.D = a;
      this.count = 0;
      this.J = [];
    },
    my = function (a) {
      if (a.count < a.D) return !1;
      var b = a.count % a.D;
      return Sb() - a.J[b] < 1e3;
    },
    ny = function (a) {
      var b = a.count++ % a.D;
      a.J[b] = Sb();
    };
  var ky = { Eo: Mf(3, 0) },
    ry = function () {
      var a = this;
      this.La = [];
      this.la = [];
      this.D = void 0;
      this.aa = {};
      this.J = void 0;
      this.Da = new ly();
      this.Rb = 1e3;
      this.U = this.M = !1;
      this.fa = Ib();
      oy(this, function () {
        return py(a);
      });
      qy(this, function () {
        return py(a);
      });
      ld(function () {
        a.fa = Ib();
      }, 864e5);
    },
    oy = function (a, b) {
      a.La.push(b);
    },
    qy = function (a, b) {
      a.la.push(b);
    },
    sy = function (a, b, c) {
      var d = a.D;
      if (d === void 0)
        if (c) d = ro();
        else return "";
      var e = { id: E(5) },
        f = n(a.La),
        g = f.next(),
        h;
      try {
        for (; !g.done; g = f.next()) {
          var k = g.value,
            m = k({ eventId: d, je: !!b }),
            p = n(m),
            q = p.next(),
            r;
          try {
            for (; !q.done; q = p.next()) {
              var t = n(q.value),
                u = t.next().value,
                v = t.next().value;
              e[u] = v;
            }
          } finally {
            q && !q.done && (r = p.return) && r.call(p);
          }
        }
      } finally {
        g && !g.done && (h = f.return) && h.call(f);
      }
      e.z = 0;
      return Vk[56](void 0) + "?" + Wi(e, { Se: !0, Ue: !1 });
    },
    ty = function (a) {
      if (
        $i(14) &&
        (a.J && (x.clearTimeout(a.J), (a.J = void 0)), a.D !== void 0 && a.U)
      ) {
        var b = hn(Km.ia.Qb);
        if (cn(b))
          a.M ||
            ((a.M = !0),
            en(b, function () {
              return void ty(a);
            }));
        else if (a.aa[a.D] || my(a.Da) || a.Rb-- <= 0) S(1), (a.aa[a.D] = !0);
        else {
          ny(a.Da);
          var c = sy(a, !0);
          Wl({ destinationId: E(5), endpoint: 56, eventId: a.D }, c);
          a.U = !1;
          a.M = !1;
        }
      }
    },
    uy = function (a) {
      a.J ||
        (a.J = x.setTimeout(function () {
          return void ty(a);
        }, 500));
    },
    wy = function (a) {
      var b = vy;
      b.aa[a] ||
        (a !== b.D && (ty(b), (b.D = a)),
        (b.U = !0),
        uy(b),
        sy(b).length >= 2022 && ty(b));
    },
    py = function (a) {
      var b = [
          ["v", "3"],
          ["t", "t"],
          ["pid", String(a.fa)],
        ],
        c = Nu();
      c && b.push(["gtm", c]);
      return b;
    },
    vy;
  function xy(a) {
    yy();
    oy(vy, a);
  }
  function zy() {
    var a = Ay;
    yy();
    qy(vy, a);
  }
  function By() {
    var a;
    a = a === void 0 ? !1 : a;
    yy();
    var b = a,
      c = vy;
    b = b === void 0 ? !1 : b;
    if (fl.M && $i(14)) {
      var d = sy(c, !0, !0);
      b
        ? Ul({ destinationId: E(5), endpoint: 56, eventId: c.D }, d)
        : Wl({ destinationId: E(5), endpoint: 56, eventId: c.D }, d);
    }
  }
  function yy() {
    vy || (vy = new ry());
  }
  var Cy = {
      read_event_data: "e",
      read_container_data: "c",
      configure_google_tags: "t",
    },
    Dy = Object.keys(Cy),
    Ey = function () {
      this.D = !1;
    };
  Ey.prototype.ai = function (a, b) {
    if (!this.D && O(610)) {
      var c = Cy[a];
      if (c) {
        this.D = !0;
        var d = [
          ["pf", c],
          ["pfs", b],
        ];
        d = d === void 0 ? [] : d;
        yy();
        var e = d,
          f = vy;
        e = e === void 0 ? [] : e;
        if (O(610)) {
          var g,
            h = e;
          h = h === void 0 ? [] : h;
          var k = { id: E(5) },
            m = n(f.la),
            p = m.next(),
            q;
          try {
            for (; !p.done; p = m.next()) {
              var r = p.value,
                t = void 0,
                u = n(r({ eventId: (t = f.D) != null ? t : 0, je: !0 })),
                v = u.next(),
                w;
              try {
                for (; !v.done; v = u.next()) {
                  var y = n(v.value),
                    z = y.next().value,
                    C = y.next().value;
                  k[z] = C;
                }
              } finally {
                v && !v.done && (w = u.return) && w.call(u);
              }
            }
          } finally {
            p && !p.done && (q = m.return) && q.call(m);
          }
          var D = n(h),
            G = D.next(),
            F;
          try {
            for (; !G.done; G = D.next()) {
              var I = n(G.value),
                L = I.next().value,
                P = I.next().value;
              k[L] = P;
            }
          } finally {
            G && !G.done && (F = D.return) && F.call(D);
          }
          k.z = 0;
          g = Vk[56](void 0) + "?" + Wi(k, { Se: !0, Ue: !1 });
          Wl({ destinationId: E(5), endpoint: 56, eventId: f.D }, g);
        }
      }
    }
  };
  var Fy;
  var cg;
  function Gy(a) {
    if (O(610)) {
      var b = dg(a);
      return function (c) {
        var d = Oa.apply(1, arguments);
        try {
          b.apply(null, [c].concat(xa(d)));
        } catch (e) {
          throw (Fy || (Fy = new Ey()), Fy.ai(c, "p"), e);
        }
      };
    }
    return dg(a);
  }
  function Hy(a, b) {
    var c;
    (c = cg) == null || Wf(c.D, a, b);
  }
  var Iy = za(["/"]),
    Jy = function (a) {
      this.D = a;
      this.failureType = void 0;
    };
  Jy.prototype.Rn = function (a, b, c) {
    try {
      var d = this.D.active;
      d
        ? (d.postMessage({ type: 1, command: a }), b({ data: "" }))
        : c({ failureType: 13, data: "" });
    } catch (e) {
      c({ failureType: 11, data: e.message });
    }
  };
  var Ky = function (a, b) {
    this.failureType = a;
    this.D = b;
  };
  Ky.prototype.Rn = function (a, b, c) {
    c({
      failureType: this.failureType,
      data: "f" + this.failureType + ("t" + (new Date().getTime() - this.D)),
    });
  };
  var Ny = function (a) {
      var b = this;
      this.initTime = new Date().getTime();
      this.D = new Ky(15, this.initTime);
      var c = new Promise(function (e) {
          x.setTimeout(function () {
            e();
          }, 20);
        }),
        d = Ly(a)
          .then(function (e) {
            b.D = new Jy(e);
            My(b, e);
          })
          .catch(function () {
            b.D = new Ky(4, b.initTime);
          });
      this.J = Promise.race([c, d]);
    },
    My = function (a, b) {
      var c = function (d) {
        d &&
          d.addEventListener("statechange", function () {
            if (d.state === "redundant") {
              var e = b.active;
              (e && e.state !== "redundant") || (a.D = new Ky(10, a.initTime));
            }
          });
      };
      c(b.active);
      c(b.waiting);
      c(b.installing);
      b.addEventListener("updatefound", function () {
        c(b.installing);
      });
    };
  Ny.prototype.delegate = function (a, b, c) {
    var d = this;
    this.J.then(function () {
      d.D.Rn(a, b, c);
    });
  };
  Ny.prototype.getState = function () {
    return 2;
  };
  var Ly = function (a) {
    var b,
      c = Kf(11);
    c = Kf(10);
    b = c;
    var d = {
      scope:
        ($b(a.href, "/") ? a.href.slice(0, -1) : a.href) + "/_/service_worker",
    };
    b && (d.updateViaCache = "all");
    var e,
      f = Oy(a, b),
      g = new Map([["path", a.pathname]]),
      h = rq(tc(f).toString());
    e = tq(h.lk, h.params, h.fragment, g);
    var k = Rc(),
      m = tc(e);
    try {
      return k.register(m, d);
    } catch (p) {
      try {
        return k.register(m.toString(), d);
      } catch (q) {
        return Promise.reject(q);
      }
    }
  };
  function Oy(a, b) {
    var c = sq(Iy),
      d = a.pathname.split("/").filter(function (k) {
        return k.length > 0;
      }),
      e = [].concat(xa(d), ["_", "service_worker", b, "sw.js"]),
      f = n(e),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) c = uq(c, g.value);
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
    return c;
  }
  function Py(a) {
    var b = uk(qk.da.Ih),
      c = b == null ? void 0 : b[a];
    c || a !== "lite" || (c = b == null ? void 0 : b.full);
    return c;
  }
  var Qy = function (a, b, c) {
    var d = Py("full");
    d ? d.delegate(a, b, c) : c({ failureType: 16 });
  };
  function Ry(a, b, c, d, e, f) {
    Qy(
      {
        commandType: 0,
        params: {
          url: a,
          method: 1,
          templates: b,
          body: "",
          processResponse: !1,
          encryptionKeyString: e,
          soReferrer: x.location.href,
          collectEncryptionMetrics: f,
        },
      },
      c,
      function (g) {
        d(g.failureType, g.data);
      }
    );
  }
  var cz = {
    Z: {
      Nq: 0,
      qk: 1,
      Wg: 2,
      Mk: 3,
      hi: 4,
      Kk: 5,
      Lk: 6,
      Nk: 7,
      ii: 8,
      Zl: 9,
      Yl: 10,
      Ni: 11,
      am: 12,
      zh: 13,
      km: 14,
      aj: 15,
      Jq: 16,
      gd: 17,
      mj: 18,
      nj: 19,
      oj: 20,
      mn: 21,
      pj: 22,
    },
  };
  cz.Z[cz.Z.Nq] = "RESERVED_ZERO";
  cz.Z[cz.Z.qk] = "ADS_CONVERSION_HIT";
  cz.Z[cz.Z.Wg] = "CONTAINER_EXECUTE_START";
  cz.Z[cz.Z.Mk] = "CONTAINER_SETUP_END";
  cz.Z[cz.Z.hi] = "CONTAINER_SETUP_START";
  cz.Z[cz.Z.Kk] = "CONTAINER_BLOCKING_END";
  cz.Z[cz.Z.Lk] = "CONTAINER_EXECUTE_END";
  cz.Z[cz.Z.Nk] = "CONTAINER_YIELD_END";
  cz.Z[cz.Z.ii] = "CONTAINER_YIELD_START";
  cz.Z[cz.Z.Zl] = "EVENT_EXECUTE_END";
  cz.Z[cz.Z.Yl] = "EVENT_EVALUATION_END";
  cz.Z[cz.Z.Ni] = "EVENT_EVALUATION_START";
  cz.Z[cz.Z.am] = "EVENT_SETUP_END";
  cz.Z[cz.Z.zh] = "EVENT_SETUP_START";
  cz.Z[cz.Z.km] = "GA4_CONVERSION_HIT";
  cz.Z[cz.Z.aj] = "PAGE_LOAD";
  cz.Z[cz.Z.Jq] = "PAGEVIEW";
  cz.Z[cz.Z.gd] = "SNIPPET_LOAD";
  cz.Z[cz.Z.mj] = "TAG_CALLBACK_ERROR";
  cz.Z[cz.Z.nj] = "TAG_CALLBACK_FAILURE";
  cz.Z[cz.Z.oj] = "TAG_CALLBACK_SUCCESS";
  cz.Z[cz.Z.mn] = "TAG_EXECUTE_END";
  cz.Z[cz.Z.pj] = "TAG_EXECUTE_START";
  var dz = {};
  dz.Z = cz.Z;
  var ez = {
      Av: "L",
      Qq: "S",
      Lv: "Y",
      wu: "B",
      Ru: "E",
      wv: "I",
      Hv: "TC",
      Zu: "HTC",
      Su: "F",
      vv: "C",
    },
    fz = { Qq: "S", Pu: "V", Du: "E", Gv: "tag" },
    gz = {},
    hz = ((gz[dz.Z.nj] = "6"), (gz[dz.Z.oj] = "5"), (gz[dz.Z.mj] = "7"), gz);
  function iz(a) {
    var b = E(5),
      c = Number(a.eventId),
      d = Number(a.tagId);
    return (
      (Zb(b, "GTM-") ? b : "GTM-" + b) +
      ":" +
      (Fb(c) ? c + ":" : "") +
      (Fb(d) ? d + ":" : "") +
      a.stage
    );
  }
  function jz() {
    var a = Ad();
    return !!(
      a &&
      a.mark instanceof Function &&
      a.measure instanceof Function &&
      a.clearMeasures instanceof Function &&
      a.clearMarks instanceof Function
    );
  }
  var kz = function () {
    this.D = {};
  };
  kz.prototype.mark = function (a, b) {
    if (jz()) {
      var c = iz(a),
        d,
        e;
      if ((d = (e = Ad()) == null ? void 0 : e.mark(c, b)))
        return (this.D[c] = d);
    }
  };
  var lz;
  function mz() {
    lz || (lz = new kz());
    return lz;
  }
  function nz(a) {
    var b = mz(),
      c = iz(a);
    return b.D[c];
  }
  function oz(a, b) {
    return mz().mark(a, b);
  }
  function pz(a, b) {
    if (jz()) {
      a.entry = iz(a);
      var c = ma(Object, "assign").call(Object, {}, a);
      c.stage = b;
      delete c.sent;
      var d = nz(b === dz.Z.gd ? { stage: dz.Z.gd } : c),
        e = nz(a);
      if (d && e && !(d.startTime > e.startTime)) {
        c.stage = b + ":" + a.stage;
        var f = iz(c),
          g = { start: d.name, end: e.name },
          h,
          k;
        return (k = (h = Ad()) == null ? void 0 : h.measure(f, g)) == null
          ? void 0
          : k.duration;
      }
    }
  }
  function qz() {
    function a(c, d) {
      var e = ub(rb[d] || []);
      e && b.push([c, e]);
    }
    var b = [];
    a("u", "GTM");
    a("ut", "TAGGING");
    a("h", "HEALTH");
    return b;
  }
  var rz = "https://" + E(21),
    sz = function () {
      this.M = !1;
      this.U = [];
      this.aa = [];
      this.D = { TC: 0, HTC: 0 };
      this.J = {};
    },
    tz = function (a, b, c, d) {
      a.J[b] || (a.J[b] = {});
      a.J[b][c] = d;
    },
    wz = function (a) {
      var b = "",
        c = "",
        d = uz();
      Fb(d) && (a.D.I = Math.floor(d));
      c = vz(a.D, ez).toString();
      var e = n(Object.keys(a.J)),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value,
            k = a.J[h].name,
            m = "",
            p = vz(a.J[h], fz);
          p && ((m = k + "." + p.toString()), (b += "~" + m));
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
      var q = "~AWCT" + a.U.join("."),
        r = "~GA" + a.aa.join("."),
        t =
          "&ccid=" +
          nm().toString() +
          "&cid=" +
          E(5).toString() +
          "&l=" +
          c +
          b +
          (a.U.length ? q : "") +
          (a.aa.length ? r : "");
      if (O(214)) {
        var u,
          v =
            (u = Ad()) == null
              ? void 0
              : u
                  .getEntriesByName(Uc)
                  .map(function (w) {
                    return String(w.duration);
                  })
                  .join(".");
        v && (t += "~SS" + v);
      }
      return t;
    },
    xz = function (a, b) {
      if (!b.stage || a.M || !jz() || nz(b)) return !1;
      var c,
        d = (c = Ad()) == null ? void 0 : c.timeOrigin;
      if (!Fb(d)) a.M = !0;
      else if (Fb($i(11)) && !nz({ stage: dz.Z.gd }) && !a.M && jz())
        try {
          var e = Number($i(11));
          oz({ stage: dz.Z.gd }, { startTime: Math.max(e - d, 0) });
          oz({ stage: dz.Z.aj }, { startTime: 0 });
          var f = pz({ stage: dz.Z.gd }, dz.Z.aj);
          f && (a.D.L = Math.floor(f));
        } catch (g) {
          a.M = !0;
        }
      if (a.M) return !1;
      try {
        if (!oz(b)) return !1;
      } catch (g) {
        return (a.M = !0), !1;
      }
      return !0;
    },
    yz = function (a, b, c) {
      if (xz(a, b))
        try {
          var d = pz(b, c);
          if (d) return Math.floor(d);
        } catch (e) {
          a.M = !0;
        }
    },
    Az = function () {
      var a = zz();
      xz(a, { stage: dz.Z.hi });
    },
    Bz = function () {
      var a = zz(),
        b = yz(a, { stage: dz.Z.Mk }, dz.Z.hi);
      b !== void 0 && (a.D.S = b);
    },
    Cz = function () {
      var a = zz();
      xz(a, { stage: dz.Z.ii });
    },
    Dz = function (a, b) {
      var c = zz();
      xz(c, { stage: dz.Z.zh, eventId: a });
      (c.J[a] && c.J[a].name) || tz(c, a, "name", Zb(b, "gtm.") ? b : "*");
    },
    Ez = function (a) {
      var b = zz(),
        c = yz(b, { stage: dz.Z.am, eventId: a }, dz.Z.zh);
      c !== void 0 && tz(b, a, "S", c);
    },
    Gz = function (a, b) {
      var c = zz(),
        d = yz(c, { stage: dz.Z.Zl, eventId: a }, dz.Z.zh);
      d !== void 0 && tz(c, a, "E", d);
      if (b === "gtm.load") {
        var e = yz(c, { stage: dz.Z.Lk }, dz.Z.Wg);
        e !== void 0 && (c.D.E = e);
        en(hn(Km.ia.Qb), function () {
          if (!c.M && jz() && E(5)) {
            var f = Fz();
            f !== void 0 && (c.D.F = Math.floor(f));
            try {
              var g = qz({ eventId: 0, je: !1 }),
                h = [],
                k = n(g),
                m = k.next(),
                p;
              try {
                for (; !m.done; m = k.next()) {
                  var q = n(m.value),
                    r = q.next().value,
                    t = q.next().value;
                  h.push("&" + r + "=" + t);
                }
              } finally {
                m && !m.done && (p = k.return) && p.call(k);
              }
              var u = iq(),
                v = [
                  [
                    Xj(rz),
                    "/a?v=3&t=l",
                    "&pid=" + Ib().toString(),
                    "&rv=" + E(14),
                    u ? "&tag_exp=" + u : "",
                    h.join(""),
                  ].join(""),
                  "&gtm=",
                  Nu(),
                  wz(c),
                ].join("");
              if (v.length > 2022) {
                var w = Math.max(
                  v.lastIndexOf(".TS", 2022),
                  v.lastIndexOf("~", 2022)
                );
                v = v.slice(0, w);
              }
              Wl({ destinationId: E(5), endpoint: 56 }, v);
            } catch (y) {}
          }
        });
      }
    },
    Hz;
  function zz() {
    Hz || (Hz = new sz());
    return Hz;
  }
  function uz() {
    try {
      var a;
      return ((a = Ad()) == null ? void 0 : a.getEntriesByType("navigation")[0])
        .domInteractive;
    } catch (b) {}
  }
  function vz(a, b) {
    return Object.keys(b)
      .map(function (c) {
        return b[c];
      })
      .filter(function (c) {
        return a[c] !== void 0;
      })
      .map(function (c) {
        return ("" + (c === "tag" ? "" : c)).concat(a[c].toString());
      })
      .join(".");
  }
  function Iz(a) {
    var b = zz(),
      c = yz(b, { stage: dz.Z.km, eventId: a }, dz.Z.gd);
    c !== void 0 && b.aa.push(c);
  }
  function Jz(a) {
    var b = zz(),
      c = yz(b, { stage: dz.Z.qk, eventId: a }, dz.Z.gd);
    c !== void 0 && b.U.push(c);
  }
  function Kz(a) {
    var b = zz();
    xz(b, { stage: dz.Z.Ni, eventId: a });
  }
  function Lz(a) {
    var b = zz(),
      c = yz(b, { stage: dz.Z.Yl, eventId: a }, dz.Z.Ni);
    c !== void 0 && tz(b, a, "V", c);
  }
  function Fz() {
    try {
      var a, b;
      return (b =
        (a = Ad()) == null
          ? void 0
          : a.getEntriesByType("paint").find(function (c) {
              return c.name === "first-contentful-paint";
            })) == null
        ? void 0
        : b.startTime;
    } catch (c) {}
  }
  function Mz(a, b) {
    var c = zz();
    xz(c, { stage: dz.Z.pj, eventId: a.id, tagId: Number(b.tag_id) });
  }
  function Nz(a, b, c) {
    var d = zz(),
      e = dl(b),
      f = Number(b.tag_id),
      g = yz(d, { stage: c, eventId: a.id, tagId: f }, dz.Z.pj);
    if (g !== void 0 && d.J[a.id]) {
      var h = d.J[a.id].tag || "",
        k,
        m = (k = hz[c]) != null ? k : "1",
        p = new RegExp("TS\\d" + e + ".TI" + f),
        q = "TS" + m + e + ".TI" + f + ".TE" + g;
      h.search(p) >= 0
        ? m !== "1" &&
          tz(d, a.id, "tag", h.replace(p, q.replace(".TE" + g, "")))
        : (tz(d, a.id, "tag", (h ? h + "." : "") + q),
          e === "html" && (d.D.HTC += 1),
          (d.D.TC += 1));
    }
  }
  var Sz = { Zi: { Oo: "1", nq: "2", Mq: "3" } };
  var Xz, Yz;
  function Zz(a, b) {
    var c = a["function"],
      d = b.event;
    if (!c) throw Error("Error: No function name given for function call.");
    var e = Yz[c],
      f = {},
      g;
    for (g in a)
      a.hasOwnProperty(g) &&
        (Zb(g, "vtp_")
          ? (f[e !== void 0 ? g : g.substring(4)] = a[g])
          : g === "generated_tagging_metadata".toString() &&
            (f[e !== void 0 ? "vtp_gtmGeneratedTaggingMetadata" : g] = a[g]));
    Hf(61) && e && (f.vtp_extraExperimentIds = !0);
    e &&
      d &&
      d.cachedModelValues &&
      (f.vtp_gtmCachedValues = d.cachedModelValues);
    e && ((f.vtp_gtmEntityIndex = b.index), (f.vtp_gtmEntityName = b.name));
    return e !== void 0 ? e(f) : Xz(c, f, b);
  }
  var aA = function () {
    var a = this;
    this.J = new Kb();
    this.D = {};
    this.M = {};
    this.U = {
      name: E(19),
      set: function (b, c) {
        Bb(bc(b, c), a.D);
        $z(a);
      },
      get: function (b) {
        return a.get(b, 2);
      },
      reset: function () {
        a.J = new Kb();
        a.D = {};
        $z(a);
      },
    };
  };
  aA.prototype.get = function (a, b) {
    return b != 2 ? this.J.get(a) : bA(this, a);
  };
  var bA = function (a, b, c) {
    var d = b.split(".");
    c = c || [];
    for (var e = a.D, f = 0; f < d.length; f++) {
      if (e === null) return !1;
      if (e === void 0) break;
      e = e[d[f]];
      if (c.indexOf(e) !== -1) return;
    }
    return e;
  };
  aA.prototype.set = function (a, b) {
    this.M.hasOwnProperty(a) ||
      (this.J.set(a, b), Bb(bc(a, b), this.D), $z(this));
  };
  var dA = function () {
      for (
        var a = [
            "gtm.allowlist",
            "gtm.blocklist",
            "gtm.whitelist",
            "gtm.blacklist",
            "tagTypeBlacklist",
          ],
          b = cA,
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c],
          e = b.get(d, 1);
        if (Array.isArray(e) || Ab(e)) e = Bb(e, null);
        b.M[d] = e;
      }
    },
    $z = function (a, b) {
      Lb(a.M, function (c, d) {
        a.J.set(c, d);
        Bb(bc(c), a.D);
        Bb(bc(c, d), a.D);
        b && delete a.M[c];
      });
    },
    cA = new aA(),
    eA = cA.U;
  function fA(a, b) {
    return cA.get(a, b);
  }
  function gA(a, b) {
    var c = b === void 0 ? 2 : b,
      d = cA,
      e,
      f = (c === void 0 ? 2 : c) !== 1 ? bA(d, a) : d.J.get(a);
    yb(f) === "array" || yb(f) === "object" ? (e = Bb(f, null)) : (e = f);
    return e;
  }
  var hA = new RegExp(
      /^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/
    ),
    iA = {
      cl: ["ecl"],
      customPixels: ["nonGooglePixels"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: [
        "customScripts",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      customScripts: [
        "html",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGooglePixels: [],
      nonGoogleScripts: ["nonGooglePixels"],
      nonGoogleIframes: ["nonGooglePixels"],
    },
    jA = {
      cl: ["ecl"],
      customPixels: ["customScripts", "html"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: ["customScripts"],
      customScripts: ["html"],
      nonGooglePixels: [
        "customPixels",
        "customScripts",
        "html",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGoogleScripts: ["customScripts", "html"],
      nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"],
    },
    kA =
      "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(
        " "
      );
  function lA() {
    var a = fA("gtm.allowlist") || fA("gtm.whitelist");
    a && S(9);
    Hf(62) && (a = void 0);
    mA() &&
      (Hf(62)
        ? (S(116), Zb(E(5), "GTM-") && S(199))
        : (S(117),
          !O(647) &&
            Hf(48) &&
            ((a = []),
            window.console &&
              window.console.log &&
              window.console.log("GTM blocked. See go/13687728."))));
    var b = a && Yb(Pb(a), iA),
      c = fA("gtm.blocklist") || fA("gtm.blacklist");
    c || ((c = fA("tagTypeBlacklist")) && S(3));
    c ? S(8) : (c = []);
    mA() &&
      ((c = Pb(c)),
      c.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
    Pb(c).indexOf("google") >= 0 && S(2);
    var d = c && Yb(Pb(c), jA),
      e = {};
    return function (f) {
      var g = f && f["function"];
      if (!g || typeof g !== "string") return !0;
      g = g.replace(/^_*/, "");
      if (e[g] !== void 0) return e[g];
      var h =
          aj(21, function () {
            return {};
          })[g] || [],
        k = !0;
      a && (k = k && nA(g, h, b));
      var m = !1;
      c && (m = oA(g, h, d));
      var p = !k || m;
      !p &&
        (h.indexOf("sandboxedScripts") === -1 ||
        (b && b.indexOf("sandboxedScripts") !== -1)
          ? 0
          : Jb(d, kA)) &&
        (p = !0);
      return (e[g] = p);
    };
  }
  function nA(a, b, c) {
    if (c.indexOf(a) < 0)
      if (b && b.length > 0)
        for (var d = 0; d < b.length; d++) {
          if (c.indexOf(b[d]) < 0) return S(11), !1;
        }
      else return !1;
    return !0;
  }
  function oA(a, b, c) {
    var d = c.indexOf(a) >= 0;
    if (d) return d;
    var e = Jb(c, b || []);
    e && S(10);
    return e;
  }
  function mA() {
    return hA.test(x.location && x.location.hostname);
  }
  var qA = function () {
      var a = pA,
        b = E(5).indexOf("GTM-") === 0 && Hf(62);
      O(639) && !a.J && b && mA() && ((a.J = !0), S(201));
      if (O(585) && fl.J) {
        var c = E(5).indexOf("OPT-") === 0,
          d,
          e = ((d = Am()) == null ? void 0 : d.source) === 1;
        mA() || (b && !e) || a.D || c || ((a.D = !0), hj("abl", "1"), pn());
      }
    },
    pA = new (function () {
      this.J = this.D = !1;
    })();
  var rA = function (a, b, c, d) {
    this.D = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.name = String(this.D.instance_name || "");
  };
  rA.prototype.evaluate = function (a, b) {
    if (!b[this.index] && !a.isBlocked(this.D)) {
      b[this.index] = !0;
      this.D["disabled_in_google_mode".toString()] && qA();
      var c = this.name,
        d;
      try {
        var e = {},
          f;
        for (f in this.D)
          this.D.hasOwnProperty(f) &&
            (e[f] = Eo(this.D[f], a, this.tags, this.macros, b));
        e.vtp_gtmEventId = a.id;
        a.priorityId && (e.vtp_gtmPriorityId = a.priorityId);
        var g = (d = Zz(e, { event: a, index: this.index, type: 2, name: c }));
        e.convert_case_to &&
          typeof g === "string" &&
          (g = e.convert_case_to === 1 ? g.toLowerCase() : g.toUpperCase());
        e.hasOwnProperty("convert_to_number") &&
          (g =
            e.convert_to_number === 1
              ? Uf(g, "PERIOD")
              : e.convert_to_number === 2
              ? Uf(g, "COMMA")
              : Uf(g, "AUTOMATIC"));
        e.hasOwnProperty("convert_null_to") &&
          g === null &&
          (g = e.convert_null_to);
        e.hasOwnProperty("convert_undefined_to") &&
          g === void 0 &&
          (g = e.convert_undefined_to);
        e.hasOwnProperty("convert_to_boolean") && (g = Ob(g));
        e.hasOwnProperty("convert_true_to") &&
          g === !0 &&
          (g = e.convert_true_to);
        e.hasOwnProperty("convert_false_to") &&
          g === !1 &&
          (g = e.convert_false_to);
        d = g;
      } catch (h) {
        a.logMacroError && a.logMacroError(h, Number(this.index), c), (d = !1);
      }
      b[this.index] = !1;
      return d;
    }
  };
  rA.prototype.Dg = function () {
    return ma(Object, "assign").call(Object, {}, this.D);
  };
  var sA = function (a, b, c) {
    this.D = a;
    this.tags = b;
    this.macros = c;
  };
  sA.prototype.evaluate = function (a, b) {
    try {
      var c = {},
        d = n(Object.keys(this.D)),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = e.value;
          c[g] =
            g === "function"
              ? this.D[g]
              : Eo(this.D[g], a, this.tags, this.macros, b);
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      return Co(c);
    } catch (h) {
      JSON.stringify(this.D);
    }
    return 2;
  };
  sA.prototype.Dg = function () {
    return ma(Object, "assign").call(Object, {}, this.D);
  };
  var tA = function (a, b) {
    this.index = b;
    this.M = [];
    this.U = [];
    this.J = [];
    this.D = [];
    this.name = "";
    var c = n(a),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) {
        var f = n(d.value),
          g = f.next().value,
          h = wa(f),
          k = g,
          m = h;
        k === "if"
          ? (this.M = m)
          : k === "unless"
          ? (this.U = m)
          : k === "add"
          ? (this.J = m)
          : k === "block"
          ? (this.D = m)
          : k === "ruleName" && (this.name = m[0]);
      }
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
  };
  tA.prototype.evaluate = function (a, b) {
    var c = uA(this, b),
      d = [],
      e = [];
    c
      ? (d.push.apply(d, xa(this.J)), e.push.apply(e, xa(this.D)))
      : c === null && e.push.apply(e, xa(this.D));
    Hf(71) && a.ruleResults && (a.ruleResults[String(this.index)] = c);
    return { firingTags: d, blockingTags: e };
  };
  var uA = function (a, b) {
    var c = n(a.M),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) {
        var f = b(d.value);
        if (f === 0) return !1;
        if (f === 2) return null;
      }
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    var g = n(a.U),
      h = g.next(),
      k;
    try {
      for (; !h.done; h = g.next()) {
        var m = b(h.value);
        if (m === 2) return null;
        if (m === 1) return !1;
      }
    } finally {
      h && !h.done && (k = g.return) && k.call(g);
    }
    return !0;
  };
  tA.prototype.getName = function () {
    return this.name;
  };
  var vA = function (a, b, c, d) {
    this.Ka = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.P = String(this.Ka["function"]);
    this.name = String(this.Ka.instance_name || "");
    this.tagId = Number(this.Ka.tag_id);
  };
  vA.prototype.evaluate = function (a, b, c) {
    c = c === void 0 ? {} : c;
    var d,
      e = c;
    e = e === void 0 ? {} : e;
    var f = {},
      g;
    for (g in this.Ka)
      this.Ka.hasOwnProperty(g) &&
        (f[g] = Eo(this.Ka[g], a, this.tags, this.macros, []));
    d = ma(Object, "assign").call(Object, {}, f, e);
    d.vtp_gtmTagId = this.tagId;
    this.Ka["disabled_in_google_mode".toString()] && qA();
    Zz(d, { event: a, index: this.index, type: 1, name: this.name });
  };
  vA.prototype.Dg = function () {
    return ma(Object, "assign").call(Object, {}, this.Ka);
  };
  var wA = function (a, b) {
      if (a.Ka.setup_tags) return Eo(a.Ka.setup_tags, b, a.tags, a.macros, []);
    },
    xA = function (a, b) {
      if (a.Ka.teardown_tags)
        return Eo(a.Ka.teardown_tags, b, a.tags, a.macros, []);
    },
    yA = function (a, b) {
      var c = a.Ka.consent;
      if (c) return Eo(c, b, a.tags, a.macros, []);
    };
  vA.prototype.getMetadata = function (a) {
    return Eo(this.Ka.metadata, a, this.tags, this.macros, []);
  };
  vA.prototype.getName = function () {
    return this.name;
  };
  var zA = function () {
    this.macros = [];
    this.rules = [];
    this.predicates = [];
    this.tags = [];
    this.hk = [];
  };
  zA.prototype.getRules = function () {
    return this.rules;
  };
  var AA = new zA();
  var BA = !1;
  var CA = new Set(
      "dest_aw dest_ga dest_mc dest_dc __dest_aw __dest_ga __dest_mc __dest_dc".split(
        " "
      )
    ),
    DA,
    EA = new Map();
  function FA(a) {
    var b = EA.get(a);
    b === void 0 && ((b = cn(hn(Km.ia.Qb))), EA.set(a, b));
    var c;
    if (
      !(c =
        b ||
        Wo() ||
        BA ||
        Hf(66) ||
        !lm().includes(a) ||
        GA(a) === 3 ||
        a.indexOf("UA-") === 0)
    ) {
      if (DA === void 0)
        a: {
          for (var d = AA.tags, e = 0; e < d.length; e++) {
            var f = d[e];
            if (f && CA.has(f.P)) {
              DA = !0;
              break a;
            }
          }
          DA = !1;
        }
      c = !DA;
    }
    return c || Jf(67).includes("120213116") || !Jf(67).includes("121049589")
      ? !1
      : hq(612);
  }
  function HA(a, b) {
    vk(qk.da.og, {})[a] = b;
    yk(qk.da.og);
  }
  function IA() {
    var a = E(5);
    HA(a, 2);
  }
  function GA(a) {
    var b;
    return (b = uk(qk.da.og)) == null ? void 0 : b[a];
  }
  function JA(a, b) {
    var c = GA(a);
    if (c === 2 || c === 3) b();
    else {
      c !== 1 && HA(a, 1);
      var d;
      d = wk(qk.da.og, function (e, f) {
        var g = f == null ? void 0 : f[a];
        if (g === 2 || g === 3) d !== void 0 && xk(qk.da.og, d), b();
      });
    }
  }
  function KA(a, b, c, d) {
    var e = fd(),
      f;
    if (e === 1)
      a: {
        var g = E(3);
        g = g.toLowerCase();
        for (
          var h = "https://" + g,
            k = "http://" + g,
            m = 1,
            p = A.getElementsByTagName("script"),
            q = 0;
          q < p.length && q < 100;
          q++
        ) {
          var r = p[q].src;
          if (r) {
            r = r.toLowerCase();
            if (r.indexOf(k) === 0) {
              f = 3;
              break a;
            }
            m === 1 && r.indexOf(h) === 0 && (m = 2);
          }
        }
        f = m;
      }
    else f = e;
    return (f === 2 || d || "http:" !== x.location.protocol ? a : b) + c;
  }
  var LA = function () {
      var a = this;
      this.J = {};
      this.D = {};
      xy(function (b) {
        var c = [],
          d;
        for (d in a.J)
          Object.prototype.hasOwnProperty.call(a.J, d) &&
            c.push(d + "~" + a.J[d]);
        var e = [],
          f;
        for (f in a.D)
          Object.prototype.hasOwnProperty.call(a.D, f) &&
            e.push(f + "~" + a.D[f]);
        b.je && ((a.J = {}), (a.D = {}));
        var g = [];
        c.length > 0 && g.push(["bcs", c.join(".")]);
        e.length > 0 && g.push(["bet", e.join(".")]);
        return g;
      });
    },
    MA;
  function NA() {
    MA || (MA = new LA());
  }
  function OA(a, b, c, d, e) {
    if (!zm(a)) {
      d.loadExperiments = nj();
      Cm(a, d, e);
      var f = PA(a),
        g = function () {
          gm().container[a] && (gm().container[a].state = 3);
          QA();
        },
        h = { destinationId: a, endpoint: 0 };
      if (Oj()) {
        var k = Pj(),
          m = k + "/" + RA(f, a);
        Yl(h, m, void 0, function () {
          SA(a, m, k + "/" + f, h, g);
        });
      } else {
        var p = Zb(a, "GTM-"),
          q = Vj(),
          r = c ? "/gtag/js" : "/gtm.js",
          t = TA(b, r + f, a);
        if (!t) {
          var u = E(3) + r;
          q &&
            Uc &&
            p &&
            (u = Uc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
          t = KA("https://", "http://", u + f);
        }
        Yl(h, t, void 0, g);
      }
    }
  }
  function QA() {
    Fm() ||
      Lb(Gm(), function (a, b) {
        UA(a, b.transportUrl, b.context);
        S(92);
      });
  }
  function UA(a, b, c, d, e, f) {
    if ((e = e === void 0 ? !1 : e) || !Bm(a))
      if ((c.loadExperiments || (c.loadExperiments = nj()), !e && Fm()))
        Em(a, b, c, d);
      else {
        e || Dm(a, c, d);
        var g = { destinationId: a, endpoint: 0 };
        if (Oj()) {
          var h = Pj(),
            k = "gtd" + PA(a, { isDestination: !0, Xn: e }),
            m = h + "/" + RA(k, a);
          Yl(g, m, void 0, function () {
            SA(a, m, h + "/" + k, g, f);
          });
        } else {
          var p = "/gtag/destination" + PA(a, { isDestination: !0, Xn: e }),
            q = TA(b, p, a);
          q || (q = KA("https://", "http://", E(3) + p));
          Yl(g, q, void 0, f);
        }
      }
  }
  function SA(a, b, c, d, e) {
    NA();
    var f = MA;
    if (fl.M) {
      var g = x.performance,
        h = -1;
      if (g && g.getEntriesByType) {
        var k = Jj(b).href,
          m = g.getEntriesByName(k).pop();
        if (!m)
          for (
            var p = g.getEntriesByType("resource"), q = 0;
            q < p.length;
            q++
          ) {
            var r = p[q];
            if (r.name && r.name.indexOf(b) !== -1) {
              m = r;
              break;
            }
          }
        m && m.responseStatus !== void 0 && (h = m.responseStatus);
      }
      f.J[a] = h;
    }
    S(190);
    var t = uk(qk.da.cj) || {};
    t[a] = !0;
    tk(qk.da.cj, t);
    var u = c + (c.indexOf("?") === -1 ? "?f=1" : "&f=1");
    e ? Yl(d, u, void 0, e) : Yl(d, u);
  }
  function PA(a, b) {
    var c = (b = b === void 0 ? {} : b),
      d = c.isDestination,
      e = d === void 0 ? !1 : d,
      f = c.Xn,
      g = f === void 0 ? !1 : f,
      h = Zb(a, "GTM-"),
      k = E(19),
      m = Vj(),
      p = h && Hf(62) ? "true" : void 0,
      q,
      r = { releaseExperiment: If(15), runtimeVersion: E(14) };
    q = Cf(r);
    var t = {
        id: a,
        l: k !== "dataLayer" ? k : void 0,
        cx: !h || e ? "c" : void 0,
        google_only: p,
        gtm: q,
        sign: m ? rj.ij : void 0,
        load_study: e && FA(a) && g ? 1 : void 0,
      },
      u = If(54);
    if (u === 1) {
      t.fps = "fc";
      var v = E(60);
      v && (t.gdev = v);
    } else u === 2 && (t.fps = "fe");
    return "?" + Wi(t);
  }
  function RA(a, b) {
    if (!Pj()) return a;
    var c = E(58);
    if (!c) return S(182), a;
    try {
      var d = Sb(),
        e = Ef(a, c),
        f = Sb() - d;
      NA();
      var g = MA;
      fl.M && (g.D[b] = f);
      return e;
    } catch (h) {
      return S(183), a;
    }
  }
  function TA(a, b, c) {
    if (Sj() && a) {
      var d = E(58),
        e = Pj();
      if (d && e)
        try {
          var f = Sb();
          b = e + "/" + Ef(b, d);
          var g = Sb() - f;
          NA();
          var h = MA;
          fl.M && (h.D[c] = g);
        } catch (k) {
          S(183);
        }
      return Qj(a, b);
    }
  }
  function VA(a) {
    var b = [],
      c = [],
      d = WA(a),
      e = n(AA.getRules()),
      f = e.next(),
      g;
    try {
      for (; !f.done; f = e.next()) {
        for (
          var h = f.value.evaluate(a, d),
            k = h.firingTags,
            m = h.blockingTags,
            p = 0;
          p < k.length;
          p++
        )
          b[k[p]] = !0;
        for (var q = 0; q < m.length; q++) c[m[q]] = !0;
      }
    } finally {
      f && !f.done && (g = e.return) && g.call(e);
    }
    for (var r = [], t = 0; t < AA.tags.length; t++)
      b[t] && !c[t] && (r[t] = !0);
    return r;
  }
  function WA(a) {
    var b = [];
    return function (c) {
      b[c] === void 0 && (b[c] = AA.predicates[c].evaluate(a, []));
      return b[c];
    };
  }
  var XA = function () {
    this.J = 0;
    this.D = {};
  };
  XA.prototype.addListener = function (a, b, c) {
    var d = ++this.J;
    this.D[a] = this.D[a] || {};
    this.D[a][String(d)] = { listener: b, lf: c };
    return d;
  };
  XA.prototype.removeListener = function (a, b) {
    var c = this.D[a],
      d = String(b);
    if (!c || !c[d]) return !1;
    delete c[d];
    return !0;
  };
  var ZA = function (a, b) {
    var c = [];
    Lb(YA.D[a], function (d, e) {
      c.indexOf(e.listener) < 0 &&
        (e.lf === void 0 || b.indexOf(e.lf) >= 0) &&
        c.push(e.listener);
    });
    return c;
  };
  function $A(a, b, c) {
    return {
      entityType: a,
      indexInOriginContainer: b,
      nameInOriginContainer: c,
      originContainerId: E(5),
      originCId: nm(),
    };
  }
  function aB(a, b) {
    if (data.entities) {
      var c = data.entities[a];
      if (c) return c[b];
    }
  }
  function bB() {
    return x[cB()];
  }
  function cB() {
    return x.GoogleAnalyticsObject || "ga";
  }
  var fB = new (function () {
    this.D = {};
  })();
  function gB() {
    a: {
      var a = E(5);
    }
  }
  function hB(a, b) {
    return function () {
      var c = bB(),
        d = c && c.getByName && c.getByName(a);
      if (d) {
        var e = d.get("sendHitTask");
        d.set("sendHitTask", function (f) {
          var g = f.get("hitPayload"),
            h = f.get("hitCallback"),
            k = g.indexOf("&tid=" + b) < 0;
          k &&
            (f.set(
              "hitPayload",
              g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b),
              !0
            ),
            f.set("hitCallback", void 0, !0));
          e(f);
          k &&
            (f.set("hitPayload", g, !0),
            f.set("hitCallback", h, !0),
            f.set("_x_19", void 0, !0),
            e(f));
        });
      }
    };
  }
  var kB = ["es", "1"],
    lB = function () {
      var a = this;
      this.eventData = {};
      this.D = {};
      xy(function (b) {
        var c;
        var d = b.eventId,
          e = b.je;
        if (a.eventData[d]) {
          var f = [];
          a.D[d] || f.push(kB);
          f.push.apply(f, xa(a.eventData[d]));
          e && (a.D[d] = !0);
          c = f;
        } else c = [];
        return c;
      });
    },
    mB;
  function nB(a, b) {
    var c;
    if ((c = mB) != null && fl.M) {
      var d = c.eventData,
        e;
      e = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
      d[a] = [
        ["e", e],
        ["eid", String(a)],
      ];
      yy();
      wy(a);
    }
  }
  var oB = function () {
      var a = this;
      this.D = {};
      this.J = {};
      xy(function (b) {
        var c = b.eventId,
          d = b.je,
          e = [],
          f = a.D[c] || [];
        f.length && e.push(["tr", f.join(".")]);
        var g = a.J[c] || [];
        g.length && e.push(["ti", g.join(".")]);
        d && (delete a.D[c], delete a.J[c]);
        return e;
      });
    },
    pB;
  function qB(a, b, c) {
    pB || (pB = new oB());
    var d = pB;
    if (fl.M && b) {
      var e = dl(b),
        f = c + e;
      d.D[a] = d.D[a] || [];
      d.D[a].push(f);
      var g = b["function"];
      if (!g) throw Error("Error: No function name given for function call.");
      var h = (Yz[g] ? "1" : "2") + e;
      d.J[a] = d.J[a] || [];
      d.J[a].push(h);
      yy();
      wy(a);
    }
  }
  function rB(a, b, c) {
    c = c === void 0 ? !1 : c;
    sB().addRestriction(0, a, b, c);
  }
  function tB() {
    var a = nm();
    return sB().getRestrictions(0, a);
  }
  function uB(a, b, c) {
    c = c === void 0 ? !1 : c;
    sB().addRestriction(1, a, b, c);
  }
  function vB() {
    var a = nm();
    return sB().getRestrictions(1, a);
  }
  var wB = function () {
      this.container = {};
      this.D = {};
    },
    xB = function (a, b) {
      var c = a.container[b];
      c ||
        ((c = {
          _entity: { internal: [], external: [] },
          _event: { internal: [], external: [] },
        }),
        (a.container[b] = c));
      return c;
    };
  wB.prototype.addRestriction = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!d || !this.D[b]) {
      var e = xB(this, b);
      a === 0
        ? d
          ? e._entity.external.push(c)
          : e._entity.internal.push(c)
        : a === 1 &&
          (d ? e._event.external.push(c) : e._event.internal.push(c));
    }
  };
  wB.prototype.getRestrictions = function (a, b) {
    var c = xB(this, b);
    if (a === 0) {
      var d, e;
      return [].concat(
        xa(
          (c == null
            ? void 0
            : (d = c._entity) == null
            ? void 0
            : d.internal) || []
        ),
        xa(
          (c == null
            ? void 0
            : (e = c._entity) == null
            ? void 0
            : e.external) || []
        )
      );
    }
    if (a === 1) {
      var f, g;
      return [].concat(
        xa(
          (c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) ||
            []
        ),
        xa(
          (c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) ||
            []
        )
      );
    }
    return [];
  };
  wB.prototype.getExternalRestrictions = function (a, b) {
    var c = xB(this, b),
      d,
      e;
    return a === 0
      ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) ||
          []
      : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) ||
          [];
  };
  wB.prototype.removeExternalRestrictions = function (a) {
    var b = xB(this, a);
    b._event && (b._event.external = []);
    b._entity && (b._entity.external = []);
    this.D[a] = !0;
  };
  function sB() {
    return ko("r", function () {
      return new wB();
    });
  }
  function yB(a, b, c, d) {
    var e = AA.tags[a],
      f = zB(a, b, c, d);
    if (!f) return null;
    var g = wA(e, c);
    if (g && g.length) {
      var h = g[0];
      f = yB(
        h.index,
        {
          onSuccess: f,
          onFailure: h.Ln === 1 ? b.terminate : f,
          terminate: b.terminate,
        },
        c,
        d
      );
    }
    return f;
  }
  function zB(a, b, c, d) {
    function e() {
      function y() {
        pk(3);
        var L = Sb() - I;
        $A(1, a, f.getName());
        qB(c.id, g, "7");
        Io(c.kd, D, "exception", L);
        fl.D && Nz(c, g, dz.Z.mj);
        G || ((G = !0), k());
      }
      if (f.Ka.malware_disabled) k();
      else {
        var z = yA(f, c);
        if (z != null)
          for (var C = 0; C < z.length; C++)
            if (!pp(z[C])) {
              k();
              return;
            }
        var D = Ho(c.kd, f.P, f.tagId, f.getMetadata(c)),
          G = !1,
          F = {
            vtp_gtmOnSuccess: function () {
              if (!G) {
                G = !0;
                var L = Sb() - I;
                qB(c.id, g, "5");
                Io(c.kd, D, "success", L);
                fl.D && Nz(c, g, dz.Z.oj);
                h();
              }
            },
            vtp_gtmOnFailure: function () {
              if (!G) {
                G = !0;
                var L = Sb() - I;
                qB(c.id, g, "6");
                Io(c.kd, D, "failure", L);
                fl.D && Nz(c, g, dz.Z.nj);
                k();
              }
            },
          };
        F.vtp_gtmEventId = c.id;
        c.priorityId && (F.vtp_gtmPriorityId = c.priorityId);
        qB(c.id, g, "1");
        fl.D && Mz(c, g);
        var I = Sb();
        try {
          f.evaluate(c, d, F);
        } catch (L) {
          y(L);
        }
        fl.D && Nz(c, g, dz.Z.mn);
      }
    }
    var f = AA.tags[a],
      g = f.Dg(),
      h = b.onSuccess,
      k = b.onFailure,
      m = b.terminate;
    if (c.isBlocked(g)) return null;
    var p = xA(f, c);
    if (p && p.length) {
      var q = p[0],
        r = yB(q.index, { onSuccess: h, onFailure: k, terminate: m }, c, d);
      if (!r) return null;
      h = r;
      k = q.Ln === 2 ? m : r;
    }
    if (f.Ka.once_per_load || f.Ka.once_per_event) {
      var t = f.Ka.once_per_load ? AA.hk : c.hk,
        u = h,
        v = k;
      if (!t[a]) {
        var w = AB(a, t, Wb(e));
        h = w.onSuccess;
        k = w.onFailure;
      }
      return function () {
        t[a](u, v);
      };
    }
    return e;
  }
  function AB(a, b, c) {
    var d = [],
      e = [];
    b[a] = BB(d, e, c);
    return {
      onSuccess: function () {
        b[a] = CB;
        for (var f = 0; f < d.length; f++) d[f]();
      },
      onFailure: function () {
        b[a] = DB;
        for (var f = 0; f < e.length; f++) e[f]();
      },
    };
  }
  function BB(a, b, c) {
    return function (d, e) {
      a.push(d);
      b.push(e);
      c();
    };
  }
  function CB(a) {
    a();
  }
  function DB(a, b) {
    b();
  }
  var GB = function (a, b) {
    for (var c = [], d = 0; d < AA.tags.length; d++)
      if (a[d]) {
        var e = AA.tags[d];
        var f = Ko(b.kd);
        try {
          var g = yB(d, { onSuccess: f, onFailure: f, terminate: f }, b, d);
          if (g) {
            var h = Yz[e.P];
            c.push({
              Co: d,
              priorityOverride:
                (h ? h.priorityOverride || 0 : 0) || aB(e.P, 1) || 0,
              execute: g,
            });
          } else EB(d, b), f();
        } catch (m) {
          f();
        }
      }
    c.sort(FB);
    for (var k = 0; k < c.length; k++) c[k].execute();
    return c.length > 0;
  };
  function HB(a, b) {
    if (!YA) return !1;
    var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
      d = ZA(a.event, c ? String(c).split(",") : []);
    if (!d.length) return !1;
    for (var e = 0; e < d.length; ++e) {
      var f = Ko(b);
      try {
        d[e](a, f);
      } catch (g) {
        f();
      }
    }
    return !0;
  }
  function FB(a, b) {
    var c,
      d = b.priorityOverride,
      e = a.priorityOverride;
    c = d > e ? 1 : d < e ? -1 : 0;
    var f;
    if (c !== 0) f = c;
    else {
      var g = a.Co,
        h = b.Co;
      f = g > h ? 1 : g < h ? -1 : 0;
    }
    return f;
  }
  function EB(a, b) {
    if (fl.M) {
      var c = function (d) {
        var e = b.isBlocked(AA.tags[d].Dg()) ? "3" : "4",
          f = wA(AA.tags[d], b);
        f && f.length && c(f[0].index);
        qB(b.id, AA.tags[d].Dg(), e);
        var g = xA(AA.tags[d], b);
        g && g.length && c(g[0].index);
      };
      c(a);
    }
  }
  var YA;
  function IB() {
    YA || (YA = new XA());
    return YA;
  }
  function JB(a) {
    var b = a["gtm.uniqueEventId"],
      c = a["gtm.priorityId"],
      d = a["gtm.priorityQueue"],
      e = a.event;
    fl.D && Dz(b, e);
    if (e === "gtm.js") {
      if ($i(10)) return !1;
      Zi(10, !0);
    }
    var f = !1,
      g = vB(),
      h = Bb(a, null);
    if (
      !g.every(function (u) {
        return u({ originalEventData: h });
      })
    ) {
      if (e !== "gtm.js" && e !== "gtm.init" && e !== "gtm.init_consent")
        return !1;
      f = !0;
    }
    nB(b, e);
    var k = a.eventCallback,
      m = a.eventTimeout,
      p = {
        id: b,
        priorityId: c,
        priorityQueue: d,
        name: e,
        isBlocked: KB(h, f),
        hk: [],
        logMacroError: function (u, v, w) {
          S(6);
          pk(4);
          $A(2, v, w);
        },
        cachedModelValues: LB(),
        kd: new Go(function () {
          fl.D && Gz(b, e);
          k && k.apply(k, Array.prototype.slice.call(arguments, 0));
        }, m),
        originalEventData: h,
      };
    fl.D && Kz(p.id);
    var q = VA(p);
    fl.D && Lz(p.id);
    AA.getRules();
    f && (q = MB(q));
    fl.D && Ez(b);
    var r = GB(q, p),
      t = HB(a, p.kd);
    Lo(p.kd);
    (e !== "gtm.js" && e !== "gtm.sync") || gB();
    return NB(q, r) || t;
  }
  function LB() {
    var a = {};
    a.event = gA("event", 1);
    a.ecommerce = gA("ecommerce", 1);
    a.gtm = gA("gtm");
    a.eventModel = gA("eventModel");
    return a;
  }
  function KB(a, b) {
    var c = lA();
    return function (d) {
      var e = c(d);
      if (e) return !0;
      var f = d && d["function"];
      if (!f || typeof f !== "string") return !0;
      f = f.replace(/^_*/, "");
      var g = tB(),
        h = a;
      b &&
        ((h = Bb(a, null)), (h["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER));
      var k = !1,
        m =
          aj(21, function () {
            return {};
          })[f] || [],
        p = n(g),
        q = p.next(),
        r;
      try {
        for (; !q.done; q = p.next()) {
          var t = q.value;
          try {
            t({ entityId: f, securityGroups: m, originalEventData: h }) ||
              (k = !0);
          } catch (u) {
            k = !0;
          }
        }
      } finally {
        q && !q.done && (r = p.return) && r.call(p);
      }
      return k || e;
    };
  }
  function MB(a) {
    for (var b = [], c = 0; c < a.length; c++)
      if (a[c]) {
        var d = AA.tags[c].P;
        if (sj[d] || AA.tags[c].Ka.original_activity_id !== void 0 || aB(d, 2))
          b[c] = !0;
      }
    return b;
  }
  function NB(a, b) {
    if (!b) return b;
    for (var c = 0; c < a.length; c++)
      if (a[c] && AA.tags[c] && !tj[AA.tags[c].P]) return !0;
    return !1;
  }
  var OB = Mf(61, 1e3),
    PB = Mf(68, 2e3),
    rp = ["ad_storage", "analytics_storage"];
  function QB(a, b) {
    if (a) {
      var c = ko("gth", function () {
          return {};
        }),
        d;
      a !== 2 ||
        ((d = RB()) == null ? void 0 : d.status) !== 3 ||
        (b !== void 0 && b <= PB) ||
        ((a = 3), (c.dl = b ? Math.floor(b / 1e3) : void 0));
      c.s = a;
      SB(c);
    }
  }
  function SB(a) {
    if (a.s) {
      var b = function () {
        var c = { status: a.s, expires: Date.now() + 864e5 };
        a.dl !== void 0 && (c.delay = a.dl);
        Tr("gtg_load_status", c);
      };
      up(function () {
        if (qp()) b();
        else {
          var c = Wb(b),
            d = n(rp),
            e = d.next(),
            f;
          try {
            for (; !e.done; e = d.next()) $m(c, e.value);
          } finally {
            e && !e.done && (f = d.return) && f.call(d);
          }
        }
      }, rp);
    }
  }
  function TB() {
    var a = UB(!0);
    return a ? (VB(a.status, a.delay), !1) : !0;
  }
  function UB(a) {
    a = a === void 0 ? !1 : a;
    if (Sj()) {
      var b = Wr("gtg_load_status"),
        c = b.value,
        d =
          a &&
          Fb(c == null ? void 0 : c.expires) &&
          (c == null ? void 0 : c.expires) < Date.now() + 36e5;
      if (b.error === 0 && Fb(c == null ? void 0 : c.status) && !d) {
        var e = { status: c.status };
        (c == null ? void 0 : c.delay) !== void 0 && (e.delay = c.delay);
        return e;
      }
      return RB();
    }
  }
  function VB(a, b) {
    var c = ko("gth", function () {
      return {};
    });
    c.s = a;
    b !== void 0 && (c.dl = b);
  }
  function RB() {
    var a = mo("gth");
    if (a != null && a.s) {
      var b = { status: a.s };
      a.dl !== void 0 && (b.delay = a.dl);
      return b;
    }
  }
  function WB() {
    var a;
    ((a = RB()) == null ? void 0 : a.status) === 1 && QB(3);
  }
  function XB() {
    if (TB()) {
      var a = Date.now();
      no("gth", {
        l: function () {
          QB(2, Date.now() - a);
        },
        s: 1,
      });
      var b = E(5),
        c = Zb(b, "GTM-") ? "/gtm.js" : "/gtag/js",
        d = "https://" + E(3) + c + "?id=" + b + "&gtg_health=1";
      cd(d, WB, WB);
      x.setTimeout(WB, OB);
    }
  }
  function YB() {
    IB().addListener("gtm.init", function (a, b) {
      Zi(14, !0);
      O(556) && Sj() && !Hf(45) && (bn.D[Km.ia.Qb] = Jm.Oa.Fh);
      if (Sj()) {
        var c = hn(Km.ia.Qb);
        cn(c) ? en(c, XB) : XB();
      }
      pn(!1, !0);
      b();
    });
  }
  function ZB() {
    if (mo("pscdl") !== void 0)
      uk(qk.da.Xg) === void 0 && tk(qk.da.Xg, mo("pscdl"));
    else {
      var a = function (c) {
          no("pscdl", c);
          tk(qk.da.Xg, c);
        },
        b = function () {
          a("error");
        };
      try {
        Qc.cookieDeprecationLabel
          ? (a("pending"),
            Qc.cookieDeprecationLabel.getValue().then(a).catch(b))
          : a("noapi");
      } catch (c) {
        b(c);
      }
    }
  }
  var aC = function () {
    var a = this;
    this.ready = !1;
    this.D = 0;
    this.listeners = [];
    var b = x;
    if (
      (A.readyState === "interactive" && !A.createEventObject) ||
      A.readyState === "complete"
    )
      this.onReady();
    else {
      id(A, "DOMContentLoaded", function (d) {
        return void a.onReady(d);
      });
      id(A, "readystatechange", function (d) {
        return void a.onReady(d);
      });
      if (A.createEventObject && A.documentElement.doScroll) {
        var c = !0;
        try {
          c = !b.frameElement;
        } catch (d) {}
        c && $B(this);
      }
      id(b, "load", function (d) {
        return void a.onReady(d);
      });
    }
  };
  aC.prototype.isReady = function () {
    return this.ready;
  };
  aC.prototype.onReady = function (a) {
    if (!this.ready) {
      var b = A.createEventObject,
        c = A.readyState === "complete",
        d = A.readyState === "interactive";
      if (!a || a.type !== "readystatechange" || c || (!b && d)) {
        this.ready = !0;
        for (var e = 0; e < this.listeners.length; e++) kd(this.listeners[e]);
      }
      this.listeners.push = function () {
        for (var f = Oa.apply(0, arguments), g = 0; g < f.length; g++) kd(f[g]);
        return 0;
      };
    }
  };
  var $B = function (a) {
      if (!a.ready && a.D < 140) {
        a.D++;
        try {
          var b, c;
          (c = (b = A.documentElement).doScroll) == null || c.call(b, "left");
          a.onReady();
        } catch (d) {
          x.setTimeout(function () {
            return void $B(a);
          }, 50);
        }
      }
    },
    bC;
  function cC() {
    bC || (bC = new aC());
  }
  function dC() {
    cC();
    var a;
    return (a = bC) == null ? void 0 : a.isReady();
  }
  function eC(a) {
    cC();
    var b;
    (b = bC) != null && (b.ready ? kd(a) : b.listeners.push(a));
  }
  var gC = function (a, b, c) {
      var d = fC,
        e;
      if ((e = d.D) == null || !e.us) {
        var f = Object.keys(b).length > 0 ? 2 : 1,
          g,
          h,
          k =
            (c == null
              ? void 0
              : (h = c.originatingEntity) == null
              ? void 0
              : h.originContainerId) || "";
        g = k ? (Zb(k, "GTM-") ? 3 : 2) : 1;
        if (!a) d.D = { type: f, source: g, params: b };
        else if (d.D) {
          S(184);
          var m = !1;
          d.D.source === g ||
            (d.D.source !== 3 && g !== 3) ||
            (hj("idcs", "1"), (m = !0));
          (d.D.type !== 2 && f !== 2) || S(186);
          var p;
          if ((p = d.D.type === 2 && f === 2))
            a: {
              var q = d.D.params,
                r = Object.keys(q),
                t = Object.keys(b);
              if (r.length !== t.length) p = !0;
              else {
                var u = n(r),
                  v = u.next(),
                  w;
                try {
                  for (; !v.done; v = u.next()) {
                    var y = v.value;
                    if (!b.hasOwnProperty(y) || q[y] !== b[y]) {
                      p = !0;
                      break a;
                    }
                  }
                } finally {
                  v && !v.done && (w = u.return) && w.call(u);
                }
                p = !1;
              }
            }
          p && (hj("idcc", "1"), (m = !0));
          m && (pn(), (d.D.us = !0));
        }
      }
    },
    fC = new (function () {
      this.D = void 0;
    })();
  var iC = function (a) {
      var b = hC;
      (!fl.J || Zb(E(5), "GTM-") ? 0 : a === void 0) &&
        b.D === 0 &&
        (hj("mcc", "1"), (b.D = 1));
    },
    hC = new (function () {
      var a = this;
      this.D = 0;
      hj("ncc", function () {
        if (Hf(45) && a.D !== 2) return "1";
      });
    })();
  var jC = {
    X: {
      wk: 1,
      ej: 2,
      rk: 3,
      Qk: 4,
      sk: 5,
      ud: 6,
      Pk: 7,
      Fq: 8,
      Xm: 9,
      uk: 10,
      vk: 11,
      Ch: 12,
      jm: 13,
      gm: 14,
      im: 15,
      fm: 16,
      hm: 17,
      dm: 18,
      Fo: 19,
      pq: 20,
      qq: 21,
      Gq: 22,
      Gk: 26,
      Hk: 27,
      Fk: 28,
      Ik: 29,
      jj: 30,
      Ck: 31,
      Lo: 32,
    },
  };
  jC.X[jC.X.wk] = "ALLOW_INTEREST_GROUPS";
  jC.X[jC.X.ej] = "SERVER_CONTAINER_URL";
  jC.X[jC.X.rk] = "ADS_DATA_REDACTION";
  jC.X[jC.X.Qk] = "CUSTOMER_LIFETIME_VALUE";
  jC.X[jC.X.sk] = "ALLOW_CUSTOM_SCRIPTS";
  jC.X[jC.X.ud] = "ANY_COOKIE_PARAMS";
  jC.X[jC.X.Pk] = "COOKIE_EXPIRES";
  jC.X[jC.X.Fq] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
  jC.X[jC.X.Xm] = "RESTRICTED_DATA_PROCESSING";
  jC.X[jC.X.uk] = "ALLOW_DISPLAY_FEATURES";
  jC.X[jC.X.vk] = "ALLOW_GOOGLE_SIGNALS";
  jC.X[jC.X.Ch] = "GENERATED_TRANSACTION_ID";
  jC.X[jC.X.jm] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
  jC.X[jC.X.gm] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
  jC.X[jC.X.im] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
  jC.X[jC.X.fm] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
  jC.X[jC.X.hm] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
  jC.X[jC.X.dm] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
  jC.X[jC.X.Fo] = "ADS_OGT_V1_USAGE";
  jC.X[jC.X.pq] = "FORM_INTERACTION_PERMISSION_DENIED";
  jC.X[jC.X.qq] = "FORM_SUBMIT_PERMISSION_DENIED";
  jC.X[jC.X.Gq] = "MICROTASK_NOT_SUPPORTED";
  jC.X[jC.X.Gk] = "CONFIG_DETECTED_WITH_NO_PARAM";
  jC.X[jC.X.Hk] = "CONFIG_DETECTED_WITH_PARAM";
  jC.X[jC.X.Fk] = "CONFIG_CONSENT_SET_BEFORE";
  jC.X[jC.X.Ik] = "CONFIG_SET_USED_BEFORE";
  jC.X[jC.X.jj] = "SHADOW_DOM_AUTO_PII";
  jC.X[jC.X.Ck] = "CCD_USER_DATA_WEB_ON_CONFIG";
  jC.X[jC.X.Lo] = "BLENDED_USER_DATA";
  var kC = {},
    lC =
      ((kC[H.A.li] = jC.X.wk),
      (kC[H.A.wc] = jC.X.ej),
      (kC[H.A.yc] = jC.X.ej),
      (kC[H.A.qb] = jC.X.rk),
      (kC[H.A.we] = jC.X.Qk),
      (kC[H.A.ji] = jC.X.sk),
      (kC[H.A.Ed] = jC.X.ud),
      (kC[H.A.rb] = jC.X.ud),
      (kC[H.A.Ob] = jC.X.ud),
      (kC[H.A.Dd] = jC.X.ud),
      (kC[H.A.sc] = jC.X.ud),
      (kC[H.A.Xb] = jC.X.ud),
      (kC[H.A.Cb] = jC.X.Pk),
      (kC[H.A.xb] = jC.X.Xm),
      (kC[H.A.eh] = jC.X.uk),
      (kC[H.A.Qc] = jC.X.vk),
      kC),
    mC = {},
    nC =
      ((mC.unknown = jC.X.jm),
      (mC.standard = jC.X.gm),
      (mC.unique = jC.X.im),
      (mC.per_session = jC.X.fm),
      (mC.transactions = jC.X.hm),
      (mC.items_sold = jC.X.dm),
      mC);
  var oC = function (a, b, c) {
      c = c === void 0 ? !1 : c;
      sb("GTAG_EVENT_FEATURE_CHANNEL", b);
      c && (a.D[b] = !0);
    },
    pC = new (function () {
      this.D = [];
    })();
  function qC(a) {
    oC(pC, a, !1);
  }
  function rC(a, b) {
    var c = b === void 0 ? !1 : b,
      d = pC;
    c = c === void 0 ? !1 : c;
    var e = Object.keys(a),
      f = n(Object.keys(lC)),
      g = f.next(),
      h;
    try {
      for (; !g.done; g = f.next()) {
        var k = g.value;
        e.includes(k) && oC(d, lC[k], c);
      }
    } finally {
      g && !g.done && (h = f.return) && h.call(f);
    }
  }
  var sC = /^(?:AW|DC|G|GF|GT|HA|MC|S|UA)$/,
    tC = /\s/;
  function uC(a, b) {
    if (Eb(a)) {
      a = Qb(a);
      var c = a.indexOf("-");
      if (!(c < 0)) {
        var d = a.substring(0, c);
        if (sC.test(d)) {
          var e = a.substring(c + 1),
            f;
          if (b) {
            var g = function (m) {
              var p = m.indexOf("/");
              return p < 0 ? [m] : [m.substring(0, p), m.substring(p + 1)];
            };
            f = g(e);
            if (d === "DC" && f.length === 2) {
              var h = g(f[1]);
              h.length === 2 && ((f[1] = h[0]), f.push(h[1]));
            }
          } else {
            f = e.split("/");
            for (var k = 0; k < f.length; k++)
              if (!f[k] || (tC.test(f[k]) && (d !== "AW" || k !== 1))) return;
          }
          return {
            id: a,
            prefix: d,
            destinationId: d + "-" + f[0],
            ids: f,
            Ec: function () {
              return this.id !== this.destinationId;
            },
          };
        }
      }
    }
  }
  function vC(a, b) {
    for (var c = {}, d = 0; d < a.length; ++d) {
      var e = uC(a[d], b);
      e && (c[e.id] = e);
    }
    var f = [],
      g;
    for (g in c)
      if (c.hasOwnProperty(g)) {
        var h = c[g];
        h.prefix === "AW" && h.ids[wC[1]] && f.push(h.destinationId);
      }
    for (var k = 0; k < f.length; ++k) delete c[f[k]];
    var m = [],
      p = n(Object.keys(c)),
      q = p.next(),
      r;
    try {
      for (; !q.done; q = p.next()) m.push(c[q.value]);
    } finally {
      q && !q.done && (r = p.return) && r.call(p);
    }
    return m;
  }
  var xC = {},
    wC =
      ((xC[0] = 0),
      (xC[1] = 1),
      (xC[2] = 2),
      (xC[3] = 0),
      (xC[4] = 1),
      (xC[5] = 0),
      (xC[6] = 0),
      (xC[7] = 0),
      xC);
  var yC = { initialized: 11, complete: 12, interactive: 13 },
    zC = {},
    AC = Object.freeze(((zC[H.A.Od] = !0), zC)),
    BC = function () {
      this.U = Mf(34, 500);
      this.D = {};
      this.M = {};
      this.J = void 0;
    },
    CC = function (a, b, c) {
      if (c.length && fl.J) {
        var d;
        (d = a.D)[b] != null || (d[b] = []);
        var e;
        (e = a.M)[b] != null || (e[b] = []);
        var f = c.filter(function (g) {
          return !a.M[b].includes(g);
        });
        a.D[b].push.apply(a.D[b], xa(f));
        a.M[b].push.apply(a.M[b], xa(f));
        !a.J &&
          f.length > 0 &&
          (fj(dj, "tdc", !0),
          (a.J = x.setTimeout(function () {
            pn();
            a.D = {};
            a.J = void 0;
          }, a.U)));
      }
    };
  BC.prototype.bind = function () {
    var a = this;
    hj(
      "tdc",
      function () {
        a.J && (x.clearTimeout(a.J), (a.J = void 0));
        var b = [],
          c;
        for (c in a.D)
          a.D.hasOwnProperty(c) && b.push(c + "*" + a.D[c].join("."));
        return b.length ? b.join("!") : void 0;
      },
      !1
    );
  };
  var DC = function (a, b) {
      var c = {},
        d;
      for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
      for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
      return c;
    },
    EC = function (a, b, c, d, e) {
      d = d === void 0 ? {} : d;
      e = e === void 0 ? "" : e;
      if (b === c) return [];
      var f = function (t, u) {
          var v;
          yb(u) === "object" ? (v = u[t]) : yb(u) === "array" && (v = u[t]);
          return v === void 0 ? AC[t] : v;
        },
        g = DC(b, c),
        h;
      for (h in g)
        if (g.hasOwnProperty(h) && h !== H.A.Zb) {
          var k = (e ? e + "." : "") + h,
            m = f(h, b),
            p = f(h, c),
            q = yb(m) === "object" || yb(m) === "array",
            r = yb(p) === "object" || yb(p) === "array";
          if (q && r) EC(a, m, p, d, k);
          else if (q || r || m !== p) d[k] = !0;
        }
      return Object.keys(d);
    },
    FC = new BC();
  var GC = function (a, b, c, d, e) {
      this.J = b;
      this.D = c;
      this.args = d;
      this.messageContext = e;
      this.type = a;
    },
    HC = function () {
      this.Za = {};
      this.mb = {};
      this.J = {};
      this.M = null;
      this.kb = {};
      this.D = !1;
      this.status = 1;
    };
  function IC(a, b) {
    return arguments.length === 1 ? JC("set", a) : JC("set", a, b);
  }
  function KC(a, b) {
    return arguments.length === 1 ? JC("config", a) : JC("config", a, b);
  }
  function LC(a, b, c) {
    c = c || {};
    c[H.A.Zb] = a;
    return JC("event", b, c);
  }
  function JC() {
    return arguments;
  }
  var MC = function (a, b, c, d, e, f, g, h, k, m, p, q, r) {
    this.eventId = a;
    this.priorityId = b;
    this.priorityQueue = c;
    this.Ma = d;
    this.Za = e;
    this.kb = f;
    this.Cc = g;
    this.zg = h;
    this.mb = k;
    this.eventMetadata = m;
    this.onSuccess = p;
    this.onFailure = q;
    this.isGtmEvent = r;
  };
  MC.prototype.copy = function (a) {
    a = a === void 0 ? {} : a;
    var b,
      c,
      d,
      e,
      f,
      g,
      h,
      k,
      m,
      p,
      q,
      r,
      t,
      u,
      v,
      w,
      y,
      z,
      C,
      D,
      G,
      F,
      I,
      L,
      P,
      R;
    return new MC(
      (u = (b = a) == null ? void 0 : b.eventId) != null ? u : this.eventId,
      (v = (c = a) == null ? void 0 : c.priorityId) != null
        ? v
        : this.priorityId,
      (w = (d = a) == null ? void 0 : d.priorityQueue) != null
        ? w
        : this.priorityQueue,
      (y = (e = a) == null ? void 0 : e.Ma) != null ? y : this.Ma,
      (z = (f = a) == null ? void 0 : f.Za) != null ? z : this.Za,
      (C = (g = a) == null ? void 0 : g.kb) != null ? C : this.kb,
      (D = (h = a) == null ? void 0 : h.Cc) != null ? D : this.Cc,
      (G = (k = a) == null ? void 0 : k.zg) != null ? G : this.zg,
      (F = (m = a) == null ? void 0 : m.mb) != null ? F : this.mb,
      (I = (p = a) == null ? void 0 : p.eventMetadata) != null
        ? I
        : this.eventMetadata,
      (L = (q = a) == null ? void 0 : q.onSuccess) != null ? L : this.onSuccess,
      (P = (r = a) == null ? void 0 : r.onFailure) != null ? P : this.onFailure,
      (R = (t = a) == null ? void 0 : t.isGtmEvent) != null
        ? R
        : this.isGtmEvent
    );
  };
  var NC = function (a, b) {
      var c = [];
      switch (b) {
        case 3:
          c.push(a.Ma);
          c.push(a.Za);
          c.push(a.kb);
          c.push(a.Cc);
          c.push(a.mb);
          break;
        case 2:
          c.push(a.Ma);
          break;
        case 1:
          c.push(a.Za);
          c.push(a.kb);
          c.push(a.Cc);
          c.push(a.mb);
          break;
        case 4:
          c.push(a.Ma), c.push(a.Za), c.push(a.kb), c.push(a.Cc);
      }
      return c;
    },
    Q = function (a, b, c, d) {
      var e = n(NC(a, d === void 0 ? 3 : d)),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value;
          if (h[b] !== void 0) return h[b];
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
      return c;
    },
    OC = function (a) {
      var b = {},
        c = NC(a, 4),
        d = n(c),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = void 0,
            h = Object.keys(e.value),
            k = n(h),
            m = k.next();
          try {
            for (; !m.done; m = k.next()) b[m.value] = 1;
          } finally {
            m && !m.done && (g = k.return) && g.call(k);
          }
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      return Object.keys(b);
    };
  MC.prototype.getMergedValues = function (a, b, c) {
    b = b === void 0 ? 3 : b;
    var d = {},
      e = !1,
      f = function (p) {
        Ab(p) &&
          Lb(p, function (q, r) {
            e = !0;
            d[q] = r;
          });
      };
    c && f(c);
    var g = NC(this, b);
    g.reverse();
    var h = n(g),
      k = h.next(),
      m;
    try {
      for (; !k.done; k = h.next()) f(k.value[a]);
    } finally {
      k && !k.done && (m = h.return) && m.call(h);
    }
    return e ? d : void 0;
  };
  var PC = function (a) {
      var b = [H.A.Cf, H.A.yf, H.A.zf, H.A.Af, H.A.Bf, H.A.Df, H.A.Ef],
        c = NC(a, 3),
        d = n(c),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = void 0,
            h = void 0,
            k = e.value,
            m = {},
            p = !1,
            q = n(b),
            r = q.next();
          try {
            for (; !r.done; r = q.next())
              (g = r.value), k[g] !== void 0 && ((m[g] = k[g]), (p = !0));
          } finally {
            r && !r.done && (h = q.return) && h.call(q);
          }
          var t = p ? m : void 0;
          if (t) return t;
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      return {};
    },
    QC = function (a, b, c) {
      this.eventId = a;
      this.priorityId = b;
      this.priorityQueue = c;
      this.Ma = {};
      this.Za = {};
      this.kb = {};
      this.Cc = {};
      this.zg = {};
      this.mb = {};
      this.eventMetadata = {};
      this.isGtmEvent = !1;
      this.onSuccess = function () {};
      this.onFailure = function () {};
    },
    RC = function (a, b) {
      a.Ma = b;
      return a;
    },
    SC = function (a, b) {
      a.Za = b;
      return a;
    },
    TC = function (a, b) {
      a.kb = b;
      return a;
    },
    UC = function (a, b) {
      a.Cc = b;
      return a;
    },
    VC = function (a, b) {
      a.zg = b;
      return a;
    },
    WC = function (a, b) {
      a.mb = b;
      return a;
    },
    XC = function (a, b) {
      a.eventMetadata = b || {};
      return a;
    },
    YC = function (a, b) {
      a.onSuccess = b;
      return a;
    },
    ZC = function (a, b) {
      a.onFailure = b;
      return a;
    },
    $C = function (a, b) {
      a.isGtmEvent = b;
      return a;
    },
    aD = function (a) {
      return new MC(
        a.eventId,
        a.priorityId,
        a.priorityQueue,
        a.Ma,
        a.Za,
        a.kb,
        a.Cc,
        a.zg,
        a.mb,
        a.eventMetadata,
        a.onSuccess,
        a.onFailure,
        a.isGtmEvent
      );
    };
  function bD(a, b) {
    Lb(a, function (c) {
      var d;
      if ((d = c.charAt(0) === "_")) {
        var e;
        a: switch (c) {
          case H.A.Yb:
          case H.A.Jf:
          case H.A.qh:
            e = !0;
            break a;
          default:
            e = !1;
        }
        d = !e;
      }
      d && (b && b(c), delete a[c]);
    });
  }
  var cD = function () {
      var a = this;
      this.D = {};
      xy(function (b) {
        var c = b.eventId,
          d = b.je,
          e = [],
          f = a.D[c] || [];
        f.length && e.push(["epr", f.join(".")]);
        d && delete a.D[c];
        return e;
      });
    },
    eD = function (a, b, c) {
      var d = dD;
      if (fl.M && a !== void 0) {
        var e = c + b;
        d.D[a] = d.D[a] || [];
        d.D[a].push(e);
        yy();
        wy(a);
      }
    },
    dD;
  function fD() {
    dD || (dD = new cD());
  }
  var gD = function () {
      this.destinations = {};
      this.D = {};
      this.commands = [];
    },
    hD = function (a, b) {
      return (a.destinations[b.destinationId] =
        a.destinations[b.destinationId] || new HC());
    },
    iD = function (a, b, c, d) {
      if (d.D) {
        var e = hD(a, d.D),
          f = e.M;
        if (f) {
          var g = Bb(c, null),
            h = Bb(e.Za[d.D.destinationId], null),
            k = Bb(e.kb, null),
            m = Bb(e.mb, null),
            p = Bb(a.D, null),
            q = {};
          if (fl.M)
            try {
              q = Bb(cA.D, null);
            } catch (y) {
              S(72);
            }
          var r = d.D.prefix,
            t = function (y) {
              var z = d.messageContext.eventId;
              fD();
              eD(z, r, y);
            },
            u = aD(
              $C(
                ZC(
                  YC(
                    XC(
                      VC(
                        UC(
                          WC(
                            TC(
                              SC(
                                RC(
                                  new QC(
                                    d.messageContext.eventId,
                                    d.messageContext.priorityId,
                                    d.messageContext.priorityQueue
                                  ),
                                  g
                                ),
                                h
                              ),
                              k
                            ),
                            m
                          ),
                          p
                        ),
                        q
                      ),
                      ma(Object, "assign").call(
                        Object,
                        {},
                        d.messageContext.eventMetadata
                      )
                    ),
                    function () {
                      if (t) {
                        var y = t;
                        t = void 0;
                        y("2");
                        if (d.messageContext.onSuccess)
                          d.messageContext.onSuccess();
                      }
                    }
                  ),
                  function () {
                    if (t) {
                      var y = t;
                      t = void 0;
                      y("3");
                      if (d.messageContext.onFailure)
                        d.messageContext.onFailure();
                    }
                  }
                ),
                !!d.messageContext.isGtmEvent
              )
            ),
            v = function () {
              try {
                if (d.D && GA(d.D.destinationId) === 3) {
                  fq();
                  var y = dq(Zp, 612);
                  if (y) {
                    var z = u.eventMetadata[J.H.lj] || [];
                    z.includes(y) || z.push(y);
                    u.eventMetadata[J.H.lj] = z;
                  }
                }
                var C = d.messageContext.eventId;
                fD();
                eD(C, r, "1");
                var D = d.D.id,
                  G = FC;
                if (fl.J && b === H.A.ya) {
                  var F,
                    I = (F = uC(D)) == null ? void 0 : F.ids;
                  if (!(I && I.length > 1)) {
                    var L = u.Ma[H.A.Zb];
                    if (!L || L === D) {
                      var P,
                        R = Vc("google_tag_data", {});
                      R.td || (R.td = {});
                      P = R.td;
                      var U = Bb(u.Cc, null);
                      Bb(u.Ma, U);
                      var X = [],
                        ea;
                      for (ea in P)
                        P.hasOwnProperty(ea) &&
                          EC(G, P[ea], U).length &&
                          X.push(ea);
                      X.length &&
                        (CC(G, D, X), sb("TAGGING", yC[A.readyState] || 14));
                      P[D] = U;
                    }
                  }
                }
                f(d.D.id, b, d.J, u);
              } catch (va) {
                var ja = d.messageContext.eventId;
                fD();
                eD(ja, r, "4");
              }
            };
          if (b === "gtag.get") v();
          else {
            var w = function () {
              en(e.U, v);
            };
            FA(d.D.destinationId)
              ? (GA(d.D.destinationId) ||
                  UA(
                    d.D.destinationId,
                    Wj(u),
                    {
                      source: 3,
                      fromContainerExecution:
                        d.messageContext.fromContainerExecution,
                    },
                    void 0,
                    !0,
                    function () {
                      HA(d.D.destinationId, 3);
                    }
                  ),
                JA(d.D.destinationId, w))
              : w();
          }
        }
      }
    },
    jD = function (a, b) {
      if (b.type !== "require") {
        var c = void 0;
        b.type === "event" && (c = b.args[1]);
        if (b.D)
          for (var d = hD(a, b.D).J[b.type] || [], e = 0; e < d.length; e++)
            d[e](c);
        else
          for (var f in a.destinations)
            if (a.destinations.hasOwnProperty(f)) {
              var g = a.destinations[f];
              if (g && g.J)
                for (var h = g.J[b.type] || [], k = 0; k < h.length; k++)
                  h[k](c);
            }
      }
    };
  gD.prototype.register = function (a, b, c, d) {
    var e = hD(this, a);
    e.status !== 3 &&
      ((e.M = b),
      (e.status = 3),
      (e.U = hn(c)),
      kD(this, a, d || {}),
      this.flush());
  };
  gD.prototype.push = function (a, b, c, d) {
    c !== void 0 &&
      (hD(this, c).status === 1 &&
        ((hD(this, c).status = 2), this.push("require", [{}], c, {})),
      hD(this, c).D && (d.deferrable = !1),
      d.eventMetadata || (d.eventMetadata = {}),
      d.eventMetadata[J.H.qg] || (d.eventMetadata[J.H.qg] = [c.destinationId]),
      d.eventMetadata[J.H.dj] || (d.eventMetadata[J.H.dj] = [c.id]));
    var e = Sb();
    this.commands.push(new GC(a, e, c, b, d));
    d.deferrable || this.flush();
  };
  gD.prototype.flush = function (a) {
    for (
      var b = this, c = [], d = !1, e = {};
      this.commands.length;
      e = { Jn: void 0 }
    ) {
      var f = this.commands[0],
        g = f.D;
      if (f.messageContext.deferrable)
        !g || hD(this, g).D
          ? ((f.messageContext.deferrable = !1), this.commands.push(f))
          : c.push(f),
          this.commands.shift();
      else {
        switch (f.type) {
          case "require":
            if (hD(this, g).status !== 3 && !a) {
              this.commands.push.apply(this.commands, c);
              return;
            }
            break;
          case "set":
            var h = f.args[0];
            bD(h);
            lD(h);
            Lb(h, function (w, y) {
              Bb(bc(w, y), b.D);
            });
            rC(h, !0);
            break;
          case "event":
            e.Jn = f.args[1];
            var k = mD(
                f.args[0],
                (function () {
                  return function () {};
                })(e)
              ),
              m = k[H.A.Zb];
            (m && m !== g.id) || rC(k);
            iD(this, e.Jn, k, f);
            break;
          case "get":
            var p = {},
              q = ((p[H.A.Lf] = f.args[0]), (p[H.A.Kf] = f.args[1]), p);
            iD(this, H.A.Mb, q, f);
            break;
          case "container_config":
            var r = hD(this, g),
              t = mD(f.args[0], function () {});
            rC(t, !0);
            r.D = !0;
            Bb(t, r.kb);
            d = !0;
            break;
          case "destination_config":
            var u = hD(this, g),
              v = mD(f.args[0], function () {});
            rC(v, !0);
            u.Za[g.id] || (u.Za[g.id] = {});
            u.D = !0;
            Bb(v, u.Za[g.id]);
            d = !0;
            break;
          case "reset_container_config":
            hD(this, g).kb = {};
            break;
          case "reset_target_config":
            hD(this, g).Za[g.id] = {};
        }
        this.commands.shift();
        jD(this, f);
      }
    }
    this.commands.push.apply(this.commands, c);
    d && this.flush();
  };
  var kD = function (a, b, c) {
    var d = Bb(c, null);
    Bb(hD(a, b).mb, d);
    hD(a, b).mb = d;
  };
  function mD(a, b) {
    var c = {};
    Lb(a, function (d, e) {
      Bb(bc(d, e), c);
    });
    bD(c, b);
    lD(c);
    return c;
  }
  function lD(a) {
    if (mA()) {
      var b = !1,
        c = n(new Set([H.A.yc, H.A.wc])),
        d = c.next(),
        e;
      try {
        for (; !d.done; d = c.next()) {
          var f = d.value;
          a[f] !== void 0 && ((b = !0), delete a[f]);
        }
      } finally {
        d && !d.done && (e = c.return) && e.call(c);
      }
      b &&
        !aj(18, function () {
          return !1;
        }) &&
        (Zi(18, !0),
        window.console &&
          window.console.log &&
          window.console.log(
            "Google Tag Manager: Server-side GTM parameters (transport_url/server_container_url) are not permitted on this domain and have been ignored."
          ),
        S(197));
    }
  }
  var nD = function () {
      this.D = new gD();
      this.J = !1;
    },
    oD = function (a, b, c, d, e) {
      var f = uC(d, e.isGtmEvent);
      f && (a.J && (e.deferrable = !0), a.D.push("event", [c, b], f, e));
    };
  nD.prototype.flush = function () {
    this.D.flush();
  };
  var pD;
  function qD() {
    pD || (pD = new nD());
    return pD;
  }
  function rD(a, b, c, d) {
    var e = qD(),
      f = uC(c, d.isGtmEvent);
    f && e.D.push("get", [a, b], f, d);
  }
  function sD(a, b, c) {
    var d = qD(),
      e = uC(a, c.isGtmEvent);
    e && d.D.push("container_config", [b], e, c);
  }
  function tD(a, b, c) {
    var d = qD(),
      e = uC(a, c.isGtmEvent);
    e && d.D.push("destination_config", [b], e, c);
  }
  function uD(a) {
    var b = qD(),
      c = uC(a, !0);
    c && b.D.push("reset_container_config", [], c, {});
  }
  function vD(a) {
    var b = qD(),
      c = uC(a, !0);
    c && b.D.push("reset_target_config", [], c, {});
  }
  function wD(a) {
    var b = qD(),
      c = uC(a, !0);
    return c ? hD(b.D, c).mb : {};
  }
  function xD(a) {
    return qD().D.D[a];
  }
  function yD(a) {
    var b = qD(),
      c = uC(a, !0);
    return c ? hD(b.D, c).D : !1;
  }
  function zD(a, b) {
    a.hasOwnProperty("gtm.uniqueEventId") ||
      Object.defineProperty(a, "gtm.uniqueEventId", { value: ro() });
    b.eventId = a["gtm.uniqueEventId"];
    b.priorityId = a["gtm.priorityId"];
    return { eventId: b.eventId, priorityId: b.priorityId };
  }
  function AD(a) {
    var b = n([H.A.wc, H.A.yc]),
      c = b.next(),
      d;
    try {
      for (; !c.done; c = b.next()) {
        var e = c.value,
          f = (a && a[e]) || xD(e);
        if (f) return f;
      }
    } finally {
      c && !c.done && (d = b.return) && d.call(b);
    }
  }
  function BD(a) {
    return !a.isGtmEvent ||
      (a.eventMetadata &&
        a.eventMetadata[J.H.Ac] &&
        a.eventMetadata[J.H.Gb] !== nm())
      ? !1
      : !0;
  }
  var CD = new (function () {
    this.D = !1;
  })();
  var DD = function () {
    this.messages = [];
    this.listeners = [];
    this.D = Mf(71, 20);
  };
  DD.prototype.enqueue = function (a, b, c) {
    var d = this.messages.length + 1,
      e = c.priorityQueue ? [].concat(xa(c.priorityQueue), [d]) : [d];
    if (Ru() && e.length > this.D) S(200);
    else {
      a["gtm.uniqueEventId"] = b;
      a["gtm.priorityId"] = d;
      a["gtm.priorityQueue"] = e;
      var f = ma(Object, "assign").call(Object, {}, c, {
          eventId: b,
          priorityId: d,
          fromContainerExecution: !0,
          priorityQueue: e,
        }),
        g = {
          message: a,
          notBeforeEventId: b,
          priorityId: d,
          messageContext: f,
        };
      this.messages.push(g);
      for (var h = 0; h < this.listeners.length; h++)
        try {
          this.listeners[h](g);
        } catch (k) {}
    }
  };
  DD.prototype.listen = function (a) {
    this.listeners.push(a);
  };
  DD.prototype.get = function () {
    for (var a = {}, b = 0; b < this.messages.length; b++) {
      var c = this.messages[b],
        d = a[c.notBeforeEventId];
      d || ((d = []), (a[c.notBeforeEventId] = d));
      d.push(c);
    }
    return a;
  };
  DD.prototype.prune = function (a) {
    for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
      var e = this.messages[d];
      e.notBeforeEventId === a ? b.push(e) : c.push(e);
    }
    this.messages = c;
    return b;
  };
  function ED(a, b, c) {
    c.eventMetadata = c.eventMetadata || {};
    c.eventMetadata[J.H.Gb] = Ru() ? nm() : E(6);
    FD().enqueue(a, b, c);
  }
  function FD() {
    return ko("mb", function () {
      return new DD();
    });
  }
  var HD = function (a, b) {
      var c = GD;
      b = String(b).split(",");
      for (var d = 0; d < b.length; d++) {
        var e = c.M[b[d]] || [];
        c.M[b[d]] = e;
        e.indexOf(a) < 0 && e.push(a);
      }
    },
    ID = function (a, b) {
      for (
        var c = GD, d = [], e = [], f = {}, g = 0;
        g < a.length;
        f = { bk: void 0, Gj: void 0, Hj: void 0 }, g++
      ) {
        var h = a[g];
        if (h.indexOf("-") >= 0) {
          if (((f.bk = uC(h, b)), f.bk)) {
            var k = lm();
            Hb(
              k,
              (function (w) {
                return function (y) {
                  return w.bk.destinationId === y;
                };
              })(f)
            )
              ? d.push(h)
              : e.push(h);
          }
        } else {
          if (Ru()) {
            var m = c.J[h] || [];
            f.Hj = {};
            m.forEach(
              (function (w) {
                return function (y) {
                  w.Hj[y] = !0;
                };
              })(f)
            );
            for (var p = lm(), q = 0; q < p.length; q++)
              f.Hj[p[q]] && d.push(p[q]);
          } else {
            var r = c.D[h] || [];
            f.Gj = {};
            r.forEach(
              (function (w) {
                return function (y) {
                  w.Gj[y] = !0;
                };
              })(f)
            );
            for (var t = om(), u = 0; u < t.length; u++)
              if (f.Gj[t[u]]) {
                d = d.concat(lm());
                break;
              }
          }
          var v = c.M[h] || [];
          v.length && (d = d.concat(v));
        }
      }
      return { Rj: d, wt: e };
    },
    JD = function (a) {
      Lb(GD.D, function (b, c) {
        var d = c.indexOf(a);
        d >= 0 && c.splice(d, 1);
      });
    },
    KD = function (a) {
      Lb(GD.J, function (b, c) {
        var d = c.indexOf(a);
        d >= 0 && c.splice(d, 1);
      });
    },
    LD = function (a) {
      Lb(GD.M, function (b, c) {
        var d = c.indexOf(a);
        d >= 0 && c.splice(d, 1);
      });
    },
    GD = new (function () {
      this.D = {};
      this.M = {};
      this.J = {};
    })();
  function MD(a, b, c) {
    var d = Bb(a, null);
    d.eventId = void 0;
    d.inheritParentConfig = void 0;
    Object.keys(b).some(function (f) {
      return b[f] !== void 0;
    }) && S(136);
    var e = Bb(b, null);
    Bb(c, e);
    ED(KC(om()[0], e), a.eventId, d);
  }
  function ND(a, b, c, d) {
    var e = {},
      f =
        ((e[H.A.uc] = H.A.ya),
        (e["gtm.configContainerId"] = a.id),
        (e["gtm.configParameters"] = b),
        (e["gtm.uniqueEventId"] = d.eventId),
        e);
    d.priorityId && (f["gtm.priorityId"] = d.priorityId);
    c.priorityQueue && (f["gtm.priorityQueue"] = c.priorityQueue);
    c.noTargetGroup &&
      ((c.eventMetadata = c.eventMetadata || {}),
      (c.eventMetadata[J.H.Iq] = !0));
    c.eventMetadata && (f["gtm.eventMetadata"] = c.eventMetadata);
    a.Ec() &&
      ((f["gtm.configContainerId"] = om()[0]),
      (f["gtm.originalConfigTargetId"] = a.id));
    return f;
  }
  function OD(a, b, c) {
    if (Hf(11) && !c && !a[H.A.Qd]) {
      var d = aj(2, function () {
        return !1;
      });
      Zi(2, !0);
      gC(d, a, b);
      if (d) return !0;
    }
    return !1;
  }
  function PD(a, b) {
    var c = {},
      d = ((c.event = a), c);
    b &&
      ((d.eventModel = Bb(b, null)),
      b[H.A.Hf] && (d.eventCallback = b[H.A.Hf]),
      b[H.A.nh] && (d.eventTimeout = b[H.A.nh]));
    return d;
  }
  function QD(a, b) {
    var c = a && a[H.A.Zb];
    c === void 0 && ((c = fA(H.A.Zb, 2)), c === void 0 && (c = "default"));
    if (Eb(c) || Array.isArray(c)) {
      var d;
      d = b.isGtmEvent
        ? Eb(c)
          ? [c]
          : c
        : c.toString().replace(/\s+/g, "").split(",");
      var e = ID(d, b.isGtmEvent),
        f = e.Rj,
        g = e.wt;
      if (g.length)
        for (var h = AD(a), k = 0; k < g.length; k++) {
          var m = uC(g[k], b.isGtmEvent);
          if (m) {
            var p = m.destinationId,
              q = void 0;
            ((q = fm(m.destinationId)) == null ? void 0 : q.state) === 0 ||
              UA(p, h, {
                source: 3,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      var r = f.concat(g);
      return { Rj: vC(f, b.isGtmEvent), Mr: vC(r, b.isGtmEvent) };
    }
  }
  var RD = {},
    SD =
      ((RD.config = function (a, b) {
        var c = zD(a, b),
          d;
        a: {
          if (!(a.length < 2) && Eb(a[1])) {
            var e = {};
            if (a.length > 2) {
              if ((a[2] !== void 0 && !Ab(a[2])) || a.length > 3) {
                d = void 0;
                break a;
              }
              e = a[2];
            }
            var f = uC(a[1], b.isGtmEvent);
            if (f) {
              d = { target: f, params: e };
              break a;
            }
          }
          d = void 0;
        }
        var g = d;
        if (g) {
          var h = g.target,
            k = g.params,
            m;
          a: {
            if (!Hf(7)) {
              var p = qm(rm());
              if (Hm(p)) {
                var q = p.parent,
                  r = q.isDestination;
                m = { Et: qm(q), ot: r };
                break a;
              }
            }
            m = void 0;
          }
          var t = m,
            u = t == null ? void 0 : t.Et,
            v = t == null ? void 0 : t.ot;
          nB(c.eventId, "gtag.config");
          var w,
            y = h.destinationId;
          if (h.Ec() ? lm().indexOf(y) !== -1 : om().indexOf(y) !== -1)
            a: {
              if (u && (S(128), v && S(130), b.inheritParentConfig)) {
                var z;
                var C = $i(5);
                if (C) MD(b, C, k), (z = !1);
                else {
                  var D = $i(4);
                  (!k[H.A.Qd] && (Ru() || Hf(11)) && D) || Zi(4, Bb(k, null));
                  z = !0;
                }
                z && u.containers && u.containers.join(",");
                w = void 0;
                break a;
              }
              var G = !Hf(45),
                F = !Zb(h.id, "GTM-");
              G &&
                F &&
                (Object.keys(k).length === 0 ? qC(jC.X.Gk) : qC(jC.X.Hk),
                Wm() && qC(jC.X.Fk),
                $i(23) && qC(jC.X.Ik));
              var I = hC;
              fl.J && (I.D === 1 && (dj.D.mcc = !1), (I.D = 2));
              if (Ru() || !OD(k, b, h.Ec())) {
                CD.D || S(43);
                if (!Ru()) {
                  if (!b.noTargetGroup) {
                    var L = h.id;
                    if (h.Ec()) LD(L), HD(L, k[H.A.Kd] || "default");
                    else {
                      JD(L);
                      var P = k[H.A.Kd] || "default",
                        R = GD;
                      P = P.toString().split(",");
                      for (var U = 0; U < P.length; U++) {
                        var X = R.D[P[U]] || [];
                        R.D[P[U]] = X;
                        X.indexOf(L) < 0 && X.push(L);
                      }
                    }
                  }
                  delete k[H.A.Kd];
                }
                var ea = b.eventMetadata || {};
                ea.hasOwnProperty(J.H.dd) ||
                  (ea[J.H.dd] = !b.fromContainerExecution);
                b.eventMetadata = ea;
                delete k[H.A.Hf];
                if (Ru()) {
                  w = ND(h, k, b, c);
                  break a;
                }
                var ja = !!k[H.A.Qd];
                delete k[H.A.Qd];
                var va = lm(),
                  Ga = uD,
                  ka = sD;
                h.Ec() && ((va = [h.id]), (Ga = vD), (ka = tD));
                for (var ia = 0; ia < va.length; ia++) {
                  ja || Ga(va[ia]);
                  var ab = yD(va[ia]);
                  ka(va[ia], Bb(k, null), Bb(b, null));
                  if (!ab || !ja) {
                    var vb = H.A.ya,
                      gb = Bb(k, null),
                      wb = va[ia],
                      Ub = Bb(b, null);
                    oD(qD(), vb, gb, wb, Ub);
                  }
                }
              }
              w = void 0;
            }
          else
            a: {
              if (!b.inheritParentConfig && !k[H.A.Vc]) {
                var ed = AD(k),
                  Vb = h.destinationId;
                if (h.Ec())
                  UA(Vb, ed, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
                else if (u !== void 0 && u.containers.indexOf(Vb) !== -1) {
                  var hc = $i(4),
                    hg = $i(5);
                  hc ? MD(b, k, hc) : hg || Zi(5, Bb(k, null));
                } else if (
                  (OA(Vb, ed, !0, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  }),
                  Ru())
                ) {
                  w = ND(h, k, b, c);
                  break a;
                }
              }
              w = void 0;
            }
          return w;
        }
      }),
      (RD.consent = function (a, b) {
        if (a.length === 3) {
          S(39);
          var c = zD(a, b),
            d = a[1],
            e = {},
            f = Kn(a[2]),
            g;
          for (g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              e[g] =
                g === H.A.Vg
                  ? Array.isArray(h)
                    ? NaN
                    : Number(h)
                  : g === H.A.nc
                  ? (Array.isArray(h) ? h : [h]).map(Ln)
                  : Mn(h);
            }
          b.fromContainerExecution ||
            (e[H.A.ma] && S(139), e[H.A.Wa] && S(140));
          d === "default"
            ? lp(e)
            : d === "update"
            ? np(e, c)
            : d === "declare" && b.fromContainerExecution && kp(e);
        }
      }),
      (RD.container_config = function (a, b) {
        if (BD(b) && a.length === 3 && Eb(a[1]) && Ab(a[2])) {
          var c = a[2],
            d = uC(a[1], !0);
          d && sD(d.destinationId, c, Bb(b, null));
        }
      }),
      (RD.destination_config = function (a, b) {
        if (BD(b) && a.length === 3 && Eb(a[1]) && Ab(a[2])) {
          var c = a[2],
            d = uC(a[1], !0);
          if (d) {
            if (Ru()) {
              if (!b.noTargetGroup) {
                var e = d.id;
                if (d.Ec()) LD(e), HD(e, c[H.A.Kd] || "default");
                else {
                  KD(e);
                  var f = c[H.A.Kd] || "default",
                    g = GD;
                  f = String(f).split(",");
                  for (var h = 0; h < f.length; h++) {
                    var k = g.J[f[h]] || [];
                    g.J[f[h]] = k;
                    k.indexOf(e) < 0 && k.push(e);
                  }
                }
              }
              delete c[H.A.Kd];
            }
            tD(d.id, c, Bb(b, null));
          }
        }
      }),
      (RD.event = function (a, b) {
        var c = a[1];
        if (!(a.length < 2) && Eb(c)) {
          var d = void 0;
          if (a.length > 2) {
            if ((!Ab(a[2]) && a[2] !== void 0) || a.length > 3) return;
            d = a[2];
          }
          var e = PD(c, d),
            f = zD(a, b),
            g = f.eventId,
            h = f.priorityId;
          e["gtm.uniqueEventId"] = g;
          h && (e["gtm.priorityId"] = h);
          b.priorityQueue && (e["gtm.priorityQueue"] = b.priorityQueue);
          if (c === "optimize.callback")
            return (e.eventModel = e.eventModel || {}), e;
          var k = QD(d, b);
          if (k) {
            var m = k.Rj,
              p = k.Mr,
              q = p.map(function (P) {
                return P.id;
              }),
              r = p.map(function (P) {
                return P.destinationId;
              }),
              t = m.map(function (P) {
                return P.id;
              }),
              u = n(lm()),
              v = u.next(),
              w;
            try {
              for (; !v.done; v = u.next()) {
                var y = v.value;
                r.indexOf(y) < 0 && t.push(y);
              }
            } finally {
              v && !v.done && (w = u.return) && w.call(u);
            }
            nB(g, c);
            var z = n(t),
              C = z.next(),
              D;
            try {
              for (; !C.done; C = z.next()) {
                var G = C.value,
                  F = Bb(b, null),
                  I = Bb(d, null);
                delete I[H.A.Hf];
                var L = F.eventMetadata || {};
                L.hasOwnProperty(J.H.dd) ||
                  (L[J.H.dd] = !F.fromContainerExecution);
                L[J.H.dj] = q.slice();
                L[J.H.qg] = r.slice();
                F.eventMetadata = L;
                oD(qD(), c, I, G, F);
              }
            } finally {
              C && !C.done && (D = z.return) && D.call(z);
            }
            e.eventModel = e.eventModel || {};
            q.length > 0
              ? (e.eventModel[H.A.Zb] = q.join(","))
              : delete e.eventModel[H.A.Zb];
            CD.D || S(43);
            b.noGtmEvent === void 0 &&
              b.eventMetadata &&
              b.eventMetadata[J.H.ln] &&
              (b.noGtmEvent = !0);
            e.eventModel[H.A.Uc] && (b.noGtmEvent = !0);
            return b.noGtmEvent ? void 0 : e;
          }
        }
      }),
      (RD.get = function (a, b) {
        S(53);
        if (a.length === 4 && Eb(a[1]) && Eb(a[2]) && Db(a[3])) {
          var c = uC(a[1], b.isGtmEvent),
            d = String(a[2]),
            e = a[3];
          if (c) {
            CD.D || S(43);
            var f = AD();
            if (
              Hb(lm(), function (h) {
                return c.destinationId === h;
              })
            ) {
              zD(a, b);
              var g = {};
              Bb(((g[H.A.Lf] = d), (g[H.A.Kf] = e), g), null);
              rD(
                d,
                function (h) {
                  kd(function () {
                    e(h);
                  });
                },
                c.id,
                b
              );
            } else
              UA(c.destinationId, f, {
                source: 4,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      }),
      (RD.js = function (a, b) {
        var c;
        if (a.length === 2 && a[1].getTime) {
          CD.D = !0;
          var d = zD(a, b),
            e = d.eventId,
            f = d.priorityId,
            g = {};
          c =
            ((g.event = "gtm.js"),
            (g["gtm.start"] = a[1].getTime()),
            (g["gtm.uniqueEventId"] = e),
            (g["gtm.priorityId"] = f),
            g);
        } else c = void 0;
        return c;
      }),
      (RD.policy = function (a) {
        if (a.length === 3 && Eb(a[1]) && Db(a[2])) {
          Hy(a[1], a[2]);
          S(74);
          if (a[1] === "all") {
            S(75);
            var b = !1;
            try {
              b = a[2](E(5), "unknown", {});
            } catch (m) {}
            b || S(76);
          }
          if (O(610)) {
            var c = a[1] === "all";
            if (Dy.includes(a[1]) || c) {
              var d = c ? "a" : "i",
                e = n(c ? Dy : [a[1]]),
                f = e.next(),
                g;
              try {
                for (; !f.done; f = e.next()) {
                  var h = f.value,
                    k = !1;
                  try {
                    k = a[2](E(5), h, {});
                  } catch (m) {}
                  k || (Fy || (Fy = new Ey()), Fy.ai(h, d));
                }
              } finally {
                f && !f.done && (g = e.return) && g.call(e);
              }
            }
          }
        } else S(73);
      }),
      (RD.reset_target_config = function (a, b) {
        if (BD(b) && a.length === 2 && Eb(a[1])) {
          var c = uC(a[1], !0);
          c && vD(c.id);
        }
      }),
      (RD.set = function (a, b) {
        var c = void 0;
        a.length === 2 && Ab(a[1])
          ? (c = Bb(a[1], null))
          : a.length === 3 &&
            Eb(a[1]) &&
            ((c = {}),
            Ab(a[2]) || Array.isArray(a[2])
              ? (c[a[1]] = Bb(a[2], null))
              : (c[a[1]] = a[2]));
        if (c) {
          Zi(23, !0);
          var d = zD(a, b),
            e = d.eventId,
            f = d.priorityId;
          Bb(c, null);
          E(5);
          var g = Bb(c, null);
          qD().D.push("set", [g], void 0, b);
          c["gtm.uniqueEventId"] = e;
          f && (c["gtm.priorityId"] = f);
          delete c.event;
          b.overwriteModelFields = !0;
          return c;
        }
      }),
      RD),
    TD = {},
    UD = ((TD.policy = !0), TD);
  var WD = function (a) {
    if (VD(a)) return a;
    this.value = a;
  };
  WD.prototype.getUntrustedMessageValue = function () {
    return this.value;
  };
  var VD = function (a) {
    return !a || yb(a) !== "object" || Ab(a)
      ? !1
      : "getUntrustedMessageValue" in a;
  };
  WD.prototype.getUntrustedMessageValue = WD.prototype.getUntrustedMessageValue;
  function uE(a) {}
  var vE = function () {
    var a = this;
    this.loaded = !1;
    this.listeners = [];
    if (A.readyState === "complete") this.onLoad();
    else
      id(x, "load", function () {
        return void a.onLoad();
      });
  };
  vE.prototype.onLoad = function () {
    if (!this.loaded) {
      this.loaded = !0;
      for (var a = 0; a < this.listeners.length; a++) kd(this.listeners[a]);
    }
  };
  var xE = function (a) {
      var b = wE;
      b.loaded ? kd(a) : b.listeners.push(a);
    },
    wE = new vE();
  var yE = function () {
      this.aa = 0;
      this.J = {};
      this.D = [];
      this.M = [];
      this.fa = this.U = this.la = !1;
    },
    AE = function (a, b, c) {
      var d = zE;
      a.eventCallback = b;
      c && (a.eventTimeout = c);
      return d.push(a);
    },
    BE = function (a, b) {
      if (!Fb(b) || b < 0) b = 0;
      var c = qo(),
        d = 0,
        e = !1,
        f = void 0;
      f = x.setTimeout(function () {
        e || ((e = !0), a());
        f = void 0;
      }, b);
      return function () {
        var g = c ? c.subscribers : 1;
        ++d === g &&
          (f && (x.clearTimeout(f), (f = void 0)), e || (a(), (e = !0)));
      };
    },
    DE = function (a) {
      var b;
      if (a.M.length) b = a.M.shift();
      else if (a.D.length) b = a.D.shift();
      else return;
      var c;
      var d = b;
      if (a.la || !CE(d.message)) c = d;
      else {
        a.la = !0;
        var e = d.message["gtm.uniqueEventId"],
          f,
          g;
        typeof e === "number"
          ? ((f = e - 2), (g = e - 1))
          : ((f = ro()), (g = ro()), (d.message["gtm.uniqueEventId"] = ro()));
        var h = {},
          k = {
            message:
              ((h.event = "gtm.init_consent"), (h["gtm.uniqueEventId"] = f), h),
            messageContext: { eventId: f },
          },
          m = {},
          p = {
            message: ((m.event = "gtm.init"), (m["gtm.uniqueEventId"] = g), m),
            messageContext: { eventId: g },
          };
        a.D.unshift(p, d);
        c = k;
      }
      return c;
    },
    GE = function (a) {
      a.fa || S(196);
      for (var b = !1, c; !a.U && (c = DE(a)); ) {
        a.U = !0;
        var d = cA;
        delete d.D.eventModel;
        $z(d);
        var e = c,
          f = e.message,
          g = e.messageContext;
        if (f == null) a.U = !1;
        else {
          g.fromContainerExecution && dA();
          try {
            if (Db(f))
              try {
                f.call(eA);
              } catch (P) {}
            else if (Array.isArray(f)) {
              if (Eb(f[0])) {
                var h = f[0].split("."),
                  k = h.pop(),
                  m = f.slice(1),
                  p = fA(h.join("."), 2);
                if (p != null)
                  try {
                    p[k].apply(p, m);
                  } catch (P) {}
              }
            } else {
              var q = void 0;
              if (Mb(f))
                a: {
                  if (f.length && Eb(f[0])) {
                    var r = SD[f[0]];
                    if (r && (!g.fromContainerExecution || !UD[f[0]])) {
                      q = r(f, g);
                      break a;
                    }
                  }
                  q = void 0;
                }
              else q = f;
              if (q) {
                var t;
                var u = void 0,
                  v = void 0,
                  w = q,
                  y = w._clear || g.overwriteModelFields,
                  z = n(Object.keys(w)),
                  C = z.next();
                try {
                  for (; !C.done; C = z.next())
                    (u = C.value),
                      u !== "_clear" &&
                        (y && cA.set(u, void 0), cA.set(u, w[u]));
                } finally {
                  C && !C.done && (v = z.return) && v.call(z);
                }
                O(592) && uE(w);
                $i(11) || Zi(11, w["gtm.start"]);
                var D = w["gtm.uniqueEventId"];
                w.event
                  ? (typeof D !== "number" &&
                      ((D = ro()),
                      (w["gtm.uniqueEventId"] = D),
                      cA.set("gtm.uniqueEventId", D)),
                    (t = JB(w)))
                  : (t = !1);
                b = t || b;
              }
            }
          } finally {
            g.fromContainerExecution && $z(cA, !0);
            var G = f["gtm.uniqueEventId"];
            if (typeof G === "number") {
              for (
                var F = a, I = F.J[String(G)] || [], L = 0;
                L < I.length;
                L++
              )
                F.M.push(EE(I[L]));
              I.length && F.M.sort(FE);
              delete F.J[String(G)];
              G > a.aa && (a.aa = G);
            }
            a.U = !1;
          }
        }
      }
      return !b;
    },
    HE = function () {
      var a = zE;
      a.fa && S(195);
      a.fa = !0;
      if (fl.D) {
        var b = !Hf(51),
          c = zz();
        xz(c, { stage: dz.Z.Wg });
        if (b) {
          var d = yz(c, { stage: dz.Z.Nk }, dz.Z.ii);
          d !== void 0 && (c.D.Y = d);
        }
        var e = a.D.length;
        zz().D.C = e;
      }
      GE(a);
      if (fl.D) {
        var f = zz(),
          g = yz(f, { stage: dz.Z.Kk }, dz.Z.Wg);
        g !== void 0 && (f.D.B = g);
      }
      try {
        var h = x[E(19)],
          k = E(5),
          m = h.hide;
        if (m && m[k] !== void 0 && m.end) {
          m[k] = !1;
          var p = !0,
            q;
          for (q in m)
            if (m.hasOwnProperty(q) && m[q] === !0) {
              p = !1;
              break;
            }
          p && (m.end(), (m.end = null));
        }
      } catch (r) {
        E(5);
      }
    },
    IE = function (a, b) {
      if (a.aa < b.notBeforeEventId) {
        var c = String(b.notBeforeEventId);
        a.J[c] = a.J[c] || [];
        a.J[c].push(b);
      } else
        a.M.push(EE(b)),
          a.M.sort(FE),
          md(function () {
            a.U || GE(a);
          });
    };
  yE.prototype.bind = function () {
    function a(h) {
      var k = {};
      if (VD(h)) {
        var m = h;
        h = VD(m) ? m.getUntrustedMessageValue() : void 0;
        k.fromContainerExecution = !0;
      }
      return { message: h, messageContext: k };
    }
    var b = this,
      c = Vc(E(19), []),
      d = po();
    d.pruned === !0 && S(83);
    this.J = FD().get();
    FD().listen(function (h) {
      IE(b, h);
    });
    d.subscribers = (d.subscribers || 0) + 1;
    var e = c.push,
      f = this;
    c.push = function () {
      var h;
      lo();
      if (jo.D.SANDBOXED_JS_SEMAPHORE > 0) {
        h = [];
        for (var k = 0; k < arguments.length; k++) h[k] = new WD(arguments[k]);
      } else h = [].slice.call(arguments, 0);
      var m = h.map(function (t) {
        return a(t);
      });
      f.D.push.apply(f.D, m);
      var p = e.apply(c, h),
        q = Math.max(100, Mf(1, 300));
      if (this.length > q)
        for (S(4), d.pruned = !0; this.length > q; ) this.shift();
      var r = typeof p !== "boolean" || p;
      return GE(f) && r;
    };
    var g = c.slice(0).map(function (h) {
      return a(h);
    });
    this.D.push.apply(this.D, g);
    Hf(51) || (fl.D && Cz(), kd(JE));
    eC(function () {
      if (!d.gtmDom) {
        d.gtmDom = !0;
        var h = {};
        c.push(((h.event = "gtm.dom"), h));
      }
    });
    xE(function () {
      if (!d.gtmLoad) {
        d.gtmLoad = !0;
        var h = {};
        c.push(((h.event = "gtm.load"), h));
      }
    });
  };
  yE.prototype.push = function (a) {
    return x[E(19)].push(a);
  };
  var zE = new yE();
  function FE(a, b) {
    var c = a.messageContext,
      d = b.messageContext;
    if (c.eventId !== d.eventId) return c.eventId - d.eventId;
    var e, f, g;
    a: {
      for (
        var h = (e = c.priorityQueue) != null ? e : [c.priorityId],
          k = (f = d.priorityQueue) != null ? f : [d.priorityId],
          m = Math.min(h.length, k.length),
          p = 0;
        p < m;
        p++
      )
        if (h[p] !== k[p]) {
          g = h[p] - k[p];
          break a;
        }
      g = h.length - k.length;
    }
    return g;
  }
  function CE(a) {
    if (a == null || typeof a !== "object") return !1;
    if (a.event) return !0;
    if (Mb(a)) {
      var b = a[0];
      if (b === "config" || b === "event" || b === "js" || b === "get")
        return !0;
    }
    return !1;
  }
  function EE(a) {
    return { message: a.message, messageContext: a.messageContext };
  }
  function KE(a, b, c) {
    return AE(a, b, c);
  }
  function LE(a, b) {
    return BE(a, b);
  }
  function JE() {
    HE();
  }
  function ME(a) {
    return zE.push(a);
  }
  var NE = function () {};
  NE.prototype.bind = function () {
    var a,
      b = Jj(x.location.href);
    (a = b.hostname + b.pathname) && hj("dl", encodeURIComponent(a));
    var c;
    var d = E(5);
    if (d) {
      var e = Hf(7) ? 1 : 0,
        f = Am(),
        g = f && f.fromContainerExecution ? 1 : 0,
        h = (f && f.source) || 0,
        k = E(6);
      c = d + ";" + k + ";" + g + ";" + h + ";" + e;
    } else c = void 0;
    var m = c;
    m && hj("tdp", m);
    var p = wq(!0);
    p !== void 0 && hj("frm", String(p));
  };
  var OE = new NE();
  var PE = function () {
      this.D = Xk();
      this.J = void 0;
    },
    QE = function (a, b) {
      return Zk(a, function (c) {
        return c.nb > 0 ? (b ? c.nb + "_" + Wk(c) : String(c.nb)) : void 0;
      });
    };
  PE.prototype.bind = function () {
    var a = this;
    if (Wo() || fl.J)
      hj(
        "csp",
        function () {
          var b = QE(a.D, !0);
          $k(a.D);
          return b;
        },
        !1
      ),
        hj(
          "mde",
          function () {
            var b = cl.D,
              c = QE(b, !1);
            $k(b);
            return c;
          },
          !1
        ),
        x.addEventListener("securitypolicyviolation", function (b) {
          if (b.disposition === "enforce") {
            S(179);
            var c = ml(b.effectiveDirective);
            if (c) {
              var d;
              a: {
                var e = b.blockedURI,
                  f = jl;
                if (fl.J && e) {
                  var g = il(c, e);
                  if (g) {
                    var h;
                    d = (h = kl(f, c)) == null ? void 0 : h[g];
                    break a;
                  }
                }
                d = void 0;
              }
              var k = d;
              if (k) {
                var m;
                a: {
                  try {
                    var p = new URL(b.blockedURI),
                      q = p.pathname.indexOf(";");
                    m =
                      q >= 0
                        ? p.origin + p.pathname.substring(0, q)
                        : p.origin + p.pathname;
                    break a;
                  } catch (G) {}
                  m = void 0;
                }
                var r = m;
                if (r) {
                  var t = n(k),
                    u = t.next(),
                    v;
                  try {
                    for (; !u.done; u = t.next()) {
                      var w = u.value;
                      if (!w.so) {
                        w.so = !0;
                        var y = {
                          eventId: w.eventId,
                          priorityId: w.priorityId,
                        };
                        if (Wo()) {
                          var z = y,
                            C = {
                              type: 1,
                              blockedUrl: r,
                              endpoint: w.endpoint,
                              violation: b.effectiveDirective,
                            };
                          if (Wo()) {
                            var D = bp("TAG_DIAGNOSTICS", {
                              eventId: z == null ? void 0 : z.eventId,
                              priorityId: z == null ? void 0 : z.priorityId,
                            });
                            D.tagDiagnostics = C;
                            Vo(D);
                          }
                        }
                        RE(a, w.destinationId, w.endpoint, c);
                      }
                    }
                  } finally {
                    u && !u.done && (v = t.return) && v.call(t);
                  }
                  ll(c, b.blockedURI);
                }
              }
            }
          }
        });
  };
  var RE = function (a, b, c, d) {
      al(a.D, b, c, 1, d);
      fj(dj, "csp", !0);
      fj(dj, "mde", !0);
      c !== 61 &&
        c !== 56 &&
        a.J === void 0 &&
        (a.J = x.setTimeout(function () {
          a.D.nb > 0 && pn(!1);
          a.J = void 0;
        }, 500));
    },
    SE = new PE();
  var TE = function () {
    this.sequenceNumber = 0;
  };
  TE.prototype.bind = function () {
    var a = this;
    UE(this);
    Hf(65) && hj("mtbl", "1");
    hj("v", "3");
    hj("t", "t");
    hj("pid", function () {
      return String(uk(qk.da.Yg));
    });
    hj("gtm", function () {
      return Nu();
    });
    hj("seq", function () {
      return String(++a.sequenceNumber);
    });
    hj("exp", function () {
      return iq();
    });
  };
  var UE = function (a) {
      if (uk(qk.da.Yg) === void 0) {
        var b = function () {
          tk(qk.da.Yg, Ib());
          a.sequenceNumber = 0;
        };
        b();
        ld(b, 864e5);
      } else
        wk(qk.da.Yg, function () {
          a.sequenceNumber = 0;
        });
      a.sequenceNumber = 0;
    },
    VE = new TE();
  function WE(a) {
    return function () {
      return x[a];
    };
  }
  var XE = {},
    YE =
      ((XE[14] = function () {
        var a;
        return (a = x.crypto) == null ? void 0 : a.getRandomValues;
      }),
      (XE[15] = function () {
        var a, b;
        return (a = x.crypto) == null
          ? void 0
          : (b = a.subtle) == null
          ? void 0
          : b.digest;
      }),
      (XE[1] = WE("fetch")),
      (XE[6] = WE("Map")),
      (XE[2] = function () {
        return Math.random;
      }),
      (XE[8] = function () {
        return ma(Object, "assign");
      }),
      (XE[9] = function () {
        return Object.entries;
      }),
      (XE[10] = function () {
        return Object.fromEntries;
      }),
      (XE[5] = WE("Promise")),
      (XE[16] = WE("queueMicrotask")),
      (XE[13] = WE("RegExp")),
      (XE[17] = WE("requestIdleCallback")),
      (XE[3] = function () {
        return Qc.sendBeacon;
      }),
      (XE[7] = WE("Set")),
      (XE[12] = function () {
        return String.prototype.endsWith;
      }),
      (XE[11] = function () {
        return String.prototype.startsWith;
      }),
      (XE[4] = WE("XMLHttpRequest")),
      XE),
    ZE = {},
    $E = ((ZE[15] = !0), ZE);
  var dF = /^(https?:)?\/\//;
  function yF() {}
  function zF() {
    Hf(62) &&
      (Hy("detect_link_click_events", function (a, b, c) {
        var d;
        return ((d = c.options) == null ? void 0 : d.waitForTags) !== !0;
      }),
      Hy("detect_form_submit_events", function (a, b, c) {
        var d;
        return ((d = c.options) == null ? void 0 : d.waitForTags) !== !0;
      }),
      Hy("detect_youtube_activity_events", function (a, b, c) {
        var d;
        return ((d = c.options) == null ? void 0 : d.fixMissingApi) !== !0;
      }));
  }
  var AF = function () {
    this.D = this.gppString = void 0;
  };
  AF.prototype.reset = function () {
    this.D = this.gppString = void 0;
  };
  var BF = new AF();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  Ut({
    ov: 0,
    nv: 1,
    kv: 2,
    dv: 3,
    lv: 4,
    fv: 5,
    mv: 6,
    hv: 7,
    jv: 8,
    bv: 9,
    gv: 10,
    pv: 11,
  }).map(function (a) {
    return Number(a);
  });
  Ut({ rv: 0, sv: 1, qv: 2 }).map(function (a) {
    return Number(a);
  });
  var CF = function (a, b, c, d) {
    $t.call(this);
    this.Vd = b;
    this.jd = c;
    this.Rb = d;
    this.La = new Map();
    this.Wd = 0;
    this.la = new Map();
    this.Da = new Map();
    this.aa = void 0;
    this.J = a;
  };
  ta(CF, $t);
  CF.prototype.M = function () {
    delete this.D;
    this.La.clear();
    this.la.clear();
    this.Da.clear();
    this.aa && (Wt(this.J, "message", this.aa), delete this.aa);
    delete this.J;
    delete this.Rb;
    $t.prototype.M.call(this);
  };
  var DF = function (a) {
      if (a.D) return a.D;
      a.jd && a.jd(a.J) ? (a.D = a.J) : (a.D = vq(a.J, a.Vd));
      var b;
      return (b = a.D) != null ? b : null;
    },
    FF = function (a, b, c) {
      if (DF(a))
        if (a.D === a.J) {
          var d = a.La.get(b);
          d && d(a.D, c);
        } else {
          var e = a.la.get(b);
          if (e && e.Qj) {
            EF(a);
            var f = ++a.Wd;
            a.Da.set(f, {
              be: e.be,
              ks: e.Yn(c),
              persistent: b === "addEventListener",
            });
            a.D.postMessage(e.Qj(c, f), "*");
          }
        }
    },
    EF = function (a) {
      a.aa ||
        ((a.aa = function (b) {
          if (b.source === a.D)
            try {
              var c;
              c = a.Rb ? a.Rb(b) : void 0;
              if (c) {
                var d = c.Ht,
                  e = a.Da.get(d);
                if (e) {
                  e.persistent || a.Da.delete(d);
                  var f;
                  (f = e.be) == null || f.call(e, e.ks, c.payload);
                }
              }
            } catch (g) {}
        }),
        Vt(a.J, "message", a.aa));
    };
  var GF = function (a, b) {
      var c = b.listener,
        d = (0, a.__gpp)("addEventListener", c);
      d && c(d, !0);
    },
    HF = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    IF = {
      Yn: function (a) {
        return a.listener;
      },
      Qj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          c
        );
      },
      be: function (a, b) {
        var c = b.__gppReturn;
        a(c.returnValue, c.success);
      },
    },
    JF = {
      Yn: function (a) {
        return a.listener;
      },
      Qj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      be: function (a, b) {
        var c = b.__gppReturn,
          d = c.returnValue.data;
        a == null || a(d, c.success);
      },
    };
  function KF(a) {
    var b = {};
    vf(a.data) ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Ht: b.__gppReturn.callId };
  }
  var LF = function (a, b) {
    var c;
    c = (b === void 0 ? {} : b).timeoutMs;
    $t.call(this);
    this.caller = new CF(
      a,
      "__gppLocator",
      function (d) {
        return typeof d.__gpp === "function";
      },
      KF
    );
    this.caller.La.set("addEventListener", GF);
    this.caller.la.set("addEventListener", IF);
    this.caller.La.set("removeEventListener", HF);
    this.caller.la.set("removeEventListener", JF);
    this.timeoutMs = c != null ? c : 500;
  };
  ta(LF, $t);
  LF.prototype.M = function () {
    this.caller.dispose();
    $t.prototype.M.call(this);
  };
  LF.prototype.addEventListener = function (a) {
    var b = this,
      c = pq(function () {
        a(MF, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    FF(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          var h;
          ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 ||
          e.pingData.gppVersion === "1" ||
          e.pingData.gppVersion === "1.0"
            ? (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 1,
                  gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                  applicableSections: [-1],
                },
              }))
            : Array.isArray(e.pingData.applicableSections)
            ? (g = e)
            : (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 2,
                  gppString:
                    "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                  applicableSections: [-1],
                },
              }));
          a(g, f);
        } catch (k) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (m) {
              a(NF, !0);
              return;
            }
          a(OF, !0);
        }
      },
    });
  };
  LF.prototype.removeEventListener = function (a) {
    FF(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var OF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    MF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    NF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function PF(a) {
    var b;
    if (!(b = a.pingData.signalStatus === "ready")) {
      var c = a.pingData.applicableSections;
      b = !c || (c.length === 1 && c[0] === -1);
    }
    if (b) {
      BF.gppString = a.pingData.gppString;
      var d = a.pingData.applicableSections.join(",");
      BF.D = d;
    }
  }
  function QF() {
    try {
      var a = new LF(x, { timeoutMs: -1 });
      DF(a.caller) && a.addEventListener(PF);
    } catch (b) {}
  }
  function Ay() {
    var a = [
        ["cv", E(1)],
        ["rv", E(14)],
        [
          "tc",
          AA.tags.filter(function (d) {
            return d;
          }).length,
        ],
      ],
      b = If(15);
    b && a.push(["x", b]);
    var c = iq();
    c && a.push(["tag_exp", c]);
    return a;
  }
  var RF = function () {
      var a = this;
      this.D = {};
      this.J = {};
      xy(function (b) {
        var c = b.eventId,
          d = b.je,
          e = [],
          f = a.D[c] || [];
        f.length && e.push(["hf", f.join(".")]);
        var g = a.J[c] || [];
        g.length && e.push(["ht", g.join(".")]);
        d && (delete a.D[c], delete a.J[c]);
        return e;
      });
    },
    SF = function () {
      var a = 0;
      return function (b) {
        switch (b) {
          case 1:
            a |= 1;
            break;
          case 2:
            a |= 2;
            break;
          case 3:
            a |= 4;
        }
        return a;
      };
    },
    TF;
  function UF() {
    return !1;
  }
  function VF() {
    var a = {};
    return function (b, c, d) {};
  }
  function WF() {
    var a = XF;
    return function (b, c, d) {
      YF(c);
      var e = sh(b) ? void 0 : 1,
        f = new kb();
      Lb(c, function (r, t) {
        var u = Vd(t, void 0, e);
        u === void 0 && t !== void 0 && S(44);
        f.set(r, u);
      });
      a.Tb(Pf());
      var g = d.event,
        h = {
          yn: Gy(b),
          eventId: g.id,
          priorityId: g.priorityId,
          priorityQueue: g.priorityQueue,
          ug: function (r) {
            g.kd.ug(r);
          },
          Sb: function () {
            return b;
          },
          log: function () {},
          rs: { index: d.index, type: d.type, name: d.name },
          ai: !!aB(b, 3),
          originalEventData: g.originalEventData,
        };
      g.cachedModelValues &&
        (h.cachedModelValues = {
          gtm: g.cachedModelValues.gtm,
          ecommerce: g.cachedModelValues.ecommerce,
        });
      if (UF()) {
        var k = VF(),
          m,
          p;
        h.Bb = {
          ik: [],
          wg: {},
          hc: function (r, t, u) {
            t === 1 && (m = r);
            t === 7 && (p = u);
            k(r, t, u);
          },
          Wh: Wh(),
        };
        h.log = function (r) {
          var t = Oa.apply(1, arguments);
          m && k(m, 4, { level: r, source: p, message: t });
        };
      }
      var q = rf(a, h, [b, f]);
      a.Tb();
      q instanceof Sa && (q.type === "return" ? (q = q.data) : (q = void 0));
      return B(q, void 0, e);
    };
  }
  function YF(a) {
    var b = a.gtmOnSuccess,
      c = a.gtmOnFailure;
    Db(b) &&
      (a.gtmOnSuccess = function () {
        kd(b);
      });
    Db(c) &&
      (a.gtmOnFailure = function () {
        kd(c);
      });
  }
  function cG() {
    var a;
    a = a === void 0 ? document : a;
    var b;
    return !(
      (b = a.featurePolicy) == null ||
      !b.allowedFeatures().includes("attribution-reporting")
    );
  }
  function fG(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e = nq(),
      f = lq(e);
    if (f.url)
      if (d) {
        var g = c(f.url);
        b !== g && W(a, H.A.Ge, g);
      } else {
        var h = f.url;
        b !== h && W(a, H.A.Ge, c(h));
      }
  }
  function gG() {
    var a = x.screen;
    return { width: a ? a.width : 0, height: a ? a.height : 0 };
  }
  function hG(a) {
    if (A.hidden) return !0;
    var b = a.getBoundingClientRect();
    if (b.top === b.bottom || b.left === b.right || !x.getComputedStyle)
      return !0;
    var c = x.getComputedStyle(a, null);
    if (c.visibility === "hidden") return !0;
    for (var d = a, e = c; d; ) {
      if (e.display === "none") return !0;
      var f = e.opacity,
        g = e.filter;
      if (g) {
        var h = g.indexOf("opacity(");
        h >= 0 &&
          ((g = g.substring(h + 8, g.indexOf(")", h))),
          g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)),
          (f = String(Math.min(Number(g), Number(f)))));
      }
      if (f !== void 0 && Number(f) <= 0) return !0;
      (d = d.parentElement) && (e = x.getComputedStyle(d, null));
    }
    return !1;
  }
  var wG =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function xG(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function yG(a) {
    var b, c;
    return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) !=
      null
      ? c
      : null;
  }
  function zG(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
        ? void 0
        : c.getHighEntropyValues) === "function"
    );
  }
  function AG(a) {
    if (!zG(a)) return null;
    var b = xG(a);
    if (b.uach_promise) return b.uach_promise;
    var c = a.navigator.userAgentData
      .getHighEntropyValues(wG)
      .then(function (d) {
        b.uach != null || (b.uach = d);
        return d;
      });
    return (b.uach_promise = c);
  }
  var NG = new Map([["aw", 4]]);
  function OG(a) {
    var b = ds[a],
      c = NG.get(a);
    return c
      ? (er(b, c) || []).some(function (d) {
          return d.m === "0" || d.m === void 0;
        })
      : !1;
  }
  function PG(a, b) {
    if (O(495)) {
      var c = new Map(),
        d = n(NG),
        e = d.next(),
        f;
      try {
        for (; !e.done; e = d.next()) {
          var g = n(e.value),
            h = g.next().value,
            k = g.next().value,
            m = h,
            p = k,
            q = a[m],
            r = Array.isArray(q) ? q[0] : q;
          if (r !== void 0) {
            var t = {},
              u =
                ((t.k = r),
                (t.i = String(Math.floor(Date.now() / 1e3))),
                (t.b = []),
                (t.m = "1"),
                t),
              v = Jq(u, p);
            v && (OG(m) || c.set(m, v));
          }
        }
      } finally {
        e && !e.done && (f = d.return) && f.call(d);
      }
      if (c.size) {
        var w,
          y =
            b.domain && b.domain !== "auto"
              ? b.domain
              : "auto:" + x.location.hostname,
          z = {},
          C = ((z.p = b.path || "/"), (z.ce = b.Ov), (z.d = y), z),
          D = n(c),
          G = D.next(),
          F;
        try {
          for (; !G.done; G = D.next()) {
            var I = n(G.value),
              L = I.next().value,
              P = I.next().value;
            C[L] = P;
          }
        } finally {
          G && !G.done && (F = D.return) && F.call(D);
        }
        w = "_/set_cookie?" + Wi(C);
        var R,
          U = E(58);
        R = Ef(w, U);
        var X = Pj() + "/" + R;
        vd(X);
      }
    }
  }
  function QG(a) {
    return "CWVWebViewMessage" in a;
  }
  function RG(a) {
    var b = x,
      c = b.webkit;
    delete b.webkit;
    a(b.webkit);
    b.webkit = c;
  }
  function SG(a, b) {
    var c = { action: "gcl_setup" };
    if (QG(a.messageHandlers))
      return (
        a.messageHandlers.CWVWebViewMessage.postMessage({
          command: b,
          payload: c,
        }),
        !0
      );
    var d = a.messageHandlers[b];
    return d ? (d.postMessage(c), !0) : !1;
  }
  var TG = {},
    UG = ((TG.awb = { notFound: 178 }), (TG.ytb = { notFound: 194 }), TG);
  function VG(a) {
    var b,
      c = (b = UG[a]) == null ? void 0 : b.notFound;
    c && S(c);
  }
  function WG(a) {
    if (!uk(qk.da.Rm) && "webkit" in x && x.webkit.messageHandlers) {
      var b = function () {
        try {
          RG(function (c) {
            if (c) {
              var d;
              d =
                QG(c.messageHandlers) || "awb" in c.messageHandlers
                  ? { command: "awb", source: 5 }
                  : QG(c.messageHandlers) || "ytb" in c.messageHandlers
                  ? { command: "ytb", source: 8 }
                  : void 0;
              d &&
                (tk(qk.da.Rm, function (e) {
                  var f = d.source;
                  e.gclid && Ts("gcl_aw", e.gclid, f, a);
                  e.wbraid && Ts("gcl_gb", e.wbraid, f, a);
                }),
                SG(c, d.command) || VG(d.command));
            }
          });
        } catch (c) {
          S(193);
        }
      };
      Zm(function () {
        ks(kq) ? b() : $m(b, kq);
      }, kq);
    }
  }
  var XG = [
    "https://www.google.com",
    "https://www.youtube.com",
    "https://m.youtube.com",
  ];
  function YG(a) {
    return a.data.action !== "gcl_transfer"
      ? (S(173), !0)
      : a.data.gadSource
      ? a.data.gclid
        ? !1
        : (S(181), !0)
      : (S(180), !0);
  }
  function ZG(a, b) {
    if (!a || O(a)) {
      if (uk(qk.da.Oe)) return S(176), qk.da.Oe;
      if (uk(qk.da.Tm)) return S(170), qk.da.Oe;
      var c = nq();
      if (!c) S(171);
      else if (c.opener) {
        var d = function (h) {
          if (!XG.includes(h.origin)) S(172);
          else if (!YG(h)) {
            var k = { gadSource: h.data.gadSource };
            k.gclid = h.data.gclid;
            tk(qk.da.Oe, k);
            b && h.data.gclid && Ts("gcl_aw", String(h.data.gclid), 6, b);
            var m;
            (m = h.stopImmediatePropagation) == null || m.call(h);
            Wt(c, "message", d);
          }
        };
        if (Vt(c, "message", d)) {
          tk(qk.da.Tm, !0);
          var e = n(XG),
            f = e.next(),
            g;
          try {
            for (; !f.done; f = e.next())
              c.opener.postMessage({ action: "gcl_setup" }, f.value);
          } finally {
            f && !f.done && (g = e.return) && g.call(e);
          }
          S(174);
          return qk.da.Oe;
        }
        S(175);
      }
    }
  }
  function hH(a, b) {
    b = b === void 0 ? !0 : b;
    var c = ub(rb.GTAG_EVENT_FEATURE_CHANNEL || []);
    if (c && (W(a, H.A.Pf, c), b)) {
      var d = pC.D.slice();
      rb.GTAG_EVENT_FEATURE_CHANNEL = d;
    }
  }
  function mH() {
    var a = x.__uspapi;
    if (Db(a)) {
      var b = "";
      try {
        a("getUSPData", 1, function (c, d) {
          if (d && c) {
            var e = c.uspString;
            e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e);
          }
        });
      } catch (c) {}
      return b;
    }
  }
  function pH() {
    return Math.floor(Math.random() * 20);
  }
  var qH = [H.A.ri].map(function (a) {
    return a.slice(2);
  });
  function tH(a) {}
  tH.R = "internal.addAdsClickIds";
  function uH(a, b) {
    var c = this;
  }
  uH.publicName = "addConsentListener";
  var vH = !1;
  function wH(a) {
    for (var b = 0; b < a.length; ++b)
      if (vH)
        try {
          a[b]();
        } catch (c) {
          S(77);
        }
      else a[b]();
  }
  function xH(a, b, c) {
    var d = this,
      e;
    return e;
  }
  xH.R = "internal.addDataLayerEventListener";
  function yH(a, b, c) {}
  yH.publicName = "addDocumentEventListener";
  function zH(a, b, c, d) {}
  zH.publicName = "addElementEventListener";
  function AH(a) {
    return a.T.lb();
  }
  function BH(a) {}
  BH.publicName = "addEventCallback";
  function MH(a) {
    if (a.form) {
      var b;
      return ((b = a.form) == null ? 0 : b.tagName)
        ? a.form
        : A.getElementById(a.form);
    }
    return qd(a, ["form"], 100);
  }
  function QH(a) {}
  QH.R = "internal.addFormAbandonmentListener";
  function RH(a, b, c, d) {}
  RH.R = "internal.addFormData";
  function WH(a) {}
  WH.R = "internal.addGaSendListener";
  function XH(a) {
    if (!a) return {};
    var b = a.rs;
    return $A(b.type, b.index, b.name);
  }
  function YH(a) {
    if (!a) return {};
    var b = { originatingEntity: XH(a) };
    a.priorityQueue && (b.priorityQueue = a.priorityQueue);
    return b;
  }
  var $H = function (a, b, c) {
      ZH().updateZone(a, b, c);
    },
    bI = function (a, b, c, d, e) {
      var f = {},
        g = ZH();
      c = c && Yb(c, aI);
      for (var h = g.createZone(a, c), k = 0; k < b.length; k++) {
        var m = String(b[k]);
        if (g.registerChild(m, E(5), h)) {
          var p = m,
            q = a,
            r = f,
            t = d,
            u = e;
          if (Zb(p, "GTM-"))
            OA(p, void 0, !1, { source: 1, fromContainerExecution: !0 });
          else {
            var v,
              w = Rb();
            v = JC("js", w);
            OA(p, void 0, !0, { source: 1, fromContainerExecution: !0 });
            var y = { originatingEntity: t, inheritParentConfig: u };
            ED(v, q, y);
            ED(KC(p, r), q, y);
          }
        }
      }
      return h;
    },
    ZH = function () {
      return ko("zones", function () {
        return new cI();
      });
    },
    dI = {
      zone: 1,
      cn: 1,
      css: 1,
      ew: 1,
      eq: 1,
      ge: 1,
      gt: 1,
      lc: 1,
      le: 1,
      lt: 1,
      re: 1,
      sw: 1,
      um: 1,
    },
    aI = {
      cl: ["ecl"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
    },
    cI = function () {
      this.D = {};
      this.J = {};
      this.M = 0;
    };
  l = cI.prototype;
  l.isActive = function (a, b) {
    for (var c, d = 0; d < a.length && !(c = this.D[a[d]]); d++);
    if (!c) return !0;
    if (!this.isActive([c.Zj], b)) return !1;
    for (var e = 0; e < c.Sg.length; e++) if (this.J[c.Sg[e]].We(b)) return !0;
    return !1;
  };
  l.getIsAllowedFn = function (a, b) {
    if (!this.isActive(a, b))
      return function () {
        return !1;
      };
    for (var c, d = 0; d < a.length && !(c = this.D[a[d]]); d++);
    if (!c)
      return function () {
        return !0;
      };
    for (var e = [], f = 0; f < c.Sg.length; f++) {
      var g = this.J[c.Sg[f]];
      g.We(b) && e.push(g);
    }
    if (!e.length)
      return function () {
        return !1;
      };
    var h = this.getIsAllowedFn([c.Zj], b);
    return function (k, m) {
      m = m || [];
      if (!h(k, m)) return !1;
      for (var p = 0; p < e.length; ++p) if (e[p].M(k, m)) return !0;
      return !1;
    };
  };
  l.unregisterChild = function (a) {
    for (var b = 0; b < a.length; b++) delete this.D[a[b]];
  };
  l.createZone = function (a, b) {
    var c = String(++this.M);
    this.J[c] = new eI(a, b);
    return c;
  };
  l.updateZone = function (a, b, c) {
    var d = this.J[a];
    d && d.U(b, c);
  };
  l.registerChild = function (a, b, c) {
    var d = this.D[a],
      e;
    if ((e = !d)) lo(), (e = jo.D[a]);
    if (e || (!d && zm(a)) || (d && d.Zj !== b)) return !1;
    if (d) return d.Sg.push(c), !1;
    this.D[a] = { Zj: b, Sg: [c] };
    return !0;
  };
  var eI = function (a, b) {
    this.J = null;
    this.D = [{ eventId: a, We: !0 }];
    if (b) {
      this.J = {};
      for (var c = 0; c < b.length; c++) this.J[b[c]] = !0;
    }
  };
  eI.prototype.U = function (a, b) {
    var c = this.D[this.D.length - 1];
    a <= c.eventId || (c.We !== b && this.D.push({ eventId: a, We: b }));
  };
  eI.prototype.We = function (a) {
    for (var b = this.D.length - 1; b >= 0; b--)
      if (this.D[b].eventId <= a) return this.D[b].We;
    return !1;
  };
  eI.prototype.M = function (a, b) {
    b = b || [];
    if (!this.J || dI[a] || this.J[a]) return !0;
    for (var c = 0; c < b.length; ++c) if (this.J[b[c]]) return !0;
    return !1;
  };
  function fI(a) {
    var b = mo("zones");
    return b
      ? b.getIsAllowedFn(om(), a)
      : function () {
          return !0;
        };
  }
  function gI() {
    var a = mo("zones");
    a && a.unregisterChild(om());
  }
  function hI() {
    uB(nm(), function (a) {
      var b = a.originalEventData["gtm.uniqueEventId"],
        c = mo("zones");
      return c ? c.isActive(om(), b) : !0;
    });
    rB(nm(), function (a) {
      var b, c;
      b = a.entityId;
      c = a.securityGroups;
      return fI(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c);
    });
  }
  var iI = function (a, b) {
    this.tagId = a;
    this.canonicalId = b;
  };
  function jI(a, b) {
    var c = this;
    if (!dh(a) || (!Xg(b) && !Zg(b)))
      throw M(this.getName(), ["string", "Object|undefined"], arguments);
    var d = B(b, this.T, 1) || {},
      e = d.firstPartyUrl,
      f = d.onLoad,
      g = d.loadByDestination === !0,
      h = d.isGtmEvent === !0;
    wH([
      function () {
        N(c, "load_google_tags", a, e);
      },
    ]);
    if (g) {
      if (Bm(a)) return a;
    } else if (zm(a)) return a;
    var k = 6,
      m = AH(this);
    h && (k = 7);
    m.Sb() === "__zone" && (k = 1);
    var p = { source: k, fromContainerExecution: !0 },
      q = function (r) {
        rB(
          r,
          function (t) {
            var u = sB().getExternalRestrictions(0, nm()),
              v = n(u),
              w = v.next(),
              y;
            try {
              for (; !w.done; w = v.next()) {
                var z = w.value;
                if (!z(t)) return !1;
              }
            } finally {
              w && !w.done && (y = v.return) && y.call(v);
            }
            return !0;
          },
          !0
        );
        uB(
          r,
          function (t) {
            var u = sB().getExternalRestrictions(1, nm()),
              v = n(u),
              w = v.next(),
              y;
            try {
              for (; !w.done; w = v.next()) {
                var z = w.value;
                if (!z(t)) return !1;
              }
            } finally {
              w && !w.done && (y = v.return) && y.call(v);
            }
            return !0;
          },
          !0
        );
        f && f(new iI(a, r));
      };
    g ? UA(a, e, p, q) : OA(a, e, !Zb(a, "GTM-"), p, q);
    f &&
      m.Sb() === "__zone" &&
      bI(Number.MIN_SAFE_INTEGER, [a], null, XH(AH(this)));
    return a;
  }
  jI.R = "internal.loadGoogleTag";
  function kI(a) {
    return new Nd("", function (b) {
      var c = this.evaluate(b);
      if (c instanceof Nd)
        return new Nd("", function () {
          var d = Oa.apply(0, arguments),
            e = this,
            f = Bb(AH(this), null);
          f.eventId = a.eventId;
          f.priorityId = a.priorityId;
          f.originalEventData = a.originalEventData;
          var g = d.map(function (k) {
              return e.evaluate(k);
            }),
            h = this.T.yb();
          h.he(f);
          return c.Jc.apply(c, [h].concat(xa(g)));
        });
    });
  }
  function lI(a, b, c) {
    var d = this;
  }
  lI.R = "internal.addGoogleTagRestriction";
  function sI(a, b) {}
  sI.R = "internal.addHistoryChangeListener";
  function tI(a, b, c) {}
  tI.publicName = "addWindowEventListener";
  function uI(a, b) {
    return !0;
  }
  uI.publicName = "aliasInWindow";
  function vI(a, b, c) {}
  vI.R = "internal.appendRemoteConfigParameter";
  function wI(a) {
    var b;
    return b;
  }
  wI.publicName = "callInWindow";
  function xI(a) {}
  xI.publicName = "callLater";
  function yI(a) {}
  yI.R = "callOnDomReady";
  function zI(a) {}
  zI.R = "callOnWindowLoad";
  function CI(a, b) {
    return c;
  }
  CI.R = "internal.claimDestination";
  function VI(a) {
    var b = Sb(),
      c;
    return c;
  }
  VI.R = "internal.compileFormMetadata";
  function WI(a, b) {
    var c;
    return c;
  }
  WI.R = "internal.computeGtmParameter";
  function XI(a, b) {
    var c = this;
  }
  XI.R = "internal.consentScheduleFirstTry";
  function YI(a, b) {
    var c = this;
  }
  YI.R = "internal.consentScheduleRetry";
  function ZI(a) {
    var b;
    return b;
  }
  ZI.R = "internal.copyFromCrossContainerData";
  function $I(a, b) {
    var c;
    if (!dh(a) || (!ih(b) && b !== null && !Zg(b)))
      throw M(this.getName(), ["string", "number|undefined"], arguments);
    N(this, "read_data_layer", a);
    var d;
    (b || 2) !== 2 ? (d = fA(a, 1)) : (d = bA(cA, a, [x, A]));
    c = d;
    var e = Vd(c, this.T, sh(AH(this).Sb()) ? 2 : 1);
    e === void 0 && c !== void 0 && S(45);
    return e;
  }
  $I.publicName = "copyFromDataLayer";
  function aJ(a) {
    var b = void 0;
    return b;
  }
  aJ.R = "internal.copyFromDataLayerCache";
  function bJ(a) {
    var b;
    return b;
  }
  bJ.publicName = "copyFromWindow";
  function cJ(a) {
    var b = void 0;
    return Vd(b, this.T, 1);
  }
  cJ.R = "internal.copyKeyFromWindow";
  var dJ = function (a) {
    return a === Km.ia.eb && bn.D[a] === Jm.Oa.Ne && !pp(H.A.ja);
  };
  var eJ = function () {
      return "0";
    },
    fJ = function (a) {
      if (typeof a !== "string") return "";
      var b = ["gclid", "dclid", "wbraid", "_gl"];
      O(102) && b.push("gbraid");
      return Kj(a, b, "0");
    };
  var gJ = {},
    hJ = {},
    iJ = {},
    jJ = {},
    kJ = {},
    lJ = {},
    mJ = {},
    nJ = {},
    oJ = {},
    pJ = {},
    qJ = {},
    rJ = {},
    sJ = {},
    tJ = {},
    uJ = {},
    vJ = {},
    wJ = {},
    xJ = {},
    yJ = {},
    zJ = {},
    AJ = {},
    BJ = {},
    CJ = {},
    DJ = {},
    EJ = {},
    FJ = {},
    GJ =
      ((FJ[H.A.hb] = ((gJ[2] = [dJ]), gJ)),
      (FJ[H.A.Uf] = ((hJ[2] = [dJ]), hJ)),
      (FJ[H.A.Ei] = ((iJ[2] = [dJ]), iJ)),
      (FJ[H.A.Pl] = ((jJ[2] = [dJ]), jJ)),
      (FJ[H.A.Ql] = ((kJ[2] = [dJ]), kJ)),
      (FJ[H.A.Rl] = ((lJ[2] = [dJ]), lJ)),
      (FJ[H.A.Sl] = ((mJ[2] = [dJ]), mJ)),
      (FJ[H.A.Tl] = ((nJ[2] = [dJ]), nJ)),
      (FJ[H.A.He] = ((oJ[2] = [dJ]), oJ)),
      (FJ[H.A.Vf] = ((pJ[2] = [dJ]), pJ)),
      (FJ[H.A.Wf] = ((qJ[2] = [dJ]), qJ)),
      (FJ[H.A.Xf] = ((rJ[2] = [dJ]), rJ)),
      (FJ[H.A.Yf] = ((sJ[2] = [dJ]), sJ)),
      (FJ[H.A.Zf] = ((tJ[2] = [dJ]), tJ)),
      (FJ[H.A.cg] = ((uJ[2] = [dJ]), uJ)),
      (FJ[H.A.dg] = ((vJ[2] = [dJ]), vJ)),
      (FJ[H.A.eg] = ((wJ[2] = [dJ]), wJ)),
      (FJ[H.A.pb] = ((xJ[1] = [dJ]), xJ)),
      (FJ[H.A.zd] = ((yJ[1] = [dJ]), yJ)),
      (FJ[H.A.Fd] = ((zJ[1] = [dJ]), zJ)),
      (FJ[H.A.ue] = ((AJ[1] = [dJ]), AJ)),
      (FJ[H.A.tf] =
        ((BJ[1] = [
          function (a) {
            return O(102) && dJ(a);
          },
        ]),
        BJ)),
      (FJ[H.A.Sc] = ((CJ[1] = [dJ]), CJ)),
      (FJ[H.A.Ca] = ((DJ[1] = [dJ]), DJ)),
      (FJ[H.A.Ja] = ((EJ[1] = [dJ]), EJ)),
      FJ),
    HJ = {},
    IJ =
      ((HJ[H.A.pb] = eJ),
      (HJ[H.A.zd] = eJ),
      (HJ[H.A.Fd] = eJ),
      (HJ[H.A.ue] = eJ),
      (HJ[H.A.tf] = eJ),
      (HJ[H.A.Sc] = function (a) {
        if (!Ab(a)) return {};
        var b = Bb(a, null);
        delete b.match_id;
        return b;
      }),
      (HJ[H.A.Ca] = fJ),
      (HJ[H.A.Ja] = fJ),
      HJ),
    JJ = {},
    KJ = {},
    LJ = ((KJ[J.H.jb] = ((JJ[2] = [dJ]), JJ)), KJ),
    MJ = {};
  var NJ = function (a, b, c, d) {
    this.D = a;
    this.M = b;
    this.U = c;
    this.aa = d;
  };
  NJ.prototype.getValue = function (a) {
    a = a === void 0 ? Km.ia.ed : a;
    if (
      !this.M.some(function (b) {
        return b(a);
      })
    )
      return this.U.some(function (b) {
        return b(a);
      })
        ? this.aa(this.D)
        : this.D;
  };
  NJ.prototype.J = function () {
    return yb(this.D) === "array" || Ab(this.D) ? Bb(this.D, null) : this.D;
  };
  var OJ = function () {},
    PJ = function (a, b) {
      this.conditions = a;
      this.D = b;
    },
    QJ = function (a, b, c) {
      var d,
        e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
        f,
        g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
      return new NJ(c, e, g, a.D[b] || OJ);
    },
    RJ,
    SJ;
  var TJ = function (a) {
      a.D = !0;
      if (Hf(52)) {
        var b;
        a.settings = (b = data.productSettings) != null ? b : {};
        data.productSettings = void 0;
      }
    },
    VJ = function (a) {
      var b = UJ;
      b.D || TJ(b);
      return b.settings[a];
    },
    UJ = new (function () {
      this.settings = {};
      this.D = !1;
    })();
  var WJ = function (a, b, c) {
      this.eventName = b;
      this.K = c;
      this.D = {};
      this.isAborted = !1;
      this.target = a;
      this.metadata = {};
      var d = c.eventMetadata || {},
        e = n(Object.keys(d)),
        f = e.next(),
        g;
      try {
        for (; !f.done; f = e.next()) {
          var h = f.value;
          V(this, h, d[h]);
        }
      } finally {
        f && !f.done && (g = e.return) && g.call(e);
      }
    },
    Si = function (a, b) {
      var c, d;
      return (c = a.D[b]) == null
        ? void 0
        : (d = c.getValue) == null
        ? void 0
        : d.call(c, T(a, J.H.rg));
    },
    W = function (a, b, c) {
      var d = a.D,
        e;
      c === void 0
        ? (e = void 0)
        : (RJ != null || (RJ = new PJ(GJ, IJ)), (e = QJ(RJ, b, c)));
      d[b] = e;
    };
  WJ.prototype.mergeHitDataForKey = function (a, b) {
    var c, d, e;
    c =
      (d = this.D[a]) == null ? void 0 : (e = d.J) == null ? void 0 : e.call(d);
    if (!c) return W(this, a, b), !0;
    if (!Ab(c)) return !1;
    W(this, a, ma(Object, "assign").call(Object, c, b));
    return !0;
  };
  var XJ = function (a, b) {
    b = b === void 0 ? {} : b;
    var c = n(Object.keys(a.D)),
      d = c.next(),
      e;
    try {
      for (; !d.done; d = c.next()) {
        var f = d.value,
          g = void 0,
          h = void 0,
          k = void 0;
        b[f] =
          (g = a.D[f]) == null
            ? void 0
            : (k = (h = g).J) == null
            ? void 0
            : k.call(h);
      }
    } finally {
      d && !d.done && (e = c.return) && e.call(c);
    }
    return b;
  };
  WJ.prototype.copyToHitData = function (a, b, c) {
    var d = Q(this.K, a);
    d === void 0 && (d = b);
    if (Eb(d) && c !== void 0)
      try {
        d = c(d);
      } catch (e) {}
    d !== void 0 && W(this, a, d);
  };
  var T = function (a, b) {
      var c = a.metadata[b];
      if (b === J.H.rg) {
        var d;
        return c == null ? void 0 : (d = c.J) == null ? void 0 : d.call(c);
      }
      var e;
      return c == null
        ? void 0
        : (e = c.getValue) == null
        ? void 0
        : e.call(c, T(a, J.H.rg));
    },
    V = function (a, b, c) {
      var d = a.metadata,
        e;
      c === void 0
        ? (e = c)
        : (SJ != null || (SJ = new PJ(LJ, MJ)), (e = QJ(SJ, b, c)));
      d[b] = e;
    },
    YJ = function (a, b) {
      b = b === void 0 ? {} : b;
      var c = n(Object.keys(a.metadata)),
        d = c.next(),
        e;
      try {
        for (; !d.done; d = c.next()) {
          var f = d.value,
            g = void 0,
            h = void 0,
            k = void 0;
          b[f] =
            (g = a.metadata[f]) == null
              ? void 0
              : (k = (h = g).J) == null
              ? void 0
              : k.call(h);
        }
      } finally {
        d && !d.done && (e = c.return) && e.call(c);
      }
      return b;
    },
    Mx = function (a, b, c) {
      var d = VJ(a.target.destinationId);
      return d && d[b] !== void 0 ? d[b] : c;
    };
  WJ.prototype.copy = function (a) {
    var b = new WJ(
        (a == null ? void 0 : a.target) || this.target,
        (a == null ? void 0 : a.eventName) || this.eventName,
        (a == null ? void 0 : a.K) || this.K
      ),
      c = XJ(this),
      d = n(Object.keys(c)),
      e = d.next(),
      f;
    try {
      for (; !e.done; e = d.next()) {
        var g = e.value;
        W(b, g, c[g]);
      }
    } finally {
      e && !e.done && (f = d.return) && f.call(d);
    }
    var h = YJ(this),
      k = n(Object.keys(h)),
      m = k.next(),
      p;
    try {
      for (; !m.done; m = k.next()) {
        var q = m.value;
        V(b, q, h[q]);
      }
    } finally {
      m && !m.done && (p = k.return) && p.call(k);
    }
    b.isAborted = this.isAborted;
    return b;
  };
  var ZJ = function (a) {
    var b = a.K,
      c = b.eventId,
      d = b.priorityId;
    return d ? c + "_" + d : String(c);
  };
  WJ.prototype.accept = function () {
    var a = vk(qk.da.Mi, {}),
      b = ZJ(this),
      c = this.target.destinationId;
    a[b] || (a[b] = {});
    a[b][c] = nm();
    yk(qk.da.Mi);
  };
  WJ.prototype.canBeAccepted = function (a) {
    var b = uk(qk.da.Mi);
    if (!b) return !0;
    var c = b[ZJ(this)];
    if (!c) return !0;
    var d = c[a != null ? a : this.target.destinationId];
    return d === void 0 || d === nm();
  };
  function $J(a) {
    return {
      getDestinationId: function () {
        return a.target.destinationId;
      },
      getEventName: function () {
        return a.eventName;
      },
      setEventName: function (b) {
        a.eventName = b;
      },
      getHitData: function (b) {
        return Si(a, b);
      },
      setHitData: function (b, c) {
        W(a, b, c);
      },
      setHitDataIfNotDefined: function (b, c) {
        Si(a, b) === void 0 && W(a, b, c);
      },
      copyToHitData: function (b, c) {
        a.copyToHitData(b, c);
      },
      getMetadata: function (b) {
        return T(a, b);
      },
      setMetadata: function (b, c) {
        V(a, b, c);
      },
      isAborted: function () {
        return a.isAborted;
      },
      abort: function () {
        a.isAborted = !0;
      },
      getFromEventContext: function (b) {
        return Q(a.K, b);
      },
      Ab: function () {
        return a;
      },
      getHitKeys: function () {
        return Object.keys(a.D);
      },
      getMergedValues: function (b) {
        return a.K.getMergedValues(b, 3);
      },
      mergeHitDataForKey: function (b, c) {
        return Ab(c) ? a.mergeHitDataForKey(b, c) : !1;
      },
      accept: function () {
        a.accept();
      },
      canBeAccepted: function (b) {
        return a.canBeAccepted(b);
      },
    };
  }
  function aK(a, b) {
    var c;
    return c;
  }
  aK.R = "internal.copyPreHit";
  function bK(a, b) {
    var c = null;
    if (!dh(a) || !dh(b))
      throw M(this.getName(), ["string", "string"], arguments);
    N(this, "access_globals", "readwrite", a);
    N(this, "access_globals", "readwrite", b);
    var d = [x, A],
      e = a.split("."),
      f = ac(x, e, d),
      g = e[e.length - 1];
    if (f === void 0) throw Error("Path " + a + " does not exist.");
    var h = f[g];
    if (h) return Db(h) ? Vd(h, this.T, 2) : null;
    var k;
    h = function () {
      if (!Db(k.push))
        throw Error("Object at " + b + " in window is not an array.");
      k.push.call(k, arguments);
    };
    f[g] = h;
    var m = b.split("."),
      p = ac(x, m, d),
      q = m[m.length - 1];
    if (p === void 0) throw Error("Path " + m + " does not exist.");
    k = p[q];
    k === void 0 && ((k = []), (p[q] = k));
    c = function () {
      h.apply(h, Array.prototype.slice.call(arguments, 0));
    };
    return Vd(c, this.T, 2);
  }
  bK.publicName = "createArgumentsQueue";
  function cK(a) {
    return Vd(
      function (c) {
        var d = bB();
        if (typeof c === "function")
          d(function () {
            c(function (f, g, h) {
              var k = bB(),
                m = k && k.getByName && k.getByName(f);
              return new x.gaplugins.Linker(m).decorate(g, h);
            });
          });
        else if (Array.isArray(c)) {
          var e = String(c[0]).split(".");
          b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c);
        } else if (c === "isLoaded") return !!d.loaded;
      },
      this.T,
      1
    );
  }
  cK.R = "internal.createGaCommandQueue";
  function dK(a) {
    return Vd(
      function () {
        if (!Db(e.push))
          throw Error("Object at " + a + " in window is not an array.");
        e.push.apply(e, Array.prototype.slice.call(arguments, 0));
      },
      this.T,
      sh(AH(this).Sb()) ? 2 : 1
    );
  }
  dK.publicName = "createQueue";
  function eK(a, b) {
    var c = null;
    if (!dh(a) || !eh(b))
      throw M(this.getName(), ["string", "string|undefined"], arguments);
    try {
      var d = (b || "")
        .split("")
        .filter(function (e) {
          return "ig".indexOf(e) >= 0;
        })
        .join("");
      c = new Sd(new RegExp(a, d));
    } catch (e) {}
    return c;
  }
  eK.R = "internal.createRegex";
  function fK(a) {}
  fK.R = "internal.declareConsentState";
  function gK(a) {
    var b = "";
    return b;
  }
  gK.R = "internal.decodeUrlHtmlEntities";
  function hK(a, b, c) {
    var d;
    return d;
  }
  hK.R = "internal.decorateUrlWithGaCookies";
  function iK() {}
  iK.R = "internal.deferCustomEvents";
  function jK(a, b) {
    try {
      return a.closest(b);
    } catch (c) {
      return null;
    }
  }
  function RK(a) {
    var b;
    return b;
  }
  RK.R = "internal.detectUserProvidedData";
  var WK = function () {
    this.D = new Set();
    this.J = this.la = this.aa = this.fa = this.M = this.U = !1;
  };
  WK.prototype.subscribe = function (a) {
    var b = this;
    XK(this, a);
    this.D.add(a);
    return function () {
      b.D.delete(a);
    };
  };
  var XK = function (a, b) {
      var c = x;
      b.onFocus &&
        !a.U &&
        ((a.U = !0),
        id(c, "focus", function () {
          var d = [].concat(xa(a.D)),
            e = n(d),
            f = e.next(),
            g;
          try {
            for (; !f.done; f = e.next()) {
              var h = void 0,
                k = void 0;
              (k = (h = f.value).onFocus) == null || k.call(h);
            }
          } finally {
            f && !f.done && (g = e.return) && g.call(e);
          }
        }));
      b.onBlur &&
        !a.M &&
        ((a.M = !0),
        id(c, "blur", function () {
          var d = [].concat(xa(a.D)),
            e = n(d),
            f = e.next(),
            g;
          try {
            for (; !f.done; f = e.next()) {
              var h = void 0,
                k = void 0;
              (k = (h = f.value).onBlur) == null || k.call(h);
            }
          } finally {
            f && !f.done && (g = e.return) && g.call(e);
          }
        }));
      (!b.fo && !b.Xh) ||
        a.fa ||
        ((a.fa = !0),
        id(c, "pageshow", function (d) {
          var e = !(!d || !d.persisted),
            f = [].concat(xa(a.D)),
            g = n(f),
            h = g.next(),
            k;
          try {
            for (; !h.done; h = g.next()) {
              var m = h.value,
                p = void 0,
                q = void 0;
              (q = (p = m).fo) == null || q.call(p, e);
              if (e) {
                var r = void 0,
                  t = void 0;
                (t = (r = m).Xh) == null || t.call(r);
              }
            }
          } finally {
            h && !h.done && (k = g.return) && k.call(g);
          }
        }));
      (!b.Uj && !b.xt) ||
        a.aa ||
        ((a.aa = !0),
        id(c, "pagehide", function (d) {
          var e = !(!d || !d.persisted),
            f = [].concat(xa(a.D)),
            g = n(f),
            h = g.next(),
            k;
          try {
            for (; !h.done; h = g.next()) {
              var m = h.value,
                p = void 0,
                q = void 0;
              (q = (p = m).Uj) == null || q.call(p, e);
              if (e) {
                var r = void 0,
                  t = void 0;
                (t = (r = m).xt) == null || t.call(r);
              }
            }
          } finally {
            h && !h.done && (k = g.return) && k.call(g);
          }
        }));
      b.jo &&
        !a.la &&
        ((a.la = !0),
        id(A, "visibilitychange", function () {
          var d = !A.hidden,
            e = [].concat(xa(a.D)),
            f = n(e),
            g = f.next(),
            h;
          try {
            for (; !g.done; g = f.next()) {
              var k = void 0,
                m = void 0;
              (m = (k = g.value).jo) == null || m.call(k, d);
            }
          } finally {
            g && !g.done && (h = f.return) && h.call(f);
          }
        }));
      b.bo &&
        !a.J &&
        ((a.J = !0),
        id(c, "beforeunload", function () {
          var d = [].concat(xa(a.D)),
            e = n(d),
            f = e.next(),
            g;
          try {
            for (; !f.done; f = e.next()) {
              var h = void 0,
                k = void 0;
              (k = (h = f.value).bo) == null || k.call(h);
            }
          } finally {
            f && !f.done && (g = e.return) && g.call(e);
          }
        }));
    },
    YK = new WK();
  function ZK(a, b) {
    var c = this;
    return d;
  }
  ZK.R = "internal.enableAutoEventOnBfcacheRestore";
  function bL(a, b) {
    return f;
  }
  bL.R = "internal.enableAutoEventOnClick";
  function iL(a, b) {
    return p;
  }
  iL.R = "internal.enableAutoEventOnElementVisibility";
  function jL() {}
  jL.R = "internal.enableAutoEventOnError";
  function pL(a, b) {
    var c = this;
    return d;
  }
  pL.R = "internal.enableAutoEventOnFormInteraction";
  function uL(a, b) {
    var c = this;
    return f;
  }
  uL.R = "internal.enableAutoEventOnFormSubmit";
  function zL() {
    var a = this;
  }
  zL.R = "internal.enableAutoEventOnGaSend";
  function GL(a, b) {
    var c = this;
    return f;
  }
  GL.R = "internal.enableAutoEventOnHistoryChange";
  var HL = ["http://", "https://", "javascript:", "file://"];
  function LL(a, b) {
    var c = this;
    return h;
  }
  LL.R = "internal.enableAutoEventOnLinkClick";
  function WL(a, b) {
    var c = this;
    return g;
  }
  WL.R = "internal.enableAutoEventOnScroll";
  function XL(a) {
    return function () {
      if (a.limit && a.Tj >= a.limit) a.Sh && x.clearInterval(a.Sh);
      else {
        a.Tj++;
        var b = Sb();
        ME({
          event: a.eventName,
          "gtm.timerId": a.Sh,
          "gtm.timerEventNumber": a.Tj,
          "gtm.timerInterval": a.interval,
          "gtm.timerLimit": a.limit,
          "gtm.timerStartTime": a.Bo,
          "gtm.timerCurrentTime": b,
          "gtm.timerElapsedTime": b - a.Bo,
          "gtm.triggers": a.pu,
        });
      }
    };
  }
  function YL(a, b) {
    return f;
  }
  YL.R = "internal.enableAutoEventOnTimer";
  var Jc = za(["data-gtm-yt-inspected-"]),
    $L = ["www.youtube.com", "www.youtube-nocookie.com"],
    aM;
  function kM(a, b) {
    var c = this;
    return e;
  }
  kM.R = "internal.enableAutoEventOnYouTubeActivity";
  function lM(a, b) {
    if (!dh(a) || !Yg(b))
      throw M(this.getName(), ["string", "Object|undefined"], arguments);
    var c = b ? B(b) : {};
    c.regexCache = aj(20, function () {
      return new Map();
    });
    return xh(a, c);
  }
  lM.R = "internal.evaluateBooleanExpression";
  function mM(a) {
    var b = !1;
    return b;
  }
  mM.R = "internal.evaluateMatchingRules";
  function qM(a, b) {
    var c = Array.isArray(a) ? a : [a],
      d = Gb(b),
      e = n(c),
      f = e.next(),
      g;
    try {
      for (; !f.done; f = e.next()) {
        var h = f.value;
        if (h && typeof h === "object") {
          h.testReason || (h.testReason = []);
          var k = n(d),
            m = k.next(),
            p;
          try {
            for (; !m.done; m = k.next()) {
              var q = m.value;
              h.testReason.indexOf(q) === -1 && h.testReason.push(q);
            }
          } finally {
            m && !m.done && (p = k.return) && p.call(k);
          }
        }
      }
    } finally {
      f && !f.done && (g = e.return) && g.call(e);
    }
  }
  function rM(a, b) {
    if (a) {
      var c = a._tag_metadata;
      if (c) {
        var d = n(Object.keys(c)),
          e = d.next(),
          f;
        try {
          for (; !e.done; e = d.next()) {
            var g = c[e.value];
            g && qM(g, b);
          }
        } finally {
          e && !e.done && (f = d.return) && f.call(d);
        }
      }
    }
  }
  function wM() {
    return tu(7) && tu(9) && tu(10);
  }
  var CM = function (a, b) {
      a &&
        (BM("sid", a.targetId, b),
        BM("cc", a.clientCount, b),
        BM("tl", a.totalLifeMs, b),
        BM("hc", a.heartbeatCount, b),
        BM("cl", a.clientLifeMs, b));
    },
    BM = function (a, b, c) {
      b != null && c.push(a + "=" + b);
    },
    DM = function () {
      var a = A.referrer;
      if (a) {
        var b;
        return Dj(Jj(a), "host") ===
          ((b = x.location) == null ? void 0 : b.host)
          ? 1
          : 2;
      }
      return 0;
    },
    FM = function () {
      this.la = EM;
      this.M = 0;
      this.Da = Mf(57, 5);
      this.U = Mf(58, 50);
      this.fa = Ib();
      this.La = "https://" + E(21) + "/a?";
    };
  FM.prototype.J = function (a, b, c, d) {
    var e = DM(),
      f,
      g = [];
    f =
      x === x.top && e !== 0 && b
        ? (b == null ? void 0 : b.clientCount) > 1
          ? e === 2
            ? 1
            : 2
          : e === 2
          ? 0
          : 3
        : 4;
    a && BM("si", a.Hg, g);
    BM("m", 0, g);
    BM("iss", f, g);
    BM("if", c, g);
    CM(b, g);
    d && BM("fm", encodeURIComponent(d.substring(0, this.U)), g);
    this.aa(g);
  };
  FM.prototype.D = function (a, b, c, d, e) {
    var f = [];
    BM("m", 1, f);
    BM("s", a, f);
    BM("po", DM(), f);
    b && (BM("st", b.state, f), BM("si", b.Hg, f), BM("sm", b.Rg, f));
    CM(c, f);
    BM("c", d, f);
    e && BM("fm", encodeURIComponent(e.substring(0, this.U)), f);
    this.aa(f);
  };
  FM.prototype.aa = function (a) {
    a = a === void 0 ? [] : a;
    !fl.M ||
      this.M >= this.Da ||
      (BM("pid", this.fa, a),
      BM("bc", ++this.M, a),
      a.unshift("ctid=" + E(5) + "&t=s"),
      this.la("" + this.La + a.join("&")));
  };
  function GM(a) {
    return (a.performance && a.performance.now()) || Date.now();
  }
  var HM = function (a, b) {
    var c = x,
      d = Mf(53, 500),
      e = Mf(54, 5e3),
      f = Mf(8, 20),
      g = Mf(55, 5e3),
      h;
    var k = function (m, p, q) {
      q =
        q === void 0
          ? {
              onInit: function () {},
              ho: function () {},
              co: function () {},
              onFailure: function () {},
            }
          : q;
      this.yj = m;
      this.D = p;
      this.M = q;
      this.fa = this.la = this.heartbeatCount = this.uj = 0;
      this.jd = !1;
      this.J = {};
      this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
      this.state = 0;
      this.Hg = GM(this.D);
      this.Rg = GM(this.D);
      this.aa = 10;
    };
    k.prototype.init = function () {
      this.U(1);
      this.Da();
    };
    k.prototype.getState = function () {
      return {
        state: this.state,
        Hg: Math.round(GM(this.D) - this.Hg),
        Rg: Math.round(GM(this.D) - this.Rg),
      };
    };
    k.prototype.U = function (m) {
      this.state !== m && ((this.state = m), (this.Rg = GM(this.D)));
    };
    k.prototype.Wd = function () {
      return String(this.uj++);
    };
    k.prototype.Da = function () {
      var m = this;
      this.heartbeatCount++;
      this.addRequest(
        {
          type: 0,
          clientId: this.id,
          requestId: this.Wd(),
          maxDelay: this.Vd(),
        },
        function (p) {
          if (p.type === 0) {
            var q;
            if (((q = p.failure) == null ? void 0 : q.failureType) != null)
              if (
                (p.stats && (m.stats = p.stats), m.fa++, p.isDead || m.fa > f)
              ) {
                var r = p.isDead && p.failure.failureType;
                m.aa = r || 10;
                m.U(4);
                m.Jh();
                var t, u;
                (u = (t = m.M).co) == null ||
                  u.call(t, { failureType: r || 10, data: p.failure.data });
              } else m.U(3), m.sg();
            else {
              if (m.heartbeatCount > p.stats.heartbeatCount + f) {
                m.heartbeatCount = p.stats.heartbeatCount;
                var v, w;
                (w = (v = m.M).onFailure) == null ||
                  w.call(v, { failureType: 13 });
              }
              m.stats = p.stats;
              var y = m.state;
              m.U(2);
              if (y !== 2)
                if (m.jd) {
                  var z, C;
                  (C = (z = m.M).ho) == null || C.call(z);
                } else {
                  m.jd = !0;
                  var D, G;
                  (G = (D = m.M).onInit) == null || G.call(D);
                }
              m.fa = 0;
              m.Cj();
              m.sg();
            }
          }
        }
      );
    };
    k.prototype.Vd = function () {
      return this.state === 2 ? e : d;
    };
    k.prototype.sg = function () {
      var m = this,
        p = GM(this.D) - this.la;
      this.D.setTimeout(function () {
        m.Da();
      }, Math.max(0, this.Vd() - p));
    };
    k.prototype.Jr = function (m, p, q) {
      var r = this;
      this.addRequest(
        { type: 1, clientId: this.id, requestId: this.Wd(), command: m },
        function (t) {
          if (t.type === 1)
            if (t.result) p(t.result);
            else {
              var u,
                v,
                w,
                y = {
                  failureType:
                    (w = (u = t.failure) == null ? void 0 : u.failureType) !=
                    null
                      ? w
                      : 12,
                  data: (v = t.failure) == null ? void 0 : v.data,
                },
                z,
                C;
              (C = (z = r.M).onFailure) == null || C.call(z, y);
              q(y);
            }
        }
      );
    };
    k.prototype.addRequest = function (m, p) {
      var q = this;
      if (this.state === 4) (m.failure = { failureType: this.aa }), p(m);
      else {
        var r = this.state !== 2 && m.type !== 0,
          t = m.requestId,
          u,
          v = this.D.setTimeout(
            function () {
              var y = q.J[t];
              y && (pk(6), q.Rb(y, 7));
            },
            (u = m.maxDelay) != null ? u : g
          ),
          w = { request: m, wo: p, oo: r, st: v };
        this.J[t] = w;
        r || this.sendRequest(w);
      }
    };
    k.prototype.sendRequest = function (m) {
      this.la = GM(this.D);
      m.oo = !1;
      this.yj(m.request);
    };
    k.prototype.Cj = function () {
      var m = n(Object.keys(this.J)),
        p = m.next(),
        q;
      try {
        for (; !p.done; p = m.next()) {
          var r = this.J[p.value];
          r.oo && this.sendRequest(r);
        }
      } finally {
        p && !p.done && (q = m.return) && q.call(m);
      }
    };
    k.prototype.Jh = function () {
      var m = n(Object.keys(this.J)),
        p = m.next(),
        q;
      try {
        for (; !p.done; p = m.next()) this.Rb(this.J[p.value], this.aa);
      } finally {
        p && !p.done && (q = m.return) && q.call(m);
      }
    };
    k.prototype.Rb = function (m, p) {
      this.La(m);
      var q = m.request;
      q.failure = { failureType: p };
      m.wo(q);
    };
    k.prototype.La = function (m) {
      delete this.J[m.request.requestId];
      this.D.clearTimeout(m.st);
    };
    k.prototype.Ks = function (m) {
      this.la = GM(this.D);
      var p = this.J[m.requestId];
      if (p) this.La(p), p.wo(m);
      else {
        var q, r;
        (r = (q = this.M).onFailure) == null || r.call(q, { failureType: 14 });
      }
    };
    h = new k(a, c, b);
    return h;
  };
  var IM = function () {
      return aj(22, function () {
        return new FM();
      });
    },
    EM = function (a) {
      en(hn(Km.ia.Qb), function () {
        hd(a);
      });
    },
    JM = function (a) {
      var b = x.location.origin;
      if (!b) return null;
      Oj() && !a && (a = "" + b + Pj() + "/_/service_worker");
      var c = a,
        d,
        e = Kf(11);
      e = Kf(10);
      d = e;
      c
        ? (c.charAt(c.length - 1) !== "/" && (c += "/"), (a = c + d))
        : (a =
            "https://www.googletagmanager.com/static/service_worker/" +
            d +
            "/");
      var f;
      try {
        f = new URL(a);
      } catch (g) {
        return null;
      }
      return f.protocol !== "https:" ? null : f;
    },
    KM = function (a) {
      var b = uk(qk.da.Ih);
      return b && b[a];
    },
    LM = function (a) {
      var b = this;
      this.J = IM();
      this.aa = this.U = !1;
      this.fa = null;
      this.initTime = Math.round(Sb());
      this.D = 15;
      this.M = this.ds(a);
      x.setTimeout(function () {
        b.initialize();
      }, 1e3);
      kd(function () {
        b.Ws(a);
      });
    };
  l = LM.prototype;
  l.delegate = function (a, b, c) {
    this.getState() !== 2
      ? (this.J.D(
          this.D,
          {
            state: this.getState(),
            Hg: this.initTime,
            Rg: Math.round(Sb()) - this.initTime,
          },
          void 0,
          a.commandType
        ),
        c({ failureType: this.D }))
      : this.M.Jr(a, b, c);
  };
  l.getState = function () {
    return this.M.getState().state;
  };
  l.Ws = function (a) {
    var b = x.location.origin,
      c = this,
      d = gd();
    try {
      var e = d.contentDocument.createElement("iframe"),
        f = a.pathname,
        g = f[f.length - 1] === "/" ? a.toString() : a.toString() + "/",
        h = { origin: b };
      if (a.origin !== "https://www.googletagmanager.com") {
        h["1p"] = 1;
        var k = f.substring(0, f.indexOf("/_/service_worker"));
        k && (h.path = k);
      }
      var m;
      O(133) && (m = { sandbox: "allow-same-origin allow-scripts" });
      gd(g + "sw_iframe.html?" + Wi(h), void 0, m, void 0, e);
      var p = function () {
        d.contentDocument.body.appendChild(e);
        e.addEventListener("load", function () {
          c.fa = e.contentWindow;
          d.contentWindow.addEventListener("message", function (q) {
            q.origin === a.origin && c.M.Ks(q.data);
          });
          c.initialize();
        });
      };
      d.contentDocument.readyState === "complete"
        ? p()
        : d.contentWindow.addEventListener("load", function () {
            p();
          });
    } catch (q) {
      d.parentElement.removeChild(d),
        (this.D = 11),
        this.J.J(void 0, void 0, this.D, q.toString());
    }
  };
  l.ds = function (a) {
    var b = this,
      c = HM(
        function (d) {
          var e;
          (e = b.fa) == null || e.postMessage(d, a.origin);
        },
        {
          onInit: function () {
            b.U = !0;
            b.J.J(c.getState(), c.stats);
          },
          ho: function () {},
          co: function (d) {
            b.U
              ? ((b.D = (d == null ? void 0 : d.failureType) || 10),
                b.J.D(
                  b.D,
                  c.getState(),
                  c.stats,
                  void 0,
                  d == null ? void 0 : d.data
                ))
              : ((b.D = (d == null ? void 0 : d.failureType) || 4),
                b.J.J(c.getState(), c.stats, b.D, d == null ? void 0 : d.data));
          },
          onFailure: function (d) {
            b.D = d.failureType;
            b.J.D(b.D, c.getState(), c.stats, d.command, d.data);
          },
        }
      );
    return c;
  };
  l.initialize = function () {
    this.aa || this.M.init();
    this.aa = !0;
  };
  var MM = function (a, b, c, d) {
    var e;
    if ((e = KM(a)) == null || !e.delegate) {
      var f = Rc() ? 16 : 6;
      IM().D(f, void 0, void 0, b.commandType);
      d({ failureType: f });
      return;
    }
    KM(a).delegate(b, c, d);
  };
  function NM(a, b, c, d) {
    var e = JM(a);
    if (e === null) {
      d("_is_sw=f" + (Rc() ? 16 : 6) + "te");
      return;
    }
    var f = b ? 1 : 0,
      g = Math.round(Sb()),
      h,
      k = (h = KM(e.origin)) == null ? void 0 : h.initTime,
      m = k ? g - k : void 0;
    MM(
      e.origin,
      {
        commandType: 0,
        params: {
          url: a,
          method: f,
          templates: c,
          body: b || "",
          processResponse: !0,
          sinceInit: m,
          attributionReporting: !0,
          referer: x.location.href,
          strict: !0,
        },
      },
      function () {},
      function (p) {
        var q = "_is_sw=f" + p.failureType,
          r,
          t = (r = KM(e.origin)) == null ? void 0 : r.getState();
        t !== void 0 && (q += "s" + t);
        d(m ? q + ("t" + m) : q + "te");
      }
    );
  }
  function OM(a) {
    if (Hf(47) && Mx(a, "ccd_add_1p_data", !1) && Oj()) {
      var b = a.K;
      if (Rc() && Yf(cg.D, "internal_sw_allowed", "")) {
        var c = Wj(b),
          d = Oj() ? Pj() : void 0,
          e;
        e = d ? { path: d, Nn: "full" } : c ? { path: c, Nn: "lite" } : void 0;
        if (e) {
          var f = e.Nn,
            g = new URL(e.path, x.location.origin);
          if (g.origin === x.location.origin && Py(f) === void 0) {
            var h = vk(qk.da.Ih, {});
            h[f] || (h[f] = new Ny(g));
          }
        }
      }
    }
  }
  function RM(a) {
    V(a, J.H.Ua, !0);
    V(a, J.H.Eb, Sb());
    V(a, J.H.hn, a.K.eventMetadata[J.H.Ua]);
  }
  var iN = new (function () {
    this.D = {};
  })();
  function kN(a) {
    var b = UB(!1);
    if (b != null && b.status) {
      var c = { gtb: b.status };
      b.delay && (c.gtbd = b.delay);
      a.mergeHitDataForKey(H.A.Ra, c);
      O(646) && W(a, H.A.yq, b.status);
    }
  }
  function lN(a, b) {
    b = b === void 0 ? !1 : b;
    var c = T(a, J.H.qg),
      d = Mx(a, "custom_event_accept_rules", !1) && !b;
    if (c) {
      var e = c.indexOf(a.target.destinationId) >= 0,
        f = !0;
      T(a, J.H.Ac) && (f = T(a, J.H.Gb) === nm());
      e && f ? V(a, J.H.fi, !0) : (V(a, J.H.fi, !1), d || (a.isAborted = !0));
      if (a.canBeAccepted()) {
        var g = mm().indexOf(a.target.destinationId) >= 0,
          h = !1;
        if (!g) {
          var k,
            m =
              (k = fm(a.target.destinationId)) == null
                ? void 0
                : k.canonicalContainerId;
          m && (h = nm() === m);
        }
        g || h ? T(a, J.H.fi) && a.accept() : (a.isAborted = !0);
      } else a.isAborted = !0;
    }
  }
  function tN() {
    return ko("dedupe_gclid", function () {
      return Fv();
    });
  }
  var uN = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
    vN = /^www.googleadservices.com$/;
  function wN(a) {
    a || (a = xN());
    return a.qu
      ? !1
      : a.Ms ||
        a.Ns ||
        a.Qs ||
        a.Os ||
        a.Bg ||
        a.Nh ||
        a.zs ||
        a.Dj === "aw.ds" ||
        a.Es
      ? !0
      : !1;
  }
  function xN() {
    var a = {},
      b = Cr(!0);
    a.qu = !!b._up;
    var c = Ms(),
      d = Jt();
    a.Ms = c.aw !== void 0;
    a.Ns = c.dc !== void 0;
    a.Qs = c.wbraid !== void 0;
    a.Os = c.gbraid !== void 0;
    a.Dj = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
    a.Bg = d.Bg;
    a.Nh = d.Nh;
    var e = A.referrer ? Dj(Jj(A.referrer), "host") : "";
    a.Es = uN.test(e);
    a.zs = vN.test(e);
    return a;
  }
  function AN(a) {
    if (fl.J)
      if (((sn.D = !0), a.eventName === H.A.ya)) vn(a.K, a.target.id);
      else {
        T(a, J.H.Mc) || (sn.J[a.target.id] = !0);
        var b = T(a, J.H.Gb);
        iC(b);
      }
  }
  function CN(a, b) {
    return Tr("gsid_dc", {
      value: { joinId: a, lastJoinedTimeMs: b },
      expires: b + 3e5,
    }) === 0
      ? !0
      : !1;
  }
  var EN = { rq: { yu: "cd", Po: "ce", zu: "cf", Au: "cpf", Bu: "cu" } };
  function YO(a, b, c, d) {}
  YO.R = "internal.executeEventProcessor";
  function ZO(a) {
    var b;
    return Vd(b, this.T, 1);
  }
  ZO.R = "internal.executeJavascriptString";
  function $O(a) {
    var b;
    return b;
  }
  function aP(a) {
    var b = "";
    return b;
  }
  aP.R = "internal.generateClientId";
  function bP(a) {
    var b = {};
    return Vd(b);
  }
  bP.R = "internal.getAdsCookieWritingOptions";
  function cP(a, b) {
    var c = !1;
    return c;
  }
  cP.R = "internal.getAllowAdPersonalization";
  function dP(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  dP.R = "internal.getAuid";
  function eP() {
    var a = [];
    return Vd(a);
  }
  eP.R = "internal.getContainerIds";
  function fP() {
    var a = new kb();
    return a;
  }
  fP.publicName = "getContainerVersion";
  function gP(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  gP.publicName = "getCookieValues";
  function hP() {
    var a = "";
    return a;
  }
  hP.R = "internal.getCorePlatformServicesParam";
  function iP() {
    return Fk();
  }
  iP.R = "internal.getCountryCode";
  function jP() {
    var a = [];
    a = lm();
    return Vd(a);
  }
  jP.R = "internal.getDestinationIds";
  function kP(a) {
    var b = new kb();
    return b;
  }
  kP.R = "internal.getDeveloperIds";
  function lP(a) {
    var b;
    return b;
  }
  lP.R = "internal.getEcsidCookieValue";
  function mP(a, b) {
    var c = null;
    return c;
  }
  mP.R = "internal.getElementAttribute";
  function nP(a) {
    var b = null;
    return b;
  }
  nP.R = "internal.getElementById";
  function oP(a) {
    var b = "";
    return b;
  }
  oP.R = "internal.getElementInnerText";
  function pP(a) {
    var b = null;
    return b;
  }
  pP.R = "internal.getElementParent";
  function qP(a) {
    var b = null;
    return b;
  }
  qP.R = "internal.getElementPreviousSibling";
  function rP(a, b) {
    var c = null;
    return Vd(c);
  }
  rP.R = "internal.getElementProperty";
  function sP(a) {
    var b;
    return b;
  }
  sP.R = "internal.getElementValue";
  function tP(a) {
    var b = 0;
    return b;
  }
  tP.R = "internal.getElementVisibilityRatio";
  function uP(a) {
    var b = null;
    return b;
  }
  uP.R = "internal.getElementsByCssSelector";
  function vP(a) {
    var b;
    if (!dh(a)) throw M(this.getName(), ["string"], arguments);
    N(this, "read_event_data", a);
    var c;
    a: {
      var d = a,
        e = AH(this).originalEventData;
      if (e) {
        for (
          var f = e, g = {}, h = {}, k = {}, m = [], p = d.split("\\\\"), q = 0;
          q < p.length;
          q++
        ) {
          for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
            for (var u = r[t].split("."), v = 0; v < u.length; v++)
              m.push(u[v]), v !== u.length - 1 && m.push(k);
            t !== r.length - 1 && m.push(h);
          }
          q !== p.length - 1 && m.push(g);
        }
        var w = [],
          y = "",
          z = n(m),
          C = z.next(),
          D;
        try {
          for (; !C.done; C = z.next()) {
            var G = C.value;
            G === k
              ? (w.push(y), (y = ""))
              : (y = G === g ? y + "\\" : G === h ? y + "." : y + G);
          }
        } finally {
          C && !C.done && (D = z.return) && D.call(z);
        }
        y && w.push(y);
        var F = n(w),
          I = F.next(),
          L;
        try {
          for (; !I.done; I = F.next()) {
            if (f == null) {
              c = void 0;
              break a;
            }
            f = f[I.value];
          }
        } finally {
          I && !I.done && (L = F.return) && L.call(F);
        }
        c = f;
      } else c = void 0;
    }
    b = Vd(c, this.T, 1);
    return b;
  }
  vP.R = "internal.getEventData";
  function wP(a) {
    var b = null;
    return b;
  }
  wP.R = "internal.getFirstElementByCssSelector";
  function xP() {
    var a;
    return a;
  }
  xP.R = "internal.getGsaExperimentId";
  function yP() {
    return new Sd(to);
  }
  yP.R = "internal.getHtmlId";
  function zP() {
    var a;
    return a;
  }
  zP.R = "internal.getIframingState";
  function AP(a, b) {
    var c = {};
    return Vd(c);
  }
  AP.R = "internal.getLinkerValueFromLocation";
  function BP() {
    var a = new kb();
    return a;
  }
  BP.R = "internal.getPrivacyStrings";
  function CP(a, b) {
    var c;
    return c;
  }
  CP.R = "internal.getProductSettingsParameter";
  function DP(a, b) {
    var c;
    return c;
  }
  DP.publicName = "getQueryParameters";
  function EP(a, b) {
    var c;
    return c;
  }
  EP.publicName = "getReferrerQueryParameters";
  function FP(a) {
    var b = "";
    if (!eh(a)) throw M(this.getName(), ["string|undefined"], arguments);
    N(this, "get_referrer", a);
    b = Fj(Jj(A.referrer), a);
    return b;
  }
  FP.publicName = "getReferrerUrl";
  function GP() {
    return Gk();
  }
  GP.R = "internal.getRegionCode";
  function HP(a, b) {
    var c;
    return c;
  }
  HP.R = "internal.getRemoteConfigParameter";
  function IP(a, b) {
    var c = null;
    return c;
  }
  IP.R = "internal.getScopedElementsByCssSelector";
  function JP() {
    var a = new kb();
    a.set("width", 0);
    a.set("height", 0);
    return a;
  }
  JP.R = "internal.getScreenDimensions";
  function KP() {
    var a = "";
    return a;
  }
  KP.R = "internal.getTopSameDomainUrl";
  function LP() {
    var a = "";
    return a;
  }
  LP.R = "internal.getTopWindowUrl";
  function MP(a) {
    var b = "";
    if (!eh(a)) throw M(this.getName(), ["string|undefined"], arguments);
    N(this, "get_url", a);
    b = Dj(Jj(x.location.href), a);
    return b;
  }
  MP.publicName = "getUrl";
  function NP() {
    N(this, "get_user_agent");
    return Qc.userAgent;
  }
  NP.publicName = "getUserAgent";
  NP.R = "internal.getUserAgent";
  function OP() {
    var a;
    return a ? Vd(DG(a)) : a;
  }
  OP.R = "internal.getUserAgentClientHints";
  function RP() {
    var a = x;
    return (a.gaGlobal = a.gaGlobal || {});
  }
  function SP(a, b) {
    var c = RP();
    if (c.vid === void 0 || (b && !c.from_cookie))
      (c.vid = a), (c.from_cookie = b);
  }
  function uQ(a) {
    (Tj(AM(a)) || Oj()) && W(a, H.A.Vl, Gk() || Fk());
    !Tj(AM(a)) && Oj() && W(a, H.A.Si, "::");
  }
  function vQ(a) {
    Oj() && (Tj(AM(a)) || Jk() || W(a, H.A.Cl, !0));
  }
  function AQ(a, b, c, d) {
    var e;
    if ((wd() || td()) && Pj() && Pj() !== "/") {
      var f = Jj(a);
      e =
        Hf(50) && d && $b(f.pathname, "/g/collect")
          ? 2
          : (
              d || !Oj() || Jk()
                ? 0
                : $b(f.pathname, "/ga/g/c") || $b(f.pathname, "/ag/g/c")
            )
          ? 1
          : 0;
    } else e = 0;
    switch (e) {
      case 2:
        var g;
        if (O(546)) {
          var h = $b(a, "/g/collect") ? a.substring(0, a.length - 10) : a,
            k = BQ(),
            m = h + k,
            p = CQ("/g/collect", b, c);
          g = { Dc: m, cf: "", body: p, Kg: !0 };
        } else g = { Dc: a, cf: b, body: c, Kg: !1 };
        return g;
      case 1:
        var q;
        if (O(547)) {
          var r = BQ(),
            t = a.indexOf(r),
            u = a.substring(0, t) + r,
            v = CQ(a.substring(t + r.length - 1), b, c);
          q = { Dc: u, cf: "", body: v, Kg: !0 };
        } else q = { Dc: a, cf: b, body: c, Kg: !1 };
        return q;
      default:
        return { Dc: a, cf: b, body: c, Kg: !1 };
    }
  }
  function BQ() {
    var a = Pj();
    if (!a) return "";
    Zb(a, "/") || (a = "/" + a);
    $b(a, "/") || (a += "/");
    return a;
  }
  function CQ(a, b, c) {
    var d = [a];
    b && d.push("?", b);
    c && d.push("\r\n", c);
    return d.join("");
  }
  function NR(a) {
    a.copyToHitData(H.A.hb);
    var b = Q(a.K, H.A.yh);
    b && (bD(b, function () {}), W(a, H.A.yh, b));
  }
  function QR(a) {
    var b = function (c) {
      return !!c && c.conversion;
    };
    V(a, J.H.hg, b(yM(a)));
    T(a, J.H.ig) && V(a, J.H.Im, b(yM(a, "first_visit")));
    T(a, J.H.Me) && V(a, J.H.Mm, b(yM(a, "session_start")));
  }
  var VR = function (a) {
    for (
      var b = {}, c = String(UR.cookie).split(";"), d = 0;
      d < c.length;
      d++
    ) {
      var e = c[d].split("="),
        f = e[0].trim();
      if (f && a(f)) {
        var g = e.slice(1).join("=").trim();
        g && (g = decodeURIComponent(g));
        var h = void 0,
          k = void 0;
        ((h = b)[(k = f)] || (h[k] = [])).push(g);
      }
    }
    return b;
  };
  var WR = window,
    UR = document,
    YR = function (a) {
      var b = WR._gaUserPrefs;
      if (
        (b && b.ioo && b.ioo()) ||
        UR.documentElement.hasAttribute("data-google-analytics-opt-out") ||
        (a && WR["ga-disable-" + a] === !0)
      )
        return !0;
      try {
        var c = WR.external;
        if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0;
      } catch (f) {}
      for (
        var d =
            VR(function (f) {
              return f === "AMP_TOKEN";
            }).AMP_TOKEN || [],
          e = 0;
        e < d.length;
        e++
      )
        if (d[e] == "$OPT_OUT") return !0;
      return UR.getElementById("__gaOptOutExtension") ? !0 : !1;
    };
  var hS =
    "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(
      " "
    );
  var jS = [H.A.wa, H.A.ja],
    kS = [H.A.wa, H.A.ja, H.A.ma];
  function lS(a) {
    var b,
      c = O(506) && !Mx(a, "ccd_ga_ads_ids_opt_out", !1),
      d = !!Mx(a, "google_ng", !1),
      e = pp(c ? (d ? kS : kq) : jS),
      f;
    f = Mx(a, H.A.Mf, Q(a.K, H.A.Mf)) || !!Mx(a, "google_ng", !1);
    b = {
      af: c,
      ct: d,
      vo: e,
      Ze: f,
      Jg: !!Mx(a, "ga4_ads_linked", !1),
      Th: Hk(),
      wj: !wM(),
      et: Tj(AM(a)),
      bt: !!T(a, J.H.Rd),
      ft: !!T(a, J.H.Me),
      Ps: !!Q(a.K, H.A.wl),
      kt: !!T(a, J.H.Xi),
      vg: Q(a.K, H.A.Qc),
      Nr: Q(a.K, H.A.Qc, void 0, 4),
      ht: !!T(a, J.H.kg),
    };
    V(a, J.H.Wi, b.Ze);
    V(a, J.H.Vi, mS(b));
    b.af && !b.Ze && b.Jg && mS(b) && W(a, "_&ibt", "1");
    mS(b) && b.vo && (b.af ? b.vg !== !1 || b.Jg : 1) && V(a, J.H.Zm, !0);
    b.ct && !b.Th && W(a, H.A.Jd, 1);
    (b.af ? b.vg : b.Nr) === !1 && W(a, "_&ngs", "1");
    V(a, J.H.Qe, nS(b) && (b.ft || b.Ps));
    V(a, J.H.pg, nS(b) && b.kt && !b.Th);
  }
  function mS(a) {
    return a.af
      ? (a.Jg || a.Ze) && !a.Th && !a.wj
      : a.Ze && a.vg !== !1 && !a.wj && !a.Th;
  }
  function nS(a) {
    if (a.ht) return !1;
    if (a.af) {
      if (!a.Ze && !a.Jg) return !1;
    } else if (!a.Ze) return !1;
    return a.et ||
      a.bt ||
      a.wj ||
      (a.af ? a.vg === !1 && !a.Jg : a.vg === !1) ||
      !a.vo
      ? !1
      : !0;
  }
  function AS(a) {}
  function BS(a) {
    var b = function () {};
    return b;
  }
  function CS(a, b) {}
  function DS(a, b) {
    var c = lm();
    c && c.indexOf(b) > -1 && (a[J.H.Ac] = !0);
  }
  var ES = function (a, b, c) {
    for (var d = 0; d < b.length; d++)
      a.hasOwnProperty(b[d]) && (a[String(b[d])] = c(a[String(b[d])]));
  };
  function FS(a, b, c) {
    var d = this;
    if (!dh(a) || !Yg(b) || !Yg(c))
      throw M(
        this.getName(),
        ["string", "Object|undefined", "Object|undefined"],
        arguments
      );
    var e = b ? B(b, this.T, 1) : {};
    wH([
      function () {
        return N(d, "configure_google_tags", a, e);
      },
    ]);
    var f = c ? B(c) : {},
      g = AH(this);
    f.originatingEntity = XH(g);
    g.priorityQueue && (f.priorityQueue = g.priorityQueue);
    ED(KC(a, e), g.eventId, f);
  }
  FS.R = "internal.gtagConfig";
  function GS(a, b, c, d) {
    var e = this;
  }
  GS.R = "internal.gtagDestinationConfig";
  function IS(a, b) {}
  IS.publicName = "gtagSet";
  function JS() {
    var a = {};
    return a;
  }
  function KS(a) {}
  KS.R = "internal.initializeServiceWorker";
  function LS(a, b) {}
  LS.publicName = "injectHiddenIframe";
  function MS(a, b, c, d, e) {}
  MS.R = "internal.injectHtml";
  var RS = { dl: 1, id: 1 };
  function SS(a, b, c, d) {}
  SS.publicName = "injectScript";
  function TS() {
    var a = Ck,
      b = !1;
    return b;
  }
  TS.R = "internal.isAutoPiiEligible";
  function US(a) {
    var b = !0;
    return b;
  }
  US.publicName = "isConsentGranted";
  function VS(a) {
    var b = !1;
    return b;
  }
  VS.R = "internal.isDebugMode";
  function WS(a) {
    var b = !1;
    return b;
  }
  WS.R = "internal.isDestinationInitialized";
  function XS() {
    return Ik();
  }
  XS.R = "internal.isDmaRegion";
  function YS() {
    return dC();
  }
  YS.R = "internal.isDomReady";
  function ZS(a) {
    var b = !1;
    return b;
  }
  ZS.R = "internal.isEntityInfrastructure";
  function $S(a) {
    var b = !1;
    if (!ih(a)) throw M(this.getName(), ["number"], [a]);
    b = O(a);
    return b;
  }
  $S.R = "internal.isFeatureEnabled";
  function aT() {
    var a = !1;
    return a;
  }
  aT.R = "internal.isFpfe";
  function bT() {
    var a = !1;
    return a;
  }
  bT.R = "internal.isGcpBrowser";
  function cT() {
    var a = !1;
    return a;
  }
  cT.R = "internal.isLandingPage";
  function dT() {
    var a = !1;
    return a;
  }
  dT.R = "internal.isM3blOrTtvDisabled";
  function eT() {
    var a = !1;
    return a;
  }
  eT.R = "internal.isOgt";
  function fT() {
    var a;
    return a;
  }
  fT.R = "internal.isSafariPcmEligibleBrowser";
  function gT() {
    var a = Ih(function (b) {
      AH(this).log("error", b);
    });
    a.publicName = "JSON";
    return a;
  }
  function hT(a) {
    var b = void 0;
    if (!dh(a)) throw M(this.getName(), ["string"], arguments);
    b = Jj(a);
    return Vd(b);
  }
  hT.R = "internal.legacyParseUrl";
  function iT() {
    return !1;
  }
  var jT = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {
      return !1;
    },
    removeItem: function (a) {},
  };
  function kT() {
    try {
      N(this, "logging");
    } catch (d) {
      return;
    }
    if (!console) return;
    for (
      var a = Array.prototype.slice.call(arguments, 0), b = 0;
      b < a.length;
      b++
    )
      a[b] = B(a[b], this.T);
    var c = AH(this);
    console.log.apply(console, a);
    XH(c);
  }
  kT.publicName = "logToConsole";
  function lT(a, b) {}
  lT.R = "internal.mergeRemoteConfig";
  function mT(a, b, c) {
    c = c === void 0 ? !0 : c;
    var d = [];
    return Vd(d);
  }
  mT.R = "internal.parseCookieValuesFromString";
  function nT(a) {
    var b = void 0;
    if (typeof a !== "string") return;
    a && Zb(a, "//") && (a = A.location.protocol + a);
    if (typeof URL === "function") {
      var c;
      a: {
        var d;
        try {
          d = new URL(a);
        } catch (w) {
          c = void 0;
          break a;
        }
        for (
          var e = {}, f = Array.from(d.searchParams), g = 0;
          g < f.length;
          g++
        ) {
          var h = f[g][0],
            k = f[g][1];
          e.hasOwnProperty(h)
            ? typeof e[h] === "string"
              ? (e[h] = [e[h], k])
              : e[h].push(k)
            : (e[h] = k);
        }
        c = {
          href: d.href,
          origin: d.origin,
          protocol: d.protocol,
          username: d.username,
          password: d.password,
          host: d.host,
          hostname: d.hostname,
          port: d.port,
          pathname: d.pathname,
          search: d.search,
          searchParams: e,
          hash: d.hash,
        };
      }
      return Vd(c);
    }
    var m;
    try {
      m = Jj(a);
    } catch (w) {
      return;
    }
    if (!m.protocol || !m.host) return;
    var p = {};
    if (m.search)
      for (
        var q = m.search.replace("?", "").split("&"), r = 0;
        r < q.length;
        r++
      ) {
        var t = q[r].split("="),
          u = t[0],
          v = Cj(t.splice(1).join("=")) || "";
        v = v.replace(/\+/g, " ");
        p.hasOwnProperty(u)
          ? typeof p[u] === "string"
            ? (p[u] = [p[u], v])
            : p[u].push(v)
          : (p[u] = v);
      }
    m.searchParams = p;
    m.origin = m.protocol + "//" + m.host;
    m.username = "";
    m.password = "";
    b = Vd(m);
    return b;
  }
  nT.publicName = "parseUrl";
  function oT(a) {}
  oT.R = "internal.processAsNewEvent";
  function pT(a, b, c) {
    var d;
    return d;
  }
  pT.R = "internal.pushToDataLayer";
  function qT(a) {
    var b = Oa.apply(1, arguments),
      c = !1;
    return c;
  }
  qT.publicName = "queryPermission";
  function rT(a) {
    var b = this;
  }
  rT.R = "internal.queueAdsTransmission";
  function sT(a) {
    var b = void 0;
    return b;
  }
  sT.publicName = "readAnalyticsStorage";
  function tT() {
    var a = "";
    return a;
  }
  tT.publicName = "readCharacterSet";
  function uT() {
    return E(19);
  }
  uT.R = "internal.readDataLayerName";
  function vT() {
    var a = "";
    return a;
  }
  vT.publicName = "readTitle";
  function wT(a, b) {
    var c = this;
  }
  wT.R = "internal.registerCcdCallback";
  function xT(a, b) {
    return !0;
  }
  xT.R = "internal.registerDestination";
  var yT = ["event"];
  function zT(a, b, c) {}
  zT.R = "internal.registerGtagCommandListener";
  function AT(a, b) {
    var c = !1;
    return c;
  }
  AT.R = "internal.removeDataLayerEventListener";
  function BT(a, b) {}
  BT.R = "internal.removeFormData";
  function CT() {}
  CT.publicName = "resetDataLayer";
  function DT(a, b, c) {
    var d = void 0;
    return d;
  }
  DT.R = "internal.scrubUrlParams";
  function ET(a) {}
  ET.R = "internal.sendAdsHit";
  function FT(a, b, c, d) {}
  FT.R = "internal.sendGtagEvent";
  function GT(a, b, c) {}
  GT.publicName = "sendPixel";
  function HT(a, b) {}
  HT.R = "internal.setAnchorHref";
  function IT(a) {}
  IT.R = "internal.setContainerConsentDefaults";
  function JT(a, b, c, d) {
    var e = this;
    d = d === void 0 ? !0 : d;
    var f = !1;
    return f;
  }
  JT.publicName = "setCookie";
  function KT(a) {}
  KT.R = "internal.setCorePlatformServices";
  function LT(a, b) {}
  LT.R = "internal.setDataLayerValue";
  function MT(a) {}
  MT.publicName = "setDefaultConsentState";
  function NT(a, b) {}
  NT.R = "internal.setDelegatedConsentType";
  function OT(a, b) {}
  OT.R = "internal.setFormAction";
  function PT(a, b, c) {
    c = c === void 0 ? !1 : c;
  }
  PT.R = "internal.setInCrossContainerData";
  function QT(a, b, c) {
    return !1;
  }
  QT.publicName = "setInWindow";
  function RT(a, b, c) {}
  RT.R = "internal.setProductSettingsParameter";
  function ST(a, b, c) {}
  ST.R = "internal.setRemoteConfigParameter";
  function TT(a, b) {}
  TT.R = "internal.setTransmissionMode";
  function UT(a, b, c, d) {
    var e = this;
  }
  UT.publicName = "sha256";
  function VT(a, b, c) {}
  VT.R = "internal.sortRemoteConfigParameters";
  function WT(a) {}
  WT.R = "internal.storeAdsBraidLabels";
  function XT(a, b) {
    var c = void 0;
    return c;
  }
  XT.R = "internal.subscribeToCrossContainerData";
  var ZT = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {},
    removeItem: function (a) {},
    clear: function () {},
    publicName: "templateStorage",
  };
  function $T(a, b) {
    var c = !1;
    return c;
  }
  $T.R = "internal.testRegex";
  function aU(a) {
    var b;
    return b;
  }
  function bU(a, b) {}
  bU.R = "internal.trackUsage";
  function cU(a, b) {
    var c;
    return c;
  }
  cU.R = "internal.unsubscribeFromCrossContainerData";
  function dU(a) {}
  dU.publicName = "updateConsentState";
  function eU(a) {
    var b = !1;
    return b;
  }
  eU.R = "internal.userDataNeedsEncryption";
  var fU = function () {
      this.D = new bi();
    },
    hU = function () {
      var a = gU;
      return function (b) {
        var c;
        var d = a.D;
        if (d.contains(b)) c = d.get(b, this);
        else {
          var e;
          if ((e = d.D.hasOwnProperty(b))) {
            var f = this.T.lb();
            if (f) {
              var g = !1,
                h = f.Sb();
              if (h) {
                sh(h) || (g = !0);
              }
              e = g;
            } else e = !0;
          }
          if (e) {
            var k = d.D.hasOwnProperty(b) ? d.D[b] : void 0;
            c = k;
          } else throw Error(b + " is not a valid API name.");
        }
        return c;
      };
    },
    gU;
  function iU(a, b, c) {
    gU || (gU = new fU());
    gU.D.add(a, b, c);
  }
  function jU(a, b) {
    gU || (gU = new fU());
    var c = gU.D;
    if (c.D.hasOwnProperty(a))
      throw Error(
        "Attempting to add a private function which already exists: " + a + "."
      );
    if (c.contains(a))
      throw Error(
        "Attempting to add a private function with an existing API name: " +
          a +
          "."
      );
    c.D[a] = Db(b) ? lh(a, b) : mh(a, b);
  }
  function kU(a, b) {
    function c(d) {
      if (!Xg(d)) throw M(this.getName(), ["Object"], arguments);
      var e = B(d, this.T, 1).Ab();
      a(e);
    }
    c.R = "internal." + b;
    return c;
  }
  function lU() {
    var a = function (c) {
        return void jU(c.R, c);
      },
      b = function (c) {
        return void iU(c.publicName, c);
      };
    b(uH);
    b(BH);
    b(uI);
    b(wI);
    b(xI);
    b($I);
    b(bJ);
    b(bK);
    b(gT());
    b(dK);
    b(fP);
    b(gP);
    b(DP);
    b(EP);
    b(FP);
    b(MP);
    b(NP);
    b(IS);
    b(LS);
    b(SS);
    b(US);
    b(kT);
    b(nT);
    b(qT);
    b(sT);
    b(tT);
    b(vT);
    b(GT);
    b(JT);
    b(MT);
    b(QT);
    b(UT);
    b(ZT);
    b(dU);
    iU("Math", qh());
    iU("Object", $h);
    iU("TestHelper", di());
    iU("assertApi", nh);
    iU("assertThat", oh);
    iU("decodeUri", th);
    iU("decodeUriComponent", uh);
    iU("encodeUri", vh);
    iU("encodeUriComponent", wh);
    iU("fail", Dh);
    iU("generateRandom", Fh);
    iU("getTimestamp", Gh);
    iU("getTimestampMillis", Gh);
    iU("getType", Hh);
    iU("makeInteger", Jh);
    iU("makeNumber", Kh);
    iU("makeString", Lh);
    iU("makeTableMap", Vh);
    iU("mock", Yh);
    iU("mockObject", Zh);
    iU("fromBase64", $O, !("atob" in x));
    iU("localStorage", jT, !iT());
    iU("toBase64", aU, !("btoa" in x));
    a(tH);
    a(xH);
    a(RH);
    a(WH);
    a(lI);
    a(sI);
    a(vI);
    a(yI);
    a(zI);
    a(CI);
    a(VI);
    a(WI);
    a(XI);
    a(YI);
    a(ZI);
    a(aJ);
    a(cJ);
    a(aK);
    a(cK);
    a(eK);
    a(fK);
    a(gK);
    a(hK);
    a(iK);
    a(RK);
    a(ZK);
    a(bL);
    a(iL);
    a(jL);
    a(pL);
    a(uL);
    a(zL);
    a(GL);
    a(LL);
    a(WL);
    a(YL);
    a(kM);
    a(lM);
    a(mM);
    a(YO);
    a(ZO);
    a(aP);
    a(bP);
    a(cP);
    a(dP);
    a(eP);
    a(hP);
    a(iP);
    a(jP);
    a(kP);
    a(lP);
    a(mP);
    a(nP);
    a(oP);
    a(pP);
    a(qP);
    a(rP);
    a(sP);
    a(tP);
    a(uP);
    a(vP);
    a(wP);
    a(xP);
    a(yP);
    a(zP);
    a(AP);
    a(BP);
    a(CP);
    a(GP);
    a(HP);
    a(IP);
    a(JP);
    a(KP);
    a(LP);
    a(OP);
    a(FS);
    a(GS);
    a(KS);
    a(MS);
    a(TS);
    a(VS);
    a(WS);
    a(XS);
    a(YS);
    a(ZS);
    a($S);
    a(aT);
    a(bT);
    a(cT);
    a(dT);
    a(eT);
    a(fT);
    a(hT);
    a(jI);
    a(lT);
    a(mT);
    a(oT);
    a(pT);
    a(rT);
    a(uT);
    a(wT);
    a(xT);
    a(zT);
    a(AT);
    a(BT);
    a(DT);
    a(ET);
    a(FT);
    a(HT);
    a(IT);
    a(KT);
    a(LT);
    a(NT);
    a(OT);
    a(PT);
    a(RT);
    a(ST);
    a(TT);
    a(VT);
    a(WT);
    a(XT);
    a($T);
    a(bU);
    a(cU);
    a(eU);
    jU("internal.IframingStateSchema", JS());
    jU("internal.quickHash", Eh);
    gU || (gU = new fU());
    return hU();
  }
  var XF;
  function mU() {
    XF.rd(function (a, b, c) {
      lo();
      var d = jo;
      d.D.SANDBOXED_JS_SEMAPHORE = d.D.SANDBOXED_JS_SEMAPHORE || 0;
      d.D.SANDBOXED_JS_SEMAPHORE++;
      try {
        return a.apply(b, c);
      } finally {
        lo(), jo.D.SANDBOXED_JS_SEMAPHORE--;
      }
    });
  }
  function nU(a) {
    if (a && a.length)
      for (
        var b = aj(21, function () {
            return {};
          }),
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c].replace(/^_*/, "");
        b[d] = ["sandboxedScripts"];
      }
  }
  function oU(a) {
    if (a) {
      var b = aj(21, function () {
        return {};
      });
      Lb(a, function (c, d) {
        for (var e = 0; e < d.length; e++) {
          var f = d[e].replace(/^_*/, "");
          b[f] = b[f] || [];
          b[f].push(c);
        }
      });
    }
  }
  function pU(a) {
    ED(IC("developer_id." + a, !0), 0, {});
  }
  function qU(a, b) {
    return Bb(a, b || null);
  }
  function Y(a) {
    return window.encodeURIComponent(a);
  }
  function rU(a) {
    hd(a, void 0, void 0);
  }
  function sU(a) {
    var b = ["veinteractive.com", "ve-interactive.cn"];
    if (!a) return !1;
    var c = Dj(Jj(a), "host");
    if (!c) return !1;
    for (var d = 0; b && d < b.length; d++) {
      var e = b[d] && b[d].toLowerCase();
      if (e) {
        var f = c.length - e.length;
        f > 0 && e.charAt(0) !== "." && (f--, (e = "." + e));
        if (f >= 0 && c.indexOf(e, f) === f) return !0;
      }
    }
    return !1;
  }
  function tU(a, b, c) {
    for (var d = {}, e = !1, f = 0; a && f < a.length; f++)
      a[f] &&
        a[f].hasOwnProperty(b) &&
        a[f].hasOwnProperty(c) &&
        ((d[a[f][b]] = a[f][c]), (e = !0));
    return e ? d : null;
  }
  function uU(a, b) {
    var c = {};
    if (a) for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
    if (b) {
      var e = tU(b, "parameter", "parameterValue");
      e && (c = qU(e, c));
    }
    return c;
  }
  function vU(a, b, c) {
    return a === void 0 || a === c ? b : a;
  }
  var wU = { Xa: { pk: 1, jn: 2, qn: 3, rn: 4, sn: 5, Vq: 6 } };
  wU.Xa[wU.Xa.pk] = "ADOBE_COMMERCE";
  wU.Xa[wU.Xa.jn] = "SQUARESPACE";
  wU.Xa[wU.Xa.qn] = "WOO_COMMERCE";
  wU.Xa[wU.Xa.rn] = "WOO_COMMERCE_LEGACY";
  wU.Xa[wU.Xa.sn] = "WORD_PRESS";
  wU.Xa[wU.Xa.Vq] = "SHOPIFY";
  function xU(a) {
    var b = x;
    return Cj(b.escape(b.atob(a)));
  }
  function yU() {
    try {
      if (!O(498)) return [];
      var a = uk(qk.da.Sm);
      if (Array.isArray(a)) return a;
      var b = [],
        c;
      a: {
        try {
          c = !!A.querySelector('script[data-requiremodule^="mage/"]');
          break a;
        } catch (u) {}
        c = !1;
      }
      c && b.push(wU.Xa.pk);
      var d;
      a: {
        try {
          var e = xU("YXNzZXRzLnNxdWFyZXNwYWNlLmNvbS8=");
          d = e ? !!A.querySelector('script[src^="//' + e + '"]') : !1;
          break a;
        } catch (u) {}
        d = !1;
      }
      d && b.push(wU.Xa.jn);
      var f;
      a: {
        try {
          f = !!A.querySelector(
            'script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]'
          );
          break a;
        } catch (u) {}
        f = !1;
      }
      f && b.push(wU.Xa.rn);
      var g;
      a: {
        try {
          var h,
            k = ((h = A.location) == null ? void 0 : h.hostname) || "",
            m,
            p = ((m = A.location) == null ? void 0 : m.origin) || "",
            q = xU("LndvcmRwcmVzcy5jb20="),
            r = xU("Ly9zLncub3Jn");
          g =
            q && r
              ? $b(k, q) ||
                !!A.querySelector(
                  '[src^="' +
                    p +
                    '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="' +
                    (r + '"]')
                )
              : !1;
          break a;
        } catch (u) {}
        g = !1;
      }
      g && b.push(wU.Xa.sn);
      var t;
      a: {
        try {
          t = !!A.querySelector(
            '[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]'
          );
          break a;
        } catch (u) {}
        t = !1;
      }
      t && b.push(wU.Xa.qn);
      dC() && tk(qk.da.Sm, b);
      return b;
    } catch (u) {}
    return [];
  }
  function zU(a, b, c) {
    return cd(a, b, c, void 0);
  }
  function AU(a, b) {
    x[a] = b;
  }
  function BU(a, b, c) {
    var d = x;
    b && (d[a] === void 0 || (c && !d[a])) && (d[a] = b);
    return d[a];
  }
  var CU = {},
    DU = Qu.W;
  var Z = { securityGroups: {} };

  (Z.securityGroups.access_globals = ["google"]),
    (function () {
      function a(b, c, d) {
        var e = { key: d, read: !1, write: !1, execute: !1 };
        switch (c) {
          case "read":
            e.read = !0;
            break;
          case "write":
            e.write = !0;
            break;
          case "readwrite":
            e.read = e.write = !0;
            break;
          case "execute":
            e.execute = !0;
            break;
          default:
            throw Error("Invalid " + b + " request " + c);
        }
        return e;
      }
      (function (b) {
        Z.__access_globals = b;
        Z.__access_globals.P = "access_globals";
        Z.__access_globals.isVendorTemplate = !0;
        Z.__access_globals.priorityOverride = 0;
        Z.__access_globals.isInfrastructure = !1;
        Z.__access_globals["6"] = !1;
      })(function (b) {
        for (
          var c = b.vtp_keys || [],
            d = b.vtp_createPermissionError,
            e = [],
            f = [],
            g = [],
            h = 0;
          h < c.length;
          h++
        ) {
          var k = c[h],
            m = k.key;
          k.read && e.push(m);
          k.write && f.push(m);
          k.execute && g.push(m);
        }
        return {
          assert: function (p, q, r) {
            if (!Eb(r)) throw d(p, {}, "Key must be a string.");
            if (q === "read") {
              if (e.indexOf(r) > -1) return;
            } else if (q === "write") {
              if (f.indexOf(r) > -1) return;
            } else if (q === "readwrite") {
              if (f.indexOf(r) > -1 && e.indexOf(r) > -1) return;
            } else if (q === "execute") {
              if (g.indexOf(r) > -1) return;
            } else
              throw d(
                p,
                {},
                "Operation must be either 'read', 'write', or 'execute', was " +
                  q
              );
            throw d(
              p,
              {},
              "Prohibited " + q + " on global variable: " + r + "."
            );
          },
          ba: a,
        };
      });
    })();
  (Z.securityGroups.get_referrer = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_referrer = b;
        Z.__get_referrer.P = "get_referrer";
        Z.__get_referrer.isVendorTemplate = !0;
        Z.__get_referrer.priorityOverride = 0;
        Z.__get_referrer.isInfrastructure = !1;
        Z.__get_referrer["6"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Eb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!Eb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          ba: a,
        };
      });
    })();
  (Z.securityGroups.read_event_data = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_event_data = b;
        Z.__read_event_data.P = "read_event_data";
        Z.__read_event_data.isVendorTemplate = !0;
        Z.__read_event_data.priorityOverride = 0;
        Z.__read_event_data.isInfrastructure = !1;
        Z.__read_event_data["6"] = !1;
      })(function (b) {
        var c = b.vtp_eventDataAccess,
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (g != null && !Eb(g))
              throw e(f, { key: g }, "Key must be a string.");
            if (c !== "any") {
              try {
                if (c === "specific" && g != null && wg(g, d)) return;
              } catch (h) {
                throw e(f, { key: g }, "Invalid key filter.");
              }
              throw e(f, { key: g }, "Prohibited read from event data.");
            }
          },
          ba: a,
        };
      });
    })();

  (Z.securityGroups.read_data_layer = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_data_layer = b;
        Z.__read_data_layer.P = "read_data_layer";
        Z.__read_data_layer.isVendorTemplate = !0;
        Z.__read_data_layer.priorityOverride = 0;
        Z.__read_data_layer.isInfrastructure = !1;
        Z.__read_data_layer["6"] = !1;
      })(function (b) {
        var c = b.vtp_allowedKeys || "specific",
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Eb(g)) throw e(f, {}, "Keys must be strings.");
            if (c !== "any") {
              try {
                if (wg(g, d)) return;
              } catch (h) {
                throw e(f, {}, "Invalid key filter.");
              }
              throw e(
                f,
                {},
                "Prohibited read from data layer variable: " + g + "."
              );
            }
          },
          ba: a,
        };
      });
    })();

  (Z.securityGroups.load_google_tags = ["google"]),
    (function () {
      function a(b, c, d) {
        return { tagId: c, firstPartyUrl: d };
      }
      (function (b) {
        Z.__load_google_tags = b;
        Z.__load_google_tags.P = "load_google_tags";
        Z.__load_google_tags.isVendorTemplate = !0;
        Z.__load_google_tags.priorityOverride = 0;
        Z.__load_google_tags.isInfrastructure = !1;
        Z.__load_google_tags["6"] = !1;
      })(function (b) {
        var c = b.vtp_allowedTagIds || "specific",
          d = b.vtp_allowFirstPartyUrls || !1,
          e = b.vtp_allowedFirstPartyUrls || "specific",
          f = b.vtp_urls || [],
          g = b.vtp_tagIds || [],
          h = b.vtp_createPermissionError;
        return {
          assert: function (k, m, p) {
            (function (q) {
              if (!Eb(q)) throw h(k, {}, "Tag ID must be a string.");
              if (c !== "any" && (c !== "specific" || g.indexOf(q) === -1))
                throw h(k, {}, "Prohibited Tag ID: " + q + ".");
            })(m);
            (function (q) {
              if (q !== void 0) {
                if (!Eb(q)) throw h(k, {}, "First party URL must be a string.");
                if (d) {
                  if (e === "any") return;
                  if (e === "specific")
                    try {
                      if (Og(Jj(q), f)) return;
                    } catch (r) {
                      throw h(k, {}, "Invalid first party URL filter.");
                    }
                }
                throw h(k, {}, "Prohibited first party URL: " + q);
              }
            })(p);
          },
          ba: a,
        };
      });
    })();

  (Z.securityGroups.get_url = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_url = b;
        Z.__get_url.P = "get_url";
        Z.__get_url.isVendorTemplate = !0;
        Z.__get_url.priorityOverride = 0;
        Z.__get_url.isInfrastructure = !1;
        Z.__get_url["6"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"),
          b.vtp_fragment && c.push("fragment"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Eb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!Eb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          ba: a,
        };
      });
    })();

  (Z.securityGroups.logging = ["google"]),
    (function () {
      function a() {
        return {};
      }
      (function (b) {
        Z.__logging = b;
        Z.__logging.P = "logging";
        Z.__logging.isVendorTemplate = !0;
        Z.__logging.priorityOverride = 0;
        Z.__logging.isInfrastructure = !1;
        Z.__logging["6"] = !1;
      })(function (b) {
        var c = b.vtp_environments || "debug",
          d = b.vtp_createPermissionError;
        return {
          assert: function (e) {
            var f;
            if ((f = c !== "all" && !0)) {
              var g = !1;
              f = !g;
            }
            if (f) throw d(e, {}, "Logging is not enabled in all environments");
          },
          ba: a,
        };
      });
    })();
  (Z.securityGroups.configure_google_tags = ["google"]),
    (function () {
      function a(b, c, d) {
        return { tagId: c, configuration: d };
      }
      (function (b) {
        Z.__configure_google_tags = b;
        Z.__configure_google_tags.P = "configure_google_tags";
        Z.__configure_google_tags.isVendorTemplate = !0;
        Z.__configure_google_tags.priorityOverride = 0;
        Z.__configure_google_tags.isInfrastructure = !1;
        Z.__configure_google_tags["6"] = !1;
      })(function (b) {
        var c = b.vtp_allowedTagIds || "specific",
          d = b.vtp_tagIds || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Eb(g)) throw e(f, {}, "Tag ID must be a string.");
            if (c !== "any" && (c !== "specific" || d.indexOf(g) === -1))
              throw e(f, {}, "Prohibited configuration for Tag ID: " + g + ".");
          },
          ba: a,
        };
      });
    })();

  function EU() {
    var a = {},
      b = {
        dataLayer: eA,
        callback: function (c) {
          a.hasOwnProperty(c) && Db(a[c]) && a[c]();
          delete a[c];
        },
        bootstrap: 0,
      };
    return b;
  }
  function FU() {
    var a = EU();
    oo(a);
    xm();
    QA();
    var b = aj(21, function () {
      return {};
    });
    Xb(b, Z.securityGroups);
    var c = qm(rm()),
      d,
      e = c == null ? void 0 : (d = c.context) == null ? void 0 : d.source;
    ap(e, c == null ? void 0 : c.parent);
    (e !== 2 && e !== 4 && e !== 3) || S(142);
    return a;
  }
  function GU() {
    var a = E(60);
    if (a)
      for (var b = a.split("."), c = 0; c < b.length; c++) {
        var d = b[c],
          e = iN;
        d && (e.D[d] = !0);
      }
  }
  function HU() {
    fq();
    lo();
    for (
      var a = data.resource || {}, b = AA, c = a.macros || [], d = 0;
      d < c.length;
      d++
    )
      b.macros.push(new rA(c[d], d, b.tags, b.macros));
    for (var e = a.tags || [], f = 0; f < e.length; f++)
      b.tags.push(new vA(e[f], f, b.tags, b.macros));
    for (var g = a.predicates || [], h = 0; h < g.length; h++)
      b.predicates.push(new sA(g[h], b.tags, b.macros));
    for (var k = a.rules || [], m = 0; m < k.length; m++)
      b.rules.push(new tA(k[m], m));
    Yz = Z;
    var p = data.permissions || {},
      q = Z;
    cg = new bg(E(5), p, q);
    var r = data.sandboxed_scripts,
      t = data.security_groups,
      u = data.runtime || [],
      v = data.runtime_lines;
    XF = new pf();
    mU();
    Xz = WF();
    var w = XF,
      y = lU(),
      z = new Od("require", y);
    z.Ya();
    w.D.D.set("require", z);
    db.set("require", z);
    for (var C = 0; C < u.length; C++) {
      var D = u[C];
      if (!Array.isArray(D) || D.length < 3) {
        if (D.length === 0) continue;
        break;
      }
      v && v[C] && v[C].length && Of(D, v[C]);
      try {
        XF.execute(D);
      } catch (IU) {}
    }
    nU(r);
    oU(t);
    var G = FU();
    zF();
    Ck.bind();
    if (!uj) {
      var F = Ik() ? xp(Kf(5)) : xp(Kf(4)),
        I = n(jp),
        L = I.next(),
        P;
      try {
        for (; !L.done; L = I.next()) {
          var R = L.value,
            U = R,
            X = F[R] ? "granted" : "denied";
          Lm().implicit(U, X);
        }
      } finally {
        L && !L.done && (P = I.return) && P.call(I);
      }
    }
    zE.bind();
    cC();
    YB();
    O(610) && (yy(), xy(Ay), zy());
    fl.M &&
      (O(610) || (yy(), xy(Ay), zy()),
      NA(),
      (mB = new lB()),
      xy(qz),
      fD(),
      TF || (TF = new RF()),
      pB || (pB = new oB()));
    if (fl.J) {
      VE.bind();
      FC.bind();
      OE.bind();
      var ea = um();
      if (ea) {
        var ja;
        a: {
          var va,
            Ga = (va = ea.scriptElement) == null ? void 0 : va.src;
          if (Ga) {
            var ka;
            try {
              var ia;
              ka =
                (ia = Ad()) == null ? void 0 : ia.getEntriesByType("resource");
            } catch (IU) {}
            if (ka) {
              var ab = -1,
                vb = n(ka),
                gb = vb.next(),
                wb;
              try {
                for (; !gb.done; gb = vb.next()) {
                  var Ub = gb.value;
                  if (
                    Ub.initiatorType === "script" &&
                    ((ab += 1), Ub.name.replace(dF, "") === Ga.replace(dF, ""))
                  ) {
                    ja = ab;
                    break a;
                  }
                }
              } finally {
                gb && !gb.done && (wb = vb.return) && wb.call(vb);
              }
              S(146);
            } else S(145);
          }
          ja = void 0;
        }
        var ed = ja;
        ed !== void 0 &&
          (ea.canonicalContainerId &&
            hj("rtg", String(ea.canonicalContainerId)),
          hj("slo", String(ed)),
          hj("hlo", ea.htmlLoadOrder || "-1"),
          hj("lst", String(ea.loadScriptType || "0")));
      } else S(144);
      var Vb;
      var hc = pm();
      if (hc)
        if (hc.canonicalContainerId) Vb = hc.canonicalContainerId;
        else {
          var hg,
            yh =
              hc.scriptContainerId ||
              ((hg = hc.destinations) == null ? void 0 : hg[0]);
          Vb = yh ? "_" + yh : void 0;
        }
      else Vb = void 0;
      var jj = Vb;
      jj && hj("pcid", jj);
      hj("bt", String(Hf(47) ? 2 : Hf(50) ? 1 : 0));
      hj("ct", String(Hf(47) ? 0 : Hf(50) ? 1 : 3));
      SE.bind();
      var kj = [],
        Tl = [],
        sm = n(Object.keys(YE)),
        vj = sm.next(),
        aF;
      try {
        for (; !vj.done; vj = sm.next()) {
          var tm = vj.value;
          if (window.isSecureContext || !$E[tm]) {
            var bF = YE[tm]();
            if (Db(bF)) {
              var cF = Function.prototype.toString.call(bF);
              $b(cF, "{ [native code] }") ||
                $b(cF, "{\n    [native code]\n}") ||
                Tl.push(tm);
            } else kj.push(tm);
          }
        }
      } finally {
        vj && !vj.done && (aF = sm.return) && aF.call(sm);
      }
      kj.length > 0 && hj("jsm", kj.join("~"));
      Tl.length > 0 && hj("jsp", Tl.join("~"));
    }
    yF();
    pk(1);
    hI();
    return G;
  }
  function Bk() {
    try {
      if (!Zj() && (Hf(47) || !Im()))
        if (Hf(70)) IA();
        else {
          Hf(64) && lj.D.J.add(118517917);
          pj();
          qj();
          fl.D && Az();
          Mh[5] = !0;
          var a = ko("debugGroupId", function () {
            return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
          });
          ip(a);
          Tt();
          QF();
          mu();
          ZB();
          if (ym()) {
            E(5);
            gI();
            sB().removeExternalRestrictions(nm());
          } else {
            HU().bootstrap = Sb();
            Hf(51) && HE();
            fl.D && Bz();
            typeof x.name === "string" &&
            Zb(x.name, "web-pixel-sandbox-CUSTOM") &&
            Bd()
              ? pU("dMDg0Yz")
              : x.Shopify && (pU("dN2ZkMj"), Bd() && pU("dNTU0Yz"));
            GU();
          }
        }
    } catch (b) {
      pk(5), By();
    }
  }
  (function (a) {
    function b() {
      g = A.documentElement.getAttribute("data-tag-assistant-present");
      No(g) && (f = e.bm);
    }
    function c() {
      f && Uc ? ((BA = !0), d(f)) : a();
    }
    if (Hf(70)) a();
    else {
      var d = function (q) {
          var r = "GTM",
            t = "GTM";
          Hf(45) && ((r = "OGT"), (t = "GTAG"));
          var u = E(23),
            v = x[u];
          v ||
            ((v = []),
            (x[u] = v),
            cd(
              "https://" +
                E(3) +
                "/debug/bootstrap?id=" +
                E(5) +
                "&src=" +
                t +
                "&cond=" +
                String(q) +
                "&gtm=" +
                Nu()
            ));
          var w = {
              messageType: "CONTAINER_STARTING",
              data: {
                scriptSource: Uc,
                containerProduct: r,
                debug: !1,
                id: E(5),
                targetRef: {
                  ctid: E(5),
                  isDestination: km(),
                  canonicalId: E(6),
                },
                aliases: om(),
                destinations: lm(),
              },
            },
            y = w.data;
          y.resume = function () {
            a();
          };
          y.resumeWithMemos = function () {
            Zo(1);
            a();
          };
          Hf(2) && (w.data.initialPublish = !0);
          v.push(w);
        },
        e = { zq: 1, Am: 2, Vm: 3, Ok: 4, bm: 5 };
      e[e.zq] = "GTM_DEBUG_LEGACY_PARAM";
      e[e.Am] = "GTM_DEBUG_PARAM";
      e[e.Vm] = "REFERRER";
      e[e.Ok] = "COOKIE";
      e[e.bm] = "EXTENSION_PARAM";
      var f = void 0,
        g = void 0,
        h = Dj(x.location, "query", !1, void 0, "gtm_debug");
      No(h) && (f = e.Am);
      if (!f && A.referrer) {
        var k = Jj(A.referrer);
        Fj(k, "host") === E(24) && (f = e.Vm);
      }
      if (!f) {
        var m = Lq("__TAG_ASSISTANT");
        m.length && m[0].length && (f = e.Ok);
      }
      f || b();
      if (!f && Mo(g)) {
        var p = !1;
        id(
          A,
          "TADebugSignal",
          function () {
            p || ((p = !0), b(), c());
          },
          !1
        );
        x.setTimeout(function () {
          p || ((p = !0), b(), c());
        }, 200);
      } else c();
    }
  })(function () {
    !Hf(47) || Ak()["0"] ? Bk() : Ek();
  });
})();
