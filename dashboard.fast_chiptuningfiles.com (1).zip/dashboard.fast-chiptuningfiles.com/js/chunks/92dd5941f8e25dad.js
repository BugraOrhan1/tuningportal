/*! For license information please see 92dd5941f8e25dad.js.LICENSE.txt */
"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
  [744],
  {
    3744: function (e, t, n) {
      n.r(t),
        n.d(t, {
          default: function () {
            return v;
          },
        });
      var o = n(29726),
        r = (0, n(5615).nY)("modal", function () {
          var e = (0, o.ref)("component"),
            t = (0, o.ref)(!1),
            n = (0, o.ref)(!1),
            r = (0, o.ref)({});
          return {
            type: e,
            isOpen: t,
            resize: n,
            config: r,
            open: function () {
              var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : null;
              (r.value = e || r.value), (t.value = !0);
            },
            close: function () {
              t.value = !1;
            },
          };
        }),
        i = n(2543);
      function u(e) {
        return (
          (u =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (e) {
                  return typeof e;
                }
              : function (e) {
                  return e &&
                    "function" == typeof Symbol &&
                    e.constructor === Symbol &&
                    e !== Symbol.prototype
                    ? "symbol"
                    : typeof e;
                }),
          u(e)
        );
      }
      function c() {
        var e,
          t,
          n = "function" == typeof Symbol ? Symbol : {},
          o = n.iterator || "@@iterator",
          r = n.toStringTag || "@@toStringTag";
        function i(n, o, r, i) {
          var c = o && o.prototype instanceof l ? o : l,
            f = Object.create(c.prototype);
          return (
            a(
              f,
              "_invoke",
              (function (n, o, r) {
                var i,
                  c,
                  a,
                  l = 0,
                  f = r || [],
                  s = !1,
                  p = {
                    p: 0,
                    n: 0,
                    v: e,
                    a: h,
                    f: h.bind(e, 4),
                    d: function (t, n) {
                      return (i = t), (c = 0), (a = e), (p.n = n), u;
                    },
                  };
                function h(n, o) {
                  for (
                    c = n, a = o, t = 0;
                    !s && l && !r && t < f.length;
                    t++
                  ) {
                    var r,
                      i = f[t],
                      h = p.p,
                      v = i[2];
                    n > 3
                      ? (r = v === o) &&
                        ((a = i[(c = i[4]) ? 5 : ((c = 3), 3)]),
                        (i[4] = i[5] = e))
                      : i[0] <= h &&
                        ((r = n < 2 && h < i[1])
                          ? ((c = 0), (p.v = o), (p.n = i[1]))
                          : h < v &&
                            (r = n < 3 || i[0] > o || o > v) &&
                            ((i[4] = n), (i[5] = o), (p.n = v), (c = 0)));
                  }
                  if (r || n > 1) return u;
                  throw ((s = !0), o);
                }
                return function (r, f, v) {
                  if (l > 1) throw TypeError("Generator is already running");
                  for (
                    s && 1 === f && h(f, v), c = f, a = v;
                    (t = c < 2 ? e : a) || !s;

                  ) {
                    i ||
                      (c
                        ? c < 3
                          ? (c > 1 && (p.n = -1), h(c, a))
                          : (p.n = a)
                        : (p.v = a));
                    try {
                      if (((l = 2), i)) {
                        if ((c || (r = "next"), (t = i[r]))) {
                          if (!(t = t.call(i, a)))
                            throw TypeError("iterator result is not an object");
                          if (!t.done) return t;
                          (a = t.value), c < 2 && (c = 0);
                        } else
                          1 === c && (t = i.return) && t.call(i),
                            c < 2 &&
                              ((a = TypeError(
                                "The iterator does not provide a '" +
                                  r +
                                  "' method"
                              )),
                              (c = 1));
                        i = e;
                      } else if ((t = (s = p.n < 0) ? a : n.call(o, p)) !== u)
                        break;
                    } catch (t) {
                      (i = e), (c = 1), (a = t);
                    } finally {
                      l = 1;
                    }
                  }
                  return { value: t, done: s };
                };
              })(n, r, i),
              !0
            ),
            f
          );
        }
        var u = {};
        function l() {}
        function f() {}
        function s() {}
        t = Object.getPrototypeOf;
        var p = [][o]
            ? t(t([][o]()))
            : (a((t = {}), o, function () {
                return this;
              }),
              t),
          h = (s.prototype = l.prototype = Object.create(p));
        function v(e) {
          return (
            Object.setPrototypeOf
              ? Object.setPrototypeOf(e, s)
              : ((e.__proto__ = s), a(e, r, "GeneratorFunction")),
            (e.prototype = Object.create(h)),
            e
          );
        }
        return (
          (f.prototype = s),
          a(h, "constructor", s),
          a(s, "constructor", f),
          (f.displayName = "GeneratorFunction"),
          a(s, r, "GeneratorFunction"),
          a(h),
          a(h, r, "Generator"),
          a(h, o, function () {
            return this;
          }),
          a(h, "toString", function () {
            return "[object Generator]";
          }),
          (c = function () {
            return { w: i, m: v };
          })()
        );
      }
      function a(e, t, n, o) {
        var r = Object.defineProperty;
        try {
          r({}, "", {});
        } catch (e) {
          r = 0;
        }
        (a = function (e, t, n, o) {
          function i(t, n) {
            a(e, t, function (e) {
              return this._invoke(t, n, e);
            });
          }
          t
            ? r
              ? r(e, t, {
                  value: n,
                  enumerable: !o,
                  configurable: !o,
                  writable: !o,
                })
              : (e[t] = n)
            : (i("next", 0), i("throw", 1), i("return", 2));
        }),
          a(e, t, n, o);
      }
      function l(e, t, n) {
        return (
          (t = (function (e) {
            var t = (function (e, t) {
              if ("object" != u(e) || !e) return e;
              var n = e[Symbol.toPrimitive];
              if (void 0 !== n) {
                var o = n.call(e, t || "default");
                if ("object" != u(o)) return o;
                throw new TypeError(
                  "@@toPrimitive must return a primitive value."
                );
              }
              return ("string" === t ? String : Number)(e);
            })(e, "string");
            return "symbol" == u(t) ? t : t + "";
          })(t)) in e
            ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (e[t] = n),
          e
        );
      }
      function f(e, t, n, o, r, i, u) {
        try {
          var c = e[i](u),
            a = c.value;
        } catch (e) {
          return void n(e);
        }
        c.done ? t(a) : Promise.resolve(a).then(o, r);
      }
      var s = { key: 0, class: "Modal" },
        p = { key: 1, class: "Modal__component" },
        h = {
          __name: "Modal",
          props: { innerClasses: { default: "" } },
          setup: function (e) {
            var t = r(),
              n = (0, o.ref)(null),
              u = (0, o.ref)({ width: !1, height: !1 }),
              a = (0, o.ref)({ width: 0, height: 0 }),
              h = (0, o.computed)(function () {
                if ("component" == t.type)
                  return i.cloneDeep(t.config.component);
              }),
              v = (0, o.computed)(function () {
                return "auto" == t.config.width
                  ? "".concat(a.value.width, "px")
                  : t.config.width || "600px";
              }),
              d = (0, o.computed)(function () {
                return "auto" == t.config.height
                  ? "".concat(a.value.height, "px")
                  : t.config.height || "700px";
              }),
              m = (0, o.computed)(function () {
                return t.config.maxWidth || "90%";
              }),
              y = (0, o.computed)(function () {
                return t.config.maxHeight || "90%";
              });
            function g() {
              t.config.closable && t.close();
            }
            function b() {
              return w.apply(this, arguments);
            }
            function w() {
              var e;
              return (
                (e = c().m(function e() {
                  return c().w(function (e) {
                    for (;;)
                      switch (e.n) {
                        case 0:
                          return (
                            "auto" == t.config.width && (u.value.width = !0),
                            "auto" == t.config.height && (u.value.height = !0),
                            (e.n = 1),
                            (0, o.nextTick)()
                          );
                        case 1:
                          setTimeout(function () {
                            "auto" == t.config.width &&
                              ((a.value.width = n.value.clientHeight + 1),
                              (u.value.width = !1)),
                              "auto" == t.config.height &&
                                ((a.value.height = n.value.clientHeight + 1),
                                (u.value.height = !1));
                          }, 1);
                        case 2:
                          return e.a(2);
                      }
                  }, e);
                })),
                (w = function () {
                  var t = this,
                    n = arguments;
                  return new Promise(function (o, r) {
                    var i = e.apply(t, n);
                    function u(e) {
                      f(i, o, r, u, c, "next", e);
                    }
                    function c(e) {
                      f(i, o, r, u, c, "throw", e);
                    }
                    u(void 0);
                  });
                }),
                w.apply(this, arguments)
              );
            }
            return (
              (0, o.onMounted)(function () {
                $(window).on("resize", function () {
                  t.isOpen.value && b();
                });
              }),
              (0, o.watch)(
                function () {
                  return t.isOpen;
                },
                function (e) {
                  e && b();
                }
              ),
              function (r, i) {
                return (
                  (0, o.openBlock)(),
                  (0, o.createBlock)(
                    o.Transition,
                    { name: "fade" },
                    {
                      default: (0, o.withCtx)(function () {
                        return [
                          (0, o.unref)(t).isOpen
                            ? ((0, o.openBlock)(),
                              (0, o.createElementBlock)("div", s, [
                                (0, o.createElementVNode)("div", {
                                  class: "Modal__overlay",
                                  onClick: (0, o.withModifiers)(g, ["prevent"]),
                                }),
                                (0, o.createElementVNode)(
                                  "div",
                                  {
                                    class: (0, o.normalizeClass)([
                                      "Modal__inner",
                                      l(
                                        {
                                          "Modal__inner--auto-width":
                                            u.value.width,
                                          "Modal__inner--auto-height":
                                            u.value.height,
                                        },
                                        e.innerClasses,
                                        !0
                                      ),
                                    ]),
                                    style: (0, o.normalizeStyle)({
                                      width: v.value,
                                      height: d.value,
                                      maxWidth: m.value,
                                      maxHeight: y.value,
                                    }),
                                    ref_key: "innerElement",
                                    ref: n,
                                  },
                                  [
                                    (0, o.unref)(t).config.closable
                                      ? ((0, o.openBlock)(),
                                        (0, o.createElementBlock)("span", {
                                          key: 0,
                                          class: "Modal__close",
                                          onClick: (0, o.withModifiers)(g, [
                                            "prevent",
                                          ]),
                                        }))
                                      : (0, o.createCommentVNode)("", !0),
                                    "component" == (0, o.unref)(t).type
                                      ? ((0, o.openBlock)(),
                                        (0, o.createElementBlock)("div", p, [
                                          ((0, o.openBlock)(),
                                          (0, o.createBlock)(
                                            (0, o.resolveDynamicComponent)(
                                              h.value
                                            ),
                                            {
                                              props: (0, o.unref)(t).config
                                                .props,
                                              translations:
                                                (0, o.unref)(t).config
                                                  .translations || {},
                                              routes:
                                                (0, o.unref)(t).config.routes ||
                                                {},
                                            },
                                            null,
                                            8,
                                            ["props", "translations", "routes"]
                                          )),
                                        ]))
                                      : (0, o.createCommentVNode)("", !0),
                                  ],
                                  6
                                ),
                              ]))
                            : (0, o.createCommentVNode)("", !0),
                        ];
                      }),
                      _: 1,
                    }
                  )
                );
              }
            );
          },
        };
      var v = h;
    },
  },
]);
