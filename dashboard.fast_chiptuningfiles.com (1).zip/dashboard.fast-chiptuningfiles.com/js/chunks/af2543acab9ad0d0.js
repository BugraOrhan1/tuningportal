/*! For license information please see af2543acab9ad0d0.js.LICENSE.txt */
"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
  [912],
  {
    76912: function (t, e, n) {
      n.r(e),
        n.d(e, {
          default: function () {
            return m;
          },
        });
      var o = n(29726),
        r = n(4967),
        i = (0, n(5615).nY)("dropdown", function () {
          return { submitting: (0, o.ref)(!1) };
        });
      function l(t) {
        return (
          (l =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    "function" == typeof Symbol &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          l(t)
        );
      }
      function c() {
        var t,
          e,
          n = "function" == typeof Symbol ? Symbol : {},
          o = n.iterator || "@@iterator",
          r = n.toStringTag || "@@toStringTag";
        function i(n, o, r, i) {
          var c = o && o.prototype instanceof u ? o : u,
            s = Object.create(c.prototype);
          return (
            a(
              s,
              "_invoke",
              (function (n, o, r) {
                var i,
                  c,
                  a,
                  u = 0,
                  s = r || [],
                  f = !1,
                  d = {
                    p: 0,
                    n: 0,
                    v: t,
                    a: p,
                    f: p.bind(t, 4),
                    d: function (e, n) {
                      return (i = e), (c = 0), (a = t), (d.n = n), l;
                    },
                  };
                function p(n, o) {
                  for (
                    c = n, a = o, e = 0;
                    !f && u && !r && e < s.length;
                    e++
                  ) {
                    var r,
                      i = s[e],
                      p = d.p,
                      m = i[2];
                    n > 3
                      ? (r = m === o) &&
                        ((a = i[(c = i[4]) ? 5 : ((c = 3), 3)]),
                        (i[4] = i[5] = t))
                      : i[0] <= p &&
                        ((r = n < 2 && p < i[1])
                          ? ((c = 0), (d.v = o), (d.n = i[1]))
                          : p < m &&
                            (r = n < 3 || i[0] > o || o > m) &&
                            ((i[4] = n), (i[5] = o), (d.n = m), (c = 0)));
                  }
                  if (r || n > 1) return l;
                  throw ((f = !0), o);
                }
                return function (r, s, m) {
                  if (u > 1) throw TypeError("Generator is already running");
                  for (
                    f && 1 === s && p(s, m), c = s, a = m;
                    (e = c < 2 ? t : a) || !f;

                  ) {
                    i ||
                      (c
                        ? c < 3
                          ? (c > 1 && (d.n = -1), p(c, a))
                          : (d.n = a)
                        : (d.v = a));
                    try {
                      if (((u = 2), i)) {
                        if ((c || (r = "next"), (e = i[r]))) {
                          if (!(e = e.call(i, a)))
                            throw TypeError("iterator result is not an object");
                          if (!e.done) return e;
                          (a = e.value), c < 2 && (c = 0);
                        } else
                          1 === c && (e = i.return) && e.call(i),
                            c < 2 &&
                              ((a = TypeError(
                                "The iterator does not provide a '" +
                                  r +
                                  "' method"
                              )),
                              (c = 1));
                        i = t;
                      } else if ((e = (f = d.n < 0) ? a : n.call(o, d)) !== l)
                        break;
                    } catch (e) {
                      (i = t), (c = 1), (a = e);
                    } finally {
                      u = 1;
                    }
                  }
                  return { value: e, done: f };
                };
              })(n, r, i),
              !0
            ),
            s
          );
        }
        var l = {};
        function u() {}
        function s() {}
        function f() {}
        e = Object.getPrototypeOf;
        var d = [][o]
            ? e(e([][o]()))
            : (a((e = {}), o, function () {
                return this;
              }),
              e),
          p = (f.prototype = u.prototype = Object.create(d));
        function m(t) {
          return (
            Object.setPrototypeOf
              ? Object.setPrototypeOf(t, f)
              : ((t.__proto__ = f), a(t, r, "GeneratorFunction")),
            (t.prototype = Object.create(p)),
            t
          );
        }
        return (
          (s.prototype = f),
          a(p, "constructor", f),
          a(f, "constructor", s),
          (s.displayName = "GeneratorFunction"),
          a(f, r, "GeneratorFunction"),
          a(p),
          a(p, r, "Generator"),
          a(p, o, function () {
            return this;
          }),
          a(p, "toString", function () {
            return "[object Generator]";
          }),
          (c = function () {
            return { w: i, m: m };
          })()
        );
      }
      function a(t, e, n, o) {
        var r = Object.defineProperty;
        try {
          r({}, "", {});
        } catch (t) {
          r = 0;
        }
        (a = function (t, e, n, o) {
          function i(e, n) {
            a(t, e, function (t) {
              return this._invoke(e, n, t);
            });
          }
          e
            ? r
              ? r(t, e, {
                  value: n,
                  enumerable: !o,
                  configurable: !o,
                  writable: !o,
                })
              : (t[e] = n)
            : (i("next", 0), i("throw", 1), i("return", 2));
        }),
          a(t, e, n, o);
      }
      function u(t, e, n) {
        return (
          (e = (function (t) {
            var e = (function (t, e) {
              if ("object" != l(t) || !t) return t;
              var n = t[Symbol.toPrimitive];
              if (void 0 !== n) {
                var o = n.call(t, e || "default");
                if ("object" != l(o)) return o;
                throw new TypeError(
                  "@@toPrimitive must return a primitive value."
                );
              }
              return ("string" === e ? String : Number)(t);
            })(t, "string");
            return "symbol" == l(e) ? e : e + "";
          })(e)) in t
            ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (t[e] = n),
          t
        );
      }
      function s(t, e, n, o, r, i, l) {
        try {
          var c = t[i](l),
            a = c.value;
        } catch (t) {
          return void n(t);
        }
        c.done ? e(a) : Promise.resolve(a).then(o, r);
      }
      function f(t) {
        return function () {
          var e = this,
            n = arguments;
          return new Promise(function (o, r) {
            var i = t.apply(e, n);
            function l(t) {
              s(i, o, r, l, c, "next", t);
            }
            function c(t) {
              s(i, o, r, l, c, "throw", t);
            }
            l(void 0);
          });
        };
      }
      var d = 1,
        p = {
          __name: "Dropdown",
          props: {
            placement: { default: "bottom-end" },
            open: { default: null },
            offset: { default: 24 },
            width: { default: 260 },
            autoWidth: { default: !1 },
            parentClass: { default: "" },
            contentClass: { default: "" },
          },
          emits: ["blur"],
          setup: function (t, e) {
            var n = e.emit,
              l = t,
              a = n,
              s = i(),
              p = (0, o.ref)(null),
              m = (0, o.ref)(null),
              h = (0, o.ref)(!1),
              g = (0, o.ref)(l.width),
              y = (0, o.ref)(0),
              v = (0, o.ref)(0),
              w = d++,
              b = null !== l.open,
              x = (0, o.computed)(function () {
                return b ? l.open : h.value;
              }),
              R = (0, o.computed)(function () {
                return {
                  width: "".concat(g.value, "px"),
                  top: "".concat(v.value, "px"),
                  left: "".concat(y.value, "px"),
                };
              });
            function T() {
              return S.apply(this, arguments);
            }
            function S() {
              return (S = f(
                c().m(function t() {
                  var e, n, o;
                  return c().w(function (t) {
                    for (;;)
                      switch (t.n) {
                        case 0:
                          return (
                            (t.n = 1),
                            (0, r.rD)(p.value, m.value, {
                              placement: l.placement,
                              middleware: [
                                (0, r.cY)(l.offset),
                                (0, r.UU)(),
                                (0, r.BN)(),
                                l.autoWidth
                                  ? (0, r.Ej)({
                                      apply: function (t) {
                                        var e = t.rects;
                                        g.value = e.reference.width;
                                      },
                                    })
                                  : null,
                              ],
                            })
                          );
                        case 1:
                          (e = t.v),
                            (n = e.x),
                            (o = e.y),
                            (y.value = n),
                            (v.value = o);
                        case 2:
                          return t.a(2);
                      }
                  }, t);
                })
              )).apply(this, arguments);
            }
            var E = function () {
              return null;
            };
            function D() {
              return O.apply(this, arguments);
            }
            function O() {
              return (O = f(
                c().m(function t() {
                  return c().w(function (t) {
                    for (;;)
                      switch (t.n) {
                        case 0:
                          return (
                            (h.value = !h.value), (t.n = 1), (0, o.nextTick)()
                          );
                        case 1:
                          x.value && (E = (0, r.ll)(p.value, m.value, T));
                        case 2:
                          return t.a(2);
                      }
                  }, t);
                })
              )).apply(this, arguments);
            }
            function L(t) {
              b || (t.preventDefault(), D());
            }
            function k() {
              return C.apply(this, arguments);
            }
            function C() {
              return (C = f(
                c().m(function t() {
                  return c().w(function (t) {
                    for (;;)
                      switch (t.n) {
                        case 0:
                          return (t.n = 1), (0, o.nextTick)();
                        case 1:
                          $(m.value).plugins();
                        case 2:
                          return t.a(2);
                      }
                  }, t);
                })
              )).apply(this, arguments);
            }
            return (
              (0, o.watch)(
                function () {
                  return x.value;
                },
                function (t) {
                  t || (E(), a("blur"));
                }
              ),
              (0, o.onMounted)(function () {
                (p.value.__vue__ = { toggleDropdown: D }),
                  $(document).on("click.dropdown-".concat(w), function (t) {
                    p.value.contains(t.target) ||
                      m.value.contains(t.target) ||
                      (h.value = !1);
                  }),
                  k(),
                  b &&
                    (0, o.watch)(
                      function () {
                        return l.open;
                      },
                      function () {
                        D();
                      },
                      { immediate: !0 }
                    ),
                  p.value.closest("form") &&
                    p.value.closest("form").addEventListener(
                      "submit",
                      function (t) {
                        (s.submitting = !0),
                          t.target.canSubmit ||
                            ((t.target.canSubmit = !0),
                            setTimeout(function () {
                              t.target.requestSubmit();
                            }, 1),
                            t.preventDefault(),
                            t.stopImmediatePropagation());
                      },
                      !0
                    );
              }),
              (0, o.onBeforeUnmount)(function () {
                $(document).off("click.dropdown-".concat(w)),
                  $(window).off("click.dropdown-".concat(w)),
                  E();
              }),
              function (e, n) {
                return (
                  (0, o.openBlock)(),
                  (0, o.createElementBlock)(
                    o.Fragment,
                    null,
                    [
                      (0, o.createElementVNode)(
                        "div",
                        {
                          class: (0, o.normalizeClass)([
                            "Dropdown",
                            u({ "Dropdown--open": x.value }, t.parentClass, !0),
                          ]),
                          ref_key: "parent",
                          ref: p,
                        },
                        [
                          (0, o.createElementVNode)(
                            "div",
                            { class: "Dropdown__trigger", onClick: L },
                            [(0, o.renderSlot)(e.$slots, "parent")]
                          ),
                        ],
                        2
                      ),
                      ((0, o.openBlock)(),
                      (0, o.createBlock)(
                        o.Teleport,
                        { to: "body", disabled: (0, o.unref)(s).submitting },
                        [
                          (0, o.createElementVNode)(
                            "div",
                            {
                              class: (0, o.normalizeClass)([
                                "Dropdown__content",
                                u(
                                  { "Dropdown__content--open": x.value },
                                  t.contentClass,
                                  !0
                                ),
                              ]),
                              style: (0, o.normalizeStyle)(R.value),
                              ref_key: "content",
                              ref: m,
                            },
                            [
                              (0, o.renderSlot)(e.$slots, "content", {
                                close: D,
                                plugins: k,
                              }),
                            ],
                            6
                          ),
                        ],
                        8,
                        ["disabled"]
                      )),
                    ],
                    64
                  )
                );
              }
            );
          },
        };
      var m = p;
    },
    4967: function (t, e, n) {
      n.d(e, {
        UE: function () {
          return bt;
        },
        ll: function () {
          return ht;
        },
        rD: function () {
          return xt;
        },
        UU: function () {
          return vt;
        },
        cY: function () {
          return gt;
        },
        BN: function () {
          return yt;
        },
        Ej: function () {
          return wt;
        },
      });
      const o = Math.min,
        r = Math.max,
        i = Math.round,
        l = Math.floor,
        c = (t) => ({ x: t, y: t }),
        a = { left: "right", right: "left", bottom: "top", top: "bottom" };
      function u(t, e, n) {
        return r(t, o(e, n));
      }
      function s(t, e) {
        return "function" == typeof t ? t(e) : t;
      }
      function f(t) {
        return t.split("-")[0];
      }
      function d(t) {
        return t.split("-")[1];
      }
      function p(t) {
        return "x" === t ? "y" : "x";
      }
      function m(t) {
        return "y" === t ? "height" : "width";
      }
      function h(t) {
        const e = t[0];
        return "t" === e || "b" === e ? "y" : "x";
      }
      function g(t) {
        return p(h(t));
      }
      function y(t) {
        return t.includes("start")
          ? t.replace("start", "end")
          : t.replace("end", "start");
      }
      const v = ["left", "right"],
        w = ["right", "left"],
        b = ["top", "bottom"],
        x = ["bottom", "top"];
      function R(t, e, n, o) {
        const r = d(t);
        let i = (function (t, e, n) {
          switch (t) {
            case "top":
            case "bottom":
              return n ? (e ? w : v) : e ? v : w;
            case "left":
            case "right":
              return e ? b : x;
            default:
              return [];
          }
        })(f(t), "start" === n, o);
        return (
          r && ((i = i.map((t) => t + "-" + r)), e && (i = i.concat(i.map(y)))),
          i
        );
      }
      function T(t) {
        const e = f(t);
        return a[e] + t.slice(e.length);
      }
      function S(t) {
        return "number" != typeof t
          ? (function (t) {
              return { top: 0, right: 0, bottom: 0, left: 0, ...t };
            })(t)
          : { top: t, right: t, bottom: t, left: t };
      }
      function E(t) {
        const { x: e, y: n, width: o, height: r } = t;
        return {
          width: o,
          height: r,
          top: n,
          left: e,
          right: e + o,
          bottom: n + r,
          x: e,
          y: n,
        };
      }
      function D(t, e, n) {
        let { reference: o, floating: r } = t;
        const i = h(e),
          l = g(e),
          c = m(l),
          a = f(e),
          u = "y" === i,
          s = o.x + o.width / 2 - r.width / 2,
          p = o.y + o.height / 2 - r.height / 2,
          y = o[c] / 2 - r[c] / 2;
        let v;
        switch (a) {
          case "top":
            v = { x: s, y: o.y - r.height };
            break;
          case "bottom":
            v = { x: s, y: o.y + o.height };
            break;
          case "right":
            v = { x: o.x + o.width, y: p };
            break;
          case "left":
            v = { x: o.x - r.width, y: p };
            break;
          default:
            v = { x: o.x, y: o.y };
        }
        switch (d(e)) {
          case "start":
            v[l] -= y * (n && u ? -1 : 1);
            break;
          case "end":
            v[l] += y * (n && u ? -1 : 1);
        }
        return v;
      }
      async function O(t, e) {
        var n;
        void 0 === e && (e = {});
        const {
            x: o,
            y: r,
            platform: i,
            rects: l,
            elements: c,
            strategy: a,
          } = t,
          {
            boundary: u = "clippingAncestors",
            rootBoundary: f = "viewport",
            elementContext: d = "floating",
            altBoundary: p = !1,
            padding: m = 0,
          } = s(e, t),
          h = S(m),
          g = c[p ? ("floating" === d ? "reference" : "floating") : d],
          y = E(
            await i.getClippingRect({
              element:
                null ==
                  (n = await (null == i.isElement ? void 0 : i.isElement(g))) ||
                n
                  ? g
                  : g.contextElement ||
                    (await (null == i.getDocumentElement
                      ? void 0
                      : i.getDocumentElement(c.floating))),
              boundary: u,
              rootBoundary: f,
              strategy: a,
            })
          ),
          v =
            "floating" === d
              ? {
                  x: o,
                  y: r,
                  width: l.floating.width,
                  height: l.floating.height,
                }
              : l.reference,
          w = await (null == i.getOffsetParent
            ? void 0
            : i.getOffsetParent(c.floating)),
          b = ((await (null == i.isElement ? void 0 : i.isElement(w))) &&
            (await (null == i.getScale ? void 0 : i.getScale(w)))) || {
            x: 1,
            y: 1,
          },
          x = E(
            i.convertOffsetParentRelativeRectToViewportRelativeRect
              ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
                  elements: c,
                  rect: v,
                  offsetParent: w,
                  strategy: a,
                })
              : v
          );
        return {
          top: (y.top - x.top + h.top) / b.y,
          bottom: (x.bottom - y.bottom + h.bottom) / b.y,
          left: (y.left - x.left + h.left) / b.x,
          right: (x.right - y.right + h.right) / b.x,
        };
      }
      const L = new Set(["left", "top"]);
      function k() {
        return "undefined" != typeof window;
      }
      function C(t) {
        return _(t) ? (t.nodeName || "").toLowerCase() : "#document";
      }
      function P(t) {
        var e;
        return (
          (null == t || null == (e = t.ownerDocument)
            ? void 0
            : e.defaultView) || window
        );
      }
      function A(t) {
        var e;
        return null ==
          (e = (_(t) ? t.ownerDocument : t.document) || window.document)
          ? void 0
          : e.documentElement;
      }
      function _(t) {
        return !!k() && (t instanceof Node || t instanceof P(t).Node);
      }
      function F(t) {
        return !!k() && (t instanceof Element || t instanceof P(t).Element);
      }
      function j(t) {
        return (
          !!k() && (t instanceof HTMLElement || t instanceof P(t).HTMLElement)
        );
      }
      function B(t) {
        return (
          !(!k() || "undefined" == typeof ShadowRoot) &&
          (t instanceof ShadowRoot || t instanceof P(t).ShadowRoot)
        );
      }
      function W(t) {
        const { overflow: e, overflowX: n, overflowY: o, display: r } = I(t);
        return (
          /auto|scroll|overlay|hidden|clip/.test(e + o + n) &&
          "inline" !== r &&
          "contents" !== r
        );
      }
      function N(t) {
        return /^(table|td|th)$/.test(C(t));
      }
      function H(t) {
        try {
          if (t.matches(":popover-open")) return !0;
        } catch (t) {}
        try {
          return t.matches(":modal");
        } catch (t) {
          return !1;
        }
      }
      const V = /transform|translate|scale|rotate|perspective|filter/,
        M = /paint|layout|strict|content/,
        z = (t) => !!t && "none" !== t;
      let $;
      function G(t) {
        const e = F(t) ? I(t) : t;
        return (
          z(e.transform) ||
          z(e.translate) ||
          z(e.scale) ||
          z(e.rotate) ||
          z(e.perspective) ||
          (!U() && (z(e.backdropFilter) || z(e.filter))) ||
          V.test(e.willChange || "") ||
          M.test(e.contain || "")
        );
      }
      function U() {
        return (
          null == $ &&
            ($ =
              "undefined" != typeof CSS &&
              CSS.supports &&
              CSS.supports("-webkit-backdrop-filter", "none")),
          $
        );
      }
      function Y(t) {
        return /^(html|body|#document)$/.test(C(t));
      }
      function I(t) {
        return P(t).getComputedStyle(t);
      }
      function q(t) {
        return F(t)
          ? { scrollLeft: t.scrollLeft, scrollTop: t.scrollTop }
          : { scrollLeft: t.scrollX, scrollTop: t.scrollY };
      }
      function X(t) {
        if ("html" === C(t)) return t;
        const e = t.assignedSlot || t.parentNode || (B(t) && t.host) || A(t);
        return B(e) ? e.host : e;
      }
      function J(t) {
        const e = X(t);
        return Y(e)
          ? t.ownerDocument
            ? t.ownerDocument.body
            : t.body
          : j(e) && W(e)
          ? e
          : J(e);
      }
      function K(t, e, n) {
        var o;
        void 0 === e && (e = []), void 0 === n && (n = !0);
        const r = J(t),
          i = r === (null == (o = t.ownerDocument) ? void 0 : o.body),
          l = P(r);
        if (i) {
          const t = Q(l);
          return e.concat(
            l,
            l.visualViewport || [],
            W(r) ? r : [],
            t && n ? K(t) : []
          );
        }
        return e.concat(r, K(r, [], n));
      }
      function Q(t) {
        return t.parent && Object.getPrototypeOf(t.parent)
          ? t.frameElement
          : null;
      }
      function Z(t) {
        const e = I(t);
        let n = parseFloat(e.width) || 0,
          o = parseFloat(e.height) || 0;
        const r = j(t),
          l = r ? t.offsetWidth : n,
          c = r ? t.offsetHeight : o,
          a = i(n) !== l || i(o) !== c;
        return a && ((n = l), (o = c)), { width: n, height: o, $: a };
      }
      function tt(t) {
        return F(t) ? t : t.contextElement;
      }
      function et(t) {
        const e = tt(t);
        if (!j(e)) return c(1);
        const n = e.getBoundingClientRect(),
          { width: o, height: r, $: l } = Z(e);
        let a = (l ? i(n.width) : n.width) / o,
          u = (l ? i(n.height) : n.height) / r;
        return (
          (a && Number.isFinite(a)) || (a = 1),
          (u && Number.isFinite(u)) || (u = 1),
          { x: a, y: u }
        );
      }
      const nt = c(0);
      function ot(t) {
        const e = P(t);
        return U() && e.visualViewport
          ? { x: e.visualViewport.offsetLeft, y: e.visualViewport.offsetTop }
          : nt;
      }
      function rt(t, e, n, o) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        const r = t.getBoundingClientRect(),
          i = tt(t);
        let l = c(1);
        e && (o ? F(o) && (l = et(o)) : (l = et(t)));
        const a = (function (t, e, n) {
          return void 0 === e && (e = !1), !(!n || (e && n !== P(t))) && e;
        })(i, n, o)
          ? ot(i)
          : c(0);
        let u = (r.left + a.x) / l.x,
          s = (r.top + a.y) / l.y,
          f = r.width / l.x,
          d = r.height / l.y;
        if (i) {
          const t = P(i),
            e = o && F(o) ? P(o) : o;
          let n = t,
            r = Q(n);
          for (; r && o && e !== n; ) {
            const t = et(r),
              e = r.getBoundingClientRect(),
              o = I(r),
              i = e.left + (r.clientLeft + parseFloat(o.paddingLeft)) * t.x,
              l = e.top + (r.clientTop + parseFloat(o.paddingTop)) * t.y;
            (u *= t.x),
              (s *= t.y),
              (f *= t.x),
              (d *= t.y),
              (u += i),
              (s += l),
              (n = P(r)),
              (r = Q(n));
          }
        }
        return E({ width: f, height: d, x: u, y: s });
      }
      function it(t, e) {
        const n = q(t).scrollLeft;
        return e ? e.left + n : rt(A(t)).left + n;
      }
      function lt(t, e) {
        const n = t.getBoundingClientRect();
        return { x: n.left + e.scrollLeft - it(t, n), y: n.top + e.scrollTop };
      }
      function ct(t, e, n) {
        let o;
        if ("viewport" === e)
          o = (function (t, e) {
            const n = P(t),
              o = A(t),
              r = n.visualViewport;
            let i = o.clientWidth,
              l = o.clientHeight,
              c = 0,
              a = 0;
            if (r) {
              (i = r.width), (l = r.height);
              const t = U();
              (!t || (t && "fixed" === e)) &&
                ((c = r.offsetLeft), (a = r.offsetTop));
            }
            const u = it(o);
            if (u <= 0) {
              const t = o.ownerDocument,
                e = t.body,
                n = getComputedStyle(e),
                r =
                  ("CSS1Compat" === t.compatMode &&
                    parseFloat(n.marginLeft) + parseFloat(n.marginRight)) ||
                  0,
                l = Math.abs(o.clientWidth - e.clientWidth - r);
              l <= 25 && (i -= l);
            } else u <= 25 && (i += u);
            return { width: i, height: l, x: c, y: a };
          })(t, n);
        else if ("document" === e)
          o = (function (t) {
            const e = A(t),
              n = q(t),
              o = t.ownerDocument.body,
              i = r(e.scrollWidth, e.clientWidth, o.scrollWidth, o.clientWidth),
              l = r(
                e.scrollHeight,
                e.clientHeight,
                o.scrollHeight,
                o.clientHeight
              );
            let c = -n.scrollLeft + it(t);
            const a = -n.scrollTop;
            return (
              "rtl" === I(o).direction &&
                (c += r(e.clientWidth, o.clientWidth) - i),
              { width: i, height: l, x: c, y: a }
            );
          })(A(t));
        else if (F(e))
          o = (function (t, e) {
            const n = rt(t, !0, "fixed" === e),
              o = n.top + t.clientTop,
              r = n.left + t.clientLeft,
              i = j(t) ? et(t) : c(1);
            return {
              width: t.clientWidth * i.x,
              height: t.clientHeight * i.y,
              x: r * i.x,
              y: o * i.y,
            };
          })(e, n);
        else {
          const n = ot(t);
          o = { x: e.x - n.x, y: e.y - n.y, width: e.width, height: e.height };
        }
        return E(o);
      }
      function at(t, e) {
        const n = X(t);
        return (
          !(n === e || !F(n) || Y(n)) && ("fixed" === I(n).position || at(n, e))
        );
      }
      function ut(t, e, n) {
        const o = j(e),
          r = A(e),
          i = "fixed" === n,
          l = rt(t, !0, i, e);
        let a = { scrollLeft: 0, scrollTop: 0 };
        const u = c(0);
        function s() {
          u.x = it(r);
        }
        if (o || (!o && !i))
          if ((("body" !== C(e) || W(r)) && (a = q(e)), o)) {
            const t = rt(e, !0, i, e);
            (u.x = t.x + e.clientLeft), (u.y = t.y + e.clientTop);
          } else r && s();
        i && !o && r && s();
        const f = !r || o || i ? c(0) : lt(r, a);
        return {
          x: l.left + a.scrollLeft - u.x - f.x,
          y: l.top + a.scrollTop - u.y - f.y,
          width: l.width,
          height: l.height,
        };
      }
      function st(t) {
        return "static" === I(t).position;
      }
      function ft(t, e) {
        if (!j(t) || "fixed" === I(t).position) return null;
        if (e) return e(t);
        let n = t.offsetParent;
        return A(t) === n && (n = n.ownerDocument.body), n;
      }
      function dt(t, e) {
        const n = P(t);
        if (H(t)) return n;
        if (!j(t)) {
          let e = X(t);
          for (; e && !Y(e); ) {
            if (F(e) && !st(e)) return e;
            e = X(e);
          }
          return n;
        }
        let o = ft(t, e);
        for (; o && N(o) && st(o); ) o = ft(o, e);
        return o && Y(o) && st(o) && !G(o)
          ? n
          : o ||
              (function (t) {
                let e = X(t);
                for (; j(e) && !Y(e); ) {
                  if (G(e)) return e;
                  if (H(e)) return null;
                  e = X(e);
                }
                return null;
              })(t) ||
              n;
      }
      const pt = {
        convertOffsetParentRelativeRectToViewportRelativeRect: function (t) {
          let { elements: e, rect: n, offsetParent: o, strategy: r } = t;
          const i = "fixed" === r,
            l = A(o),
            a = !!e && H(e.floating);
          if (o === l || (a && i)) return n;
          let u = { scrollLeft: 0, scrollTop: 0 },
            s = c(1);
          const f = c(0),
            d = j(o);
          if (
            (d || (!d && !i)) &&
            (("body" !== C(o) || W(l)) && (u = q(o)), d)
          ) {
            const t = rt(o);
            (s = et(o)), (f.x = t.x + o.clientLeft), (f.y = t.y + o.clientTop);
          }
          const p = !l || d || i ? c(0) : lt(l, u);
          return {
            width: n.width * s.x,
            height: n.height * s.y,
            x: n.x * s.x - u.scrollLeft * s.x + f.x + p.x,
            y: n.y * s.y - u.scrollTop * s.y + f.y + p.y,
          };
        },
        getDocumentElement: A,
        getClippingRect: function (t) {
          let { element: e, boundary: n, rootBoundary: i, strategy: l } = t;
          const c = [
              ...("clippingAncestors" === n
                ? H(e)
                  ? []
                  : (function (t, e) {
                      const n = e.get(t);
                      if (n) return n;
                      let o = K(t, [], !1).filter(
                          (t) => F(t) && "body" !== C(t)
                        ),
                        r = null;
                      const i = "fixed" === I(t).position;
                      let l = i ? X(t) : t;
                      for (; F(l) && !Y(l); ) {
                        const e = I(l),
                          n = G(l);
                        n || "fixed" !== e.position || (r = null),
                          (
                            i
                              ? !n && !r
                              : (!n &&
                                  "static" === e.position &&
                                  r &&
                                  ("absolute" === r.position ||
                                    "fixed" === r.position)) ||
                                (W(l) && !n && at(t, l))
                          )
                            ? (o = o.filter((t) => t !== l))
                            : (r = e),
                          (l = X(l));
                      }
                      return e.set(t, o), o;
                    })(e, this._c)
                : [].concat(n)),
              i,
            ],
            a = ct(e, c[0], l);
          let u = a.top,
            s = a.right,
            f = a.bottom,
            d = a.left;
          for (let t = 1; t < c.length; t++) {
            const n = ct(e, c[t], l);
            (u = r(n.top, u)),
              (s = o(n.right, s)),
              (f = o(n.bottom, f)),
              (d = r(n.left, d));
          }
          return { width: s - d, height: f - u, x: d, y: u };
        },
        getOffsetParent: dt,
        getElementRects: async function (t) {
          const e = this.getOffsetParent || dt,
            n = this.getDimensions,
            o = await n(t.floating);
          return {
            reference: ut(t.reference, await e(t.floating), t.strategy),
            floating: { x: 0, y: 0, width: o.width, height: o.height },
          };
        },
        getClientRects: function (t) {
          return Array.from(t.getClientRects());
        },
        getDimensions: function (t) {
          const { width: e, height: n } = Z(t);
          return { width: e, height: n };
        },
        getScale: et,
        isElement: F,
        isRTL: function (t) {
          return "rtl" === I(t).direction;
        },
      };
      function mt(t, e) {
        return (
          t.x === e.x &&
          t.y === e.y &&
          t.width === e.width &&
          t.height === e.height
        );
      }
      function ht(t, e, n, i) {
        void 0 === i && (i = {});
        const {
            ancestorScroll: c = !0,
            ancestorResize: a = !0,
            elementResize: u = "function" == typeof ResizeObserver,
            layoutShift: s = "function" == typeof IntersectionObserver,
            animationFrame: f = !1,
          } = i,
          d = tt(t),
          p = c || a ? [...(d ? K(d) : []), ...(e ? K(e) : [])] : [];
        p.forEach((t) => {
          c && t.addEventListener("scroll", n, { passive: !0 }),
            a && t.addEventListener("resize", n);
        });
        const m =
          d && s
            ? (function (t, e) {
                let n,
                  i = null;
                const c = A(t);
                function a() {
                  var t;
                  clearTimeout(n),
                    null == (t = i) || t.disconnect(),
                    (i = null);
                }
                return (
                  (function u(s, f) {
                    void 0 === s && (s = !1), void 0 === f && (f = 1), a();
                    const d = t.getBoundingClientRect(),
                      { left: p, top: m, width: h, height: g } = d;
                    if ((s || e(), !h || !g)) return;
                    const y = {
                      rootMargin:
                        -l(m) +
                        "px " +
                        -l(c.clientWidth - (p + h)) +
                        "px " +
                        -l(c.clientHeight - (m + g)) +
                        "px " +
                        -l(p) +
                        "px",
                      threshold: r(0, o(1, f)) || 1,
                    };
                    let v = !0;
                    function w(e) {
                      const o = e[0].intersectionRatio;
                      if (o !== f) {
                        if (!v) return u();
                        o
                          ? u(!1, o)
                          : (n = setTimeout(() => {
                              u(!1, 1e-7);
                            }, 1e3));
                      }
                      1 !== o || mt(d, t.getBoundingClientRect()) || u(),
                        (v = !1);
                    }
                    try {
                      i = new IntersectionObserver(w, {
                        ...y,
                        root: c.ownerDocument,
                      });
                    } catch (t) {
                      i = new IntersectionObserver(w, y);
                    }
                    i.observe(t);
                  })(!0),
                  a
                );
              })(d, n)
            : null;
        let h,
          g = -1,
          y = null;
        u &&
          ((y = new ResizeObserver((t) => {
            let [o] = t;
            o &&
              o.target === d &&
              y &&
              e &&
              (y.unobserve(e),
              cancelAnimationFrame(g),
              (g = requestAnimationFrame(() => {
                var t;
                null == (t = y) || t.observe(e);
              }))),
              n();
          })),
          d && !f && y.observe(d),
          e && y.observe(e));
        let v = f ? rt(t) : null;
        return (
          f &&
            (function e() {
              const o = rt(t);
              v && !mt(v, o) && n();
              (v = o), (h = requestAnimationFrame(e));
            })(),
          n(),
          () => {
            var t;
            p.forEach((t) => {
              c && t.removeEventListener("scroll", n),
                a && t.removeEventListener("resize", n);
            }),
              null == m || m(),
              null == (t = y) || t.disconnect(),
              (y = null),
              f && cancelAnimationFrame(h);
          }
        );
      }
      const gt = function (t) {
          return (
            void 0 === t && (t = 0),
            {
              name: "offset",
              options: t,
              async fn(e) {
                var n, o;
                const { x: r, y: i, placement: l, middlewareData: c } = e,
                  a = await (async function (t, e) {
                    const { placement: n, platform: o, elements: r } = t,
                      i = await (null == o.isRTL
                        ? void 0
                        : o.isRTL(r.floating)),
                      l = f(n),
                      c = d(n),
                      a = "y" === h(n),
                      u = L.has(l) ? -1 : 1,
                      p = i && a ? -1 : 1,
                      m = s(e, t);
                    let {
                      mainAxis: g,
                      crossAxis: y,
                      alignmentAxis: v,
                    } = "number" == typeof m
                      ? { mainAxis: m, crossAxis: 0, alignmentAxis: null }
                      : {
                          mainAxis: m.mainAxis || 0,
                          crossAxis: m.crossAxis || 0,
                          alignmentAxis: m.alignmentAxis,
                        };
                    return (
                      c &&
                        "number" == typeof v &&
                        (y = "end" === c ? -1 * v : v),
                      a ? { x: y * p, y: g * u } : { x: g * u, y: y * p }
                    );
                  })(e, t);
                return l === (null == (n = c.offset) ? void 0 : n.placement) &&
                  null != (o = c.arrow) &&
                  o.alignmentOffset
                  ? {}
                  : { x: r + a.x, y: i + a.y, data: { ...a, placement: l } };
              },
            }
          );
        },
        yt = function (t) {
          return (
            void 0 === t && (t = {}),
            {
              name: "shift",
              options: t,
              async fn(e) {
                const { x: n, y: o, placement: r, platform: i } = e,
                  {
                    mainAxis: l = !0,
                    crossAxis: c = !1,
                    limiter: a = {
                      fn: (t) => {
                        let { x: e, y: n } = t;
                        return { x: e, y: n };
                      },
                    },
                    ...d
                  } = s(t, e),
                  m = { x: n, y: o },
                  g = await i.detectOverflow(e, d),
                  y = h(f(r)),
                  v = p(y);
                let w = m[v],
                  b = m[y];
                if (l) {
                  const t = "y" === v ? "bottom" : "right";
                  w = u(w + g["y" === v ? "top" : "left"], w, w - g[t]);
                }
                if (c) {
                  const t = "y" === y ? "bottom" : "right";
                  b = u(b + g["y" === y ? "top" : "left"], b, b - g[t]);
                }
                const x = a.fn({ ...e, [v]: w, [y]: b });
                return {
                  ...x,
                  data: { x: x.x - n, y: x.y - o, enabled: { [v]: l, [y]: c } },
                };
              },
            }
          );
        },
        vt = function (t) {
          return (
            void 0 === t && (t = {}),
            {
              name: "flip",
              options: t,
              async fn(e) {
                var n, o;
                const {
                    placement: r,
                    middlewareData: i,
                    rects: l,
                    initialPlacement: c,
                    platform: a,
                    elements: u,
                  } = e,
                  {
                    mainAxis: p = !0,
                    crossAxis: v = !0,
                    fallbackPlacements: w,
                    fallbackStrategy: b = "bestFit",
                    fallbackAxisSideDirection: x = "none",
                    flipAlignment: S = !0,
                    ...E
                  } = s(t, e);
                if (null != (n = i.arrow) && n.alignmentOffset) return {};
                const D = f(r),
                  O = h(c),
                  L = f(c) === c,
                  k = await (null == a.isRTL ? void 0 : a.isRTL(u.floating)),
                  C =
                    w ||
                    (L || !S
                      ? [T(c)]
                      : (function (t) {
                          const e = T(t);
                          return [y(t), e, y(e)];
                        })(c)),
                  P = "none" !== x;
                !w && P && C.push(...R(c, S, x, k));
                const A = [c, ...C],
                  _ = await a.detectOverflow(e, E),
                  F = [];
                let j = (null == (o = i.flip) ? void 0 : o.overflows) || [];
                if ((p && F.push(_[D]), v)) {
                  const t = (function (t, e, n) {
                    void 0 === n && (n = !1);
                    const o = d(t),
                      r = g(t),
                      i = m(r);
                    let l =
                      "x" === r
                        ? o === (n ? "end" : "start")
                          ? "right"
                          : "left"
                        : "start" === o
                        ? "bottom"
                        : "top";
                    return (
                      e.reference[i] > e.floating[i] && (l = T(l)), [l, T(l)]
                    );
                  })(r, l, k);
                  F.push(_[t[0]], _[t[1]]);
                }
                if (
                  ((j = [...j, { placement: r, overflows: F }]),
                  !F.every((t) => t <= 0))
                ) {
                  var B, W;
                  const t =
                      ((null == (B = i.flip) ? void 0 : B.index) || 0) + 1,
                    e = A[t];
                  if (e) {
                    if (
                      !("alignment" === v && O !== h(e)) ||
                      j.every((t) => h(t.placement) !== O || t.overflows[0] > 0)
                    )
                      return {
                        data: { index: t, overflows: j },
                        reset: { placement: e },
                      };
                  }
                  let n =
                    null ==
                    (W = j
                      .filter((t) => t.overflows[0] <= 0)
                      .sort((t, e) => t.overflows[1] - e.overflows[1])[0])
                      ? void 0
                      : W.placement;
                  if (!n)
                    switch (b) {
                      case "bestFit": {
                        var N;
                        const t =
                          null ==
                          (N = j
                            .filter((t) => {
                              if (P) {
                                const e = h(t.placement);
                                return e === O || "y" === e;
                              }
                              return !0;
                            })
                            .map((t) => [
                              t.placement,
                              t.overflows
                                .filter((t) => t > 0)
                                .reduce((t, e) => t + e, 0),
                            ])
                            .sort((t, e) => t[1] - e[1])[0])
                            ? void 0
                            : N[0];
                        t && (n = t);
                        break;
                      }
                      case "initialPlacement":
                        n = c;
                    }
                  if (r !== n) return { reset: { placement: n } };
                }
                return {};
              },
            }
          );
        },
        wt = function (t) {
          return (
            void 0 === t && (t = {}),
            {
              name: "size",
              options: t,
              async fn(e) {
                var n, i;
                const { placement: l, rects: c, platform: a, elements: u } = e,
                  { apply: p = () => {}, ...m } = s(t, e),
                  g = await a.detectOverflow(e, m),
                  y = f(l),
                  v = d(l),
                  w = "y" === h(l),
                  { width: b, height: x } = c.floating;
                let R, T;
                "top" === y || "bottom" === y
                  ? ((R = y),
                    (T =
                      v ===
                      ((await (null == a.isRTL ? void 0 : a.isRTL(u.floating)))
                        ? "start"
                        : "end")
                        ? "left"
                        : "right"))
                  : ((T = y), (R = "end" === v ? "top" : "bottom"));
                const S = x - g.top - g.bottom,
                  E = b - g.left - g.right,
                  D = o(x - g[R], S),
                  O = o(b - g[T], E),
                  L = !e.middlewareData.shift;
                let k = D,
                  C = O;
                if (
                  (null != (n = e.middlewareData.shift) &&
                    n.enabled.x &&
                    (C = E),
                  null != (i = e.middlewareData.shift) &&
                    i.enabled.y &&
                    (k = S),
                  L && !v)
                ) {
                  const t = r(g.left, 0),
                    e = r(g.right, 0),
                    n = r(g.top, 0),
                    o = r(g.bottom, 0);
                  w
                    ? (C =
                        b -
                        2 * (0 !== t || 0 !== e ? t + e : r(g.left, g.right)))
                    : (k =
                        x -
                        2 * (0 !== n || 0 !== o ? n + o : r(g.top, g.bottom)));
                }
                await p({ ...e, availableWidth: C, availableHeight: k });
                const P = await a.getDimensions(u.floating);
                return b !== P.width || x !== P.height
                  ? { reset: { rects: !0 } }
                  : {};
              },
            }
          );
        },
        bt =
          881 == n.j
            ? (t) => ({
                name: "arrow",
                options: t,
                async fn(e) {
                  const {
                      x: n,
                      y: r,
                      placement: i,
                      rects: l,
                      platform: c,
                      elements: a,
                      middlewareData: f,
                    } = e,
                    { element: p, padding: h = 0 } = s(t, e) || {};
                  if (null == p) return {};
                  const y = S(h),
                    v = { x: n, y: r },
                    w = g(i),
                    b = m(w),
                    x = await c.getDimensions(p),
                    R = "y" === w,
                    T = R ? "top" : "left",
                    E = R ? "bottom" : "right",
                    D = R ? "clientHeight" : "clientWidth",
                    O = l.reference[b] + l.reference[w] - v[w] - l.floating[b],
                    L = v[w] - l.reference[w],
                    k = await (null == c.getOffsetParent
                      ? void 0
                      : c.getOffsetParent(p));
                  let C = k ? k[D] : 0;
                  (C &&
                    (await (null == c.isElement ? void 0 : c.isElement(k)))) ||
                    (C = a.floating[D] || l.floating[b]);
                  const P = O / 2 - L / 2,
                    A = C / 2 - x[b] / 2 - 1,
                    _ = o(y[T], A),
                    F = o(y[E], A),
                    j = _,
                    B = C - x[b] - F,
                    W = C / 2 - x[b] / 2 + P,
                    N = u(j, W, B),
                    H =
                      !f.arrow &&
                      null != d(i) &&
                      W !== N &&
                      l.reference[b] / 2 - (W < j ? _ : F) - x[b] / 2 < 0,
                    V = H ? (W < j ? W - j : W - B) : 0;
                  return {
                    [w]: v[w] + V,
                    data: {
                      [w]: N,
                      centerOffset: W - N - V,
                      ...(H && { alignmentOffset: V }),
                    },
                    reset: H,
                  };
                },
              })
            : null,
        xt = (t, e, n) => {
          const o = new Map(),
            r = { platform: pt, ...n },
            i = { ...r.platform, _c: o };
          return (async (t, e, n) => {
            const {
                placement: o = "bottom",
                strategy: r = "absolute",
                middleware: i = [],
                platform: l,
              } = n,
              c = l.detectOverflow ? l : { ...l, detectOverflow: O },
              a = await (null == l.isRTL ? void 0 : l.isRTL(e));
            let u = await l.getElementRects({
                reference: t,
                floating: e,
                strategy: r,
              }),
              { x: s, y: f } = D(u, o, a),
              d = o,
              p = 0;
            const m = {};
            for (let n = 0; n < i.length; n++) {
              const h = i[n];
              if (!h) continue;
              const { name: g, fn: y } = h,
                {
                  x: v,
                  y: w,
                  data: b,
                  reset: x,
                } = await y({
                  x: s,
                  y: f,
                  initialPlacement: o,
                  placement: d,
                  strategy: r,
                  middlewareData: m,
                  rects: u,
                  platform: c,
                  elements: { reference: t, floating: e },
                });
              (s = null != v ? v : s),
                (f = null != w ? w : f),
                (m[g] = { ...m[g], ...b }),
                x &&
                  p < 50 &&
                  (p++,
                  "object" == typeof x &&
                    (x.placement && (d = x.placement),
                    x.rects &&
                      (u =
                        !0 === x.rects
                          ? await l.getElementRects({
                              reference: t,
                              floating: e,
                              strategy: r,
                            })
                          : x.rects),
                    ({ x: s, y: f } = D(u, d, a))),
                  (n = -1));
            }
            return { x: s, y: f, placement: d, strategy: r, middlewareData: m };
          })(t, e, { ...r, platform: i });
        };
    },
  },
]);
