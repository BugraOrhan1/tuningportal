"use strict";
(self.webpackChunk = self.webpackChunk || []).push([
  [312],
  {
    99965: function (e, n, u) {
      u.d(n, {
        J: function () {
          return a;
        },
      });
      var t = u(5615),
        s = u(29726),
        a = (0, t.nY)("messages", function () {
          var e,
            n,
            u = (0, s.ref)(null),
            t = (0, s.ref)(!1),
            a = (0, s.ref)([]);
          function r(s) {
            clearTimeout(e),
              clearTimeout(n),
              (u.value = s),
              (t.value = !1),
              (e = setTimeout(function () {
                (t.value = !0),
                  "success" === u.value.type && (n = setTimeout(o, 5e3));
              }, 100));
          }
          function o() {
            clearTimeout(n), (t.value = !1);
          }
          return {
            message: u,
            messageDuration: 5e3,
            open: t,
            queue: a,
            display: r,
            close: o,
            popQueue: function () {
              var e = a.value.shift();
              e && r(e);
            },
            clearQueue: function () {
              clearTimeout(e),
                clearTimeout(n),
                (u.value = null),
                (t.value = !1),
                (a.value = []);
            },
          };
        });
    },
    19312: function (e, n, u) {
      u.r(n),
        u.d(n, {
          default: function () {
            return r;
          },
        });
      var t = u(29726),
        s = u(99965),
        a = {
          __name: "Message",
          props: ["current", "x"],
          setup: function (e) {
            var n = e,
              u = (0, s.J)();
            return (
              (0, t.onMounted)(function () {
                n.current && u.display(n.current);
              }),
              function (n, s) {
                return (0, t.unref)(u).message
                  ? ((0, t.openBlock)(),
                    (0, t.createElementBlock)(
                      "div",
                      {
                        key: 0,
                        class: (0, t.normalizeClass)([
                          "Message",
                          [
                            (0, t.unref)(u).open ? "Message--open" : null,
                            "Message--".concat((0, t.unref)(u).message.type),
                          ],
                        ]),
                      },
                      [
                        (0, t.createElementVNode)("div", null, [
                          (0, t.createTextVNode)(
                            (0, t.toDisplayString)(
                              (0, t.unref)(u).message.message
                            ) + " ",
                            1
                          ),
                          (0, t.createElementVNode)(
                            "a",
                            {
                              onClick:
                                s[0] ||
                                (s[0] = (0, t.withModifiers)(
                                  function () {
                                    var e;
                                    return (
                                      (0, t.unref)(u).close &&
                                      (e = (0, t.unref)(u)).close.apply(
                                        e,
                                        arguments
                                      )
                                    );
                                  },
                                  ["prevent"]
                                )),
                            },
                            (0, t.toDisplayString)(e.x),
                            1
                          ),
                          (0, t.unref)(u).open &&
                          "success" === (0, t.unref)(u).message.type
                            ? ((0, t.openBlock)(),
                              (0, t.createElementBlock)(
                                "span",
                                {
                                  key: 0,
                                  class: "Message__progress",
                                  style: (0, t.normalizeStyle)({
                                    "--message-duration": "".concat(
                                      (0, t.unref)(u).messageDuration,
                                      "ms"
                                    ),
                                  }),
                                },
                                null,
                                4
                              ))
                            : (0, t.createCommentVNode)("", !0),
                        ]),
                      ],
                      2
                    ))
                  : (0, t.createCommentVNode)("", !0);
              }
            );
          },
        };
      var r = a;
    },
  },
]);
